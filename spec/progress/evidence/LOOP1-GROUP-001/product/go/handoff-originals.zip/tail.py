"""Explicit post-Recorder-closure CLI capture, not a resumed Recorder run."""
import sys
from driver import capture
raise SystemExit(capture(sys.argv[1],sys.argv[2:]))
