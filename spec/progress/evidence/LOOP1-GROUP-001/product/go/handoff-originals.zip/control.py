import os,sys
from pg_run import command
env={k:v for k,v in os.environ.items() if not k.upper().startswith('PG') and k.upper() not in ['DATABASE_URL','DB_TEST_ENABLE','NATS_URL']}
env['PYTHONDONTWRITEBYTECODE']='1'
mode=sys.argv[1]
if mode not in ['Development','Acceptance']:raise RuntimeError('explicit existing Control mode required')
sys.exit(command('control-'+mode,['pwsh','-NoProfile','-File','tools/verify-loop1-ctrl-002.ps1','-Mode',mode],env,check=False).returncode)
