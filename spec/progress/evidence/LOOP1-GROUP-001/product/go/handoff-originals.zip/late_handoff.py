import collections,hashlib,json,pathlib,zipfile
from pg_run import OUT,ROOT

dest=ROOT/'spec/progress/evidence/LOOP1-GROUP-001/product/go'
run='R-GROUP-PRODUCT-R2-GO-20261020'
events=[json.loads(s)for p in (OUT/'research').rglob('*.jsonl')for s in p.read_text().splitlines()if s]
events=[e for e in events if e.get('run_id')==run]
starts=[e['data']['command_id']for e in events if e['event_type']=='command_started']
finishes=[e['data']['command_id']for e in events if e['event_type']=='command_finished']
if len(starts)!=67 or len(finishes)!=67 or len(set(starts))!=67 or set(starts)!=set(finishes):raise RuntimeError('actual Recorder command pairing differs')
finish=json.loads((OUT/'captures/finish.stdout').read_text());validation=json.loads((OUT/'captures/validate.stdout').read_text())
if finish['result']!='FAIL' or validation['status']!='finished':raise RuntimeError('actual honest Recorder closure differs')
source=json.loads((OUT/'source-commit-state.json').read_text())
summary=json.loads((OUT/'verification-summary.json').read_text())
data={'scope':'LOCAL_FIRST_GO_HANDOFF_NOT_PRODUCT_ACCEPTANCE','task':'LOOP1-GROUP-001','owner':'/root/group_product_impl_r2','source_commit':source['head'],'source_parent':source['parent'],'source_tree':source['tree'],'branch':source['branch'],'accepted_main_lkg':'79d39dcbd045597ccc5abd459edd388eed269254','product_main_sync':'NOT_STARTED','source_clean_recovery':json.loads((OUT/'captures/clean-committed-acceptance-source.json').read_text()),'source_state':source,'go_results':summary['go_results'],'new_group_main_methods':[name for name in summary['go_results'][0]['group_main_methods']if name!='TestGroup500SingleLogicalMessageAndOutbox'],'source':summary['source'],'recorder':{'run_id':run,'capture':'prospective_partial','finish':finish,'direct_validation':validation,'finish_exit_code':json.loads((OUT/'captures/finish.json').read_text())['exit_code'],'validate_exit_code':json.loads((OUT/'captures/validate.json').read_text())['exit_code'],'event_types':dict(collections.Counter(e['event_type']for e in events)),'command_started':len(starts),'command_finished':len(finishes),'unmatched':0,'recorded_command_failures':sum(e['event_type']=='command_finished' and e['data']['exit_code']!=0 for e in events),'trace_edited':False,'postclosure_tail':'One handoff metadata/evidence commit, final Control and sealed external receipt captured as explicit tail, not appended to the closed run'},'generated_cache':json.loads((OUT/'generated-cache-cleanup.json').read_text()),'final_prestage_proof_sha256':hashlib.sha256((OUT/'final-prestage-scope-proof.json').read_bytes()).hexdigest(),'metadata_development':json.loads((OUT/'captures/final-metadata-development.json').read_text()),'pending_product_acceptance':['All real Web/installed Windows Tauri/Android emulator G01..G09','Architect screenshot assessment','Fresh regular then different fresh error review on final product SHA','Exact-head required hosted CI','Protected integration/actual-main and safe main synchronization'],'next_exact_action':'Root verifies final external sealed receipt actual HEAD/one source+one metadata ancestry/all changed paths/19042 protected files and writer release, then serially grants client source/runtime phase. Task active/group_product, S2 OPEN.','final_head_control_receipt':'External final-receipt.json produced after metadata commit/final clean Control; no recursive metadata commit'}
data['source_state']={k:v for k,v in source.items()if k!='commands'}
data['source_state_original']={'entry':'source-commit-state.json','sha256':hashlib.sha256((OUT/'source-commit-state.json').read_bytes()).hexdigest(),'note':'Complete original includes every raw Git command output; loose handoff omits duplicate command bodies.'}
(dest/'handoff.json').write_bytes((json.dumps(data,ensure_ascii=False,indent=2)+'\n').encode())

old=json.loads((dest/'package-manifest.json').read_text())
original={r['entry']:r['sha256']for r in old['entries']}
files=[]
for folder in ['research','captures','runtime-captures']:
    files += [p for p in (OUT/folder).rglob('*')if p.is_file()]
files += [p for p in OUT.iterdir()if p.is_file()and p.suffix in ['.py','.json','.txt','.diff','.pyc']]
selected=[]
for p in sorted(set(files),key=lambda p:p.relative_to(OUT).as_posix()):
    raw=p.read_bytes();name=p.relative_to(OUT).as_posix();digest=hashlib.sha256(raw).hexdigest()
    if original.get(name)==digest:continue
    selected.append((name,digest,raw))
archive=dest/'handoff-originals.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    for name,digest,raw in selected:z.writestr(name,raw)
with zipfile.ZipFile(archive)as z:
    if set(z.namelist())!={name for name,_,_ in selected}:raise RuntimeError('late inventory differs')
    for name,digest,raw in selected:
        if hashlib.sha256(z.read(name)).hexdigest()!=digest:raise RuntimeError('late original hash differs')
manifest={'scope':'Additional original bytes not already identical in local-originals.zip; complete closed research and explicit postclosure CLI captures through handoff packaging. Final metadata commit/clean Control/sealed receipt stay external for root next-client archival.','archive':'handoff-originals.zip','archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_bytes':archive.stat().st_size,'handoff_json_sha256':hashlib.sha256((dest/'handoff.json').read_bytes()).hexdigest(),'entries':[{'entry':name,'sha256':digest,'bytes':len(raw)}for name,digest,raw in selected]}
(dest/'handoff-manifest.json').write_bytes((json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode())
print(json.dumps({'source_commit':source['head'],'new_group_main_methods':len(data['new_group_main_methods']),'recorder_counts':data['recorder'],'handoff_sha256':manifest['handoff_json_sha256'],'late_entries':len(selected),'late_zip_sha256':manifest['archive_sha256']},indent=2))
