import hashlib,json,pathlib,subprocess,sys
from pg_run import OUT,ROOT,save

label=sys.argv[1]
if not label.replace('-','').isalnum():raise RuntimeError('invalid receipt label')
commands=[]
def git(*args):
    r=subprocess.run(['git',*args],cwd=ROOT,capture_output=True)
    commands.append({'argv':['git',*args],'exit_code':r.returncode,'stdout':r.stdout.decode(),'stderr':r.stderr.decode()})
    if r.returncode:raise RuntimeError('git failure; '+r.stderr.decode())
    return r.stdout.decode().strip()
base=json.loads((OUT.parent/'product-r2-phase1-before-coordinator.json').read_text())
allowed={'backend/go/core/http.go','backend/go/core/social.go','spec/progress/current.md','spec/tasks/active/LOOP1-GROUP-001.md'}
unchanged=0
for name,old in base['files'].items():
    if name in allowed:continue
    if hashlib.sha256((ROOT/name).read_bytes()).hexdigest()!=old['sha256']:raise RuntimeError('protected bytes changed: '+name)
    unchanged+=1
entries={s.split('\t',1)[1]:s for s in git('ls-files','--stage').splitlines()}
flags={s[2:]:s for s in git('ls-files','-v').splitlines()}
for old in base['index_entries']:
    if old and old.split('\t',1)[1] not in allowed and entries.get(old.split('\t',1)[1])!=old:raise RuntimeError('protected index entry changed')
for old in base['index_flags']:
    if old and old[2:] not in allowed and flags.get(old[2:])!=old:raise RuntimeError('protected index flag changed')
summary=json.loads((OUT/'verification-summary.json').read_text())
for source in summary['source']:
    if hashlib.sha256((ROOT/source['path']).read_bytes()).hexdigest()!=source['sha256']:raise RuntimeError('tested Go source changed')
status=git('status','--porcelain=v1','--untracked-files=all')
if status:raise RuntimeError('not clean: '+status)
result={'result':'CLEAN_LOCAL_GO_SOURCE_CHECKPOINT_ONLY','root':git('rev-parse','--show-toplevel'),'head':git('rev-parse','HEAD'),'parent':git('rev-parse','HEAD^'),'tree':git('rev-parse','HEAD^{tree}'),'branch':git('branch','--show-current'),'status':status,'protected_old_raw_files':unchanged,'protected_index_entries_unchanged':True,'protected_index_flags_unchanged':True,'tested_source':summary['source'],'changed_paths_from_accepted79':git('diff','--name-status','79d39dcbd045597ccc5abd459edd388eed269254','HEAD').splitlines(),'ci_cache_absent':not (ROOT/'ci/__pycache__').exists(),'commands':commands}
save(label+'.json',result);print(json.dumps({k:v for k,v in result.items() if k!='commands'},indent=2))
