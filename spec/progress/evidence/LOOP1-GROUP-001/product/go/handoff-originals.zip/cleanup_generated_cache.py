import hashlib,json,pathlib,struct,subprocess,os
from pg_run import OUT,ROOT,save

observed=json.loads((OUT/'generated-cache-observation.json').read_text())
provenance=json.loads((OUT/'generated-cache-provenance.json').read_text())
cache=(ROOT/'ci/__pycache__/check_s2_planning.cpython-313.pyc').resolve()
expected=(ROOT/'ci/__pycache__').resolve()
if cache.parent!=expected or observed['baseline_cache_entries'] or set(p.name for p in expected.iterdir())!={cache.name}:raise RuntimeError('cache ownership/location/inventory is not exact')
raw=cache.read_bytes();src=ROOT/'ci/check_s2_planning.py'
compiler=pathlib.Path('C:/Users/21441/AppData/Local/Microsoft/WindowsApps/PythonSoftwareFoundation.Python.3.13_qbz5n2kfra8p0/python3.exe')
code="import sys,json,marshal,importlib.util,pathlib; p=pathlib.Path(sys.argv[1]);src=pathlib.Path(sys.argv[2]);raw=p.read_bytes();code=marshal.loads(raw[16:]);print(json.dumps(dict(version=sys.version,magic=importlib.util.MAGIC_NUMBER.hex(),cache_magic=raw[:4].hex(),code_filename=code.co_filename,code_matches_source=code==compile(src.read_bytes(),code.co_filename,'exec',dont_inherit=True))))"
env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1'
check=subprocess.run([str(compiler),'-B','-c',code,str(cache),str(src)],capture_output=True,env=env)
if check.returncode:raise RuntimeError('qualified cache compiler failed: '+check.stderr.decode())
compiler_result=json.loads(check.stdout)
save('generated-cache-qualified-compiler.json',{'argv':[str(compiler),'-B','-c',code,str(cache),str(src)],'exit_code':check.returncode,'result':compiler_result})
if compiler_result['magic']!=compiler_result['cache_magic'] or not compiler_result['code_matches_source']:raise RuntimeError('same-version code object does not match actual unchanged source')
if hashlib.sha256(raw).hexdigest()!=provenance['cache_sha256'] or struct.unpack('<4I',raw[:16])[2:]!=(int(src.stat().st_mtime),src.stat().st_size):raise RuntimeError('observed bytecode/source metadata changed')
end=(OUT/'captures/post-metadata-development.json').stat().st_mtime
duration=observed['post_metadata_development']['elapsed_seconds']
if not end-duration-1<=cache.stat().st_ctime<=end:raise RuntimeError('cache creation not within owned Control interval')
# The real nested Frozen launcher invokes the verifier without -B, which imports
# check_s2_planning; post-metadata Control did not set PYTHONDONTWRITEBYTECODE.
launcher=(ROOT/'tools/verify-frozen-architecture.ps1').read_text()
if '& $python @prefix @arguments' not in launcher:raise RuntimeError('observed nested no-B producer changed')
(OUT/'generated-cache-original.pyc').write_bytes(raw)
cache.unlink()             # One qualified generated file; no recursive deletion.
expected.rmdir()           # Succeeds only when the observed own directory is empty.
result={'result':'OWN_GENERATED_CACHE_REMOVED','cache_path':str(cache),'cache_sha256':hashlib.sha256(raw).hexdigest(),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'source_header_matches':True,'same_version_compiler_result':compiler_result,'initial_marshal_and_code_comparison':False,'initial_comparison_note':'primary runtime Python3.12 compared Python3.13 cache; raw false observations retained, qualified existing Control Python3.13 gives equal code object','baseline_absent':True,'created_within_owned_post_metadata_Control_interval':True,'producer':'post-metadata Development -> existing verify-frozen-architecture.ps1 no-B verifier -> importlib planning import','cache_file_absent':not cache.exists(),'empty_cache_dir_removed':not expected.exists()}
save('generated-cache-cleanup.json',result);print(json.dumps(result,indent=2))
