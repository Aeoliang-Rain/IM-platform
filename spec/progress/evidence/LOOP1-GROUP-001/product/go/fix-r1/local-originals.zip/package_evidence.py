import hashlib,json,pathlib,subprocess,sys,zipfile
O=pathlib.Path(__file__).parent;R=pathlib.Path('H:/.codex/worktrees/group/IM-platform');E=R/'spec/progress/evidence/LOOP1-GROUP-001/product/go/fix-r1'
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
assert subprocess.check_output(['git','rev-parse','--show-toplevel'],cwd=R).decode().strip()=='H:/.codex/worktrees/group/IM-platform'
closure=json.loads((O/'recorder-closure.json').read_text());assert closure['finish_result']=='FAIL' and closure['finish_cli_exit']==0 and closure['direct_structural_validate_exit']==0 and len(closure['unmatched_command_ids'])==1
p=E/'local-verification.json';v=json.loads(p.read_text());v['research']=closure;save(p,v)
p=R/'spec/tasks/active/LOOP1-GROUP-001.md';s=p.read_text();s=s.replace('Recorder is prospective_resume/partial and must honestly finish FAIL; launch WinError5 leaves one unmatched command start, no trace edits or fabricated finish.','Recorder prospective_resume/partial actually finished FAIL (finish CLI0), direct structural validate0;95events/45starts/44finishes/one unmatched rg launch. No trace edits or fabricated finish. Packaging/commit/clean Control/sealing are explicit postclosure tail.');p.write_text(s,encoding='utf-8',newline='\n')
p=E/'report.md';s=p.read_text();s+='\nRecorder actual closure: finish FAIL, CLI0; direct structural validation0,95 events/45 starts/44 finishes/one unmatched rg start. Structural validity is not full trace capture or acceptance.\n';p.write_text(s,encoding='utf-8',newline='\n')
excluded={'go-cache','go-tmp','__pycache__'}
paths=[p for p in O.rglob('*') if p.is_file() and not any(x in excluded for x in p.relative_to(O).parts) and p.name not in {'local-originals.zip','original-bindings.json'}]
entries=[]
archive=O/'local-originals.zip'
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(paths):
  b=p.read_bytes();name=p.relative_to(O).as_posix();z.writestr(name,b);entries.append({'path':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(entries)
 for e in entries:
  b=z.read(e['path']);assert len(b)==e['bytes'] and hashlib.sha256(b).hexdigest()==e['sha256']
manifest={'scope':'Only this fresh fix run originals through Recorder closure; final commit/clean committed Control/sealing are explicitly separate external tail in final-receipt.json. No old sealed archive duplicated.','archive':{'filename':'local-originals.zip','bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},'entries':entries};save(O/'original-bindings.json',manifest)
(E/'local-originals.zip').write_bytes(archive.read_bytes());(E/'original-bindings.json').write_bytes((O/'original-bindings.json').read_bytes());assert hashlib.sha256((E/'local-originals.zip').read_bytes()).hexdigest()==manifest['archive']['sha256'];print(json.dumps({'archive_entries':len(entries),'archive_bytes':archive.stat().st_size,'archive_sha256':manifest['archive']['sha256'],'recorder_finish':'FAIL','structural_validate':0,'unmatched':1}))