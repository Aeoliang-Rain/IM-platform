import hashlib,json,os,pathlib,subprocess,sys,time
O=pathlib.Path(__file__).parent; B=O.parent; R=pathlib.Path('H:/.codex/worktrees/group/IM-platform')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
expected={'backend-go-regular-r1/report.md':'0d909c6d40fc7e4ec8ed82bc27b6ca5e4e3325e97c212562c193e0b4d71d1e4f','backend-go-regular-r1/final-receipt.json':'a39869725d0f84b3311ded56f4a7b714fa4818863a55a59d2ad381dece32f81b','backend-go-regular-r1/artifact-bindings.json':'09d966dd9537d4e0ee2d20d399705d918dd666f66200001966f264c156b6e4d9','backend-go-regular-r1-coordinator-bindings.json':'222b0d84d2b433b5ee14bbca9c389764baa74602f78df13ee9251e5e8ecb8837','backend-go-regular-r1/spec-axis/raw-http-probe.go':'d39f268b547832051119d2719501f4e1b7d3089a0043a7b286fcfe5359872b3c'}
for p,h in expected.items(): assert sha(B/p)==h,p
bind=json.loads((B/'backend-go-regular-r1-coordinator-bindings.json').read_text())
for e in bind['artifacts']:
 p=pathlib.Path(e['path']); assert p.stat().st_size==e['bytes'] and sha(p)==e['sha256'],e
out={'result':'BOUND_REGULAR_FAIL_INPUTS','artifacts_checked':len(bind['artifacts']),'references':[{'path':str(B/p),'sha256':h} for p,h in expected.items()]}
(O/'input-review-bindings.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8',newline='\n'); print(json.dumps(out))
probe=O/'raw-http-probe.go'; probe.write_bytes((B/'backend-go-regular-r1/spec-axis/raw-http-probe.go').read_bytes()); assert sha(probe)==expected['backend-go-regular-r1/spec-axis/raw-http-probe.go']
env=os.environ.copy()
for k in list(env):
 if k.upper().startswith('PG') or k.upper() in ('DATABASE_URL','NATS_URL'): env.pop(k,None)
env.update({'GOCACHE':str(O/'go-cache'),'GOTMPDIR':str(O/'go-tmp'),'GOTELEMETRY':'off'})
(O/'go-cache').mkdir(exist_ok=True);(O/'go-tmp').mkdir(exist_ok=True)
cmd=['H:/go/bin/go.exe','-C',str(R/'backend/go'),'run','-mod=readonly',str(probe)]
a=time.monotonic();p=subprocess.run(cmd,env=env,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
tag=sys.argv[1];(O/(tag+'.stdout')).write_bytes(p.stdout);(O/(tag+'.stderr')).write_bytes(p.stderr)
v={'argv':cmd,'exit_code':p.returncode,'elapsed_seconds':round(time.monotonic()-a,3),'tested_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip(),'probe_candidate_label':'Historical original label; actual tested head is separately bound','stdout':tag+'.stdout','stderr':tag+'.stderr'}
(O/(tag+'.json')).write_text(json.dumps(v,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(v));print(p.stdout.decode('utf-8',errors='replace'));print(p.stderr.decode('utf-8',errors='replace'));sys.exit(p.returncode)