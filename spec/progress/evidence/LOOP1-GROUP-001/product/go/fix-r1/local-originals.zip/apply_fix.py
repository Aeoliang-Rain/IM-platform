import hashlib,json,pathlib,subprocess,sys
R=pathlib.Path('H:/.codex/worktrees/group/IM-platform');O=pathlib.Path(__file__).parent
root=subprocess.check_output(['git','rev-parse','--show-toplevel'],cwd=R).decode().strip();assert root=='H:/.codex/worktrees/group/IM-platform',root
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R).decode().strip()=='bda9a962d68222b9509d7697e38a6d02862c9e7a'
mode=sys.argv[1]
p=R/'backend/go/core/group_test.go' if mode=='test' else R/'backend/go/core/group.go'
b=p.read_bytes();nl=b'\r\n' if b'\r\n' in b else b'\n'
if mode=='test':
 text=r'''func TestGroupHTTPJSONEncodingPrecedence(t *testing.T) {
	server := httptest.NewServer(NewHandler(nil, []byte("group-http-input-test-key")))
	t.Cleanup(server.Close)
	id := groupUUID(t)
	prefix := `{"requestId":"` + id + `","memberUserIds":["`
	suffix := `"]}`
	for _, route := range []struct{ name, path string }{
		{"create", "/v1/groups"},
		{"add", "/v1/groups/30000000-0000-4000-8000-000000000001/members"},
	} {
		t.Run(route.name, func(t *testing.T) {
			for _, tc := range []struct {
				name, body, code string
				status           int
				correlated       bool
			}{
				{"valid", prefix + "10000000-0000-4000-8000-000000000002" + suffix, "AUTH_REQUIRED", 401, true},
				{"valid-unicode-before-shape", prefix + "é" + suffix, "AUTH_REQUIRED", 401, true},
				{"non-object-before-shape", "null", "AUTH_REQUIRED", 401, false},
				{"broken-json", `{"requestId":`, "VALIDATION_FAILED", 400, false},
				{"invalid-utf8-ff", prefix + "\xff" + suffix, "VALIDATION_FAILED", 400, false},
				{"invalid-utf8-c328", prefix + "\xc3\x28" + suffix, "VALIDATION_FAILED", 400, false},
			} {
				t.Run(tc.name, func(t *testing.T) {
					r, err := http.NewRequest(http.MethodPost, server.URL+route.path, strings.NewReader(tc.body))
					if err != nil {
						t.Fatal(err)
					}
					r.Header.Set("Content-Type", "application/json")
					response, err := server.Client().Do(r)
					if err != nil {
						t.Fatal(err)
					}
					body, readErr := io.ReadAll(response.Body)
					closeErr := response.Body.Close()
					if readErr != nil || closeErr != nil {
						t.Fatal(errors.Join(readErr, closeErr))
					}
					var result struct {
						RequestID string `json:"requestId"`
						Error     struct {
							Code string `json:"code"`
						} `json:"error"`
					}
					if response.StatusCode != tc.status || json.Unmarshal(body, &result) != nil || result.Error.Code != tc.code ||
						!groupID.MatchString(result.RequestID) || response.Header.Get("Cache-Control") != "no-store" {
						t.Fatalf("HTTP %d %s, want %d/%s with UUID and no-store", response.StatusCode, body, tc.status, tc.code)
					}
					if (result.RequestID == id) != tc.correlated {
						t.Fatalf("requestId correlation = %q, correlated = %t", result.RequestID, tc.correlated)
					}
				})
			}
		})
	}
}

'''
 text=text.replace('\\"','"')
 text=text.replace(chr(92)+chr(34),chr(34)).replace(chr(92)+chr(92)+'x',chr(92)+'x')
 marker=b'func TestGroupHTTPBoundariesAndAuthorization(t *testing.T) {';assert b.count(marker)==1
 new=b.replace(marker,text.encode('utf-8').replace(b'\n',nl)+marker)
elif mode=='source':
 marker=b'\t"time"'+nl;assert b.count(marker)==1
 new=b.replace(marker,marker+b'\t"unicode/utf8"'+nl)
 marker=b'if !json.Valid(body) {';assert new.count(marker)==1
 new=new.replace(marker,b'if !utf8.Valid(body) || !json.Valid(body) {')
else: raise ValueError(mode)
(O/('before-'+p.name)).write_bytes(b)
p.write_bytes(new)
print(json.dumps({'mode':mode,'path':str(p),'before':hashlib.sha256(b).hexdigest(),'after':hashlib.sha256(new).hexdigest(),'root':root}))