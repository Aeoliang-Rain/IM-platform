import hashlib,json,pathlib,subprocess,sys
O=pathlib.Path(__file__).parent;R=pathlib.Path('H:/.codex/worktrees/group/IM-platform')
def sha(b):return hashlib.sha256(b).hexdigest()
def norm(b):return b.replace(b'\r\n',b'\n')
owned={'backend/go/core/group.go','backend/go/core/group_test.go','spec/tasks/active/LOOP1-GROUP-001.md','spec/progress/current.md'}
old=json.loads((O/'startup-tracked-bytes.json').read_text());changed=[]
for e in old:
 p=R/e['path'];b=p.read_bytes()
 if sha(b)!=e['sha256'] or len(b)!=e['bytes']:changed.append(e['path'])
assert set(changed)<=owned,changed
before=norm((O/'before-group.go').read_bytes());want=before.replace(b'\t"time"\n',b'\t"time"\n\t"unicode/utf8"\n').replace(b'if !json.Valid(body) {',b'if !utf8.Valid(body) || !json.Valid(body) {');assert norm((R/'backend/go/core/group.go').read_bytes())==want
b=norm((R/'backend/go/core/group_test.go').read_bytes());a=b.index(b'func TestGroupHTTPJSONEncodingPrecedence(');z=b.index(b'func TestGroupHTTPBoundariesAndAuthorization(',a);assert b[:a]+b[z:]==norm((O/'before-group_test.go').read_bytes())
for tag in ('whole-normal','whole-race'):
 v=json.loads((O/(tag+'.json')).read_text());assert v['exit_code']==0 and v['passes']==265 and len(v['main_methods'])==72 and len(v['group_passes'])==70 and not v['failures'] and not v['skips']
 for p,h in v['source_hashes'].items():assert sha((R/p).read_bytes())==h
idx=subprocess.check_output(['git','ls-files','--stage','-v','-z'],cwd=R)
if sys.argv[1]=='prestage':assert idx==(O/'startup-index.stdout').read_bytes()
else:
 def entries(raw):return {r.split(b'\t',1)[1].decode():r for r in raw.split(b'\0') if r}
 original=entries((O/'startup-index.stdout').read_bytes());current=entries(idx)
 for p,r in original.items():
  if p not in owned:assert current[p]==r,p
result={'result':'SOURCE_AND_PROTECTED_BYTES_PASS','phase':sys.argv[1],'old_tracked_files':len(old),'protected_old_tracked_files':len(old)-len(owned),'protected_paths_excluded_only':sorted(owned),'actual_changed_old_paths':changed,'old_group_test_body_and_helpers_unchanged_after_removing_only_new_test':True,'group_source_only_utf8_import_and_condition':True,'source_matches_both_new_whole_go_runs':True,'index_protection':True,'git_root':subprocess.check_output(['git','rev-parse','--show-toplevel'],cwd=R).decode().strip(),'source_hashes':{p:sha((R/p).read_bytes()) for p in sorted(owned) if p.startswith('backend/')}}
assert result['git_root']=='H:/.codex/worktrees/group/IM-platform'
(O/('scope-'+sys.argv[1]+'.json')).write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(result))