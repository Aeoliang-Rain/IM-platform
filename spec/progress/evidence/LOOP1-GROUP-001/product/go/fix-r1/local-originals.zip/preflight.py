import hashlib,json,os,pathlib,subprocess,sys,time
R=pathlib.Path('H:/.codex/worktrees/group/IM-platform')
O=pathlib.Path(__file__).parent
P=sys.executable
os.environ['PYTHONDONTWRITEBYTECODE']='1'
os.environ['PATH']=str(pathlib.Path(P).parent)+os.pathsep+'H:/go/bin'+os.pathsep+os.environ['PATH']

def call(tag,args,cwd=R):
 start=time.monotonic(); p=subprocess.run(args,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 (O/(tag+'.stdout')).write_bytes(p.stdout);(O/(tag+'.stderr')).write_bytes(p.stderr)
 row={'tag':tag,'argv':args,'cwd':str(cwd),'exit_code':p.returncode,'elapsed_seconds':round(time.monotonic()-start,3),'stdout':tag+'.stdout','stderr':tag+'.stderr'}
 (O/(tag+'.json')).write_text(json.dumps(row,indent=2)+'\n',encoding='utf-8',newline='\n')
 print(json.dumps(row)); print(p.stdout.decode('utf-8',errors='replace') if len(p.stdout)<4000 else 'stdout saved bytes='+str(len(p.stdout))+' sha256='+hashlib.sha256(p.stdout).hexdigest()); print(p.stderr.decode('utf-8',errors='replace') if len(p.stderr)<4000 else 'stderr saved bytes='+str(len(p.stderr)))
 return p
if sys.argv[1]=='git':
 for tag,args in [('startup-status',['git','status','--porcelain=v1','--untracked-files=all']),('startup-diff',['git','diff','--no-ext-diff']),('startup-indexdiff',['git','diff','--cached','--no-ext-diff']),('startup-log',['git','log','-6','--format=%h %s']),('startup-root',['git','rev-parse','--show-toplevel']),('startup-branch',['git','rev-parse','--abbrev-ref','HEAD']),('startup-head',['git','rev-parse','HEAD'])]:
  r=call(tag,args); assert r.returncode==0
  if tag=='startup-root': assert r.stdout.decode().strip().replace('\\','/')==str(R).replace('\\','/')
  if tag in ('startup-status','startup-diff','startup-indexdiff'): assert not r.stdout.strip()
  if tag=='startup-head': assert r.stdout.decode().strip()=='bda9a962d68222b9509d7697e38a6d02862c9e7a'
 index=call('startup-index',['git','ls-files','--stage','-v','-z']); assert index.returncode==0
 paths=subprocess.check_output(['git','ls-files','-z'],cwd=R).decode().split('\0')
 rows=[{'path':f,'bytes':(R/f).stat().st_size,'sha256':hashlib.sha256((R/f).read_bytes()).hexdigest()} for f in paths if f]
 (O/'startup-tracked-bytes.json').write_text(json.dumps(rows,indent=2)+'\n',encoding='utf-8',newline='\n');print('tracked files',len(rows))
elif sys.argv[1]=='baseline':
 items=[('baseline-frozen',['tools/verify_frozen_architecture.py']),('baseline-planning',['ci/check_s2_planning.py']),('baseline-architecture',['ci/check_architecture.py','--scope','all','--json']),('baseline-architecture-tests',['-m','unittest','discover','-s','tests/architecture']),('baseline-ci-tests',['-m','unittest','discover','-s','tests/ci'])]
 for tag,tail in items:
  r=call(tag,[P,'-Xutf8','-B',*tail]); assert r.returncode==0
else: raise ValueError(sys.argv[1])