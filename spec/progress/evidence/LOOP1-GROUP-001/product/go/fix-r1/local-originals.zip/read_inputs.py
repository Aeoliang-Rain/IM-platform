import pathlib, sys
R=pathlib.Path('H:/.codex/worktrees/group/IM-platform')
for arg in sys.argv[1:]:
 p,*r=arg.split('::')
 lines=(R/p).read_text(encoding='utf-8').splitlines()
 if r:
  a,b=map(int,r[0].split(':')); lines=lines[a-1:b]
 print('\n===== '+arg+' =====\n'+'\n'.join(lines))