import json, pathlib, subprocess, sys, time
ROOT=pathlib.Path('H:/.codex/worktrees/group/IM-platform')
OUT=pathlib.Path('C:/Users/21441/.codex/visualizations/2026/10/18/01a14d96-146d-7f42-9fd8-0fd0c7e399e0/backend-go-fix-r1')
PY=sys.executable
COMMON=['--repo',str(ROOT),'--research-root',str(OUT/'research')]
REC=str(ROOT/'tools/research/recorder.py')
RUN='R-BACKEND-GO-FIX-R1-20261020'
mode=sys.argv[1]
if mode=='warning':
 data={'reason':'Startup reads, prompt/bootstrap creation, public coordination messages and this external helper authoring were not fully captured before routing. The run is prospective_resume with an incomplete trace. Only observed facts are recorded; no product acceptance is claimed.','pre_recorder_trace_complete':False,'current_grant':'READONLY_PREPARATION; no repository writes or product runtime'}
 cmd=[PY,'-Xutf8','-B',REC,'record-event',*COMMON,'--run-id',RUN,'--event-type','instrumentation_warning','--data-json',json.dumps(data,ensure_ascii=False)]
elif mode=='command':
 cmd=[PY,'-Xutf8','-B',REC,'run-command',*COMMON,'--run-id',RUN,'--',*sys.argv[2:]]
else: raise ValueError(mode)
r=subprocess.run(cmd,cwd=ROOT)
sys.exit(r.returncode)