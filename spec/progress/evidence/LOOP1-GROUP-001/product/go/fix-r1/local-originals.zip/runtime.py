import copy,hashlib,json,os,pathlib,re,socket,subprocess,sys,time,uuid
O=pathlib.Path(__file__).parent;R=pathlib.Path('H:/.codex/worktrees/group/IM-platform');PG=pathlib.Path('H:/IM-platform/.git/worktrees/IM-platform4/group-pg16-20261018');PSQL=PG/'pgsql/bin/psql.exe';OWNER='R-BACKEND-GO-FIX-R1-20261020'
PGFILE=O/'owned-pg.json';NATSFILE=O/'owned-nats.json';CAP=O/'runtime-captures';CAP.mkdir(exist_ok=True)
def save(path,v): pathlib.Path(path).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
def env(schema=None):
 e={k:v for k,v in os.environ.items() if not k.upper().startswith('PG') and k.upper() not in ('DATABASE_URL','NATS_URL','DB_TEST_ENABLE')}
 e.update(PGHOST='127.0.0.1',PGPORT='63830',PGDATABASE='group_contract_20261018',PGUSER='group_contract_fixture',PGPASSFILE=str(PG/'libpq-v2.private'),PGCONNECT_TIMEOUT='5',PGAPPNAME='backend-go-fix-r1',DB_TEST_ENABLE='1',PYTHONDONTWRITEBYTECODE='1',GOCACHE=str(O/'go-cache'),GOTMPDIR=str(O/'go-tmp'),GOTELEMETRY='off',GOFLAGS='-mod=readonly')
 e['PATH']=str(PSQL.parent)+os.pathsep+str(pathlib.Path(sys.executable).parent)+os.pathsep+'H:/go/bin'+os.pathsep+e.get('PATH','')
 if schema:e['PGOPTIONS']='-c search_path='+schema
 if NATSFILE.is_file():
  f=json.loads(NATSFILE.read_text())
  if f.get('created') and not f.get('cleaned'):
   assert re.fullmatch(r'nats://127\.0\.0\.1:[0-9]+',f['url']);e['NATS_URL']=f['url']
 return e
def call(tag,argv,e=None,cwd=R,check=True):
 argv=[str(a) for a in argv];a=time.monotonic();p=subprocess.run(argv,cwd=cwd,env=e,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 stamp=str(time.time_ns())+'-'+tag
 (CAP/(stamp+'.stdout')).write_bytes(p.stdout);(CAP/(stamp+'.stderr')).write_bytes(p.stderr)
 row={'tag':tag,'argv':argv,'cwd':str(cwd),'exit_code':p.returncode,'elapsed_seconds':round(time.monotonic()-a,3),'stdout':{'path':str(CAP/(stamp+'.stdout')),'bytes':len(p.stdout),'sha256':hashlib.sha256(p.stdout).hexdigest()},'stderr':{'path':str(CAP/(stamp+'.stderr')),'bytes':len(p.stderr),'sha256':hashlib.sha256(p.stderr).hexdigest()}}
 save(CAP/(stamp+'.json'),row);print(json.dumps(row),flush=True)
 if len(p.stdout)<1000:print(p.stdout.decode('utf-8',errors='replace'),flush=True)
 if p.returncode and len(p.stderr)<4000:print(p.stderr.decode('utf-8',errors='replace'),flush=True)
 if check and p.returncode:raise RuntimeError(tag+' native exit '+str(p.returncode)+'; raw outputs preserved')
 return p,row
def sql(tag,q,e):return call(tag,[PSQL,'-X','-w','-q','-A','-t','-v','ON_ERROR_STOP=1','-c',q],e)[0].stdout.decode().strip()
def qualify():
 e=env();v=json.loads(sql('pg-identity',"SELECT json_build_object('host',host(inet_server_addr()),'port',inet_server_port(),'database',current_database(),'user',current_user,'version',current_setting('server_version_num'),'datadir',current_setting('data_directory'),'backend_pid',pg_backend_pid(),'current_schema',current_schema(),'search_path',current_setting('search_path'));",e))
 want={'host':'127.0.0.1','port':63830,'database':'group_contract_20261018','user':'group_contract_fixture','version':'160015'}
 assert all(v[k]==w for k,w in want.items()),v
 assert pathlib.Path(v['datadir']).resolve()==(PG/'data-v2').resolve(),v
 status,_=call('pg-control-status',[PG/'pgsql/bin/pg_ctl.exe','status','-D',PG/'data-v2'],e)
 assert 'PID: 49572' in status.stdout.decode() and 'data-v2' in status.stdout.decode()
 pid=int((PG/'data-v2/postmaster.pid').read_text().splitlines()[0]);assert pid==49572
 save(O/'pg-qualification-latest.json',{'identity':v,'postmaster_pid':pid,'credential_handling':'PGPASSFILE path supplied only to libpq, never read/hash/copy/print contents','qualified':True});return e,v
def schemas(e):return json.loads(sql('schema-inventory',"SELECT coalesce(json_agg(json_build_array(nspname,pg_get_userbyid(nspowner)) ORDER BY nspname),'[]'::json) FROM pg_namespace;",e))
def loadpg():
 f=json.loads(PGFILE.read_text());assert f['created'] and not f['cleaned'] and re.fullmatch('backend_go_fix_r1_[0-9a-f]{16}',f['schema'])
 qualify();e=env(f['schema']);observed=json.loads(sql('owned-schema-qualification',"SELECT json_build_object('schema',current_schema(),'search_path',current_setting('search_path'),'owner',(SELECT pg_get_userbyid(nspowner) FROM pg_namespace WHERE nspname=current_schema()));",e));assert observed=={'schema':f['schema'],'search_path':f['schema'],'owner':'group_contract_fixture'},observed
 return f,e
def docker(tag,*args):return call(tag,['docker',*args])[0].stdout.decode().strip()
def inspect(ident):
 fmt='{{json .Id}} {{json .Name}} {{json .Config.Image}} {{json .Image}} {{json .State}} {{json .Mounts}} {{json .Config.Labels}} {{json .NetworkSettings.Ports}}'
 raw=docker('docker-inspect-public','inspect','--format',fmt,ident);d=json.JSONDecoder();items=[]
 while raw:v,n=d.raw_decode(raw);items.append(v);raw=raw[n:].lstrip()
 return dict(zip(['id','name','image','image_id','state','mounts','labels','ports'],items))
def inventory():
 ids=docker('docker-ids','ps','-aq').splitlines();containers=[inspect(i) for i in ids]
 volumes=[json.loads(x) for x in docker('docker-volumes','volume','ls','--format','{{json .}}').splitlines()]
 return {'containers':containers,'volumes':volumes}
def stable(v):
 v=copy.deepcopy(v)
 for c in v['containers']:
  c['mounts']=sorted(c['mounts'],key=lambda x:json.dumps(x,sort_keys=True))
  for log in c['state'].get('Health',{}).get('Log',[]):log.pop('Start',None);log.pop('End',None)
 v['containers'].sort(key=lambda x:x['id']);v['volumes'].sort(key=lambda x:json.dumps(x,sort_keys=True));return v
mode=sys.argv[1]
if mode=='pg-setup':
 assert not PGFILE.exists();e,v=qualify();before=schemas(e);f={'owner':OWNER,'schema':'backend_go_fix_r1_'+uuid.uuid4().hex[:16],'identity':v,'before_schemas':before,'created':False,'cleaned':False};save(PGFILE,f)
 sql('create-owned-schema','CREATE SCHEMA '+f['schema']+' AUTHORIZATION group_contract_fixture;',e);f['created']=True;save(PGFILE,f);e=env(f['schema'])
 for a in ('status','up','status'):call('canonical-migrate-'+a,[sys.executable,'-Xutf8','-B','contracts/database/migrate.py',a],e)
 ledger=json.loads(sql('owned-ledger',"SELECT json_agg(json_build_array(version,checksum) ORDER BY version) FROM schema_migrations;",e));assert [r[0] for r in ledger]==['0001_initial','0002_group_operations'];f['ledger']=ledger;f['migration_complete']=True;save(PGFILE,f);loadpg();print('OWNED_PG_READY')
elif mode=='nats-setup':
 assert not NATSFILE.exists();assert b'image: nats:2.10-alpine' in (R/'deploy/compose.yaml').read_bytes();before=inventory();f={'owner':OWNER,'name':'backend-go-fix-r1-nats-'+uuid.uuid4().hex[:12],'image':'nats:2.10-alpine','before':before,'created':False,'cleaned':False};save(NATSFILE,f)
 ident=docker('own-nats-create','run','-d','--name',f['name'],'--label','backend-go-fix-r1-owner='+OWNER,'-p','127.0.0.1::4222',f['image']);assert re.fullmatch('[0-9a-f]{64}',ident);f.update(id=ident,created=True);save(NATSFILE,f);a=inspect(ident)
 assert a['id']==ident and a['name']=='/'+f['name'] and a['image']==f['image'] and a['labels']['backend-go-fix-r1-owner']==OWNER and not a['mounts'] and a['state']['Running']
 ports=a['ports']['4222/tcp'];assert len(ports)==1 and ports[0]['HostIp']=='127.0.0.1';port=int(ports[0]['HostPort']);assert all(not m for k,m in a['ports'].items() if k!='4222/tcp');f.update(url='nats://127.0.0.1:'+str(port),qualification=a);save(NATSFILE,f)
 deadline=time.monotonic()+10
 while True:
  try:
   with socket.create_connection(('127.0.0.1',port),timeout=1) as s:banner=s.recv(4096)
   assert banner.startswith(b'INFO ');f['server_info']=json.loads(banner[5:].strip());break
  except (ConnectionRefusedError,TimeoutError):
   if time.monotonic()>=deadline:raise
   time.sleep(.05)
 save(NATSFILE,f);print('OWNED_NATS_READY '+f['url'])
elif mode in ('whole-normal','whole-race'):
 f,e=loadpg();assert NATSFILE.is_file() and json.loads(NATSFILE.read_text())['created'];args=['H:/go/bin/go.exe','test']+(['-race'] if mode=='whole-race' else [])+['-count=1','-timeout=5m','-json','./...'];p,row=call(mode,args,e,cwd=R/'backend/go',check=False)
 events=[json.loads(l) for l in p.stdout.decode().splitlines() if l.startswith('{')];passes=[x['Test'] for x in events if x['Action']=='pass' and 'Test'in x];fails=[x['Test'] for x in events if x['Action']=='fail' and 'Test'in x];skips=[x['Test'] for x in events if x['Action']=='skip' and 'Test'in x]
 summary={**row,'passes':len(passes),'main_methods':[n for n in passes if '/'not in n],'group_passes':[n for n in passes if n.startswith('TestGroup')],'failures':fails,'skips':skips,'source_hashes':{p:hashlib.sha256((R/p).read_bytes()).hexdigest() for p in ['backend/go/core/group.go','backend/go/core/group_test.go','backend/go/core/http.go','backend/go/core/social.go']},'owned_schema':f['schema'],'DB_TEST_ENABLE':'1','PGOPTIONS':e['PGOPTIONS'],'NATS_URL':e['NATS_URL']};save(O/(mode+'.json'),summary);print(json.dumps({'native_exit':p.returncode,'passes':len(passes),'main_methods':len(summary['main_methods']),'group_passes':len(summary['group_passes']),'failures':fails,'skips':skips,'elapsed':row['elapsed_seconds']}));sys.exit(p.returncode or (1 if fails or skips else 0))
elif mode=='pg-cleanup':
 f,e=loadpg();f['counts_before_drop']=json.loads(sql('owned-counts-before-drop',"SELECT json_build_object('users',(SELECT count(*) FROM users),'sessions',(SELECT count(*) FROM sessions),'conversations',(SELECT count(*) FROM conversations),'members',(SELECT count(*) FROM conversation_members),'receipts',(SELECT count(*) FROM group_operation_receipts),'user_sync_events',(SELECT count(*) FROM user_sync_events),'outbox_events',(SELECT count(*) FROM outbox_events),'messages',(SELECT count(*) FROM messages));",e));save(PGFILE,f);pre=schemas(env());assert [x for x in pre if x[0]!=f['schema']]==f['before_schemas'];sql('drop-exact-owned-schema','DROP SCHEMA '+f['schema']+' CASCADE;',e);after=schemas(env());f.update(after_schemas=after,cleaned=True,preservation_pass=after==f['before_schemas']);save(PGFILE,f);assert f['preservation_pass'];qualify();print('OWNED_SCHEMA_CLEAN_AND_NONOWN_PRESERVED')
elif mode=='nats-cleanup':
 f=json.loads(NATSFILE.read_text());assert f['created'] and not f['cleaned'];a=inspect(f['id']);q=f['qualification'];assert all(a[k]==q[k] for k in ('id','name','image','image_id','labels','mounts','ports')) and not a['mounts'];actual=inventory();other={'containers':[x for x in actual['containers'] if x['id']!=f['id']],'volumes':actual['volumes']};before_pass=stable(other)==stable(f['before']);docker('remove-exact-owned-nats','rm','-f',f['id']);after=inventory();f.update(before_cleanup=actual,after_cleanup=after,cleaned=True,own_absent=all(x['id']!=f['id'] for x in after['containers']),preservation_pass=stable(after)==stable(f['before']),before_cleanup_preservation_pass=before_pass,comparison_rules='Complete public identity/image/labels/state/ports/mount records and volumes; container/mount/volume order normalized; only natural Health.Log Start/End omitted. Raw complete snapshots retained.');save(NATSFILE,f);assert f['own_absent'] and f['preservation_pass'] and before_pass;print('OWNED_NATS_CLEAN_AND_NONOWN_PRESERVED')
else:raise ValueError(mode)