import hashlib,json,os,pathlib,subprocess,sys,time
R=pathlib.Path('H:/.codex/worktrees/group/IM-platform');O=pathlib.Path(__file__).parent
mode=sys.argv[1];env=os.environ.copy()
for k in list(env):
 if k.upper().startswith('PG') or k.upper() in ('DATABASE_URL','NATS_URL','DB_TEST_ENABLE'):env.pop(k,None)
env.update({'GOCACHE':str(O/'go-cache'),'GOTMPDIR':str(O/'go-tmp'),'GOTELEMETRY':'off','GOFLAGS':'-mod=readonly','PYTHONDONTWRITEBYTECODE':'1'})
if mode.startswith('formal-'):
 cmd=['H:/go/bin/go.exe','test','-count=1','-timeout=1m','-run','^TestGroupHTTPJSONEncodingPrecedence$','-json','./core'];cwd=R/'backend/go'
elif mode=='diff':cmd=['git','diff','--no-ext-diff','--','backend/go/core/group.go','backend/go/core/group_test.go'];cwd=R
else:raise ValueError(mode)
a=time.monotonic();p=subprocess.run(cmd,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(O/(mode+'.stdout')).write_bytes(p.stdout);(O/(mode+'.stderr')).write_bytes(p.stderr)
row={'argv':cmd,'cwd':str(cwd),'exit_code':p.returncode,'elapsed_seconds':round(time.monotonic()-a,3),'stdout':mode+'.stdout','stderr':mode+'.stderr'}
if mode.startswith('formal-'):
 ev=[json.loads(l) for l in p.stdout.decode().splitlines() if l.startswith('{')];row['test_passes']=[e['Test'] for e in ev if e['Action']=='pass' and 'Test'in e];row['test_failures']=[e['Test'] for e in ev if e['Action']=='fail' and 'Test'in e];row['test_skips']=[e['Test'] for e in ev if e['Action']=='skip' and 'Test'in e]
(O/(mode+'.json')).write_text(json.dumps(row,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(row));print(p.stdout.decode(errors='replace') if len(p.stdout)<5000 else 'full stdout preserved bytes='+str(len(p.stdout)));print(p.stderr.decode(errors='replace'));sys.exit(p.returncode)