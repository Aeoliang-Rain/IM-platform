package main

import (
 "bytes"
 "encoding/hex"
 "encoding/json"
 "fmt"
 "io"
 "net/http"
 "net/http/httptest"
 "os"
 "unicode/utf8"

 "im-platform/backend/go/core"
)

type observation struct { Name string `json:"name"`; Path string `json:"path"`; BodyHex string `json:"bodyHex"`; UTF8Valid bool `json:"utf8Valid"`; GoJSONValid bool `json:"goJSONValid"`; ExpectedStatus int `json:"expectedStatus"`; ActualStatus int `json:"actualStatus"`; Response string `json:"response"`; NoStore string `json:"cacheControl"`; Pass bool `json:"pass"` }
func main() {
 server := httptest.NewServer(core.NewHandler(nil, []byte("public-review-fixture-key")))
 defer server.Close()
 prefix := []byte(`{"requestId":"40000000-0000-4000-8000-000000000001","memberUserIds":["`)
 suffix := []byte(`"]}`)
 cases := []struct{name string; body []byte; want int}{
  {"canonical-valid-missing-auth", []byte(`{"requestId":"40000000-0000-4000-8000-000000000001","memberUserIds":["10000000-0000-4000-8000-000000000002"]}`), 401},
  {"syntactically-broken-json-missing-auth", []byte(`{"requestId":`), 400},
  {"raw-invalid-utf8-ff-missing-auth", append(append(append([]byte{}, prefix...), 0xff), suffix...), 400},
  {"raw-invalid-utf8-c328-missing-auth", append(append(append([]byte{}, prefix...), 0xc3, 0x28), suffix...), 400},
 }
 var results []observation
 failed := false
 for _,path := range []string{"/v1/groups", "/v1/groups/30000000-0000-4000-8000-000000000001/members"} {
  for _, c := range cases {
   req, err := http.NewRequest(http.MethodPost, server.URL+path, bytes.NewReader(c.body)); if err != nil {panic(err)}
   req.Header.Set("Content-Type", "application/json")
   resp, err := server.Client().Do(req); if err != nil {panic(err)}
   data, err := io.ReadAll(resp.Body); if err != nil {panic(err)}
   if err=resp.Body.Close(); err != nil {panic(err)}
   o:=observation{c.name,path,hex.EncodeToString(c.body),utf8.Valid(c.body),json.Valid(c.body),c.want,resp.StatusCode,string(data),resp.Header.Get("Cache-Control"),resp.StatusCode==c.want}
   results=append(results,o); if !o.Pass { failed=true }
  }
 }
 data,err:=json.MarshalIndent(map[string]any{"handler":"core.NewHandler", "database":"nil; no database access required for preauthentication malformed JSON", "candidate":"bda9a962d68222b9509d7697e38a6d02862c9e7a", "observations":results},"","  "); if err!=nil {panic(err)}
 fmt.Println(string(data))
 if failed {os.Exit(1)}
}
