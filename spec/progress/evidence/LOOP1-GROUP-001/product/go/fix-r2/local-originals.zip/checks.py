import json
import os
from pathlib import Path
import subprocess
import sys

HERE=Path(__file__).resolve().parent
PY=r'C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
PW=r'C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'
env={k:v for k,v in os.environ.items() if not k.upper().startswith('PG') and k.upper() not in ('DATABASE_URL','DB_TEST_ENABLE','NATS_URL')}
env['PYTHONDONTWRITEBYTECODE']='1'
env['PATH']=str(Path(PY).parent)+os.pathsep+'H:/go/bin'+os.pathsep+env.get('PATH','')
items=[('final-gofmt',['H:/go/bin/gofmt.exe','-d','backend/go/core/group.go','backend/go/core/group_test.go']),('final-frozen',[PY,'-Xutf8','-B','tools/verify_frozen_architecture.py']),('final-planning',[PY,'-Xutf8','-B','ci/check_s2_planning.py']),('final-architecture',[PY,'-Xutf8','-B','ci/check_architecture.py','--scope','all','--json']),('group-contract',[PY,'-Xutf8','-B','contracts/http/verify-group.py']),('group-suite',[PY,'-Xutf8','-B','-m','unittest','discover','-s','tests/contract/group','-p','test_*.py','-v']),('auth-contract',[PW,'-NoProfile','-File','contracts/http/verify-auth-user-friend.ps1']),('sync-contract',[PY,'-Xutf8','-B','tools/verify_sync_transport.py']),('sync-suite',[PY,'-Xutf8','-B','-m','unittest','discover','-s','tests/contract','-p','test_sync_transport.py']),('wss-contract',[PY,'-Xutf8','-B','contracts/websocket/verify.py']),('plugin-contract',[PY,'-Xutf8','-B','contracts/plugin-api/verify.py'])] if sys.argv[1]=='checks' else [('control-'+sys.argv[1],[PW,'-NoProfile','-File','tools/verify-loop1-ctrl-002.ps1','-Mode',sys.argv[1]])]
for label,args in items:
    result=subprocess.run([PY,'-Xutf8','-B',str(HERE/'run.py'),label,'--',*args],env=env,capture_output=True)
    record=json.loads((HERE/'commands'/label/'result.json').read_text(encoding='utf-8'))
    print(json.dumps({'label':label,'exit_code':result.returncode,'elapsed_seconds':record['elapsed_seconds']}),flush=True)
    if result.returncode:
        sys.stdout.buffer.write(result.stdout[-3500:])
        sys.stderr.buffer.write(result.stderr[-3500:])
        sys.exit(result.returncode)
    if label=='final-gofmt':
        assert (HERE/'commands'/label/'stdout.bin').stat().st_size==0
