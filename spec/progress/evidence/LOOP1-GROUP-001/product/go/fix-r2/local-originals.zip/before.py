import hashlib
import json
import os
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
REPO = Path('H:/.codex/worktrees/group/IM-platform').resolve()
OLD = HERE.parent / 'backend-go-regular-r3'
env = os.environ.copy()
env['GIT_OPTIONAL_LOCKS'] = '0'
env['PYTHONDONTWRITEBYTECODE'] = '1'
(HERE / 'empty-git-excludes').touch(exist_ok=False)

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def git(*args):
    result = subprocess.run(['git', '--no-optional-locks', '-c', f'core.excludesFile={HERE / "empty-git-excludes"}', *args], cwd=REPO, env=env, capture_output=True)
    assert result.returncode == 0, (args, result.returncode, result.stderr)
    return result.stdout

observed = {}
for key, args in [('status', ('status','--porcelain=v1','--untracked-files=all')), ('working_diff', ('diff','--no-ext-diff')), ('staged_diff', ('diff','--cached','--no-ext-diff')), ('recent_commits', ('log','-7','--format=%H %s')), ('root', ('rev-parse','--show-toplevel')), ('branch', ('branch','--show-current')), ('head', ('rev-parse','HEAD'))]:
    raw = git(*args)
    observed[key] = raw.decode('utf-8')
    (HERE / f'before-{key}.txt').write_bytes(raw)
assert observed['status'] == observed['working_diff'] == observed['staged_diff'] == ''
assert Path(observed['root'].strip()).resolve() == REPO
assert observed['branch'].strip() == 'task/LOOP1-GROUP-001'
assert observed['head'].strip() == 'a9bb4877d9b7c2ff6f9687278504bccda0cb7aab'
print(json.dumps(observed, ensure_ascii=False, indent=2))

protected = []
for raw_path in git('ls-files','-z').split(b'\0'):
    if raw_path:
        path = raw_path.decode('utf-8')
        raw = (REPO / path).read_bytes()
        protected.append({'path': path, 'bytes': len(raw), 'sha256': digest(raw)})
(HERE / 'before-tracked.json').write_text(json.dumps(protected, ensure_ascii=False, indent=2)+'\n', encoding='utf-8', newline='\n')
(HERE / 'before-index-entries.bin').write_bytes(git('ls-files','--stage','-v','-z'))
index = Path(git('rev-parse','--git-path','index').decode().strip())
if not index.is_absolute():
    index = REPO / index
observed['index_raw_sha256'] = digest(index.read_bytes())
observed['tracked_count'] = len(protected)

authority = json.loads((OLD / 'authority-inputs.json').read_text(encoding='utf-8'))
for entry in authority:
    raw = (REPO / entry['path']).read_bytes()
    assert digest(raw) == entry['raw_sha256'], entry['path']
print('authority byte checks:', len(authority))
for part in ['', 'standards', 'spec']:
    directory = OLD / part
    manifest = json.loads((directory / 'artifact-manifest.json').read_text(encoding='utf-8'))
    entries = manifest['files'] if isinstance(manifest, dict) else manifest
    for entry in entries:
        path = Path(entry['path'])
        if not path.is_absolute():
            path = directory / path
        raw = path.read_bytes()
        assert len(raw) == entry['bytes'] and digest(raw) == entry['sha256'], str(path)
    print('R3 original checks:', part or 'coordinator', len(entries))
numeric = json.loads((OLD / 'spec/numeric-probe-originals.json').read_text(encoding='utf-8'))
for key in ['driver', 'stdout', 'stderr']:
    item = numeric[key]
    raw = Path(item['path']).read_bytes()
    assert len(raw) == item['bytes'] and digest(raw) == item['sha256'], key
print('numeric originals: bound unchanged; original probe RED native exit', numeric['command_finished']['data']['exit_code'])
(HERE / 'before-summary.json').write_text(json.dumps(observed, ensure_ascii=False, indent=2)+'\n', encoding='utf-8', newline='\n')
print('protected tracked bytes:', len(protected), 'index raw hash:', observed['index_raw_sha256'])
