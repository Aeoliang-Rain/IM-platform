import json
from pathlib import Path
import subprocess
import sys

HERE=Path(__file__).resolve().parent
REPO=Path('H:/.codex/worktrees/group/IM-platform')
argv=[sys.executable,'-Xutf8','-B',str(REPO/'tools/research/recorder.py'),'record-event','--repo',str(REPO),'--research-root',str(HERE/'research'),'--run-id','R-GROUP-BACKEND-GO-FIX-R2-20261023','--event-type',sys.argv[1],'--data-json',Path(sys.argv[2]).read_text(encoding='utf-8')]
result=subprocess.run(argv,cwd=REPO,capture_output=True)
label=Path(sys.argv[2]).stem+'-event'
(HERE/(label+'.stdout')).write_bytes(result.stdout)
(HERE/(label+'.stderr')).write_bytes(result.stderr)
sys.stdout.buffer.write(result.stdout)
sys.stderr.buffer.write(result.stderr)
sys.exit(result.returncode)
