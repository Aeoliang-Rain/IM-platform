import hashlib
import json
from pathlib import Path
import subprocess

HERE=Path(__file__).resolve().parent
REPO=Path('H:/.codex/worktrees/group/IM-platform').resolve()
assert Path(subprocess.run(['git','rev-parse','--show-toplevel'],cwd=REPO,capture_output=True,check=True).stdout.decode().strip()).resolve()==REPO
path=REPO/'backend/go/core/group.go'
raw=path.read_bytes()
before={x['path']:x for x in json.loads((HERE/'before-tracked.json').read_text(encoding='utf-8'))}
assert hashlib.sha256(raw).hexdigest()==before['backend/go/core/group.go']['sha256']
(HERE/'before-group.go').write_bytes(raw)
nl=b'\r\n' if b'\r\n' in raw else b'\n'
anchor=b'\td := json.NewDecoder(bytes.NewReader(body))'+nl
assert raw.count(anchor)==1
changed=raw.replace(anchor,anchor+b'\td.UseNumber()'+nl)
path.write_bytes(changed)
print(json.dumps({'result':'one standard-library UseNumber call added','sha256':hashlib.sha256(changed).hexdigest()}))
