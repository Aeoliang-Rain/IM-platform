import difflib
import hashlib
import json
from pathlib import Path
import subprocess
import sys

HERE=Path(__file__).resolve().parent
REPO=Path('H:/.codex/worktrees/group/IM-platform').resolve()
ALLOWED={'backend/go/core/group.go','backend/go/core/group_test.go','spec/tasks/active/LOOP1-GROUP-001.md','spec/progress/current.md'}
PREFIX='spec/progress/evidence/LOOP1-GROUP-001/product/go/fix-r2/'
def sha(raw): return hashlib.sha256(raw).hexdigest()
def git(*args):
    return subprocess.run(['git','--no-optional-locks','-c',f'core.excludesFile={HERE/"empty-git-excludes"}',*args],cwd=REPO,capture_output=True,check=True).stdout
assert Path(git('rev-parse','--show-toplevel').decode().strip()).resolve()==REPO
assert git('branch','--show-current').decode().strip()=='task/LOOP1-GROUP-001'
before=json.loads((HERE/'before-tracked.json').read_text(encoding='utf-8'))
changed=[]
for item in before:
    if sha((REPO/item['path']).read_bytes())!=item['sha256']:
        changed.append(item['path'])
assert set(changed)<=ALLOWED,changed
def entries(raw): return {r.split(b'\t',1)[1].decode('utf-8'):r for r in raw.split(b'\0') if r}
old_entries=entries((HERE/'before-index-entries.bin').read_bytes())
new_entries=entries(git('ls-files','--stage','-v','-z'))
assert all(new_entries[p]==v for p,v in old_entries.items() if p not in ALLOWED)
new_paths=set(new_entries)-set(old_entries)
assert all(p.startswith(PREFIX) for p in new_paths),new_paths
for p in ['backend/go/core/group.go','backend/go/core/group_test.go']:
    old=(HERE/('before-'+Path(p).name)).read_bytes().splitlines(keepends=True)
    new=(REPO/p).read_bytes().splitlines(keepends=True)
    changes=[(tag,i1,i2,j1,j2) for tag,i1,i2,j1,j2 in difflib.SequenceMatcher(a=old,b=new,autojunk=False).get_opcodes() if tag!='equal']
    assert all(tag=='insert' for tag,*_ in changes), (p,changes)
    inserts=[line for tag,i1,i2,j1,j2 in changes for line in new[j1:j2]]
    if p.endswith('/group.go'):
        assert inserts==[b'\td.UseNumber()\n'],inserts
    else:
        assert len(inserts)==10 and all(b'{"' in line for line in inserts),inserts
root_binding=HERE.parent/'coordinator-resume-20261023/r3-final-fail-binding.json'
assert sha(root_binding.read_bytes())=='40bb0e1698d7fd7e231b64000c462ba2db5f2a377e9041c5db54ead9fc7c541f'
receipt=HERE.parent/'backend-go-regular-r3/final-receipt.json'
assert sha(receipt.read_bytes())=='fd8dbbfc9a4e1f2b814525cb0aa4887fa578b3e5b0763ad93611b9293b8cf5e8'
proof={'result':'PASS','head':git('rev-parse','HEAD').decode().strip(),'changed_existing_tracked_paths':changed,'protected_other_tracked_files':len(before)-len(ALLOWED),'initial_tracked_files':len(before),'protected_index_entries_unchanged':True,'new_index_paths':sorted(new_paths),'source_changes':'group.go exactly one inserted UseNumber call; group_test.go exactly ten inserted table rows; all old lines retained byte-for-byte','source_hashes':{p:sha((REPO/p).read_bytes()) for p in ['backend/go/core/group.go','backend/go/core/group_test.go','backend/go/core/http.go','backend/go/core/social.go']},'r3_original_receipt_and_root_binding':'PASS'}
(HERE/('scope-'+sys.argv[1]+'.json')).write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(proof,indent=2))
