import collections
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import zipfile

HERE=Path(__file__).resolve().parent
REPO=Path('H:/.codex/worktrees/group/IM-platform').resolve()
PY=r'C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
PW=r'C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'
RUN='R-GROUP-BACKEND-GO-FIX-R2-20261023'
EVID='spec/progress/evidence/LOOP1-GROUP-001/product/go/fix-r2/'
OWN=['backend/go/core/group.go','backend/go/core/group_test.go','spec/progress/current.md','spec/tasks/active/LOOP1-GROUP-001.md',*[EVID+p for p in ['report.md','local-verification.json','local-originals.zip','original-bindings.json']]]
ENV={k:v for k,v in os.environ.items() if not k.upper().startswith('PG') and k.upper() not in ('DATABASE_URL','NATS_URL','DB_TEST_ENABLE')}
ENV.update(PYTHONDONTWRITEBYTECODE='1',GIT_OPTIONAL_LOCKS='0')
ENV['PATH']=str(Path(PY).parent)+os.pathsep+'H:/go/bin'+os.pathsep+ENV.get('PATH','')
def sha(raw): return hashlib.sha256(raw).hexdigest()
def save(path,value): path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
def read(path): return json.loads(path.read_text(encoding='utf-8'))
def call(label,argv,check=True):
    dest=HERE/'tail'/label
    dest.mkdir(parents=True,exist_ok=False)
    start=time.monotonic()
    result=subprocess.run([str(x) for x in argv],cwd=REPO,env=ENV,capture_output=True)
    (dest/'stdout.bin').write_bytes(result.stdout)
    (dest/'stderr.bin').write_bytes(result.stderr)
    record={'argv':[str(x) for x in argv],'cwd':str(REPO),'exit_code':result.returncode,'elapsed_seconds':round(time.monotonic()-start,6),'stdout_sha256':sha(result.stdout),'stderr_sha256':sha(result.stderr),'capture':'explicit direct postclosure tail; never claimed as sealed Recorder trace'}
    save(dest/'result.json',record)
    print(json.dumps({'label':label,'exit_code':result.returncode,'elapsed_seconds':record['elapsed_seconds']}),flush=True)
    if check and result.returncode:
        sys.stderr.buffer.write(result.stderr[-4000:])
        raise RuntimeError(f'{label} actual exit {result.returncode}; originals retained')
    return result,record
def git(label,*args):
    return call(label,['git','--no-optional-locks','-c',f'core.excludesFile={HERE/"empty-git-excludes"}',*args])[0].stdout
def events(path): return [json.loads(l) for l in path.read_text(encoding='utf-8').splitlines() if l.startswith('{')]
mode=sys.argv[1]
if mode=='close':
    assert read(HERE/'commands/control-Development/result.json')['exit_code']==0
    expected={'backend/go/core/group.go':'9787dca1b78ae73522a436bfb317bf8b15ae1af1ddf47feaf4f01df0279339e4','backend/go/core/group_test.go':'46875bb95a8f50e26694bb06314d80f94657e7783fd6cc142c4fe943045eb648'}
    for p,h in expected.items(): assert sha((REPO/p).read_bytes())==h
    for mode_name in ['normal','race']:
        summary=read(HERE/('whole-'+mode_name+'.json'))
        raw_events=events(Path(summary['stdout']['path']))
        assert len({e['Package'] for e in raw_events if e['Action']=='output' and '[no test files]' in e.get('Output','')})==2
        assert len([e for e in raw_events if e['Action']=='pass' and e.get('Test','').startswith('TestGroupHTTPBoundariesAndAuthorization/') and 'large-' in e['Test']])==4
    for name,fails in [('red',4),('green',0)]:
        rows=[e for e in events(HERE/f'commands/original-numeric-{name}/stdout.bin') if 'body' in e]
        assert len(rows)==14 and sum(not e['pass'] for e in rows)==fails
        if name=='green': assert all(e['server_error_log']=='' for e in rows)
    data={'result':'LOCAL_VERIFICATION_COMPLETE_NOT_ACCEPTANCE','source_hashes':expected,'whole_go':'normal51.719s/race111.610s, each72 main/281 with subtests/86 Group, zero failures/skips','runtime':'own schema and NATS removed, nonowned resources preserved; root PG40320/passfile retained','disclosed_tail':'One scope tool result initially omitted its returned terminal session metadata; direct read of the completed result.json established actual exit0/10.907s before the next Recorder command. No same-run overlap. Final packaging, single commit, clean Acceptance and sealing are direct postclosure observations.','independent_reviews':'NEW final-SHA regular and different error specialist still pending'}
    call('recorder-repair-finished',[PY,'-Xutf8','-B',REPO/'tools/research/recorder.py','record-event','--repo',REPO,'--research-root',HERE/'research','--run-id',RUN,'--event-type','repair_finished','--data-json',json.dumps(data)])
    _,finish=call('recorder-finish',[PY,'-Xutf8','-B',REPO/'tools/research/recorder.py','finish-run','--repo',REPO,'--research-root',HERE/'research','--run-id',RUN,'--result','FAIL'])
    _,validate=call('recorder-validate',[PY,'-Xutf8','-B',REPO/'tools/research/recorder.py','validate-run','--repo',REPO,'--research-root',HERE/'research','--run-id',RUN])
    trace=events(HERE/f'research/runs/{RUN}/events.jsonl')
    counts=collections.Counter(e['event_type'] for e in trace)
    starts={e['data']['command_id'] for e in trace if e['event_type']=='command_started'}
    ends={e['data']['command_id'] for e in trace if e['event_type']=='command_finished'}
    assert starts==ends
    closure={'run_id':RUN,'capture_mode':'prospective_resume','pre_recorder_trace_complete':False,'actual_finish_result':'FAIL','finish_cli_exit':finish['exit_code'],'direct_structural_validation_exit':validate['exit_code'],'event_counts':dict(counts),'unmatched_commands':sorted(starts-ends),'trace_edited':False,'tail':'Packaging/commit/clean Acceptance/sealing are explicitly direct postclosure observations'}
    save(HERE/'recorder-closure.json',closure)
    print(json.dumps(closure,indent=2))
elif mode=='package':
    closure=read(HERE/'recorder-closure.json')
    assert closure['finish_cli_exit']==closure['direct_structural_validation_exit']==0 and not closure['unmatched_commands']
    development=read(HERE/'commands/control-Development/result.json')
    dest=REPO/EVID
    verification=read(dest/'local-verification.json')
    verification['Development_Control']=development
    verification['Recorder_actual_closure']=closure
    verification['scope_proof']=read(HERE/'scope-preseal.json')
    save(dest/'local-verification.json',verification)
    report=(dest/'report.md').read_text(encoding='utf-8').replace('It will honestly finish FAIL, with separate structural validation, without editing its trace.','It actually finished FAIL (finish CLI0), and separate direct structural validation returned0; all command starts/finishes match and the trace was not edited.')
    report+=f'\nDevelopment Control actually returned0 ({development["elapsed_seconds"]}s including Recorder-wrapper overhead). Clean committed Acceptance follows the single commit and is sealed externally.\n'
    (dest/'report.md').write_text(report,encoding='utf-8',newline='\n')
    selected=[p for p in HERE.rglob('*') if p.is_file() and not any(part in ('go-cache','go-tmp') for part in p.relative_to(HERE).parts) and p.name not in ('local-originals.zip','zip-manifest.json','artifact-manifest.json','final-receipt.json','final-report.md')]
    manifest=[{'path':p.relative_to(HERE).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(selected)]
    save(HERE/'zip-manifest.json',{'scope':'This Fix new external originals only; no prior sealed evidence copied or edited; cache/temp excluded','files':manifest})
    archive=dest/'local-originals.zip'
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
        for p in selected: z.write(p,p.relative_to(HERE).as_posix())
        z.write(HERE/'zip-manifest.json','zip-manifest.json')
    with zipfile.ZipFile(archive) as z:
        for row in manifest:
            raw=z.read(row['path'])
            assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
    binding={'archive':'local-originals.zip','bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'manifest_entries':len(manifest),'zip_manifest_sha256':sha((HERE/'zip-manifest.json').read_bytes()),'all_archived_entries_read_back':True,'sealed_R3_input':{'receipt_sha256':'fd8dbbfc9a4e1f2b814525cb0aa4887fa578b3e5b0763ad93611b9293b8cf5e8','coordinator_artifacts':154,'Standards_artifacts':222,'Spec_artifacts':161},'external_final_receipt':str(HERE/'final-receipt.json'),'new_independent_acceptance':'PENDING'}
    save(dest/'original-bindings.json',binding)
    print(json.dumps(binding,indent=2))
elif mode=='commit':
    assert Path(git('precommit-root','rev-parse','--show-toplevel').decode().strip()).resolve()==REPO
    assert git('precommit-head','rev-parse','HEAD').decode().strip()=='a9bb4877d9b7c2ff6f9687278504bccda0cb7aab'
    assert git('precommit-branch','branch','--show-current').decode().strip()=='task/LOOP1-GROUP-001'
    assert git('precommit-staged','diff','--cached','--name-only','-z')==b''
    git('stage-owned','add','--',*OWN)
    staged=git('staged-names','diff','--cached','--name-only','-z')
    assert set(staged.decode().strip('\0').split('\0'))==set(OWN)
    git('staged-whitespace','diff','--cached','--check')
    git('single-commit','commit','-m','Preserve group authentication precedence for large JSON numbers')
    commit=git('commit-sha','rev-parse','HEAD').decode().strip()
    parent=git('commit-parent','rev-parse','HEAD^').decode().strip()
    assert parent=='a9bb4877d9b7c2ff6f9687278504bccda0cb7aab'
    assert git('committed-clean','status','--porcelain=v1','--untracked-files=all')==b''
    save(HERE/'commit-receipt.json',{'commit':commit,'parent':parent,'branch':'task/LOOP1-GROUP-001','paths':OWN,'single_commit':True,'status_entries':0})
    print('FROZEN_COMMIT '+commit)
elif mode=='acceptance':
    assert git('before-Acceptance-clean','status','--porcelain=v1','--untracked-files=all')==b''
    _,result=call('control-Acceptance',[PW,'-NoProfile','-File','tools/verify-loop1-ctrl-002.ps1','-Mode','Acceptance'])
    assert git('after-Acceptance-clean','status','--porcelain=v1','--untracked-files=all')==b''
elif mode=='seal':
    commit=read(HERE/'commit-receipt.json')
    actual=git('final-head','rev-parse','HEAD').decode().strip()
    assert actual==commit['commit']
    assert git('final-status','status','--porcelain=v1','--untracked-files=all')==b''
    assert git('final-working','diff','--exit-code')==b'' and git('final-staged','diff','--cached','--exit-code')==b''
    source=read(HERE/'scope-postcommit.json')
    assert source['result']=='PASS' and source['head']==actual
    acceptance=read(HERE/'tail/control-Acceptance/result.json')
    assert acceptance['exit_code']==0
    pg=read(HERE/'owned-pg.json');nats=read(HERE/'owned-nats.json');closure=read(HERE/'recorder-closure.json')
    assert pg['cleaned'] and pg['preservation_pass'] and nats['cleaned'] and nats['preservation_pass']
    owned=[]
    for path in OWN:
        blob=git('blob-'+str(len(owned)),'rev-parse','HEAD:'+path).decode().strip()
        raw=(REPO/path).read_bytes()
        owned.append({'path':path,'git_blob':blob,'bytes':len(raw),'raw_sha256':sha(raw)})
    report=f'Fresh backend numeric Fix R2 frozen at {actual}, parent a9bb4877; single commit/eight owned paths, clean state. Normal51.719s/race111.610s each native0, 72 main/281 including subtests/86 Group, no failures/skips. Original/formal real RED→GREEN, prior UTF-8 and all old lines preserved. Own schema/NATS cleaned; nonowned preservation PASS. Development0 and clean committed Acceptance0/{acceptance["elapsed_seconds"]}s. Recorder honest partial FAIL, finish0/direct structural validation0, matched commands. Fresh final-SHA ordinary and different error reviews remain PENDING; no push/PR/CI/merge/main-sync/Taskdone/client work. All Fix source/runtime leases RELEASED for coordinator independent readback. Full GROUP active/group_product/S2 OPEN, accepted LKG/main79 remains. See final-receipt.json for exact bindings.\n'
    (HERE/'final-report.md').write_text(report,encoding='utf-8',newline='\n')
    files=[p for p in HERE.rglob('*') if p.is_file() and not any(part in ('go-cache','go-tmp') for part in p.relative_to(HERE).parts) and p.name not in ('artifact-manifest.json','final-receipt.json')]
    manifest=[{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(files)]
    save(HERE/'artifact-manifest.json',{'scope':'Fresh Fix external artifacts; cache/temp and this manifest/final receipt excluded; prior sealed evidence immutable','files':manifest})
    receipt={'result':'FIX_LOCAL_COMPLETE_PENDING_FRESH_INDEPENDENT_REVIEWS','owner':'/root/backend_go_fix_r2','fresh_context':'No candidate implementation/previous Fix/review involvement','task':'LOOP1-GROUP-001','state':'active/group_product','S2_gate':'OPEN','assigned_root':str(REPO),'branch':commit['branch'],'final_sha':actual,'parent':commit['parent'],'accepted_fixed_base_and_main':'79d39dcbd045597ccc5abd459edd388eed269254','single_commit':True,'status_entries':0,'owned_blobs':owned,'source_protection':source,'original_probe':'14controls/4FAIL native1 -> 14/0 native0 unchanged original','formal_regression':'24leaves/4FAIL before -> 24/0 with27 parent-inclusive results; four authenticated400/no-effect cases in both complete Go runs','whole_go':{k:read(HERE/f'whole-{k}.json') for k in ('normal','race')},'Development_Control':read(HERE/'commands/control-Development/result.json'),'clean_committed_Acceptance':acceptance,'runtime_cleanup':{'PG':pg,'NATS':nats,'root_pg_and_passfile':'Retained for root; last qualified originaldata-v2/PID40320; contents never read/hash/copied/printed'},'Recorder':closure,'known_observer_failures':'Initial manifest-key and missing read-path observations, first PG connection refused, truncated displays, one omitted tool terminal-session metadata resolved by completed durable result before another Recorder command; all originals retained. Root PG recovery failures belong to its linked proof and are not rewritten.','tail':'Actual direct packaging/commit/clean Control/final protection/sealing after Recorder closure; not fabricated prospective trace','manifest':{'path':str(HERE/'artifact-manifest.json'),'sha256':sha((HERE/'artifact-manifest.json').read_bytes()),'files':len(manifest)},'report':{'path':str(HERE/'final-report.md'),'sha256':sha((HERE/'final-report.md').read_bytes())},'source_lease':'RELEASED_FROZEN_FINAL_SHA','runtime_lease':'RELEASED_OWN_SCHEMA_NATS_REMOVED_ROOT_PG_RETAINED','regular_review':'NEW_FRESH_PENDING_FINAL_SHA','error_specialist':'DIFFERENT_NEW_FRESH_PENDING_AFTER_NEW_REGULAR_PASS','publication':'NOT_PERFORMED_BY_FIX_OWNER','hosted_acceptance':'PENDING_NOT_ACCEPTED','main_sync':'PENDING_NOT_PERFORMED_NOT_AUTHORIZED_THIS_ROUND','full_GROUP_G01_G09_clients_Architect':'PENDING','next':'Coordinator independently bind final receipt/source/clean evidence; NEW fresh regular -> DIFFERENT NEW error specialist on this SHA -> only both PASS permit backend PR -> STOP per Human.'}
    save(HERE/'final-receipt.json',receipt)
    print(json.dumps({'final_sha':actual,'receipt_sha256':sha((HERE/'final-receipt.json').read_bytes()),'manifest_files':len(manifest),'source_lease':receipt['source_lease'],'runtime_lease':receipt['runtime_lease'],'acceptance_native_seconds':acceptance['elapsed_seconds']},indent=2))
else:
    raise ValueError(mode)
