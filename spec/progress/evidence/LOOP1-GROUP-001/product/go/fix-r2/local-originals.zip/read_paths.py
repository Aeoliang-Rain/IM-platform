from pathlib import Path
import sys

for arg in sys.argv[1:]:
    path = Path(arg)
    print(f'\n=== {path.as_posix()} ===', flush=True)
    print(path.read_text(encoding='utf-8'), flush=True)
