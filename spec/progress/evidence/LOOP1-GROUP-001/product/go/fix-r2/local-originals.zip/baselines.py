import json
import os
from pathlib import Path
import subprocess
import sys

HERE=Path(__file__).resolve().parent
PY=r'C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
commands=[('baseline-frozen',[PY,'-Xutf8','-B','tools/verify_frozen_architecture.py']),('baseline-planning',[PY,'-Xutf8','-B','ci/check_s2_planning.py']),('baseline-architecture',[PY,'-Xutf8','-B','ci/check_architecture.py','--scope','all','--json']),('baseline-architecture-tests',[PY,'-Xutf8','-B','-m','unittest','discover','-s','tests/architecture','-p','test_*.py','-v']),('baseline-ci-tests',[PY,'-Xutf8','-B','-m','unittest','discover','-s','tests/ci','-p','test_*.py','-v'])]
for label,argv in commands:
    # run.py stores every byte, while this terminal reports only the actual native outcome.
    result=subprocess.run([PY,'-Xutf8','-B',str(HERE/'run.py'),label,'--',*argv],capture_output=True)
    sys.stderr.buffer.write(result.stderr[-500:])
    record=json.loads((HERE/'commands'/label/'result.json').read_text(encoding='utf-8'))
    print(json.dumps({'label':label,'exit_code':result.returncode,'elapsed_seconds':record['elapsed_seconds']}),flush=True)
    if result.returncode:
        sys.exit(result.returncode)
