import hashlib
import json
from pathlib import Path
import subprocess

HERE=Path(__file__).resolve().parent
REPO=Path('H:/.codex/worktrees/group/IM-platform').resolve()
root=subprocess.run(['git','rev-parse','--show-toplevel'],cwd=REPO,capture_output=True,check=True).stdout.decode().strip()
assert Path(root).resolve()==REPO
assert subprocess.run(['git','rev-parse','HEAD'],cwd=REPO,capture_output=True,check=True).stdout.decode().strip()=='a9bb4877d9b7c2ff6f9687278504bccda0cb7aab'
path=REPO/'backend/go/core/group_test.go'
raw=path.read_bytes()
before={x['path']:x for x in json.loads((HERE/'before-tracked.json').read_text(encoding='utf-8'))}
assert hashlib.sha256(raw).hexdigest()==before['backend/go/core/group_test.go']['sha256']
(HERE/'before-group_test.go').write_bytes(raw)
nl=b'\r\n' if b'\r\n' in raw else b'\n'
anchor=b'\t\t\t\t{"non-object-before-shape", "null", "AUTH_REQUIRED", 401, false},'+nl
add=[
    '\t\t\t\t{"number-before-shape", "1", "AUTH_REQUIRED", 401, false},',
    '\t\t\t\t{"large-number-before-shape", "1e9999", "AUTH_REQUIRED", 401, false},',
    '\t\t\t\t{"large-negative-number-before-shape", "-1e9999", "AUTH_REQUIRED", 401, false},',
    '\t\t\t\t{"small-number-before-shape", "1e-9999", "AUTH_REQUIRED", 401, false},',
    '\t\t\t\t{"string-before-shape", `"text"`, "AUTH_REQUIRED", 401, false},',
    '\t\t\t\t{"broken-number", "1e", "VALIDATION_FAILED", 400, false},',
]
assert raw.count(anchor)==1
changed=raw.replace(anchor,anchor+nl.join(x.encode() for x in add)+nl)
anchor2=b'\t\t{"auth-before-shape", "null", "/v1/groups", "", "application/json", 401, "AUTH_REQUIRED"},'+nl
add2=[
    '\t\t{"large-number-shape", "1e9999", "/v1/groups", f.tokens[0], "application/json", 400, "VALIDATION_FAILED"},',
    '\t\t{"large-negative-number-shape", "-1e9999", "/v1/groups", f.tokens[0], "application/json", 400, "VALIDATION_FAILED"},',
    '\t\t{"add-large-number-shape", "1e9999", "/v1/groups/" + f.users[0] + "/members", f.tokens[0], "application/json", 400, "VALIDATION_FAILED"},',
    '\t\t{"add-large-negative-number-shape", "-1e9999", "/v1/groups/" + f.users[0] + "/members", f.tokens[0], "application/json", 400, "VALIDATION_FAILED"},',
]
assert changed.count(anchor2)==1
changed=changed.replace(anchor2,anchor2+nl.join(x.encode() for x in add2)+nl)
path.write_bytes(changed)
assert hashlib.sha256((REPO/'backend/go/core/group.go').read_bytes()).hexdigest()==before['backend/go/core/group.go']['sha256']
print(json.dumps({'result':'test cases appended only','missing_bearer_cases_added':6,'authenticated_shape_cases_added':4,'root':root,'sha256':hashlib.sha256(changed).hexdigest()}))
