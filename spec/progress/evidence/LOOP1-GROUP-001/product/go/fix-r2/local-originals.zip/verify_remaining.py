import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
OLD=HERE.parent/'backend-go-regular-r3'
manifest=json.loads((OLD/'spec/artifact-manifest.json').read_text(encoding='utf-8'))
entries=manifest['artifacts']
for item in entries:
    raw=Path(item['path']).read_bytes()
    assert len(raw)==item['bytes'] and hashlib.sha256(raw).hexdigest()==item['sha256'], item['path']
numeric=json.loads((OLD/'spec/numeric-probe-originals.json').read_text(encoding='utf-8'))
for key in ['driver','stdout','stderr']:
    item=numeric[key]
    raw=Path(item['path']).read_bytes()
    assert len(raw)==item['bytes'] and hashlib.sha256(raw).hexdigest()==item['sha256'], key
result={'result':'PASS','verified_r3_artifacts':{'coordinator':154,'standards':222,'spec':len(entries)},'authority_items':83,'tracked_snapshot_items':len(json.loads((HERE/'before-tracked.json').read_text(encoding='utf-8'))),'known_observer_failure':'First original-manifest observer assumed files key for Spec manifest, actual key artifacts. Failed command retained; no product/source effect.','numeric_original_exit':numeric['command_finished']['data']['exit_code']}
(HERE/'startup-proof.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(result,indent=2))
