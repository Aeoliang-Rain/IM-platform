import hashlib
import json
from pathlib import Path
import subprocess

HERE=Path(__file__).resolve().parent
REPO=Path('H:/.codex/worktrees/group/IM-platform').resolve()
PREFIX='spec/progress/evidence/LOOP1-GROUP-001/product/go/fix-r2'
FINAL=str(HERE/'final-receipt.json')
assert Path(subprocess.run(['git','rev-parse','--show-toplevel'],cwd=REPO,capture_output=True,check=True).stdout.decode().strip()).resolve()==REPO
normal=json.loads((HERE/'whole-normal.json').read_text(encoding='utf-8'))
race=json.loads((HERE/'whole-race.json').read_text(encoding='utf-8'))
for item in [normal,race]:
    assert item['exit_code']==0 and item['passes']==281 and len(item['main_methods'])==72 and len(item['group_passes'])==86
    assert not item['failures'] and not item['skips']
    assert all(hashlib.sha256((REPO/p).read_bytes()).hexdigest()==h for p,h in item['source_hashes'].items())
pg=json.loads((HERE/'owned-pg.json').read_text(encoding='utf-8'))
nats=json.loads((HERE/'owned-nats.json').read_text(encoding='utf-8'))
assert pg['cleaned'] and pg['preservation_pass'] and nats['cleaned'] and nats['preservation_pass'] and nats['before_cleanup_preservation_pass']
commands={p.parent.name:json.loads(p.read_text(encoding='utf-8')) for p in (HERE/'commands').glob('*/result.json')}
required=['baseline-frozen','baseline-planning','baseline-architecture','baseline-architecture-tests','baseline-ci-tests','original-numeric-green','formal-numeric-green','final-gofmt','final-frozen','final-planning','final-architecture','group-contract','group-suite','auth-contract','sync-contract','sync-suite','wss-contract','plugin-contract','whole-go-normal','whole-go-race']
assert all(commands[k]['exit_code']==0 for k in required)
assert commands['original-numeric-red']['exit_code']==1 and commands['formal-numeric-red']['exit_code']==1
verification={'scope':'Local numeric Fix R2 evidence only, never independent acceptance','base_candidate':'a9bb4877d9b7c2ff6f9687278504bccda0cb7aab','accepted_fixed_base':'79d39dcbd045597ccc5abd459edd388eed269254','finding':'BACKEND-GO-SPEC-R3-P2-001','repair':'Exactly one Decoder.UseNumber call; ten table rows appended, all prior source/test lines retained','original_probe':{'red':{'exit':1,'controls':14,'failures':4},'green':{'exit':0,'controls':14,'failures':0}},'formal_missing_bearer':{'red':{'exit':1,'failing_leaf_cases':4,'passing_leaf_controls':20},'green':{'exit':0,'leaf_cases':24,'results_with_parents':27,'skips':0}},'authenticated_shapes':'Four added numeric-shape cases executed in both complete Go runs; 400 VALIDATION_FAILED and zero new effects on both POST routes','whole_go':{'normal':normal,'race':race},'commands':commands,'timing_note':'commands elapsed_seconds include Recorder-wrapper overhead; whole_go elapsed_seconds are actual native Go child durations from the standard runtime driver. Raw command argv/exit/timing are preserved.','owned_pg_cleanup':pg,'owned_nats_cleanup':nats,'minimum_baseline_tests':{'architecture':{'tests':88,'existing_skips':1},'ci':{'tests':35,'existing_skips':4}},'group_contract_tests':{'tests':29,'skips':0},'review':'NEW fresh regular then different NEW fresh error specialist pending final committed SHA','hosted_acceptance':'PENDING_NOT_ACCEPTED','main_sync':'PENDING_NOT_AUTHORIZED_THIS_ROUND','full_GROUP_G01_G09_clients_Architect':'PENDING','task':'active/group_product','S2':'OPEN','final_commit_clean_control_and_recorder':'Resolve external final-receipt.json after the single commit; no recursive self-SHA metadata commit'}
dest=REPO/PREFIX
dest.mkdir(parents=True,exist_ok=False)
(dest/'local-verification.json').write_text(json.dumps(verification,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
report=f'''# Backend numeric Fix R2 local evidence

Fresh Fix context `/root/backend_go_fix_r2` repaired the sole R3 Spec P2 at clean a9bb4877. The existing bounded decoder now calls `UseNumber` before reading its top-level token. JSON syntax/UTF-8/duplicates, post-authentication shape order, correlation/no-store and all transactions, locks, receipts, paging and unknown-error propagation remain.

Original real HTTP probe: RED native1 (14 controls, four extreme-number EOF/panic failures) → unchanged probe GREEN0 (14/0). Existing HTTP regression tables only gain six missing-Bearer controls on both routes and four authenticated shape cases. Formal RED has four failing leaves/twenty passing controls; GREEN has 24 leaves/27 results, no skips. Prior UTF-8 assertions/helpers and every original line remain.

Whole Go normal native0/{normal['elapsed_seconds']}s and race native0/{race['elapsed_seconds']}s each execute 72 main tests/281 including subtests/86 Group results, no test failures/skips and two packages without tests. Four new authenticated shape cases reject400 without effects. Exact argv, child environment boundaries and source hashes are in `local-verification.json` and the raw archive.

All five startup baselines pass (architecture88/skip1, CI35/skip4). Final Frozen/planning/all-architecture, group verifier/29 tests without skips and old Auth/Sync4/WSS/Plugin pass; gofmt diff is empty. Development/clean committed Acceptance and Recorder actual closure are bound after their execution by the external receipt below.

Initial PG qualification actually refused the connection before any schema was created. Coordinator restored only its original data-v2; this Fix hash-bound that proof, refreshed only its new external driver's stale expected PID to40320, then independently qualified identity/PID. Canonical status/up/status ran in a fresh owned schema with exact search_path and path-only libpq credentials. Owned schema and owner-qualified loopback NATS were removed; nonowned schema/container/volume preservation passes. Root PostgreSQL/passfile remain for coordinator cleanup. Pre-drop counts, including any residual owned Outbox rows, are recorded without claiming empty tables.

Observer helper failures and all historical failures are preserved. Recorder is prospective_resume/partial; direct startup/helper authoring/communication and postclosure commit/control/sealing gaps are disclosed. It will honestly finish FAIL, with separate structural validation, without editing its trace. Local tests/Recorder do not accept the candidate.

Final committed SHA, clean Control, artifacts and released leases: `{FINAL}`. Fresh regular and different fresh error reviews must both cover that final SHA before coordinator publication. No push/PR/CI/merge/main-sync/client work/Task done by this Fix. GROUP active/group_product, S2 OPEN; accepted LKG/main remains79d39dcbd045597ccc5abd459edd388eed269254.
'''
(dest/'report.md').write_text(report,encoding='utf-8',newline='\n')
task=REPO/'spec/tasks/active/LOOP1-GROUP-001.md'
text=task.read_bytes().decode('utf-8')
assert 'owner: /root/backend_go_fix_r1' in text
text=text.replace('owner: /root/backend_go_fix_r1','owner: /root/backend_go_fix_r2',1).replace('product_owner: /root/backend_go_fix_r1','product_owner: /root/backend_go_fix_r2',1)
text=text.replace('backend_regular_review: R1_FAIL_AT_bda9a962_SPEC_P2_001_FIXED_NEW_FRESH_REVIEW_PENDING_FINAL_FIX_SHA','backend_regular_review: R3_FAIL_AT_a9bb4877_SPEC_P2_001_FIXED_NEW_FRESH_REVIEW_PENDING_FINAL_FIX_R2_SHA',1)
text=text.replace('backend_error_handling_review: DIFFERENT_NEW_FRESH_SPECIALIST_PENDING_FINAL_FIX_SHA_AFTER_NEW_REGULAR_PASS','backend_error_handling_review: DIFFERENT_NEW_FRESH_SPECIALIST_PENDING_FINAL_FIX_R2_SHA_AFTER_NEW_REGULAR_PASS',1)
nl='\r\n' if '\r\n' in text else '\n'
section=f'''# Backend numeric Fix R2 local outcome

Fresh owner `/root/backend_go_fix_r2` recovered exact assigned root/branch/clean a9bb4877, read authority and all five baselines, verified83 authority items and537 sealed R3 originals. R3 regular FAIL has Standards0/Spec1 P2 BACKEND-GO-SPEC-R3-P2-001. Its original numeric probe is genuinely RED1→GREEN0 (14 controls/four extreme ±number failures→zero). Minimal source repair is one standard-library `Decoder.UseNumber` call; existing real HTTP tables only append ten rows, retaining every old source/test line and UTF-8 regression. Missing Bearer obeys401 before nonobject shape; four authenticated cases obey400 with zero effects on both routes.

Final-source whole Go normal native0/{normal['elapsed_seconds']}s and race native0/{race['elapsed_seconds']}s each72 main/281 including subtests/86 Group, zero test failures/skips, two no-test packages. Frozen/planning/all-architecture, group35valid30invalid/29 methods zero skip and old Auth/Sync4/WSS/Plugin pass; startup architecture88(skip1)/CI35(skip4) are explicit. Runtime identity/own schema/canonical migrations/loopback NATS and precise cleanup/nonown preservation pass. Initial connection-refused qualification created no resources; root recovered only originaldata-v2, independently requalified by this Fix as PID40320. No passfile contents were read/hash/copied/printed.

Details and raw originals: `{PREFIX}/report.md` and `local-verification.json`/new archive. Research prospective_resume/partial and original observer failures remain honest; actual finish FAIL/direct structural validation, Development, single commit, clean committed Acceptance, final SHA and lease RELEASED are externally sealed at `{FINAL}`. No recursive self-SHA commit. Fresh regular and different fresh error specialist on the NEW final SHA remain PENDING; only two PASS permit coordinator push/new backend PR, then STOP per Human. No merge/main-sync/Taskdone/client continuation; GROUP active/group_product, S2 OPEN, accepted LKG/main79d39dcbd045597ccc5abd459edd388eed269254 remains. Historical R1 and prior Go/contract outcomes below are preserved.

'''
anchor='# Backend UTF-8 Fix R1 Local Outcome'
assert text.count(anchor)==1
text=text.replace(anchor,section.replace('\n',nl)+anchor,1)
task.write_bytes(text.encode('utf-8'))
current=REPO/'spec/progress/current.md'
text=current.read_bytes().decode('utf-8')
nl='\r\n' if '\r\n' in text else '\n'
text=text.replace('Backend Regular Review: R1 FAIL at bda9a962 (Standards0/Spec1 P2-001); UTF-8 fixed, NEW fresh Standards+Spec PENDING final Fix SHA','Backend Regular Review: R3 FAIL at a9bb4877 (Standards0/Spec1 P2-001); numeric token fixed, NEW fresh Standards+Spec PENDING final Fix R2 SHA',1)
text=text.replace('Backend Error Review: DIFFERENT NEW fresh specialist PENDING same final Fix SHA after new regular PASS','Backend Error Review: DIFFERENT NEW fresh specialist PENDING same final Fix R2 SHA after new regular PASS',1)
start=text.index('Backend Fix R1 repairs the sole regular Spec P2')
end=text.index('首契约candidate',start)
text=text[:start]+f'Backend Fix R2 repairs the sole R3 Spec P2 legal-number overflow before authentication with one Decoder.UseNumber call and ten appended existing-table rows. Original probe/formal regression are real RED→GREEN; prior UTF-8/all old assertions remain. Full Go normal/race each72 main/281 including subtests/86 Group, zero test failures/skips; two no-test packages. Own runtime cleaned and nonown preservation PASS. Single commit/clean Control and actual final SHA follow the sealed external fix-r2 receipt. New dual review/PR acceptance remains PENDING. Details: `{PREFIX}/report.md`. Older owner/next-action paragraphs are historical.'+nl+nl+text[end:]
start=text.index('## Verification')+len('## Verification')
end=text.index('首Go最终',start)
new=f'''

- Command: `go test -count=1 -timeout=5m -json ./...`
  - Result: final fixed source, real owned PG/NATS, native0/{normal['elapsed_seconds']}s;72 main/281 including subtests/86 Group, zero test failure/skip; two no-test packages.
  - Evidence: `{PREFIX}/local-verification.json`
- Command: `go test -race -count=1 -timeout=5m -json ./...`
  - Result: identical frozen source/resources, native0/{race['elapsed_seconds']}s; same72/281/86 and zero test failure/skip. Original numeric probe14/four FAIL→14/0; formal missing-Bearer RED4 failures/20 controls→GREEN27 results, plus four authenticated400/no-effect cases in each full run. Authority/group29/old contracts all0; startup architecture88(skip1)/CI35(skip4).
  - Evidence: `{PREFIX}/local-verification.json`

'''
text=text[:start]+new.replace('\n',nl)+text[end:]
old='Fix R1 changes only group.go original UTF-8 validation, one actual HTTP regression in group_test.go, Task/current and new `product/go/fix-r1/` evidence. Existing http.go/social.go and all prior20-path evidence/authority/client/CI bytes remain.'
new='Fix R2 adds only one group.go UseNumber call and ten rows in existing group_test.go HTTP tables, Task/current and new thin `product/go/fix-r2/` evidence. All old source/test lines, including prior UTF-8 validation, http.go/social.go, authority/contracts/clients/CI and old sealed evidence remain.'
assert old in text
text=text.replace(old,new,1)
anchor='## Known Failures, Risks, and Assumptions'
text=text.replace(anchor,anchor+nl+nl+'Fix R2 initial PG qualification returned connection refused before any schema/NATS creation; coordinator restored only originaldata-v2 and this Fix independently requalified PID40320 before owned runtime. Two missing-path read observers and a Spec-manifest key assumption failed and were corrected externally; originals remain. Recorder partial/FAIL and final clean Control/commit/lease facts resolve from the external fix-r2 receipt. Resource pre-drop counts are reported honestly; no root PG/passfile cleanup by this owner.',1)
start=text.index('## Next Exact Action')+len('## Next Exact Action')
end=text.index('## Last Known Good Commit',start)
text=text[:start]+(f'\n\nRoot independently binds `{FINAL}` actual final Fix R2 SHA/source/clean Control and released leases → wholly new Standards+Spec regular → different fresh error specialist on the SAME SHA. Only two PASS permit push/new backend PR; stop after PR creation per Human. No CI wait/merge/main-sync/Taskdone or client continuation. S2 OPEN/active/group_product; accepted LKG/main79 remains.\n\n').replace('\n',nl)+text[end:]
start=text.index('## Uncommitted Changes / Ownership')+len('## Uncommitted Changes / Ownership')
end=text.index('## Architecture Conflicts / ACP / ADR',start)
text=text[:start]+(f'\n\nFix R2 sole writer `/root/backend_go_fix_r2`, assigned exactroot H:/.codex/worktrees/group/IM-platform, branch task/LOOP1-GROUP-001; only two Go files, Task/current and new thin fix-r2 evidence owned here. Single final commit/clean state/source/runtime lease RELEASED are determined from sealed `{FINAL}`; no unknown main work is copied or modified. No push/PR/merge/sync by Fix owner.\n\n').replace('\n',nl)+text[end:]
current.write_bytes(text.encode('utf-8'))
print(json.dumps({'result':'Task/current and thin local evidence written','whole_normal_native_seconds':normal['elapsed_seconds'],'whole_race_native_seconds':race['elapsed_seconds'],'source_unchanged_after_tests':True,'current_state':'active/group_product/S2 OPEN; all independent reviews/PR/main sync pending'}))
