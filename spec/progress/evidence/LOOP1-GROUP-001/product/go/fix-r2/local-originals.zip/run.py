import json
import os
from pathlib import Path
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
REPO = Path('H:/.codex/worktrees/group/IM-platform')
PY = r'C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
RUN = 'R-GROUP-BACKEND-GO-FIX-R2-20261023'
label = sys.argv[1]
command = sys.argv[2:]
if command and command[0] == '--':
    command = command[1:]
target = HERE / 'commands' / label
target.mkdir(parents=True, exist_ok=False)
argv = [PY, '-Xutf8', '-B', str(REPO / 'tools/research/recorder.py'),
        'run-command', '--repo', str(REPO), '--research-root', str(HERE / 'research'),
        '--run-id', RUN, '--', *command]
env = os.environ.copy()
env['PYTHONDONTWRITEBYTECODE'] = '1'
start = time.monotonic()
result = subprocess.run(argv, cwd=REPO, env=env, capture_output=True)
(target / 'stdout.bin').write_bytes(result.stdout)
(target / 'stderr.bin').write_bytes(result.stderr)
record = {'argv': argv, 'exit_code': result.returncode, 'elapsed_seconds': round(time.monotonic()-start, 6)}
(target / 'result.json').write_text(json.dumps(record, ensure_ascii=False, indent=2)+'\n', encoding='utf-8', newline='\n')
sys.stdout.buffer.write(result.stdout)
sys.stderr.buffer.write(result.stderr)
print(json.dumps({'label': label, 'exit_code': result.returncode, 'elapsed_seconds': record['elapsed_seconds']}), flush=True)
sys.exit(result.returncode)
