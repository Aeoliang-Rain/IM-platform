import collections
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
events=[json.loads(line) for line in (HERE/'research/runs/R-GROUP-BACKEND-GO-FIX-R2-20261023/events.jsonl').read_text(encoding='utf-8').splitlines()]
starts={x['data']['command_id']:x for x in events if x['event_type']=='command_started'}
finishes={x['data']['command_id']:x for x in events if x['event_type']=='command_finished'}
pending=set(starts)-set(finishes)
assert len(pending)==1  # This currently executing audit command only.
current=starts[next(iter(pending))]['data']['argv']
assert current[-1].replace('\\','/').endswith('/backend-go-fix-r2/resume_audit.py')
commands=[x['data']['argv'] for x in starts.values()]
runtime_commands=[c for c in commands if any(s in ' '.join(c) for s in ['pg-setup','nats-setup','whole-normal','whole-race','psql.exe','pg_ctl.exe','docker run'])]
assert not runtime_commands
assert not (HERE/'owned-pg.json').exists() and not (HERE/'owned-nats.json').exists()
result={'prior_command_starts':len(starts)-1,'prior_command_finishes':len(finishes),'prior_unmatched_commands':0,'active_command':'This read-only resume audit only','temporary_resources_created_by_this_fix':'No PG schema or NATS; original and formal HTTP probes closed their owned listeners and have exited. Get-Process inspection showed no go or http_number_probe process.','runtime_operations':runtime_commands,'current_repository_writes':['backend/go/core/group.go','backend/go/core/group_test.go'],'production_fix':'GREEN, no rerun needed','formal_green':'native exit0; 24 leaf cases, 27 results with parents; authenticated cases pending real PG whole Go'}
(HERE/'resume-state.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
