import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
proof=HERE.parent/'coordinator-resume-20261023/pg-recovery-qualified.json'
assert hashlib.sha256(proof.read_bytes()).hexdigest()=='b16477a062e03592715aac0f08f4285c861983d4bea8f3a7753025dff53b4688'
qualified=json.loads(proof.read_text(encoding='utf-8'))
assert qualified['identity_qualified'] and all(qualified['checks'].values())
assert qualified['actual_postmaster_pid']==40320 and not qualified['new_instance_created']
path=HERE/'runtime.py'
raw=path.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='a7817c33e6959b1a89eb99f4bd45341b9407cbbc324c49266167d0417cdc61dd'
assert raw.count(b'49572')==2
(HERE/'runtime-before-pid-refresh.py').write_bytes(raw)
changed=raw.replace(b'49572',b'40320')
path.write_bytes(changed)
binding={'root_proof':str(proof),'root_proof_sha256':hashlib.sha256(proof.read_bytes()).hexdigest(),'old_expected_pid':49572,'new_expected_pid':40320,'change':'Only two stale expected PID literals in this new run-owned driver; original R1 driver remains immutable. Fresh local qualify still mandatory before resources.','new_driver_sha256':hashlib.sha256(changed).hexdigest()}
(HERE/'runtime-pid-refresh-binding.json').write_text(json.dumps(binding,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(binding,indent=2))
