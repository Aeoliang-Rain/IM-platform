import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
source=HERE.parent/'backend-go-fix-r1/runtime.py'
raw=source.read_bytes()
text=raw.decode('utf-8')
replacements={'BACKEND-GO-FIX-R1-20261020':'BACKEND-GO-FIX-R2-20261023','backend-go-fix-r1':'backend-go-fix-r2','backend_go_fix_r1_':'backend_go_fix_r2_'}
for old,new in replacements.items():
    assert old in text
    text=text.replace(old,new)
target=HERE/'runtime.py'
assert not target.exists()
target.write_text(text,encoding='utf-8',newline='\n')
for name in ['go-cache','go-tmp']:
    (HERE/name).mkdir(exist_ok=False)
binding={'source':str(source),'source_bytes':len(raw),'source_sha256':hashlib.sha256(raw).hexdigest(),'new_driver':str(target),'new_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'changes':replacements,'runtime_created':False,'credential_handling':'Only the existing PGPASSFILE path is passed to libpq. Its contents are never read, hashed, copied or printed.'}
(HERE/'runtime-driver-binding.json').write_text(json.dumps(binding,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(binding,indent=2))
