import hashlib,json,os,pathlib,subprocess
from pg_run import OUT,ROOT,save

baseline=OUT.parent/'product-r2-phase1-before-coordinator.json'
expected='16e064e761ec46579a567acb456fc3c984cca0fc39932214c507f793a20deb68'
if hashlib.sha256(baseline.read_bytes()).hexdigest()!=expected:raise RuntimeError('coordinator protection baseline changed')
d=json.loads(baseline.read_text())
allowed={'backend/go/core/http.go','backend/go/core/social.go','spec/progress/current.md','spec/tasks/active/LOOP1-GROUP-001.md'}
def git(*args):
    r=subprocess.run(['git',*args],cwd=ROOT,capture_output=True)
    if r.returncode:raise RuntimeError('git '+str(args)+' failed: '+r.stderr.decode())
    return r.stdout
actualroot=git('rev-parse','--show-toplevel').decode().strip()
if os.path.normcase(os.path.normpath(actualroot))!=os.path.normcase(os.path.normpath(str(ROOT))):raise RuntimeError('WORKSPACE_ERROR')
unchanged=[];changed=[]
for name,old in d['files'].items():
    p=ROOT/name
    if not p.is_file():raise RuntimeError('baseline file missing: '+name)
    data=p.read_bytes();entry={'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
    if entry['sha256']==old['sha256']:unchanged.append(entry)
    elif name in allowed:changed.append({'path':name,'before':old,'after':entry})
    else:raise RuntimeError('out-of-scope baseline file changed: '+name)
if {c['path'] for c in changed}!=allowed:raise RuntimeError('expected changed metadata/Go set differs')
flags=git('ls-files','-v').decode().split('\n');entries=git('ls-files','--stage').decode().split('\n');cached=git('diff','--cached','--binary')
if flags!=d['index_flags'] or entries!=d['index_entries'] or hashlib.sha256(cached).hexdigest()!=d['cached_diff_sha256']:raise RuntimeError('pre-stage index changed')
status=git('status','--porcelain=v1','--untracked-files=all').decode()
new_allowed={'backend/go/core/group.go','backend/go/core/group_test.go','spec/progress/checkpoints/2026-10-20-group-contract-accepted.md','spec/progress/checkpoints/2026-10-20-group-go-local.md'}
for line in status.splitlines():
    path=line[3:]
    if path not in allowed|new_allowed and not path.startswith('spec/progress/evidence/LOOP1-GROUP-001/product/'):raise RuntimeError('unexpected status path: '+line)
task=(ROOT/'spec/tasks/active/LOOP1-GROUP-001.md').read_text();current=(ROOT/'spec/progress/current.md').read_text()
locations=[p.relative_to(ROOT).as_posix() for q in ['review','active','ready','backlog','done'] for p in (ROOT/'spec/tasks'/q).glob('LOOP1-GROUP-001.md')]
if locations!=['spec/tasks/active/LOOP1-GROUP-001.md'] or '\nstatus: active\n' not in task or 'client_supplement_phase: group_product' not in task or current.count('Current Task: LOOP1-GROUP-001')!=1 or 'Current Stage: S2' not in current or 'Gate Status: OPEN' not in current:raise RuntimeError('unique current/active state differs')
result={'result':'PASS_PRESTAGE_SCOPE_ONLY','baseline_path':str(baseline),'baseline_sha256':expected,'root':actualroot,'head':git('rev-parse','HEAD').decode().strip(),'branch':git('branch','--show-current').decode().strip(),'baseline_file_count':len(d['files']),'unchanged_count':len(unchanged),'changed':changed,'unchanged':unchanged,'index_flags_unchanged':True,'index_entries_unchanged':True,'cached_diff_unchanged':True,'status':status,'task_locations':locations,'current_file_exists':True}
save('prestage-scope-proof.json',result)
(OUT/'prestage.diff').write_bytes(git('diff','--binary'))
print(json.dumps({'result':result['result'],'unchanged':len(unchanged),'changed':[c['path']for c in changed],'status':status},indent=2))
