"""Own loopback NATS only, using the repository's accepted image profile."""
import json, pathlib, re, socket, subprocess, sys, time, uuid
from pg_run import OUT, ROOT, command, save

RECEIPT=OUT/'owned-nats-fixture.json'
OWNER='R-GROUP-PRODUCT-R2-GO-20261020'

def docker(label,*args):
    import os
    return command(label,['docker',*args],os.environ.copy()).stdout.decode('utf8').strip()

def inventory():
    ids=docker('docker-container-ids','ps','-aq').splitlines()
    containers=[]
    for ident in ids:
        fmt='{{json .Id}} {{json .Name}} {{json .State}} {{json .Mounts}} {{json .Config.Labels}}'
        raw=docker('docker-container-public-inspect','inspect','--format',fmt,ident)
        decoder=json.JSONDecoder();items=[]
        while raw:
            value,n=decoder.raw_decode(raw);items.append(value);raw=raw[n:].lstrip()
        containers.append(dict(zip(['id','name','state','mounts','labels'],items)))
    volumes=docker('docker-volume-inventory','volume','ls','--format','{{json .}}').splitlines()
    return {'containers':containers,'volumes':[json.loads(v) for v in volumes]}

def main():
    action=sys.argv[1]
    if action=='setup':
        if RECEIPT.exists() and not json.loads(RECEIPT.read_text()).get('cleaned'):raise RuntimeError('owned NATS receipt already active')
        profile=(ROOT/'deploy/compose.yaml').read_bytes()
        if b'image: nats:2.10-alpine' not in profile:raise RuntimeError('accepted image declaration changed')
        before=inventory();name='group-product-r2-nats-'+uuid.uuid4().hex[:12]
        f={'owner':OWNER,'name':name,'image':'nats:2.10-alpine','before':before,'cleaned':False,'created':False}
        save(RECEIPT.name,f)
        ident=docker('docker-owned-nats-run','run','-d','--name',name,'--label','group-product-r2-owner='+OWNER,'-p','127.0.0.1::4222','nats:2.10-alpine')
        if not re.fullmatch('[0-9a-f]{64}',ident):raise RuntimeError('unexpected owned container ID')
        f.update(id=ident,created=True);save(RECEIPT.name,f)
        ports=json.loads(docker('docker-owned-nats-ports','inspect','--format','{{json .NetworkSettings.Ports}}',ident))
        mapping=ports['4222/tcp']
        if len(mapping)!=1 or mapping[0]['HostIp']!='127.0.0.1':raise RuntimeError('owned port is not loopback-only')
        port=int(mapping[0]['HostPort']);f['url']='nats://127.0.0.1:'+str(port)
        deadline=time.monotonic()+10
        while True:
            try:
                with socket.create_connection(('127.0.0.1',port),timeout=1) as sock:
                    banner=sock.recv(4096)
                    if not banner.startswith(b'INFO '):raise RuntimeError('actual endpoint not NATS')
                    f['server_info']=json.loads(banner[5:].strip());break
            except (ConnectionRefusedError,TimeoutError):
                if time.monotonic()>=deadline:raise
                time.sleep(.05)
        f['after_setup']=inventory();save(RECEIPT.name,f);print(json.dumps({'owned_nats':f['url'],'id':ident}));return
    if action!='cleanup':raise RuntimeError('unknown action')
    f=json.loads(RECEIPT.read_text());actual=inventory();own=[c for c in actual['containers'] if c['id']==f['id']]
    if len(own)!=1 or own[0]['name']!='/'+f['name'] or own[0]['labels'].get('group-product-r2-owner')!=OWNER or own[0]['mounts']:raise RuntimeError('owned container qualification differs; do not delete')
    other=[c for c in actual['containers'] if c['id']!=f['id']]
    if other!=f['before']['containers'] or actual['volumes']!=f['before']['volumes']:raise RuntimeError('other Docker inventory changed; preserve own fixture')
    docker('docker-owned-nats-remove','rm','-f',f['id'])
    after=inventory();f.update(after_cleanup=after,cleaned=True,cleanup_pass=after==f['before']);save(RECEIPT.name,f)
    if not f['cleanup_pass']:raise RuntimeError('Docker inventory did not restore')

if __name__=='__main__':main()
