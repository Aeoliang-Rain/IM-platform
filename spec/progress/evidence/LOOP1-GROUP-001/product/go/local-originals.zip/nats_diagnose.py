import json
from nats_run import inventory,RECEIPT
from pg_run import save
before=json.loads(RECEIPT.read_text());actual=inventory()
other={'containers':[c for c in actual['containers'] if c['id']!=before['id']],'volumes':actual['volumes']}
def diff(a,b,path=''):
    if type(a)!=type(b):return [{'path':path,'before':a,'after':b}]
    if isinstance(a,dict):return [d for k in sorted(a.keys()|b.keys()) for d in diff(a.get(k),b.get(k),path+'/'+k)]
    if isinstance(a,list):
        if len(a)!=len(b):return [{'path':path,'before_length':len(a),'after_length':len(b)}]
        return [d for i,(x,y) in enumerate(zip(a,b)) for d in diff(x,y,path+'/'+str(i))]
    return [] if a==b else [{'path':path,'before':a,'after':b}]
changes=diff(before['before'],other)
save('nats-cleanup-observed-diff.json',{'before':before['before'],'actual_other':other,'actual_all':actual,'differences':changes})
print(json.dumps({'difference_count':len(changes),'differences':changes[:30]},ensure_ascii=False))
