"""Controlled, path-only libpq execution owner for the granted local Go slice."""
from __future__ import annotations
import argparse, hashlib, json, os, pathlib, subprocess, sys, time, uuid

OUT = pathlib.Path(__file__).resolve().parent
ROOT = pathlib.Path('H:/.codex/worktrees/group/IM-platform')
PGBASE = pathlib.Path('H:/IM-platform/.git/worktrees/IM-platform4/group-pg16-20261018')
PGPASS = PGBASE/'libpq-v2.private'
PGDATA = PGBASE/'data-v2'
PGSQL = PGBASE/'pgsql/bin/psql.exe'
PYTHON = pathlib.Path(sys.executable)
FIXTURE = OUT/'owned-pg-fixture.json'

def save(name, value):
    (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf8')

def environment(schema=None):
    # Never inspect credential bytes. Clear all inherited libpq options, including
    # PGPASSWORD, services, search paths, host overrides and alternate passfiles.
    env={k:v for k,v in os.environ.items() if not k.upper().startswith('PG') and k.upper()!='DATABASE_URL'}
    env.update(PGHOST='127.0.0.1',PGPORT='63830',PGDATABASE='group_contract_20261018',PGUSER='group_contract_fixture',PGPASSFILE=str(PGPASS),PGCONNECT_TIMEOUT='5',PGAPPNAME='group-product-r2-owner',DB_TEST_ENABLE='1',PYTHONDONTWRITEBYTECODE='1')
    env['PATH']=str(PGSQL.parent)+os.pathsep+str(PYTHON.parent)+os.pathsep+env.get('PATH','')
    if schema: env['PGOPTIONS']='-c search_path='+schema
    nats=OUT/'owned-nats-fixture.json'
    if nats.is_file():
        fixture=json.loads(nats.read_text())
        if fixture.get('created') and not fixture.get('cleaned'):
            if not fixture['url'].startswith('nats://127.0.0.1:'):raise RuntimeError('owned NATS URL differs')
            env['NATS_URL']=fixture['url']
    return env

def command(label,argv,env,*,check=True):
    start=time.monotonic();r=subprocess.run([str(x) for x in argv],cwd=ROOT,env=env,capture_output=True)
    stamp=f'{time.time_ns()}-{label}'
    (OUT/'runtime-captures').mkdir(exist_ok=True)
    for name,data in [('stdout',r.stdout),('stderr',r.stderr)]: (OUT/'runtime-captures'/f'{stamp}.{name}').write_bytes(data)
    meta={'argv':[str(x) for x in argv],'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr).hexdigest(),'stdout_path':str(OUT/'runtime-captures'/f'{stamp}.stdout'),'stderr_path':str(OUT/'runtime-captures'/f'{stamp}.stderr')}
    save('runtime-captures/'+stamp+'.json',meta)
    print(json.dumps(meta),flush=True)
    if r.stdout: print(r.stdout.decode('utf8'),end='',flush=True)
    if r.stderr: print(r.stderr.decode('utf8'),end='',file=sys.stderr,flush=True)
    if check and r.returncode: raise RuntimeError(f'{label} exited {r.returncode}; original output retained')
    return r

def sql(label,text,env):
    return command(label,[PGSQL,'-X','-w','-q','-A','-t','-v','ON_ERROR_STOP=1','-c',text],env).stdout.decode('utf8').strip()

def qualify():
    if not PGPASS.is_file() or not PGSQL.is_file():raise RuntimeError('granted PG executable/passfile path is absent')
    env=environment()
    row=json.loads(sql('identity',"SELECT json_build_object('host',host(inet_server_addr()),'port',inet_server_port(),'database',current_database(),'user',current_user,'version',current_setting('server_version_num'),'datadir',current_setting('data_directory'),'backend_pid',pg_backend_pid());",env))
    expected={'host':'127.0.0.1','port':63830,'database':'group_contract_20261018','user':'group_contract_fixture','version':'160015'}
    if any(row.get(k)!=v for k,v in expected.items()):raise RuntimeError('granted PG identity mismatch: '+json.dumps(row))
    if os.path.normcase(os.path.normpath(row['datadir']))!=os.path.normcase(os.path.normpath(str(PGDATA))):raise RuntimeError('granted PG data_directory mismatch')
    pid=json.loads((PGDATA/'postmaster.pid').read_text().splitlines()[0])
    if pid!=49572:raise RuntimeError('granted server PID mismatch')
    save('pg-identity-latest.json',{'observed':row,'postmaster_pid':pid,'passfile_path_only':str(PGPASS),'passfile_is_file':True,'passfile_size':PGPASS.stat().st_size,'qualified':True})
    return env,row

def inventory(env):
    return json.loads(sql('schemas',"SELECT coalesce(json_agg(json_build_array(nspname,pg_get_userbyid(nspowner)) ORDER BY nspname),'[]'::json) FROM pg_namespace;",env))

def load():
    f=json.loads(FIXTURE.read_text())
    if not f['schema'].startswith('group_product_r2_') or not f['schema'].replace('_','').isalnum():raise RuntimeError('invalid owned schema receipt')
    if f.get('cleaned'):raise RuntimeError('fixture already cleaned')
    env,_=qualify();env=environment(f['schema'])
    if sql('exact-search-path',"SELECT current_setting('search_path');",env)!=f['schema']:raise RuntimeError('search_path differs')
    if sql('schema-owner',"SELECT pg_get_userbyid(nspowner) FROM pg_namespace WHERE nspname=current_schema();",env)!='group_contract_fixture':raise RuntimeError('owned schema identity differs')
    return f,env

def main():
    p=argparse.ArgumentParser();p.add_argument('action',choices=['setup','run','cleanup','qualify']);p.add_argument('args',nargs=argparse.REMAINDER);a=p.parse_args()
    if a.action=='qualify':qualify();return
    if a.action=='setup':
        if FIXTURE.exists() and not json.loads(FIXTURE.read_text()).get('cleaned'):raise RuntimeError('active fixture receipt already exists')
        env,row=qualify();before=inventory(env);schema='group_product_r2_'+uuid.uuid4().hex[:16]
        f={'schema':schema,'identity':row,'before_schemas':before,'created':False,'cleaned':False,'source_root':str(ROOT),'credential':'path-only; never read by this helper'};save(FIXTURE.name,f)
        sql('create-owned-schema','CREATE SCHEMA '+schema+' AUTHORIZATION group_contract_fixture;',env);f['created']=True;save(FIXTURE.name,f);env=environment(schema)
        for action in ['status','up','status']:command('canonical-migration-'+action,[PYTHON,'-Xutf8','-B','contracts/database/migrate.py',action],env)
        f['migration_complete']=True;save(FIXTURE.name,f);print(json.dumps({'owned_schema':schema,'ready':True}));return
    f,env=load()
    if a.action=='run':
        args=a.args[1:] if a.args[:1]==['--'] else a.args
        if not args:raise RuntimeError('explicit command argv required')
        sys.exit(command('owned-runtime',args,env,check=False).returncode)
    if a.action=='cleanup':
        f['fixture_counts_before_schema_drop']=json.loads(sql('fixture-counts-before-drop',"SELECT json_build_object('users',(SELECT count(*) FROM users),'sessions',(SELECT count(*) FROM sessions),'conversations',(SELECT count(*) FROM conversations),'members',(SELECT count(*) FROM conversation_members),'receipts',(SELECT count(*) FROM group_operation_receipts),'user_sync_events',(SELECT count(*) FROM user_sync_events),'outbox_events',(SELECT count(*) FROM outbox_events),'messages',(SELECT count(*) FROM messages),'test_functions',(SELECT count(*) FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace WHERE n.nspname=current_schema() AND p.proname LIKE 'gp%'));",env))
        save(FIXTURE.name,f)
        after=inventory(environment());others=[v for v in after if v[0]!=f['schema']]
        if others!=f['before_schemas']:raise RuntimeError('other-schema inventory changed; preserve fixture for diagnosis')
        sql('drop-owned-schema','DROP SCHEMA '+f['schema']+' CASCADE;',env)
        final=inventory(environment());f['after_schemas']=final;f['cleaned']=True;f['cleanup_pass']=final==f['before_schemas'];save(FIXTURE.name,f)
        if not f['cleanup_pass']:raise RuntimeError('schema inventory did not restore')
        qualify()

if __name__=='__main__':main()
