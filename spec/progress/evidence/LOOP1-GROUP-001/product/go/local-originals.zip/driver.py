import hashlib,json,subprocess,sys,time
from pathlib import Path
OUT=Path(__file__).resolve().parent
REPO=Path(r'H:\.codex\worktrees\group\IM-platform')
PY=Path(r'C:\Users\21441\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe')
RUN='R-GROUP-PRODUCT-R2-GO-20261020'
REC=REPO/'tools/research/recorder.py'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def capture(label,argv):
    start=time.monotonic();r=subprocess.run([str(x) for x in argv],cwd=REPO,capture_output=True)
    d=OUT/'captures';d.mkdir(parents=True,exist_ok=True)
    (d/(label+'.stdout')).write_bytes(r.stdout);(d/(label+'.stderr')).write_bytes(r.stderr)
    report={'argv':[str(x) for x in argv],'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-start,'stdout_sha256':sha(d/(label+'.stdout')),'stderr_sha256':sha(d/(label+'.stderr'))}
    (d/(label+'.json')).write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report,ensure_ascii=False))
    print(r.stdout.decode('utf-8',errors='replace') if len(r.stdout)<16000 else 'Full stdout saved '+str(len(r.stdout))+' bytes')
    if r.stderr:print(r.stderr.decode('utf-8',errors='replace'),file=sys.stderr)
    return r.returncode
def rec(label,op,args):return capture(label,[PY,'-Xutf8','-B',REC,op,'--repo',REPO,'--research-root',OUT/'research',*args])
if __name__=='__main__':
    op=sys.argv[1]
    if op=='init':
        code=rec('prompt','register-prompt',['--task-id','LOOP1-GROUP-001','--file',OUT/'prompt.txt','--source','coordinator_delegation','--prompt-id','P-GROUP-PRODUCT-R2-GO-20261020'])
        if code:sys.exit(code)
        sys.exit(rec('start','start-run',['--task-id','LOOP1-GROUP-001','--role','implementation','--capture-mode','prospective','--experiment-group','full_governance','--prompt-id','P-GROUP-PRODUCT-R2-GO-20261020','--run-id',RUN,'--agent-harness','codex-desktop','--fresh-context','false']))
    elif op=='run':sys.exit(rec(sys.argv[2],'run-command',['--run-id',RUN,'--',*sys.argv[3:]]))
    elif op=='event':sys.exit(rec(sys.argv[2],'record-event',['--run-id',RUN,'--event-type',sys.argv[3],'--data-json',sys.argv[4]]))
    elif op=='finish':sys.exit(rec('finish','finish-run',['--run-id',RUN,'--result','FAIL']))
    elif op=='validate':sys.exit(rec('validate','validate-run',['--run-id',RUN]))
    else:raise RuntimeError('unknown driver operation')
