"""Sequential post-change authority and public-contract regression commands."""
import json,os,sys
from pg_run import OUT,command,save

py=[sys.executable,'-Xutf8','-B']
commands=[
    ('frozen',py+['tools/verify_frozen_architecture.py']),
    ('planning',py+['ci/check_s2_planning.py']),
    ('architecture',py+['ci/check_architecture.py','--scope','all','--json']),
    ('architecture-tests',py+['-m','unittest','discover','-s','tests/architecture']),
    ('ci-tests',py+['-m','unittest','discover','-s','tests/ci']),
    ('group-contract',py+['contracts/http/verify-group.py']),
    ('group-contract-tests',py+['-m','unittest','discover','-s','tests/contract/group','-p','test_*.py','-v']),
    ('auth-contract',['pwsh','-NoProfile','-File','contracts/http/verify-auth-user-friend.ps1']),
    ('sync-contract',py+['tools/verify_sync_transport.py']),
    ('sync-contract-tests',py+['-m','unittest','discover','-s','tests/contract','-p','test_sync_transport.py']),
    ('wss-contract',py+['contracts/websocket/verify.py']),
    ('plugin-contract',py+['contracts/plugin-api/verify.py']),
    ('development',['pwsh','-NoProfile','-File','tools/verify-loop1-ctrl-002.ps1','-Mode','Development']),
]
env={k:v for k,v in os.environ.items() if not k.upper().startswith('PG') and k.upper() not in ['DATABASE_URL','DB_TEST_ENABLE','NATS_URL']}
env['PYTHONDONTWRITEBYTECODE']='1'
results=[]
for label,argv in commands:
    r=command('check-'+label,argv,env,check=False)
    results.append({'label':label,'argv':argv,'exit_code':r.returncode})
save('checks-result.json',{'results':results,'pass':all(r['exit_code']==0 for r in results)})
sys.exit(0 if all(r['exit_code']==0 for r in results) else 1)
