import hashlib,json,pathlib,zipfile
from pg_run import OUT,ROOT

dest=ROOT/'spec/progress/evidence/LOOP1-GROUP-001/product/go'
summary=json.loads((OUT/'verification-summary.json').read_text())
summary['metadata_only_development'] = json.loads((OUT/'captures/post-metadata-development.json').read_text())
summary['prestage_scope_proof']={'path':'prestage-scope-proof.json in local-originals.zip','sha256':hashlib.sha256((OUT/'prestage-scope-proof.json').read_bytes()).hexdigest(),'unchanged_old_files':19042,'changed_existing':['backend/go/core/http.go','backend/go/core/social.go','spec/progress/current.md','spec/tasks/active/LOOP1-GROUP-001.md']}
(dest/'verification-summary.json').write_bytes((json.dumps(summary,ensure_ascii=False,indent=2)+'\n').encode())
files=[]
for folder in ['captures','runtime-captures']:
    files += [p for p in (OUT/folder).rglob('*') if p.is_file()]
files += [p for p in OUT.iterdir() if p.is_file() and p.suffix in ['.py','.json','.txt','.diff']]
files=sorted(set(files),key=lambda p:p.relative_to(OUT).as_posix())
manifest=[]
archive=dest/'local-originals.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in files:
        data=p.read_bytes();name=p.relative_to(OUT).as_posix()
        z.writestr(name,data);manifest.append({'entry':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
with zipfile.ZipFile(archive) as z:
    if set(z.namelist())!={r['entry']for r in manifest}:raise RuntimeError('archive inventory mismatch')
    for r in manifest:
        if hashlib.sha256(z.read(r['entry'])).hexdigest()!=r['sha256']:raise RuntimeError('archive readback hash mismatch')
result={'scope':'Local first-Go phase originals through precommit packaging; active Recorder trace/final commit and clean-Acceptance are separate handoff evidence','archive':'local-originals.zip','archive_bytes':archive.stat().st_size,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'entries':manifest,'loose_summary_is_new_LF_view_of_raw_original':{'raw_entry':'verification-summary.json','raw_sha256':hashlib.sha256((OUT/'verification-summary.json').read_bytes()).hexdigest(),'loose_sha256':hashlib.sha256((dest/'verification-summary.json').read_bytes()).hexdigest()},'source':summary['source']}
(dest/'package-manifest.json').write_bytes((json.dumps(result,ensure_ascii=False,indent=2)+'\n').encode())
print(json.dumps({'archive_bytes':result['archive_bytes'],'archive_sha256':result['archive_sha256'],'entries':len(manifest),'summary_sha256':result['loose_summary_is_new_LF_view_of_raw_original']['loose_sha256']}))
