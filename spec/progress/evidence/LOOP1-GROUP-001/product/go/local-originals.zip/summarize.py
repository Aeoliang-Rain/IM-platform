import collections,hashlib,json
from pg_run import OUT,ROOT,save

go=[]
for p in sorted((OUT/'runtime-captures').glob('*.json')):
    d=json.loads(p.read_text())
    if d['argv'][:5]==['H:/go/bin/go.exe','-C','backend/go','test','-race'] or d['argv'][:4]==['H:/go/bin/go.exe','-C','backend/go','test']:
        if './...' in d['argv']:go.append((p,d))
chosen=[next((p,d) for p,d in reversed(go) if ('-race' in d['argv'])==race) for race in [False,True]]
results=[]
for meta,d in chosen:
    output=__import__('pathlib').Path(d['stdout_path'])
    records=[json.loads(s) for s in output.read_text().splitlines() if s.startswith('{')]
    tests=[r for r in records if r.get('Test') and r.get('Action') in ['pass','fail','skip']]
    mains=[r for r in tests if '/' not in r['Test']]
    groups=[r for r in tests if r['Test'].startswith('TestGroup')]
    result={'argv':d['argv'],'exit_code':d['exit_code'],'elapsed_seconds':d['elapsed_seconds'],'raw_stdout':d['stdout_path'],'raw_stdout_sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'metadata_path':str(meta),'metadata_sha256':hashlib.sha256(meta.read_bytes()).hexdigest(),'test_actions':dict(collections.Counter(r['Action'] for r in tests)),'main_test_actions':dict(collections.Counter(r['Action'] for r in mains)),'group_test_actions':dict(collections.Counter(r['Action'] for r in groups)),'group_main_methods':[r['Test'] for r in mains if r['Test'].startswith('TestGroup')],'packages':[r for r in records if not r.get('Test') and r.get('Action') in ['pass','fail','skip']]}
    if d['exit_code'] or any(r['Action']!='pass' for r in tests):raise RuntimeError('selected final Go result is not zero-skip PASS')
    results.append(result)
source=[]
for path in ['backend/go/core/group.go','backend/go/core/group_test.go','backend/go/core/http.go','backend/go/core/social.go']:
    data=(ROOT/path).read_bytes();source.append({'path':path,'size':len(data),'sha256':hashlib.sha256(data).hexdigest()})
summary={'result':'PASS_LOCAL_FIRST_GO_SLICE_ONLY','base_sha':'79d39dcbd045597ccc5abd459edd388eed269254','source':source,'go_results':results,'checks':json.loads((OUT/'checks-result.json').read_text()),'pg_cleanup':json.loads((OUT/'owned-pg-fixture.json').read_text()),'nats_cleanup':json.loads((OUT/'nats-own-cleanup-final.json').read_text()),'limitations':['No public deployment/TLS/client/Web/Desktop/Android runtime in this phase','G01..G09 and product independent reviews/Architect/hosted/integration/sync remain unaccepted','Initial default sandbox write failures, bad CHECK test fixture run and full-State Docker comparison FAIL are preserved','Seven own-schema Outbox residual rows observed before final own-schema drop; origin unavailable; all other fixture tables and test functions zero','Recorder is honest partial FAIL, separate from local test outcomes']}
save('verification-summary.json',summary)
print(json.dumps({'go':[{'elapsed':r['elapsed_seconds'],'main':r['main_test_actions'],'all':r['test_actions'],'groups':r['group_test_actions'],'group_main_count':len(r['group_main_methods'])}for r in results],'source':source,'checks_pass':summary['checks']['pass'],'pg_cleanup':summary['pg_cleanup']['cleanup_pass'],'nats_stable_inventory':summary['nats_cleanup']['stable_identity_status_mount_volume_comparison']},indent=2))
