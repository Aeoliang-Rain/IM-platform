"""Copy only the coordinator-accepted five unchanged public portable files."""
import hashlib,json,pathlib
from pg_run import OUT,ROOT,save
base=OUT.parent/'contract-frozen-portable-evidence-20261020'
dest=ROOT/'spec/progress/evidence/LOOP1-GROUP-001/product/activation'
expected={
'public-first-contract-acceptance-originals.zip':'1a9c46d04c2e78e2f5648f673e31359221321c307e3272acbda37f4fe0278b01',
'package-manifest.json':'8d444df2b903cdf912fe39b656d56e787e101ad4cdf37f7c2ef8d250257b29c6',
'relocation-map.json':'b9eb9dbd12aec98f678c77f0f7aa0de146564a960bbad54985f6fad4198b4ca4',
'report.md':'5d2b884511fdee1040f4b85972a62cfbc5eff830e9565e45b89e9bb4823bd628',
'final-receipt.json':'9ecd2e3a3e8d7257bcbfeb4967345aa6db52f22f3ec35f12657f042173239693',
}
rows=[]
for name,digest in expected.items():
    data=(base/name).read_bytes()
    if hashlib.sha256(data).hexdigest()!=digest:raise RuntimeError('portable input hash mismatch: '+name)
    if (dest/name).exists():raise RuntimeError('activation destination already exists: '+name)
    rows.append((name,digest,data))
dest.mkdir(parents=True,exist_ok=True)
for name,digest,data in rows:
    (dest/name).write_bytes(data)
    if hashlib.sha256((dest/name).read_bytes()).hexdigest()!=digest:raise RuntimeError('copy mismatch: '+name)
save('activation-copy-receipt.json',{'files':[{'path':str(dest/name),'sha256':digest,'size':len(data)} for name,digest,data in rows],'result':'COPIED_FIVE_UNCHANGED_PUBLIC_FILES','optional_binding_external_only':'contract-frozen-portable-coordinator-bindings.json; SHA702d4f2ac7fc30eed209693defc411e7ac7fe9e3884ce3084e1a856532a3a210','scope':'thin selected first-contract acceptance; no product G acceptance'})
print(json.dumps({'copied':5,'destination':str(dest)}))
