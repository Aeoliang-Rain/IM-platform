"""Final own-only cleanup; original full-State comparison FAIL stays unchanged."""
import copy,json
from nats_run import inventory,RECEIPT,OWNER,docker
from pg_run import save

f=json.loads(RECEIPT.read_text())
fmt='{{json .Id}} {{json .Name}} {{json .Config.Image}} {{json .Image}} {{json .Config.Labels}} {{json .Mounts}} {{json .NetworkSettings.Ports}}'
raw=docker('owned-final-qualification','inspect','--format',fmt,f['id']);decoder=json.JSONDecoder();items=[]
while raw:
    v,n=decoder.raw_decode(raw);items.append(v);raw=raw[n:].lstrip()
ident,name,image,image_id,labels,mounts,ports=items
mapping=ports.get('4222/tcp')
expected_port=f['url'].rsplit(':',1)[1]
if ident!=f['id'] or name!='/'+f['name'] or image!=f['image'] or labels.get('group-product-r2-owner')!=OWNER or mounts or mapping!=[{'HostIp':'127.0.0.1','HostPort':expected_port}]:raise RuntimeError('own immutable identity/image/label/ports qualification failed')
before_cleanup=inventory()
qualification={'id':ident,'name':name,'image':image,'image_id':image_id,'labels':labels,'mounts':mounts,'ports':ports,'pass':True}
save('nats-own-final-qualification.json',qualification)
docker('owned-final-remove','rm','-f',ident)
after=inventory()

def stable(source):
    value=copy.deepcopy(source)
    for c in value['containers']:
        c['mounts']=sorted(c['mounts'],key=lambda m:json.dumps(m,sort_keys=True))
        for entry in c['state'].get('Health',{}).get('Log',[]):
            # Raw timestamps remain in before/after evidence. These fields are
            # the naturally advancing healthcheck observations, not lifecycle.
            entry.pop('Start',None);entry.pop('End',None)
    value['containers']=sorted(value['containers'],key=lambda c:c['id'])
    value['volumes']=sorted(value['volumes'],key=lambda v:json.dumps(v,sort_keys=True))
    return value

matches=stable(f['before'])==stable(after)
result={'own_qualification':qualification,'before_cleanup_all':before_cleanup,'after_cleanup_all':after,'original_full_state_comparison':'FAIL; original run/output and observed field diff retained','comparison_rules':['containers by immutable ID','mount entries compared as complete unordered records','Health.Log Start/End excluded only from separate stable comparison; all other state/status/health ExitCode/Output retained','all volume entries retained'],'stable_identity_status_mount_volume_comparison':'PASS' if matches else 'FAIL','own_id_absent':all(c['id']!=ident for c in after['containers'])}
save('nats-own-cleanup-final.json',result)
f.update(cleaned=True,after_cleanup=after,initial_full_state_comparison='FAIL',stable_inventory_comparison='PASS' if matches else 'FAIL',cleanup_pass=matches)
save(RECEIPT.name,f)
print(json.dumps({'own_removed':ident,'stable_inventory_pass':matches,'initial_full_state_comparison':'FAIL retained'}))
if not matches:raise RuntimeError('postcleanup stable other-resource inventory differs; evidence retained, no other resources touched')
