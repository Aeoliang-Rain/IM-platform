"""Bind each successful hosted job's actual checkout log to the audited SHA."""
import concurrent.futures,datetime,hashlib,json,re,subprocess,sys
from pathlib import Path

p=Path(sys.argv[1]);d=json.loads(p.read_text('utf8'))
assert d['result']=='PASS' and all(d['checks'].values())
expected=d['expected_sha'];assert re.fullmatch('[0-9a-f]{40}',expected)
out=p.parent/(p.stem+'-checkouts');out.mkdir(exist_ok=True)
assert out.is_dir() and not (out/'receipt.json').exists()
attempt=out/datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ');attempt.mkdir()
jobs=[j for j in d['jobs'] if j['conclusion']=='success']
assert jobs
def verify(job):
    raw=subprocess.check_output(['C:/Program Files/GitHub CLI/gh.exe','api','--allow-escape-sequences',
        'repos/nilesthump/IM-platform/actions/jobs/'+str(job['id'])+'/logs'])
    f=attempt/(str(job['id'])+'.log');f.write_bytes(raw)
    decoded=re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',raw.decode('utf8'))
    lines=[re.sub(r'^\d{4}-\d\d-\d\dT\S+Z\s*','',s).strip() for s in decoded.splitlines()]
    heads=[]
    for i,line in enumerate(lines):
        if '[command]' in line and ' log -1 --format=%H' in line:
            assert i+1<len(lines)
            head=lines[i+1];assert re.fullmatch('[0-9a-f]{40}',head),(job['name'],head)
            heads.append(head)
    assert heads and set(heads)=={expected},(job['name'],heads,expected)
    return {'job_id':job['id'],'name':job['name'],'heads':heads,'log':{'path':f.relative_to(out).as_posix(),
        'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    verified=list(pool.map(verify,jobs))
receipt={'result':'PASS_ACTUAL_CHECKOUT_HEADS_ONLY','run_id':d['run']['id'],'attempt':d['run']['run_attempt'],
    'expected_sha':expected,'audit':{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()},
    'jobs':verified,'qualification':'Actual checkout logs of every successful required job; inactive skipped jobs have no checkout. This does not replace behavior CI, independent review or main synchronization.'}
r=out/'receipt.json';r.write_text(json.dumps(receipt,indent=2)+'\n','utf8')
print(json.dumps({'result':receipt['result'],'sha':expected,'jobs':len(verified),'receipt':str(r),'sha256':hashlib.sha256(r.read_bytes()).hexdigest()}))
