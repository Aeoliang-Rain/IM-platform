"""Offline contract-r6 step evidence check; run only after both final-SHA reviews PASS."""
import ast
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys

ROOT = Path('H:/.codex/worktrees/group/IM-platform')
BASELINE_SHA256 = '955453d2a2728e00eed1313848aff20bc25b86b0dcb0bab5a867aea0c3ee9e61'
EXPECTED_JOBS = {'classify', 'architecture', 'source_go', 'source_java', 'go', 'java', 'web',
                 'desktop (ubuntu-latest)', 'desktop (windows-latest)', 'mobile', 'shared',
                 'compatibility', 'deploy', 'gate'}
VERIFIER_PASS = ('PASS: official OpenAPI3.1/schema/exchange fixtures positive=35 negative=30; '
                 'offline authority only, server/runtime acceptance pending')


def require(ok, message):
    if not ok:
        raise ValueError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def normalize(raw):
    plain = re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]', '', raw.decode('utf-8'))
    return '\n'.join(re.sub(r'^\d{4}-\d\d-\d\dT\S+Z\s*', '', line).strip()
                     for line in plain.splitlines())


def methods_in(source, path):
    tree = ast.parse(source.decode('utf-8-sig'))
    pairs = [(cls.name, method.name) for cls in tree.body if isinstance(cls, ast.ClassDef)
             for method in cls.body if isinstance(method, (ast.FunctionDef, ast.AsyncFunctionDef))
             and method.name.startswith('test_')]
    require(pairs and len(pairs) == len(set(pairs)), 'Empty/duplicate method identities: ' + path)
    return pairs


def load_baseline():
    path = Path(__file__).with_name('method-baseline-e218.json')
    raw = path.read_bytes()
    require(digest(raw) == BASELINE_SHA256, 'Historical method baseline bytes changed')
    data = json.loads(raw)
    require(len(data['group']['methods']) == 22 and len(data['database']['methods']) == 11,
            'Historical identity floors changed')
    return data


def inspect_suite(log, modules):
    """Exactly one observed suite, each expected identity once, exact count and bare OK."""
    expected = {module + '.' + cls + '.' + name: name
                for module, pairs in modules.items() for cls, name in pairs}
    require(expected, 'No expected tests')
    lines = log.splitlines()
    pattern = re.compile(r'^(\S+)\s+\(([^)]+)\)(.*?)\s+\.\.\.\s+(.+)$')
    results = [(index, match) for index, line in enumerate(lines)
               if (match := pattern.fullmatch(line))]
    relevant = [(i, m) for i, m in results if any(m[2].startswith(module + '.') for module in modules)]
    methods = {identity: len([m for _, m in relevant if m[2] == identity]) == 1 and any(
        m[2] == identity and m[1] == name and not m[3].strip() and m[4] == 'ok'
        for _, m in relevant) for identity, name in expected.items()}
    checks = {'all_expected_once_ok': all(methods.values()),
              'no_unexpected_or_duplicate_identity': len(relevant) == len(expected)
                  and {m[2] for _, m in relevant} == set(expected)}
    data = {'methods': methods, 'expected_count': len(expected), 'checks': checks,
            'observed': [{'line': i, 'identity': m[2], 'name': m[1], 'suffix': m[3], 'status': m[4]}
                         for i, m in relevant]}
    if not relevant:
        checks['one_complete_suite'] = False
        return data
    first, last = relevant[0][0], relevant[-1][0]
    summaries = [(i, m) for i, line in enumerate(lines) if i >= first
                 and (m := re.fullmatch(r'Ran (\d+) tests? in (\d+(?:\.\d+)?)s', line))]
    checks['exactly_one_suite_summary'] = len(summaries) == 1
    if len(summaries) != 1:
        return data
    end, summary = summaries[0]
    following = [(i, line) for i, line in enumerate(lines) if i > end and line]
    terminal = following[0] if following else None
    body_results = [(i, m) for i, m in results if first <= i < end]
    checks.update({
        'summary_after_all_methods': end > last,
        'exact_dynamic_count': int(summary[1]) == len(expected),
        'one_suite_no_interleaving': len(body_results) == len(expected) and all(
            m[2] in expected and m[1] == expected[m[2]] and not m[3].strip() and m[4] == 'ok'
            for _, m in body_results),
        'bare_ok_zero_skip': terminal is not None and terminal[1] == 'OK',
        'no_failure_or_skip_diagnostics': not any(re.match(
            r'^(?:FAIL|ERROR|FAILED|SKIP|skipped|UNEXPECTED SUCCESS|EXPECTED FAILURE)\b', line)
            for line in lines[first:]),
    })
    data.update({'start_line': first, 'summary_line': end,
                 'terminal_line': terminal[0] if terminal else None, 'elapsed_seconds': float(summary[2])})
    return data


def main(audit_path):
    require(audit_path.name.startswith('contract-r6-'), 'Use a new contract-r6 audit, never old r5')
    audit_raw = audit_path.read_bytes()
    audit = json.loads(audit_raw)
    require(audit['result'] == 'PASS' and audit['checks'] and all(audit['checks'].values()), 'Run audit not PASS')
    head, run = audit['expected_sha'], audit['run']
    require(re.fullmatch('[0-9a-f]{40}', head), 'Invalid exact SHA')
    require(run['head_sha'] == head and run['status'] == 'completed' and run['conclusion'] == 'success',
            'Run head/status mismatch')
    require(run['path'] == '.github/workflows/ci.yml' and run['event'] == audit['expected_event']
            and run['head_branch'] == audit['expected_branch'], 'Run workflow/event/branch mismatch')
    ajobs = audit['jobs']
    require(len(ajobs) == 14 and {j['name'] for j in ajobs} == EXPECTED_JOBS, 'Actual 14 required jobs missing/duplicated')
    require(len({j['id'] for j in ajobs}) == 14 and all(j['status'] == 'completed' and j['conclusion'] == 'success'
            and j['head_sha'] == head and j['run_id'] == run['id'] and j['run_attempt'] == run['run_attempt']
            for j in ajobs), 'Job exact run/attempt/head/success mismatch')
    checkout_root = audit_path.parent / (audit_path.stem + '-checkouts')
    checkout_path = checkout_root / 'receipt.json'
    checkout_raw = checkout_path.read_bytes()
    checkout = json.loads(checkout_raw)
    require(checkout['result'] == 'PASS_ACTUAL_CHECKOUT_HEADS_ONLY' and checkout['expected_sha'] == head
            and checkout['run_id'] == run['id'] and checkout['attempt'] == run['run_attempt']
            and checkout['audit']['sha256'] == digest(audit_raw), 'Checkout/audit binding mismatch')
    cjobs = checkout['jobs']
    require(len(cjobs) == 14 and {(j['name'], j['job_id']) for j in cjobs} == {(j['name'], j['id']) for j in ajobs},
            'Checkout job names/IDs differ from same-attempt audit')
    logs, bindings = {}, []
    for job in cjobs:
        f = checkout_root / job['log']['path']
        require(f.resolve().is_relative_to(checkout_root.resolve()), 'Log outside checkout evidence root')
        raw = f.read_bytes()
        require(len(raw) == job['log']['bytes'] and digest(raw) == job['log']['sha256'], 'Raw log bytes/hash mismatch')
        log = normalize(raw)
        lines = log.splitlines()
        heads = [lines[i + 1] for i, line in enumerate(lines[:-1])
                 if '[command]' in line and ' log -1 --format=%H' in line]
        require(heads == job['heads'] and heads and set(heads) == {head}, 'Actual checkout SHA mismatch')
        logs[job['name']] = log
        bindings.append({**job['log'], 'job': job['name'], 'job_id': job['job_id'], 'path': str(f)})

    baseline = load_baseline()
    require(head != baseline['baseline_commit'], 'Failed historical e218 is not a new final candidate')

    def source_at(path):
        return subprocess.check_output(['git', '-C', str(ROOT), 'show', head + ':' + path])

    group_paths = subprocess.check_output(['git', '-C', str(ROOT), 'ls-tree', '-r', '--name-only', head,
                                           '--', 'tests/contract/group']).decode().splitlines()
    group_paths = [p for p in group_paths if PurePosixPath(p).name.startswith('test_') and p.endswith('.py')]
    require({'tests/contract/group/test_group.py', 'tests/contract/group/test_verification_failures.py'} <= set(group_paths),
            'Required group files missing')
    modules, sources = {}, {}
    for path in group_paths:
        module = '.'.join(PurePosixPath(path).relative_to('tests/contract/group').with_suffix('').parts)
        source = source_at(path)
        require(module not in modules, 'Duplicate group module')
        modules[module] = methods_in(source, path)
        sources[path] = digest(source)
    old_group = {tuple(pair) for pair in baseline['group']['methods']}
    require(old_group <= set(modules['test_group']), 'Original 22 group method identities removed')
    db_path = 'tests/database/test_migrations.py'
    db_source = source_at(db_path)
    db_methods = methods_in(db_source, db_path)
    require({tuple(pair) for pair in baseline['database']['methods']} <= set(db_methods), 'Original 11 DB identities removed')
    group_suite = inspect_suite(logs['shared'], modules)
    db_suite = inspect_suite(logs['compatibility'], {'test_migrations': db_methods})
    checks = {
        'group_verifier_command': 'python3 -B contracts/http/verify-group.py' in logs['shared'],
        'group_verifier_actual_35_30': VERIFIER_PASS in logs['shared'],
        'group_suite_command': 'python3 -B -m unittest discover -s tests/contract/group' in logs['shared'],
        'all_group_methods_once_ok_zero_skip': all(group_suite['checks'].values()),
        'go_standalone_migration_command': 'python3 contracts/database/migrate.py up' in logs['go'],
        'go_0002_actually_applied': '0002_group_operations: up complete' in logs['go'],
        'database_suite_command': 'python3 -m unittest discover -s tests/database -v' in logs['compatibility'],
        'database_explicitly_enabled': bool(re.search(r'^DB_TEST_ENABLE:\s*1\s*$', logs['compatibility'], re.MULTILINE)),
        'all_dynamic_database_methods_once_ok_zero_skip': all(db_suite['checks'].values()),
    }
    data = {'result': 'PASS_GROUP_REQUIRED_EXECUTION_ONLY' if all(checks.values()) else 'FAIL',
        'phase': 'contract-r6', 'expected_sha': head, 'run_id': run['id'], 'attempt': run['run_attempt'],
        'checks': checks, 'expected_group_method_count': group_suite['expected_count'],
        'expected_database_method_count': len(db_methods), 'group_suite_block': group_suite, 'database_suite_block': db_suite,
        'historical_identity_floor': {'sha256': BASELINE_SHA256, 'commit': baseline['baseline_commit'], 'group': 22, 'database': 11},
        'test_source_sha256': {'group': sources, 'database': digest(db_source)}, 'raw_log_bindings': bindings,
        'run_audit': {'path': str(audit_path), 'sha256': digest(audit_raw)},
        'checkout_receipt': {'path': str(checkout_path), 'sha256': digest(checkout_raw)},
        'helper_sha256': digest(Path(__file__).read_bytes()),
        'qualification': 'Narrow offline execution proof from supplied exact-attempt audit. Requires fresh final-SHA two-review PASS before use. Latest attempt must be freshly fetched/rechecked externally; no network performed. Does not replace protected integration, actual-main CI/tree, safe main sync or Task/Gate acceptance.'}
    dest = audit_path.with_name(audit_path.stem + '-group-execution-v2.json')
    with dest.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(data, indent=2) + '\n')
    print(json.dumps({'result': data['result'], 'group_methods': group_suite['expected_count'],
                      'database_methods': len(db_methods), 'evidence': str(dest), 'sha256': digest(dest.read_bytes())}))
    return 0 if all(checks.values()) else 1


if __name__ == '__main__':
    if len(sys.argv) != 2:
        raise SystemExit('Usage: Python3 -I -B audit_group_ci_steps_v2.py contract-r6-...-run-....json')
    raise SystemExit(main(Path(sys.argv[1])))
