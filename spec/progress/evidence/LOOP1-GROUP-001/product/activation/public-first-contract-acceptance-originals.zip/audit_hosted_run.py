"""Read-only exact-head hosted-run audit; never triggers or changes GitHub CI."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys

run_id, expected_sha, expected_branch, phase = sys.argv[1:5]
expected_event = sys.argv[5] if len(sys.argv) == 6 else "push"
if len(sys.argv) not in {5, 6} or expected_event not in {"push", "pull_request"}:
    raise SystemExit("Expected run ID, SHA, branch, phase and optional push/pull_request event")
root = Path(__file__).parent
gh = r"C:/Program Files/GitHub CLI/gh.exe"
repo = "nilesthump/IM-platform"

def fetch(endpoint):
    return json.loads(subprocess.check_output([gh, "api", endpoint]))

run = fetch(f"repos/{repo}/actions/runs/{run_id}")
attempt = run["run_attempt"]
jobs = []
page = 1
while True:
    payload = fetch(f"repos/{repo}/actions/runs/{run_id}/attempts/{attempt}/jobs?per_page=100&page={page}")
    jobs.extend(payload["jobs"])
    if len(jobs) >= payload["total_count"]:
        break
    if not payload["jobs"]:
        raise RuntimeError("Pagination ended before actual job count")
    page += 1
expected = {"classify", "architecture", "source_go", "source_java", "go", "java", "web",
            "desktop (ubuntu-latest)", "desktop (windows-latest)", "mobile", "shared",
            "compatibility", "deploy", "gate"}
allowed_skips = {
    "desktop (ubuntu-latest)": {"Approved Windows GUI assembly and auth controls"},
    "desktop (windows-latest)": {"Native Tauri prerequisites and approved Rust compiler",
                                "Actual TypeScript Repository on SQLx SQLite"},
}
unexpected_steps = []
for job in jobs:
    for step in job["steps"]:
        name = step["name"]
        if step.get("conclusion") == "skipped" and not name.startswith("Post ") and name not in allowed_skips.get(job["name"], set()):
            unexpected_steps.append({"job": job["name"], "step": name, "conclusion": "skipped"})
checks = {
    "exact_head": run["head_sha"] == expected_sha,
    "branch": run["head_branch"] == expected_branch,
    "expected_event": run["event"] == expected_event,
    "expected_workflow": run["path"] == ".github/workflows/ci.yml",
    "completed_success": run["status"] == "completed" and run["conclusion"] == "success",
    "all_14_expected_jobs": len(jobs) == len(expected) and {j["name"] for j in jobs} == expected,
    "all_jobs_success": all(j["status"] == "completed" and j["conclusion"] == "success" for j in jobs),
    "all_job_heads": all(j["head_sha"] == expected_sha and j["run_id"] == int(run_id) for j in jobs),
    "all_jobs_have_steps": all(j["steps"] for j in jobs),
    "no_failed_steps": all(s["status"] == "completed" and s["conclusion"] in {"success", "skipped"}
                           for j in jobs for s in j["steps"]),
    "no_anomalous_step_skip": not unexpected_steps,
}
result = "PASS" if all(checks.values()) else "PENDING" if run["status"] != "completed" else "FAIL"
evidence = {"result": result, "expected_sha": expected_sha, "expected_branch": expected_branch,
            "expected_event": expected_event,
            "checks": checks, "unexpected_steps": unexpected_steps, "run": run, "jobs": jobs,
            "audit_time": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "limitation": "This verifies actual latest-attempt jobs, exact push head and conditional skips; it does not substitute independent source reviews, tree integration or safe main sync."}
stamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
out = root / f"{phase}-run-{run_id}-attempt-{attempt}-{stamp}.json"
out.write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"result": result, "checks": checks, "run_id": run_id, "attempt": attempt,
                  "jobs": [{"name": j["name"], "conclusion": j["conclusion"]} for j in jobs],
                  "evidence": str(out), "sha256": hashlib.sha256(out.read_bytes()).hexdigest()}))
if result != "PASS":
    raise SystemExit(2 if result == "PENDING" else 1)
