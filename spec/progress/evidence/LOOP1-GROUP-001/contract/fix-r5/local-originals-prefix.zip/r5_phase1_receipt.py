import hashlib,json,pathlib,subprocess,time
ROOT=pathlib.Path(r'H:\.codex\worktrees\group\IM-platform').resolve(); OUT=pathlib.Path(__file__).resolve().parent
TASK='spec/tasks/active/LOOP1-GROUP-001.md'; b=json.loads((OUT/'phase1-before.json').read_text(encoding='utf-8'))
def sha(x): return hashlib.sha256(x).hexdigest()
def git(*a): return subprocess.run(['git','-C',str(ROOT),'-c','core.excludesFile=.git/info/exclude',*a],check=True,capture_output=True).stdout
root=git('rev-parse','--show-toplevel').decode().strip(); head=git('rev-parse','HEAD').decode().strip(); branch=git('branch','--show-current').decode().strip()
assert pathlib.Path(root).resolve()==ROOT and head==b['head'] and branch==b['branch']
assert git('diff','--cached','--name-only')==b''
assert git('ls-files').decode().splitlines()==list(b['files'])
changed=[p for p,h in b['files'].items() if sha((ROOT/p).read_bytes())!=h]
assert changed==[TASK],changed
status=git('status','--porcelain=v1','--untracked-files=all').decode(); assert status.strip()=='M '+TASK,status
paths=git('diff','--name-only','HEAD').decode().splitlines(); assert paths==[TASK]
diff=git('diff','--no-ext-diff','--binary','HEAD','--',TASK)
(OUT/'phase1-task.diff').write_bytes(diff)
receipt={'phase':'PHASE1_TASK_ONLY_COMPLETE_WAITING_COORDINATOR_READBACK','actor':'/root/group_contract_fix_r5','task_id':'LOOP1-GROUP-001','git_root':root,'head':head,'branch':branch,'index_empty':True,'status':status,'task_path':TASK,'task_actual_sha256':sha((ROOT/TASK).read_bytes()),'task_before_sha256':b['files'][TASK],'raw_diff_path':str(OUT/'phase1-task.diff'),'raw_diff_sha256':sha(diff),'tracked_byte_hash_count':len(b['files']),'all_other_19021_tracked_worktree_bytes_unchanged':True,'before_snapshot_path':str(OUT/'phase1-before.json'),'before_snapshot_sha256':sha((OUT/'phase1-before.json').read_bytes()),'only_changed_repo_paths':paths,'phase2_granted':False,'phase1_task_write_activity':'STOPPED_PENDING_COORDINATOR','proposed_phase2_paths':['contracts/http/verify-auth-user-friend.ps1','tests/infrastructure/smoke.ps1','tests/contract/group/test_verification_failures.py',TASK,'spec/progress/current.md','spec/progress/evidence/LOOP1-GROUP-001/contract/fix-r5/**'],'other_source_tests_current_index_commit_runtime_publication_writes':False,'source_authority':'Sealed R3 EH-R3-P2-001/002/003, existing error-handling governance; no architecture/public contract expansion','failed_attempt_preserved':'phase1-task-registration.json PermissionError13; no partial write; normal precise escalation then succeeded','baseline':{'frozen':0,'planning':0,'architecture_all':0,'architecture_tests':'88, skip1, exit0','ci_tests':'35, skip4, exit0'},'research':'prospective_resume/partial running, not acceptance','stage':'S2 OPEN','contract_freeze':'PENDING','product':'Go/three-clients/G01..G09 PENDING','created_at_epoch':time.time()}
(OUT/'phase1-receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(receipt,ensure_ascii=False,indent=2)); print('phase1_receipt_sha256',sha((OUT/'phase1-receipt.json').read_bytes()))