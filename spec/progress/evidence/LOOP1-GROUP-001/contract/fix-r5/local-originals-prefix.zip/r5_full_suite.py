import hashlib,json,pathlib,subprocess,time,unittest
O=pathlib.Path(__file__).resolve().parent;R=pathlib.Path(r'H:\.codex\worktrees\group\IM-platform');D=O/'formal-suite-children';D.mkdir(exist_ok=False)
real=subprocess.run;children=[]
def observed(*args,**kwargs):
 argv=args[0] if args else kwargs['args'];entry={'argv':list(map(str,argv)),'script_copies':[]}
 n=len(children)+1;children.append(entry)
 for arg in argv:
  p=pathlib.Path(str(arg))
  if p.suffix=='.ps1' and p.is_file() and not p.resolve().is_relative_to(R.resolve()):
   for source in sorted(p.parent.glob('*.ps1')):
    raw=source.read_bytes();target=D/(f'{n:03d}-'+source.name);target.write_bytes(raw);entry['script_copies'].append({'original':str(source),'copy':str(target),'sha256':hashlib.sha256(raw).hexdigest()})
 start=time.monotonic();p=real(*args,**kwargs);entry.update(exit_code=p.returncode,elapsed_seconds=time.monotonic()-start,outputs={})
 for channel in ('stdout','stderr'):
  value=getattr(p,channel);raw=value.encode('utf-8') if isinstance(value,str) else (value or b'');target=D/(f'{n:03d}.'+channel);target.write_bytes(raw);entry['outputs'][channel]={'path':str(target),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'representation':'UTF8 text projection after subprocess newline normalization' if isinstance(value,str) else 'actual bytes'}
 (O/'formal-suite-child-history.json').write_text(json.dumps(children,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
 return p
subprocess.run=observed
suite=unittest.defaultTestLoader.discover(str(R/'tests/contract/group'),pattern='test_*.py');assert suite.countTestCases()==28,suite.countTestCases()
start=time.monotonic();result=unittest.TextTestRunner(verbosity=2).run(suite)
report={'actual_discovered_methods':result.testsRun,'errors':len(result.errors),'failures':len(result.failures),'skipped':len(result.skipped),'elapsed_seconds':time.monotonic()-start,'child_process_observations':len(children),'result':'PASS_LOCAL_ONLY' if result.wasSuccessful() else 'FAIL'}
(O/'formal-suite-result.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(report));raise SystemExit(0 if result.wasSuccessful() else 1)