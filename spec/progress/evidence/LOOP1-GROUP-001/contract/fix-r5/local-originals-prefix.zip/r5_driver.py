import hashlib, json, os, pathlib, subprocess, sys, time
OUT = pathlib.Path(__file__).resolve().parent
ROOT = pathlib.Path(r'H:\.codex\worktrees\group\IM-platform')
PY = r'C:\Users\21441\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
label, *command = sys.argv[1:]
if not label or any(c not in 'abcdefghijklmnopqrstuvwxyz0123456789-_' for c in label):
    raise ValueError('invalid output label')
if command[:1] == ['--']:
    command = command[1:]
for suffix in ('.stdout', '.stderr', '.json'):
    if (OUT / (label + suffix)).exists():
        raise FileExistsError(label + suffix)
env = os.environ.copy()
env['PATH'] = str(pathlib.Path(PY).parent) + os.pathsep + env['PATH']
env['PYTHONDONTWRITEBYTECODE'] = '1'
argv = [PY, '-Xutf8', '-B', str(ROOT / 'tools/research/recorder.py'), 'run-command', '--repo', str(ROOT), '--research-root', str(OUT / 'research'), '--run-id', 'R-GROUP-FIX-R5-20261020', '--', *command]
started = time.time()
p = subprocess.run(argv, cwd=ROOT, env=env, capture_output=True)
for suffix, data in (('.stdout', p.stdout), ('.stderr', p.stderr)):
    (OUT / (label + suffix)).write_bytes(data)
meta = {'argv': argv, 'command_argv': command, 'exit_code': p.returncode, 'elapsed_seconds': time.time() - started, 'stdout_sha256': hashlib.sha256(p.stdout).hexdigest(), 'stderr_sha256': hashlib.sha256(p.stderr).hexdigest()}
(OUT / (label + '.json')).write_text(json.dumps(meta, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
sys.stdout.buffer.write(p.stdout)
sys.stderr.buffer.write(p.stderr)
print(json.dumps({k: meta[k] for k in ("exit_code", "elapsed_seconds", "stdout_sha256", "stderr_sha256")}, ensure_ascii=False))
raise SystemExit(p.returncode)