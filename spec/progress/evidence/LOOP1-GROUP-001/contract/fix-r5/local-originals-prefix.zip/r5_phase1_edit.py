import hashlib,json,pathlib,re,subprocess
ROOT=pathlib.Path(r'H:\.codex\worktrees\group\IM-platform').resolve(); OUT=pathlib.Path(__file__).resolve().parent
TASK='spec/tasks/active/LOOP1-GROUP-001.md'; path=ROOT/TASK
before=json.loads((OUT/'phase1-before.json').read_text(encoding='utf-8'))
def git(*args): return subprocess.run(['git','-C',str(ROOT),'-c','core.excludesFile=.git/info/exclude',*args],capture_output=True,check=True).stdout
assert pathlib.Path(git('rev-parse','--show-toplevel').decode().strip()).resolve()==ROOT
assert git('rev-parse','HEAD').decode().strip()==before['head']
assert git('status','--porcelain=v1','--untracked-files=all')==b''
assert git('diff','--cached','--name-only')==b''
raw=path.read_bytes(); assert hashlib.sha256(raw).hexdigest()==before['files'][TASK]
text=raw.decode('utf-8').replace('\r\n','\n')
text=text.replace('owner: /root/group_contract_fix_r4','owner: /root/group_contract_fix_r5',1)
old='- `contracts/http/verify-auth-user-friend.ps1`（激活时实际输入适配：仅 Get-ModelFailures 的全局 ordered registry 在原15码后接入已授权 GROUP_REQUEST_CONFLICT；旧15码顺序、Auth/Friend特定负例覆盖、全部原断言/mutations/退出传播保持；不得修改Auth OpenAPI或旧fixtures）'
new='- `contracts/http/verify-auth-user-friend.ps1`（现全局 ordered registry 仍精确为原15码原序+GROUP_REQUEST_CONFLICT；本Fix R5仅修 EH-R3-P2-001 的 Get-OpenApiStructureErrors 直接边界：只有 pinned checker 明确 schema-invalid exit1 可计结构拒绝；缺Node/launch失败、内部exit2/37及其他非零/未知异常、ConvertTo-Json内部异常正常传播，使整个verifier非零且不报PASS。保留旧15码业务覆盖、全局16码、6正例/21负例/15 mutations及全部原模型/结构断言；不得修改Auth OpenAPI、JS checkers或旧fixtures）'
assert text.count(old)==1; text=text.replace(old,new,1)
old='- `tests/infrastructure/smoke.ps1`（当前已授权canonical0001→0002验证输入适配：仅现Go/Java profile迁移ledger的SELECT显式ORDER BY version及精确两项比较；保留LASTEXITCODE、缺失/额外/重复拒绝，以及role/TLS/WSS/Compose/cleanup全部现检查和失败传播）'
new='- `tests/infrastructure/smoke.ps1`（现Go/Java profile的直接验证边界：EH-R3-P2-003要求ledger SELECT保留ORDER BY version，以保留/转义元素边界的结果精确验证两条且仅两条canonical记录0001_initial、0002_group_operations，大小写/顺序精确；拒绝单条含逗号或换行的unknown version、缺失/额外/重复/乱序/大小写错/native非零，不用另一个有歧义join、过滤unknown或动态接受未来migration。EH-R3-P2-002要求仅检查现owned project cleanup的实际结果，cleanup-only失败使操作非零，body与cleanup同时失败保留两因，环境清理仍执行，全部必需清理完成后才输出PASS。保留role/TLS/WSS/Compose、现资源归属和全部其他检查；不加通用错误/清理/重试框架）'
assert text.count(old)==1; text=text.replace(old,new,1)
old='- `tests/contract/group/**`'
new='- `tests/contract/group/**`（本Fix R5只新增 `tests/contract/group/test_verification_failures.py`，对上述三项既有验证入口做有意义的实际进程/直接边界故障回归；原test_group.py全部22测试方法、35valid/30invalid对象与helpers保持）'
assert text.count(old)==1; text=text.replace(old,new,1)
marker='- 现契约回归：'
addition='- Fix R5三项错误回归：`python -Xutf8 -B -m unittest discover -s tests/contract/group -p "test_verification_failures.py" -v`；实际调用当前PS入口/边界，隔离transport shim只控制外部依赖/原生exit，不作为真实Docker/TLS接受。known structural exit1仍为正常拒绝；初始真实Node正例0后，mutation阶段exit2/37/异常终止/launch与内部异常均令完整verifier非零且无PASS。Go/Java smoke成功、仅primary失败、仅cleanup失败、双失败覆盖真实native退出/两因/环境清理/成功输出时序；精确两canonical记录通过，单逗号/嵌入换行version及缺/extra/duplicate/order/case/nonzero拒绝。新增suite必须在现shared Ubuntu runner已有pwsh/Node下实际执行，不用Windows-only skip、未启用环境或新workflow/job冒充覆盖。\n'
assert text.count(marker)==1; text=text.replace(marker,addition+marker,1)
start=text.index('# Handoff\n'); end=text.index('\n# Next Action\n',start)
text=text[:start]+'''# Handoff

2026-10-20 fresh Fix R5 `/root/group_contract_fix_r5`已完成只读startup及minimum activation baseline。Coordinator核原专项R3 sealed FAIL/646原件并释放原只读lease后，明确授予PHASE1唯一Task-only写权限；本次仅先登记已证实三个falsePASS修复责任。脚本、tests、current及所有其他repo文件尚未修改，未stage/commit或运行服务资源；PHASE2必须等待Coordinator独立读回本Task实际hash/diff与all-other-pristine后另行明确授权。

regular_review: OLD R5 PASS at462431a45d60d1de0449a35b2fcf698a894d664b; NEW PENDING future FixR5 finalSHA
error_handling_review: R3 FAIL at462431a45d60d1de0449a35b2fcf698a894d664b; EH-R3-P2-001/002/003; DIFFERENT NEW PENDING future finalSHA
hosted_acceptance: PROHIBITED_PENDING_FRESH_FIX_AND_BOTH_NEW_REVIEWS (historical0a9 CI FAIL preserved)
main_sync: PENDING

专项原件外部 `contract-error-r3/final-receipt.json` SHA256 b083da01148b5cef0b496913358d92efe973e353aee646fdf9b8ec198d046ed7；report.md SHA256 f507ea6507ea343e2d904f9f4bb15269ed91a06803712a4aebb2c5644841bcdb；manifest646 SHA256 d5826a824a29b2c7973c4ee536f1fdaf436b56525fad6c957cce8ab1aaab2297。外部R5输出只在 `C:/Users/21441/.codex/visualizations/2026/10/18/01a14d96-146d-7f42-9fd8-0fd0c7e399e0/contract-fix-r5/`；Recorder R-GROUP-FIX-R5-20261020为prospective_resume/partial，startup/helperauthoring/通信/部分prompt缺口诚实披露。local/Recorder均不是独立接受。LKG仍6f163927334c39c9c8833eb8222335c661bde673，GROUP active/group_product、S2 OPEN、首契约freeze/Go/三端/G01..G09 PENDING。
''' + text[end:]
start=text.index('# Next Action\n'); end=text.index('\n# ',start+1)
text=text[:start]+'''# Next Action

Coordinator独立读回PHASE1 Task实际SHA/raw diff、exactroot/HEAD4624/branch、index空与其他源码逐字节不变→明确PHASE2后仅两PS、新test_verification_failures.py及Task/current/新contract/fix-r5证据实施三项最小修复。修前/修后真实fault与旧完整回归、真实受控Go/Java smoke/旧Go strictTLS E2E及必要own-schema真实PG ledger边界均记录实际argv/exit/耗时/raw/hash；不计隔离shim为runtime接受。单fixcommit/clean committedAcceptance后释放lease；NEW fresh常规R6→DIFFERENT NEW fresh专项R4覆盖最终SHA→新exact-head hosted requiredjobs/steps→protected integration→actual-main hosted/tree→保留782unknown及2unknowntracked安全主目录同步。两项新审查均PASS前禁止push/CI-triggering PR。首契约独立接受seal/同步完整后才由fresh产品Agent登记contract SHA继续Go/三端；Task不移review/done，S2不PASS。
''' + text[end:]
text += '''
# Verification Failure Repair Scope (Fix R5, registered before implementation)

本登记依据本Task原“激活时核对路径，确有新增输入先修Task范围，不在实施后追认”、既有独立runner真实部署/精确ledger/失败传播义务、canonical§12及spec/governance/error-handling.md和Minimality Contract。已封存R3三个当前可复现错误：EH-R3-P2-001 unknown checker错误被当schema-negative PASS；EH-R3-P2-002 cleanup native37仍整体0/PASS；EH-R3-P2-003真实PG一条逗号version被join压平为两条canonical而误PASS。原actual source Auth SHA256 faf8a4aab1c724dc51fd19fd39d1e077a83f67057b879029902f3004f9562e07，smoke SHA256 cc1103cd765339c9f26f6ae06c5f807cd32bcecc75aa7dcc08ab870100366700；原failed事实、旧审查/CI/Recorder/evidence均保留。

最小机制只在两个现边界：Auth仅明确exit1产生known schema错误，其他实际失败正常传播；smoke保留元素边界与精确两记录判定（拟使用现PG JSON聚合与现PowerShell解析原语，避免版本text中的逗号/换行别名），owned cleanup检查实际native结果并保留primary/cleanup双因，env cleanup在其finally执行且PASS延至必需清理结束。只在新单一test文件调用实际source/入口作三缺陷回归，不引入通用跨平台/错误/retry框架、依赖或生产test hook。Ubuntu与Windows都执行既有pwsh/Node，环境缺失明确失败，不能skip充PASS。实际实现细节仍由PHASE2和新独立Review核验，不由本Task授权架构/公共contract改变。

PHASE2精确拟写路径：`contracts/http/verify-auth-user-friend.ps1`、`tests/infrastructure/smoke.ps1`、`tests/contract/group/test_verification_failures.py`、本active Task、`spec/progress/current.md`、仅新 `spec/progress/evidence/LOOP1-GROUP-001/contract/fix-r5/**`。保留public Auth/group OpenAPI/JS checkers/errors/fixtures、原22tests/35valid30invalid、0001/0002/runner/GoE2E、全部Go/clients/Frozen/ADR/CI/Gate/旧sealed字节；不实现产品。

退出条件：三个falsePASS的原故障实际失败而known负例/正常成功保持；原检查与全局16/旧15业务码/6正例/21负例/15mutations完整；新formal suite现shared discovery确实执行；真实受控runtime及必要PG记录边界证据清理owned资源、所有原失败保留；source scope/逐字节保护/cleancommit与Development、clean committedAcceptance/Recorder实际结果明确。之后新最终SHA两项fresh独立审查、真实hosted/受保护集成/actual-main/安全主目录同步均PENDING，接受同步前不complete/done，不推进S2。
'''
# Preserve existing checkout newline convention, changing no other file.
path.write_bytes(text.replace('\n','\r\n').encode('utf-8') if b'\r\n' in raw else text.encode('utf-8'))
print('Task scope registered; no other repository file writes requested.')
print('Task actual SHA256:',hashlib.sha256(path.read_bytes()).hexdigest())