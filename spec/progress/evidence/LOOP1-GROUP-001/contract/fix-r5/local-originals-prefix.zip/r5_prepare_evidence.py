import hashlib,json,pathlib,re,subprocess,zipfile
R=pathlib.Path(r'H:\.codex\worktrees\group\IM-platform');O=pathlib.Path(__file__).resolve().parent;E=R/'spec/progress/evidence/LOOP1-GROUP-001/contract/fix-r5'
p=subprocess.run(['git','-C',str(R),'rev-parse','--show-toplevel'],check=True,capture_output=True,text=True);assert pathlib.Path(p.stdout.strip()).resolve()==R.resolve()
E.mkdir(exist_ok=False)
def dump(path,obj):path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
for source,target in [('phase1-receipt.json','scope-registration.json'),('scope-proof.json','scope-proof-prefix.json'),('error-handling-inventory.json','error-handling-inventory.json')]:
 (E/target).write_bytes((O/source).read_bytes())
upstream=[(O.parent/'contract-error-r3/final-receipt.json','r3-final-receipt.json'),(O.parent/'contract-error-r3/report.md','r3-report.md'),(O.parent/'contract-error-r3/findings.json','r3-findings.json'),(O.parent/'contract-error-r3/artifact-manifest.json','r3-artifact-manifest.json'),(O.parent/'contract-error-r3-coordinator-bindings.json','coordinator-r3-bindings.json'),(O.parent/'contract-fix-r5-phase1-coordinator-readback.json','coordinator-phase1-readback.json')]
bindings=[]
with zipfile.ZipFile(E/'original-review-and-scope.zip','x',zipfile.ZIP_DEFLATED) as z:
 for path,name in upstream:
  raw=path.read_bytes();z.writestr(name,raw);bindings.append({'source_path':str(path),'zip_entry':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
dump(E/'original-review-and-scope-bindings.json',bindings)
files=[p for p in O.rglob('*') if p.is_file() and 'runtime-private' not in p.parts]
with zipfile.ZipFile(E/'local-originals-prefix.zip','x',zipfile.ZIP_DEFLATED) as z:
 for path in files:z.write(path,path.relative_to(O).as_posix())
dump(E/'local-originals-prefix-binding.json',{'zip_sha256':hashlib.sha256((E/'local-originals-prefix.zip').read_bytes()).hexdigest(),'entries':len(files),'qualification':'Mutable-work prefix snapshot through package creation; Recorder running/partial, future commands and closure outside prefix are bound by final external receipt/manifest.'})
summary={'result':'LOCAL_REPAIR_VERIFIED_PG_AND_FINALIZATION_PENDING','parent_sha':'462431a45d60d1de0449a35b2fcf698a894d664b','formal_red':{'methods':6,'subtest_failures':14,'exit_code':1,'elapsed_seconds':88.838},'formal_final_28':json.loads((O/'formal-suite-result.json').read_text()),'group_fixtures':[35,30],'auth':{'error_codes':16,'positive':6,'negative':21,'mutation_regressions':15,'exit_code':0},'runtime':{name:json.loads((O/file).read_text()) for name,file in [('go','go-smoke-a2.result.json'),('java','java-smoke.result.json'),('go_tls','go-e2e.result.json')]},'pg':'PENDING: identity connection refused exit2 before any schema write; Coordinator restoring same owned instance; no PG PASS claimed','unchanged_group_old_methods':22,'new_methods':6,'old_sync_wss_plugin_exit':0,'baseline':'Frozen/planning/allarchitecture exit0;88architecture(skip1)/35CI(skip4) exit0 before and after fix','source_write_owner':'/root/group_contract_fix_r5','independent_reviews_hosted_integration_sync':'NEW PENDING','research':'prospective_resume/partial; final result intentionally FAIL for incomplete trace; structural validation remains pending','stage':'S2 OPEN','product':'G01..G09 PENDING'}
dump(E/'local-verification-prefix.json',summary)
current='''# Current Execution State

Current Loop: Loop 1
Current Stage: S2
Current Gate: S2
Gate Status: OPEN
Current Batch: LOOP1-GROUP-001
Batch Status: CONTRACT_FIX_R5_LOCAL_VERIFICATION_FINALIZATION_PENDING
Current Task: LOOP1-GROUP-001
Current Task State: active
Execution Status: active

## Immediately Relevant Completed Work

R3在clean462431a45d60d1de0449a35b2fcf698a894d664b封存EH-R3-P2-001/002/003 FAIL；旧R5常规PASS不豁免。fresh FixR5先PHASE1仅Task登记并经Coordinator独立bytehash/diff读回，获PHASE2唯一writer后修两个PS并新增单一故障suite。原首契约/产品接受仍PENDING；已接受规划/I18N和LKG main6f保持。

## Current Blockers

PG63830 identity连接拒绝exit2，未写schema，Coordinator正恢复同一owned实例；必要真实ledger边界未执行不计PASS。最终Development/clean committedAcceptance、单fixcommit与封存PENDING。新最终SHA regularR6/DIFFERENT specialistR4及hosted/protected integration/actual-main/安全同步全部PENDING。contract-acceptance-seal缺失，Go/三端/G01..G09尚未开始，S2 OPEN。

## Verification

- Command: `python -Xutf8 -B -m unittest discover -s tests/contract/group -p "test_*.py" -v`
  - Result: 修前新6methods真实14subtest FAIL/exit1；修后完整28methods实际执行，0failure/0error/0skip、57.550s/exit0。knownschema1保持，内部2/37/os._exit86快速终止/launch/缺Node/序列化异常不再negativePASS；不是OS信号崩溃证据。
  - Evidence: `spec/progress/evidence/LOOP1-GROUP-001/contract/fix-r5/local-verification-prefix.json`
- Command: `pwsh -NoProfile -File tests/infrastructure/smoke.ps1 -Profile go`
  - Result: 真实Go14.735s、Java12.515s、旧Go strictTLS E2E31.219s均exit0。每ownproject容器/卷空、既有容器ID/name/state保持。原TLS CA/hostname反例、Auth/成员/ACK/单Outbox/rollback/revocation及ADR4单项deferred保持。
  - Evidence: `spec/progress/evidence/LOOP1-GROUP-001/contract/fix-r5/local-originals-prefix.zip`

群35valid30invalid、原Auth全局16/旧15码业务覆盖/6positive21negative15mutations、Sync4/WSS/Plugin全部exit0。Frozen/planning/allarchitecture与88architecture(skip1)/35CI(skip4)前后exit0。隔离fault shim不作真实Docker/TLS接受；Recorder/local不是独立接受。

## Changed Files or Migrations

仅AuthPS结构checker边界、smoke精确JSON两ledger记录/cleanup失败传播与PASS时序、新test_verification_failures.py6methods、Task/current及新contract/fix-r5证据。公共OpenAPI/JScheckers/errors/fixtures、原test_group.py22methods/35valid30invalid、0001/0002/runner/GoE2E/Go/clients/Frozen/ADR/CI/Gate/旧sealed字节保持；无migration变化。

## Known Failures, Risks, and Assumptions

R3三FAIL、旧0a9两hosted FAIL与全部旧原件保持。新修前14FAIL真实保留。Task首次sandboxPermission13无partial，精确授权escalation成功。首次Docker只读API权限拒绝未建资源，后受控escalation运行成功。PG首次连接拒绝未建schema，不换库/读private或自行重启。新formal suite本地Windows执行，既有Ubuntu shared真实执行仍待最终SHA hosted，禁止Windows-only skip。

Recorder R-GROUP-FIX-R5-20261020为prospective_resume/partial：startup/helperauthoring/通信/visibleprompt摘录缺口、首次子Python未显式UTF8乱码后重读、部分工具展示截断后定向重读均公开；原raw保留。不伪完整trace；finish诚实FAIL、direct validate另报结构。same-run command串行并drain，无self-wrapped finish/validate。

## Next Exact Action

等Coordinator恢复PG同一实例→只own新随机schema真实canonical两row/单comma或newlineunknown/runner拒绝/native查询失败及cleanup边界→更新Task/current/新证据→Development→单fixcommit→clean committedAcceptance→诚实Recorder direct closure/sealed receipt并释放lease。NEW fresh regularR6→DIFFERENT NEW specialistR4同最终SHA都PASS后才可publication→新exact-head hosted实际requiredjobs/steps→protected integration→actual-main hosted/tree→保留782unknown及2unknowntracked安全同步。首契约正式接受同步后才fresh产品Agent继续，Task仍active/S2OPEN。

## Last Known Good Commit

`6f163927334c39c9c8833eb8222335c661bde673`：已接受、集成并安全同步的规划main。

## Latest Checkpoint

`spec/progress/checkpoints/2026-10-18-group-contract-activation.md`

## Uncommitted Changes / Ownership

唯一source writer `/root/group_contract_fix_r5`，exactroot `H:/.codex/worktrees/group/IM-platform`，branch `task/LOOP1-GROUP-001`，parent4624/base6f。只own已登记两PS、新单一formal测试、Task/current与新fix-r5证据；main未知工作不读取/采纳/覆盖。最终SHA/clean/ownedblobs/cleanAcceptance与lease释放只由外部contract-fix-r5/final-receipt.json绑定，当前尚未commit/释放。无push/PR/CI/merge/sync。

## Architecture Conflicts / ACP / ADR

无新增架构/技术/公共contract。当前错误治理直接修复，不改变ACK/security/兼容/源码职责。GROUP active/group_product、S2 OPEN；新两审/hosted/integration/sync仍PENDING。
'''
(R/'spec/progress/current.md').write_text(current,encoding='utf-8',newline='\n')
p=R/'spec/tasks/active/LOOP1-GROUP-001.md';text=p.read_text(encoding='utf-8');start=text.index('# Handoff\n');end=text.index('\n# Next Action\n',start)
text=text[:start]+'''# Handoff

2026-10-20 fresh Fix R5只在assigned root/branch/clean4624完成PHASE1 Task登记，Coordinator独立读回Task a352ce78/rawdiff942d6e及19021其他tracked bytes不变后，明确PHASE2唯一SOURCE WRITE LEASE。现仅两个PS+单新formal文件修复R3三个falsePASS；原schema/checkers/fixtures/22methods/SQL/runner/GoE2E/Go/clients/Frozen/ADR/CI/Gate/旧sealed字节保持。修前6methods14subtestFAIL/exit1保留；修后完整28methods0failure0error0skip/57.550s exit0。旧Auth全局16/旧15码覆盖/6positive21negative15mutations与群35valid30invalid、Sync4/WSS/Plugin保持。真实Go14.735s/Java12.515s/旧strictTLS31.219s全exit0，own容器卷空、原容器身份状态保持。详见新contract/fix-r5/local-verification-prefix.json与raw prefixZIP；local不是独立接受。

PG同一owned63830实例初次identity连接拒绝exit2，未建schema，Coordinator恢复中；不换库/读private或自启，必要真实ledger边界PENDING。首次Task Permission13/Docker只读API权限拒绝无partial/资源，后精确escalation成功；所有原failure保留。Recorder R-GROUP-FIX-R5-20261020 prospective_resume/partial，startup/helperauthoring/通信/prompt摘录/UTF8重读缺口诚实披露，后续串行drain；最终finish FAIL/structural validate/commit/cleanAcceptance另由外部finalreceipt实际绑定，当前仍工作中。

regular_review: NEW PENDING future FixR5 finalSHA (old regularR5 PASS bound4624 only)
error_handling_review: R3 FAIL at462431a45d60d1de0449a35b2fcf698a894d664b EH-R3-P2-001/002/003; DIFFERENT NEW PENDING future finalSHA
hosted_acceptance: PROHIBITED_PENDING_BOTH_NEW_REVIEWS (historical0a9 CI FAIL preserved)
main_sync: PENDING

R3原receipt b083da01148b5cef0b496913358d92efe973e353aee646fdf9b8ec198d046ed7/report f507ea6507ea343e2d904f9f4bb15269ed91a06803712a4aebb2c5644841bcdb/646manifest d5826a824a29b2c7973c4ee536f1fdaf436b56525fad6c957cce8ab1aaab2297及Coordinator核验/phase1批准原件在新original-review-and-scope.zip逐字节绑定。新最终SHA/ownedblobs/lease只从外部 `C:/Users/21441/.codex/visualizations/2026/10/18/01a14d96-146d-7f42-9fd8-0fd0c7e399e0/contract-fix-r5/final-receipt.json`恢复，当前未封存；LKG6f不变。GROUPactive/group_product、S2OPEN、首契约freeze/Go/三端/G01..G09 PENDING。
''' + text[end:]
p.write_text(text,encoding='utf-8',newline='\n')
(E/'handoff-prefix.md').write_text('FixR5 local verification prefix. PG/control/commit/cleanAcceptance/independent reviews/CI/sync pending. See local-verification-prefix.json and immutable raw-prefix ZIP. This is not final acceptance.\n',encoding='utf-8',newline='\n')
print('Wrote only new FixR5 evidence and authorized Task/current recovery state; PG pending is explicit.')