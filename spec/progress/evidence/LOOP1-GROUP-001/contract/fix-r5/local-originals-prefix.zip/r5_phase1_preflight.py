import hashlib,json,pathlib,subprocess,sys
ROOT=pathlib.Path(r'H:\.codex\worktrees\group\IM-platform').resolve()
OUT=pathlib.Path(__file__).resolve().parent
TASK='spec/tasks/active/LOOP1-GROUP-001.md'
def git(*args):
 p=subprocess.run(['git','-C',str(ROOT),'-c','core.excludesFile=.git/info/exclude',*args],capture_output=True,check=True)
 return p.stdout.decode('utf-8')
def h(raw): return hashlib.sha256(raw).hexdigest()
assert pathlib.Path(git('rev-parse','--show-toplevel').strip()).resolve()==ROOT
assert git('rev-parse','HEAD').strip()=='462431a45d60d1de0449a35b2fcf698a894d664b'
assert git('branch','--show-current').strip()=='task/LOOP1-GROUP-001'
assert git('status','--porcelain=v1','--untracked-files=all')==''
assert git('diff','--cached','--name-only')==''
files=git('ls-files').splitlines()
state={'git_root':str(ROOT),'head':git('rev-parse','HEAD').strip(),'branch':git('branch','--show-current').strip(),'index_empty':True,'clean':True,'files':{p:h((ROOT/p).read_bytes()) for p in files if (ROOT/p).is_file()}}
(OUT/'phase1-before.json').write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
(OUT/'phase1-task-before.bin').write_bytes((ROOT/TASK).read_bytes())
print(json.dumps({k:v for k,v in state.items() if k!='files'},ensure_ascii=False))
print('Tracked worktree byte digests saved:',len(state['files']))