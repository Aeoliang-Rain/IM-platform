import hashlib,json,pathlib
R=pathlib.Path(r'H:\.codex\worktrees\group\IM-platform')
paths=['contracts/http/auth-user-friend.openapi.json','contracts/http/sync.openapi.json','contracts/http/group.openapi.json','contracts/errors/http-errors.schema.json','contracts/websocket/envelope.schema.json','contracts/websocket/sync-v1.schema.json']
paths += [str(p.relative_to(R)) for p in (R/'contracts/fixtures').rglob('*.json') if any(s in p.parts for s in ('auth-user-friend','group','sync','database','websocket'))]
for rel in sorted(set(paths)):
 p=R/rel; raw=p.read_bytes(); v=json.loads(raw)
 print(json.dumps({'path':rel,'sha256':hashlib.sha256(raw).hexdigest(),'root_type':type(v).__name__,'keys':list(v) if isinstance(v,dict) else len(v)},ensure_ascii=False))
 if 'openapi' in v:
  print(json.dumps({'paths':v['paths'],'schema_names':list(v.get('components',{}).get('schemas',{}))},ensure_ascii=False))
 elif rel in paths[:6]: print(json.dumps(v,ensure_ascii=False))
for rel in ('contracts/database/migrations/0001_initial.up.sql','contracts/database/migrations/0001_initial.down.sql'):
 p=R/rel; raw=p.read_bytes(); print(rel,hashlib.sha256(raw).hexdigest()); print(raw.decode('utf-8'))