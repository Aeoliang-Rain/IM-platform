import pathlib, sys
path = pathlib.Path(sys.argv[1]); lines = path.read_text(encoding='utf-8-sig').splitlines()
for span in sys.argv[2:]:
    start, end = map(int, span.split(':'))
    for i in range(start - 1, min(end, len(lines))): print(f'{i+1}: {lines[i]}')