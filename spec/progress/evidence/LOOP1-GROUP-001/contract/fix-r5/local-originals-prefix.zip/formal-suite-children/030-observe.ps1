
$code = 0
try { & 'C:\Users\21441\AppData\Local\Temp\group-smoke-fault-jobdj5cw\smoke.ps1' -Profile 'go' }
catch { [Console]::Error.WriteLine($_.ToString()); $code = 1 }
finally {
    [Console]::Out.WriteLine('ENV_CLEAN=' + (-not (Test-Path Env:IM_HTTPS_PORT) -and -not (Test-Path Env:COMPOSE_PROGRESS)))
}
exit $code
