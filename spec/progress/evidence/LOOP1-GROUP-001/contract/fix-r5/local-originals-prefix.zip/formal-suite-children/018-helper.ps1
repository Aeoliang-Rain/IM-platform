$ErrorActionPreference = 'Stop'
function Get-OpenApiStructureErrors {
    param($Value, [string]$ValidatorPath, [string]$Location)
    $json = $Value | ConvertTo-Json -Depth 100
    $diagnostics = @($json | & node $ValidatorPath 2>&1)
    $checkerExit = $LASTEXITCODE
    # The pinned checker reserves exit1 for known schema rejection.
    # Launch, serialization and internal checker defects must fail the verifier.
    if ($checkerExit -eq 1) {
        return @("$Location does not conform to the pinned OAI OpenAPI 3.1 structural schema: $($diagnostics -join '; ')")
    }
    if ($checkerExit -ne 0) {
        throw "$Location OpenAPI structural checker failed with exit ${checkerExit}: $($diagnostics -join '; ')"
    }
    return @()
}

$env:PATH = ''
Get-OpenApiStructureErrors ([pscustomobject]@{}) 'unused-checker.js' 'fault'
Write-Output 'FALSE_HELPER_SUCCESS'
