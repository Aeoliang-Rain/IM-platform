import pathlib,subprocess,sys
R=pathlib.Path(r'H:\.codex\worktrees\group\IM-platform').resolve(); O=pathlib.Path(__file__).resolve().parent
p=subprocess.run(['git','-C',str(R),'rev-parse','--show-toplevel'],check=True,capture_output=True,text=True)
assert pathlib.Path(p.stdout.strip()).resolve()==R
rel=sys.argv[1]; assert rel in ('tests/contract/group/test_verification_failures.py','contracts/http/verify-auth-user-friend.ps1','tests/infrastructure/smoke.ps1','spec/tasks/active/LOOP1-GROUP-001.md','spec/progress/current.md')
target=R/rel; raw=(O/sys.argv[2]).read_bytes()
# The new test file is owned by this Fix; later edits stay in the same authorized path.
target.write_bytes(raw)
print('Wrote authorized',rel,len(raw))