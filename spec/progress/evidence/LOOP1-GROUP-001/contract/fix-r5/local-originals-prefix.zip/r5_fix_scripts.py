import hashlib,pathlib,subprocess
R=pathlib.Path(r'H:\.codex\worktrees\group\IM-platform').resolve()
p=subprocess.run(['git','-C',str(R),'rev-parse','--show-toplevel'],check=True,capture_output=True,text=True);assert pathlib.Path(p.stdout.strip()).resolve()==R
for rel,expected in [('contracts/http/verify-auth-user-friend.ps1','faf8a4aab1c724dc51fd19fd39d1e077a83f67057b879029902f3004f9562e07'),('tests/infrastructure/smoke.ps1','cc1103cd765339c9f26f6ae06c5f807cd32bcecc75aa7dcc08ab870100366700')]:
 path=R/rel; raw=path.read_bytes(); assert hashlib.sha256(raw).hexdigest()==expected
 text=raw.decode('utf-8').replace('\r\n','\n')
 if rel.startswith('contracts/'):
  old='''    try {
        $json = $Value | ConvertTo-Json -Depth 100
        $diagnostics = @($json | & node $ValidatorPath 2>&1)
        if ($LASTEXITCODE -ne 0) {
            return @("$Location does not conform to the pinned OAI OpenAPI 3.1 structural schema: $($diagnostics -join '; ')")
        }
    } catch {
        return @("$Location OpenAPI 3.1 structural schema validation failed: $($_.Exception.Message)")
    }'''
  new='''    $json = $Value | ConvertTo-Json -Depth 100
    $diagnostics = @($json | & node $ValidatorPath 2>&1)
    $checkerExit = $LASTEXITCODE
    # The pinned checker reserves exit1 for known schema rejection.
    # Launch, serialization and internal checker defects must fail the verifier.
    if ($checkerExit -eq 1) {
        return @("$Location does not conform to the pinned OAI OpenAPI 3.1 structural schema: $($diagnostics -join '; ')")
    }
    if ($checkerExit -ne 0) {
        throw "$Location OpenAPI structural checker failed with exit ${checkerExit}: $($diagnostics -join '; ')"
    }'''
  assert text.count(old)==1; text=text.replace(old,new,1)
 else:
  old="""    $migration = & docker compose -f $compose -p $project --profile $Profile exec -T postgres psql -U im -d im -Atc 'SELECT version FROM schema_migrations ORDER BY version'
    if ($LASTEXITCODE -ne 0 -or ($migration -join ',').Trim() -cne '0001_initial,0002_group_operations') { throw "canonical migration missing: $migration" }"""
  new="""    # JSON aggregation preserves row boundaries even for unknown versions
    # containing commas or newlines; native psql failure remains an error.
    $migrationJson = @(& docker compose -f $compose -p $project --profile $Profile exec -T postgres psql -U im -d im -Atc 'SELECT json_agg(version ORDER BY version) FROM schema_migrations')
    if ($LASTEXITCODE -ne 0 -or $migrationJson.Count -ne 1) { throw "canonical migration query failed: $migrationJson" }
    $migration = ConvertFrom-Json -InputObject $migrationJson[0] -NoEnumerate
    if (-not ($migration -is [array]) -or $migration.Count -ne 2 -or $migration[0] -cne '0001_initial' -or $migration[1] -cne '0002_group_operations') { throw "canonical migration missing: $migrationJson" }"""
  assert text.count(old)==1; text=text.replace(old,new,1)
  marker="\ntry {\n    Compose @('config', '--quiet')";assert text.count(marker)==1;text=text.replace(marker,"\n$primaryFailed = $false"+marker,1)
  old='''    Write-Output "PASS: $Profile profile, PostgreSQL migration, Core NATS, HTTPS and WSS over $($health.Protocol)"
} finally {
    & docker compose -f $compose -p $project --profile $Profile down --volumes --remove-orphans | Out-Host
    Remove-Item Env:IM_HTTPS_PORT -ErrorAction SilentlyContinue
    Remove-Item Env:COMPOSE_PROGRESS -ErrorAction SilentlyContinue
}'''
  new='''} catch {
    $primaryFailed = $true
    throw
} finally {
    try {
        Compose @('down', '--volumes', '--remove-orphans') | Out-Host
    } catch {
        if (-not $primaryFailed) { throw }
        # Cleanup cannot replace a pending primary failure; report its own
        # original error while the primary exception continues to propagate.
        Write-Error -ErrorRecord $_ -ErrorAction Continue
    } finally {
        Remove-Item Env:IM_HTTPS_PORT -ErrorAction SilentlyContinue
        Remove-Item Env:COMPOSE_PROGRESS -ErrorAction SilentlyContinue
    }
}
Write-Output "PASS: $Profile profile, PostgreSQL migration, Core NATS, HTTPS and WSS over $($health.Protocol)"'''
  assert text.count(old)==1; text=text.replace(old,new,1)
 path.write_bytes(text.replace('\n','\r\n').encode() if b'\r\n' in raw else text.encode())
 print(rel,hashlib.sha256(path.read_bytes()).hexdigest())