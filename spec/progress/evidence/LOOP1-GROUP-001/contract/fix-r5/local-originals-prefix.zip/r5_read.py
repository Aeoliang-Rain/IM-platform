import hashlib, pathlib, sys
ROOT = pathlib.Path(r'H:\.codex\worktrees\group\IM-platform')
mode, *args = sys.argv[1:]
for raw in args:
    path = pathlib.Path(raw)
    if not path.is_absolute():
        path = ROOT / path
    if mode == 'read':
        data = path.read_bytes()
        print('\nFILE', str(path), 'SHA256', hashlib.sha256(data).hexdigest())
        print(data.decode('utf-8-sig'))
    elif mode == 'sections':
        text = path.read_text(encoding='utf-8-sig')
        lines = text.splitlines()
        requested = {'2-3', '3', '4-3', '5', '6-1', '6-5', '6-6', '6-7', '10', '11', '12', '15', '19', '20'}
        collecting = False
        for i, line in enumerate(lines):
            if line.startswith('<a id="section-'):
                key = line.split('section-', 1)[1].split('"', 1)[0]
                collecting = key in requested or any(key.startswith(x + '-') for x in requested if x in {'3','5','10','11','12','15','19','20'})
            if collecting:
                print(f'{i+1}: {line}')
    elif mode == 'list':
        for p in sorted(path.rglob('*')):
            if p.is_file(): print(p.relative_to(ROOT) if p.is_relative_to(ROOT) else p)
    else:
        raise ValueError(mode)