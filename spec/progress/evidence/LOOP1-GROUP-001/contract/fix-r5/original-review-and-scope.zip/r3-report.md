# Independent error-handling audit R3 — FAIL

Actor `/root/group_contract_error_r3` reviewed only the first public-contract slice of `LOOP1-GROUP-001`. Final clean committed candidate: `462431a45d60d1de0449a35b2fcf698a894d664b`; parent `0a9f24a38774760e8003e15cc77ff65e3c0d25ac`; accepted base `6f163927334c39c9c8833eb8222335c661bde673`; branch `task/LOOP1-GROUP-001`; exact assigned root `H:/.codex/worktrees/group/IM-platform`.

**Three reproducible P2 findings prevent specialist acceptance.** This is a specialized audit result, not CI, public-contract freeze, integration, complete GROUP product acceptance or S2 Gate acceptance. GROUP remains active/group_product, S2 OPEN; Go/three-client/G01–G09 implementation and acceptance remain pending.

I am the original fresh specialist context, different from `/root/group_contract_regular_r5` and its Standards/Spec reviewers, and did not implement, fix or participate in any regular review of this candidate. I spawned no agents. Work paused after the initial October 18 review and resumed in the same context after Human “继续” on October 20; that pause is not a new independent reviewer or measured active work. Source, index, task/current, main, old evidence and publication were not modified. Source write lease was NONE throughout.

## Exact evidence and authority

Mandatory startup resolved the unique active task, canonical resolver/baseline and SHA `33b7b2a0a29b555b8c2842383890ae67fc382286b582b4681d2cd78b9f5829ca`. Canonical required sections, ADR0005–0013, domain/invariants, G01–G09/client acceptance and the five governance documents were read; frozen verification also checks historical PDF provenance. Recovered GROUP-PLAN/I18N acceptance is preserved through the exact recovery originals; historical pending paragraphs do not reopen those accepted prerequisites or freeze this new contract.

The entire `base..candidate --no-renames` range contains 83 paths: 82 present, one deleted backlog task. All actual Git blobs and present worktree bytes match the Fix receipt; canonical and0001 up/down bytes match accepted base. Latest parent..candidate has26 paths and exactly3 script-line replacements. `final-file-inventory.json` binds every path/status/revision/hash/responsibility/inspection, including files with no catch/search hits. `evidence-file-audit.json` additionally parses all changed JSON/Markdown and checks ZIP CRC plus every embedded entry hash.

Fresh regular R5 PASS was read before this specialist acceptance decision. Its receipt SHA is `1537ac0f53a79bbcb1ff7fe2c943d1b58a9b082348bab8c6cf1d6535e8206eb7`, report `2b5eaf58d182b546f0afe9d3e0f9534eaf11b42b7d855aacbf6ff22c41338aa2`, manifest `c89f3fcd0999c5caae14014cc1df07378b2a5173e3587532d79209e9035da11b`; all852 artifacts were individually rehashed. Fix R4 receipt `b2438d42cb4492cb31aa384caff3b73761cd38a0c4fefe2f085f6aeb8a776ecb`, report `cae84dce1fe2c71d2e4f9574ddacd8b56882f8a40c388541f75bd603401e6560` and manifest `b7a940a052bfad51fefa992a3d9b6b4e74fcffcb069c64e2957bad806728a366` match, including all201 items. See `upstream-artifact-verification.json`. An older PASS does not waive current semantic findings.

## EH-R3-P2-001 — Checker execution failure earns Auth negative-test PASS

Location: `contracts/http/verify-auth-user-friend.ps1:228–235`, consumed at544–548. Actual source SHA256 `faf8a4aab1c724dc51fd19fd39d1e077a83f67057b879029902f3004f9562e07`.

`Get-OpenApiStructureErrors` returns a rejection diagnostic for **every** checker nonzero exit and for its blanket catch. The structural mutation loop treats any nonempty result as a correctly rejected mutation. After the initial real Node validation succeeds, an internal checker exit2/37 or unknown launch exception during the negative controls is therefore credited as successful rejection. The full original verifier still exits0 and prints `PASS ... mutation_regressions=15.`

Independent actualsource reproductions preserve the entire verifier; the external shim only controls its `node` invocation. `auth-v2-structure-37-calls.jsonl` records ten calls: first real Node0, then nine actual native37 results with `CHECKER_INTERNAL_SENTINEL_37`. `auth-v2-structure-37.json` records full argv, exit0 and PASS stdout. Separate exit2 and unknown `InvalidOperationException` probes also exit0/PASS; the exit1 control behaves as expected. The unshimmed verifier independently passes, confirming the failure is classification of injected execution defects, not broken normal input.

Current basis: error-handling.md requires unknown/internal errors to propagate and forbids false rejection classifications. The pinned `check-openapi-3.1.js` distinguishes known schema rejection1 from unexpected failure2. Task preservation of15 old codes/21 negative scenarios/15 mutations requires meaningful negative oracles.

Minimal correction: only checker exit1 may count as schema rejection. Other native failures, missing/failed launches and unknown exceptions must fail the operation/runner with the real code/diagnostics/cause. Preserve old registry order, fixtures and all mutation controls. No new error framework is needed. A fresh Fix must first register any required narrow scope change.

Required regression: initial real positive0, each negative checker1 remains rejection; negative checker2/37/abnormal termination/launch exception makes the whole verifier nonzero and does not report PASS. Do not just catch a broader exception under another name.

## EH-R3-P2-002 — Smoke ignores cleanup native failure

Location: `tests/infrastructure/smoke.ps1:71–75`, especially72. Actual source SHA256 `cc1103cd765339c9f26f6ae06c5f807cd32bcecc75aa7dcc08ab870100366700`.

The finally block runs bounded `docker compose down` but never checks its native outcome. When the main smoke checks succeed and cleanup exits37, the script has printed PASS and the documented `pwsh -File ... -Profile go/java` process exits0. Necessary owned-resource cleanup has failed without failing that invocation.

The external reproduction retains the whole actual script and isolates Docker/TLS dependencies; cleanup invokes a real native child that writes `CLEANUP_NATIVE_SENTINEL_37` and exits37. `smoke-v2-go-primary0-cleanup37.json` and its Java counterpart record process0/PASS and the cleanup sentinel. The cleanup0 control also exits0. `smoke-v2-go-primary1-cleanup37.json` records primary ledger failure plus cleanup37 and process1; both original diagnostics are retained. These are fault probes, not real Docker/TLS runtime claims. A caller that separately checks ambient `$LASTEXITCODE` may still fail; this report does not assert that an actual hosted run containing this injected fault succeeded.

Current basis: error-handling.md requires resource cleanup and propagation of unrecoverable cleanup failure without replacing the primary cause; the Task requires real failure propagation and preserved cleanup.

Minimal correction: inspect the cleanup result and explicitly fail cleanup-only failure. If body and cleanup both fail, preserve the primary exception/cause and the cleanup diagnostic rather than replacing the original with a finally throw. Keep cleanup bounded to the owned project and restore the test environment. No generic cleanup/retry platform is justified.

Required regression: body-success/cleanup37 yields nonzero; body-failure/cleanup-success retains primary cause; dual failure yields nonzero and both causes; existing success and resource ownership checks remain.

## EH-R3-P2-003 — Comma join loses ledger row identity/count

Location: `tests/infrastructure/smoke.ps1:59–60`, same source hash as above.

The new `($migration -join ',').Trim()` comparison accepts both two canonical rows and **one** unknown row whose version is `0001_initial,0002_group_operations`. Delimiter flattening destroys the exact row/cardinality information the check must validate.

This was proven with real PostgreSQL16.15, not forged psql output: in an owned random schema, actual canonical runner up succeeds; the ledger is then changed to one unknown comma-valued row. The runner’s actual status fails1 with `migration ledger is not a known ordered prefix`. Original PS59–60, consuming the real exact SELECT output through a transport-only shim, exits0 and prints `ACCEPTED_ONE_REAL_LEDGER_ROW`. A separate real SELECT proves count1 and the comma version. See `pg-fault-audit-a2.json`, `a2-pg-comma-row-count.stdout`, `a2-pg-corrupt-runner-status.stderr`, and `a2-pg-comma-ledger-actual-smoke.stdout`.

Current basis: the Task’s explicitly bounded R4 adaptation requires the exact ordered two canonical ledger entries, not a projection that aliases unknown state; canonical runner/README reject unknown ledger; error governance forbids invalid state becoming normal success. This is in the new R4 comparison. It is distinct from the retained cleanup and Auth defects.

Minimal correction: compare an unambiguous exact set of **two ordered, case-sensitive canonical rows**, retaining native failure propagation and `ORDER BY version`. Do not choose another ambiguous join, ignore unknown rows or dynamically accept future migrations. The fresh Fix chooses the smallest implementation after prior Task scope registration.

Required regression: the two real canonical rows pass; singleton comma-valued row, missing/extra/duplicate/reversed/case-wrong/native-failure rows reject. Preserve the Python E2E exact two-line comparison and all existing TLS/business checks.

## Remaining semantic coverage

The15 changed execution/schema/fixture inputs were inspected in full responsibility context: workflow, database README/runner/up/down, error catalog, both group fixtures, group OpenAPI, both HTTP verifiers, group/database tests, E2E and smoke. Remaining68 paths are task/recovery/evidence, including the deleted backlog instance. Imports use the existing standard-library validation/migration/testing paths and the existing pinned Node validator. No new sensitive technology, product service, Go/client implementation, source ownership inversion or speculative framework was found.

Group verifier behavior outside the findings is sound within this offline slice: only structural exit1 becomes known Invalid; missing Node, exit2/37/-9 and launch/internal exceptions propagate. Nonobject body/query returns legitimate400 without attribute failure; valid request IDs remain correlated. Unknown validator/context defects tested as RuntimeError/KeyError propagate. Current authorization precedes replay/conflict. Missing original receipts require non2xx server failure with no invented409/backfill. Eligible row prefixes and derived truthful lookahead reject omissions/false empty terminal; legal short pages and237 members across pages remain accepted. `per-fixture-outcomes.json` individually records all35 accepted and30 specifically Invalid outcomes; product runtime vectors remain PENDING.

Migration review confirms original0001 raw bytes/text checksum, original advisory lock481233001, known ordered ledger prefix/checksums, under-lock complete state recheck, atomic all-pending DDL+ledger, highest-single-level down and explicit data-loss acknowledgement. Actual owned-PG failure injection makes0002 fail after0001 work and proves users/ledger/helper all roll back; the original PG relation error reaches nonzero CLI. Actual subsequent up applies both versions. The full11-test PG suite was independently run by R5 and its originals are hash-bound; this specialist claims only its own targeted real PG probes, not another full11-test run.

Existing workflow shared calls to group verifier and group suite have immediate LASTEXITCODE checks; old checks and job/gate selection remain. The new group formal-negative oracle actually becomes a unittest error for internal2/37/-9. Old Auth global registry adapts exactly15+GROUP while old15-specific coverage remains; its separate structural mutation classification is finding001.

`retained-catch-fallback-inventory.json` binds56 individual catches/finally/schema sentinel boundaries to actual file hash, concrete failure, current authority and real recovery/failure behavior. `fallback-inventory-supplement.json` covers27 further defaults/fixture representations. Known schema alternative rejection, known malformed input400/server-UUID correlation, explicit negative fixture Invalid, CLI nonzero, bounded TLS startup retry, exact TLS rejection checks, rollback/owned cleanup and test SQLSTATE assertions are separately explained. Files without handlers are still in the per-file inventory. Findings001/002 explicitly identify unjustified retained handling rather than approving it.

## Verification and raw evidence

Every recorded command’s exact argv, cwd, exit, elapsed time, raw-output paths/hashes and command/event IDs are in `command-history.json`; outer unredacted public-source/raw outputs are in `commands/`, with Recorder’s immutable blobs also retained. Nested actual native/fault and PG argv/exit/elapsed outputs are in the two fault matrices and PG audit. The review findings are determined by their observed child/process behavior, not the audit harness’s own successful completion.

| Verification | Outer exit | Elapsed seconds |
| --- | ---: | ---: |
| Frozen architecture | 0 | 0.229 |
| S2 planning (Gate not evaluated) | 0 | 0.231 |
| Architecture all | 0 | 0.925 |
| 88 architecture tests (skip1) | 0 | 21.678 |
| 35 CI tests (skip4) | 0 | 5.673 |
| Group35valid/30invalid | 0 | 0.465 |
| Group22 tests | 0 | 1.997 |
| Old AUF6positive/21negative/15mutations | 0 | 7.758 |
| Existing Sync contract | 0 | 0.676 |
| Existing Sync4 tests | 0 | 0.699 |
| Existing WSS verifier | 0 | 0.748 |
| Existing Plugin verifier | 0 | 0.583 |
| Whole-script fault observation harness | 0 | 29.077 |
| 54Python/10PS fault observation harness | 0 | 3.946 |
| Initial external PG helper (CRLF assertion failure) | 1 | 1.256 |
| RealPG failure/cardinality/cleanup observation harness | 0 | 1.658 |

`python-fault-matrix.json` contains54 independent Python cases and10 PS ledger cases, including structural known rejection/execution defects, nonobject requests, context/validator propagation, negative-suite internal errors, runner failure causes and exactsource ledger conditions. `shell-fault-matrix.json` contains eight full-script probes. `pg-fault-audit-a2.json` contains real owned-PG operations and cleanup. Reproduce using the exact Python3/Pwsh argv in the corresponding JSON or run the bound helper `fault_shell_v2.py`, `fault_python.py` or `fault_pg_v2.py`; the last requires the already-authorized disposable PG endpoint and credential-file path, never credential contents.

All original failed attempts remain: rg launcher WinError5, ambient Git ignore permission warnings, and the first PG helper’s LF-only assertion failing on Windows CRLF after successful real up. That first helper still executed finally cleanup. The new attempt changes only external comparison to decoded splitlines, preserves raw bytes, and creates new a2 files. The initial Python matrix’s statement that comma input required forged psql output was too strong; real PG disproved that interpretation. `limitations-and-corrections.json` records the correction without altering the original matrix.

## Research and resources

Recorder `R-GROUP-ERROR-R3-20261018` is **prospective_resume/partial**, deliberately finished FAIL; direct finish and validate each exit0. Structural closure has 57 starts, 57 finishes, zero unmatched commands and an intact hash chain. Startup/direct reads, semantic prompt transcription, helper authoring, communications, pause/resume and final sealing are not a complete prospective trace. Recorder’s file metadata cannot turn that partial prompt/transcription into a complete platform prompt. No hidden timing/model/token facts were inferred. No trace/blob was edited to obtain PASS. Research FAIL is reported separately from the three product-review findings; neither Recorder result is CI/Task/Stage acceptance.

Both random own PG schemas from the two attempts were dropped; before/after schema lists are equal. PGPASSFILE was only passed by path and never read, printed or copied. No public/other schema was modified, no server was stopped, and this specialist did not start Docker/product services or change trust. All child processes completed and no sessions or source write lease remain. Final source root/HEAD/branch/status/diffs are rechecked in `final-state-binding-v3.json`.

## Required next action

Coordinator records specialized FAIL and all three finding IDs for this exact SHA in task/current/evidence, retaining active/group_product and S2 OPEN. This read-only specialist does not edit those source files. Publication/push/CI-triggering PR updates remain prohibited under error-handling.md. Assign a fresh Fix, register necessary narrow Task scope before edits, repair and verify, then use a fresh regular reviewer and a different fresh specialist on the new final SHA. Only after both PASS may new exact-head hosted jobs/steps, protected integration, actual-main and safe main synchronization proceed. The first contract must be independently frozen/synchronized before Go/three-client product implementation.
