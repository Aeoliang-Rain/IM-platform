import hashlib,json,pathlib,re,subprocess,zipfile
R=pathlib.Path(r'H:\.codex\worktrees\group\IM-platform');O=pathlib.Path(__file__).resolve().parent;E=R/'spec/progress/evidence/LOOP1-GROUP-001/contract/fix-r5'
assert pathlib.Path(subprocess.check_output(['git','-C',str(R),'rev-parse','--show-toplevel'],text=True).strip()).resolve()==R.resolve()
def h(raw):return hashlib.sha256(raw).hexdigest()
def dump(path,obj):path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
pg=json.loads((O/'pg-a3/pg-ledger-result.json').read_text(encoding='utf-8'));assert pg['own_schema_removed'] and pg['schemas_before_after_equal']
for attempt in ('pg-a2','pg-a3'):
 assert (O/attempt/'pg-schemas-before.stdout').read_bytes()==(O/attempt/'pg-schemas-after.stdout').read_bytes()
summary=json.loads((E/'local-verification-prefix.json').read_text(encoding='utf-8'));summary['result']='PASS_LOCAL_REPAIR_ONLY_NEW_REVIEWS_HOSTED_SYNC_PENDING';summary['pg']=pg;summary['pg_prior_failures']=['initial identity connection refused exit2 before schema writes','A2 external helper incorrectly required known-prefix diagnostic for newline; actual runner ValueError propagated exit1 and own cleanup passed; raw unchanged, A3 current-cause assertion corrected externally only'];summary['development_clean_committed_acceptance']='PENDING actual command results bound by final external receipt';summary['research']='prospective_resume/partial; final direct finish intentionally FAIL, structural validation separately bound by final receipt'
dump(E/'local-verification.json',summary)
for source,target in [('pg-a3/pg-ledger-result.json','pg-ledger-result.json'),('formal-suite-result.json','formal-suite-result.json')]: (E/target).write_bytes((O/source).read_bytes())
# Preserve the old prefix archive; store only newly created public outputs here.
with zipfile.ZipFile(E/'local-originals-prefix.zip') as old: prior=set(old.namelist())
late=[p for p in O.rglob('*') if p.is_file() and p.relative_to(O).as_posix() not in prior and 'runtime-private' not in p.parts and 'research' not in p.relative_to(O).parts]
with zipfile.ZipFile(E/'local-originals-late.zip','x',zipfile.ZIP_DEFLATED) as z:
 for p in late:z.write(p,p.relative_to(O).as_posix())
 root_pg=O.parent/'pg-owned-recovery-20261020-availability.json';z.write(root_pg,'coordinator-pg-availability.json')
dump(E/'local-originals-late-binding.json',{'sha256':h((E/'local-originals-late.zip').read_bytes()),'entries':len(late)+1,'qualification':'Additional public outputs after immutable prefix, including failed A2 and successful A3. Final control/commit/Recorder closure remain external receipt-bound. Root PG start itself is not claimed PASS; own actual identity/probes are separate.'})
# All original fields/headings stay recoverable; replace current pending PG state.
p=R/'spec/progress/current.md';text=p.read_text(encoding='utf-8')
text=text.replace('Batch Status: CONTRACT_FIX_R5_LOCAL_VERIFICATION_FINALIZATION_PENDING','Batch Status: CONTRACT_FIX_R5_CANDIDATE_PENDING_NEW_REVIEWS')
text=text.replace('PG63830 identity连接拒绝exit2，未写schema，Coordinator正恢复同一owned实例；必要真实ledger边界未执行不计PASS。最终Development/clean committedAcceptance、单fixcommit与封存PENDING。','真实PG16.15已亲自核身份；两canonical记录通过，单comma/newline真实unknown row与native查询失败均明确失败，own schemas清理/前后清单保持。最终Development/clean committedAcceptance、单fixcommit与封存实际结果由外部final receipt绑定。')
text=text.replace('spec/progress/evidence/LOOP1-GROUP-001/contract/fix-r5/local-verification-prefix.json','spec/progress/evidence/LOOP1-GROUP-001/contract/fix-r5/local-verification.json')
text=text.replace('PG首次连接拒绝未建schema，不换库/读private或自行重启。','PG首次连接拒绝未建schema，Coordinator恢复同实例后才own验证；A2外部helper过强假设newline也应known-prefix而assert失败，实际runner未知ValueError/exit1正常传播，finally清理完整；A3仅纠正外部断言后真实全部通过，不修runner/伪knownnegative。原FAIL全保留，凭据仅libpq路径。')
text=text.replace('等Coordinator恢复PG同一实例→只own新随机schema真实canonical两row/单comma或newlineunknown/runner拒绝/native查询失败及cleanup边界→更新Task/current/新证据→Development→单fixcommit→clean committedAcceptance→诚实Recorder direct closure/sealed receipt并释放lease。','从外部 `contract-fix-r5/final-receipt.json` 核实际Development、clean committed最终SHA/Acceptance、ownedblobs、诚实Recorder direct closure与lease RELEASED。')
text=text.replace('当前尚未commit/释放','单fixcommit及释放的实际状态以该receipt为准')
p.write_text(text,encoding='utf-8',newline='\n')
p=R/'spec/tasks/active/LOOP1-GROUP-001.md';text=p.read_text(encoding='utf-8')
text=text.replace('PG同一owned63830实例初次identity连接拒绝exit2，未建schema，Coordinator恢复中；不换库/读private或自启，必要真实ledger边界PENDING。','PG初次identity连接拒绝exit2，未建schema；Coordinator恢复同一实例后，own亲自核PG16.15/data-v2/63830/db/user，再在两次新随机schema验证。最终A3 canonical runner up/status0和actual smoke snippet0；真实count1的comma/newline version都令smoke非零，comma runner known-prefix1/newline未知ValueError1保留；缺表native查询也失败。两次finally均drop own schema、before/after列表相同，credentials只交libpq路径。A2外部helper过强known-prefix诊断假设assert失败原件保留，A3仅外部断言校正，不改runner/重分类unknown。')
text=text.replace('contract/fix-r5/local-verification-prefix.json与raw prefixZIP','contract/fix-r5/local-verification.json与raw prefix/late ZIP')
text=text.replace('当前仍工作中。','最终实际结果由sealed receipt绑定；本writer不自评独立接受。')
text += '''
# Fresh Fix R5 Local Outcome

仅两处现验证边界修复三项R3发现；新增一个formal文件6methods，原22methods/35valid30invalid与公共schema/fixtures/checkers/SQL/runner/GoE2E/Go/三端/Frozen/ADR/CI/Gate/旧sealed逐字节保持。28methods实际0fail0error0skip、旧Auth15mutations与其他旧契约/控制/架构回归、真实Go/Java smoke/旧strictTLS E2E、必要真实PG ledger边界均已执行，完整argv/exit/elapsed及原失败见新fix-r5原件。隔离fault shim不代替真实运行，os._exit86仅快速原生终止，不冒称信号崩溃。未重复无变化全11 migration suite，也不声称本Fix独立DB11 PASS；历史11/0skip保持、未来真实hosted仍必需。

Development/clean committedAcceptance、实际单fixcommit/clean/ownedblobs和Recorder direct finish FAIL/validate结构状态由外部final-receipt.json封存，不提前自称通过。完整trace缺口真实披露，原事件/blob不改。新最终SHA fresh regularR6及DIFFERENT specialistR4均NEW PENDING，两审PASS前禁止push/CI-triggering PR；hosted/protected integration/actual-main/安全同步PENDING。首契约未冻结，GROUP active/group_product、S2OPEN，所有G01..G09与产品仍PENDING。
'''
p.write_text(text,encoding='utf-8',newline='\n')
# Byte-preservation proof after all recovery writes; no hashing of untracked/main data.
b=json.loads((O/'phase1-before.json').read_text(encoding='utf-8'));allowed={'contracts/http/verify-auth-user-friend.ps1','tests/infrastructure/smoke.ps1','spec/tasks/active/LOOP1-GROUP-001.md','spec/progress/current.md'}
changed=[p for p,s in b['files'].items() if h((R/p).read_bytes())!=s];assert set(changed)==allowed,changed
scope={'result':'PASS_SCOPE_PRESERVATION','initial_tracked_files':len(b['files']),'changed_existing_paths':changed,'unchanged_existing_count':len(b['files'])-len(changed),'all_other_tracked_bytes_unchanged':True,'new_code_path':'tests/contract/group/test_verification_failures.py','new_evidence_prefix':'spec/progress/evidence/LOOP1-GROUP-001/contract/fix-r5/','source_hashes':{p:h((R/p).read_bytes()) for p in sorted(allowed|{'tests/contract/group/test_verification_failures.py'})},'main_work_not_read_or_written':True}
dump(O/'scope-proof-final.json',scope);dump(E/'scope-proof.json',scope)
# Expose exact recorded finished command prefix, never pretend the current capture is finished.
events=[json.loads(line) for line in (O/'research/runs/R-GROUP-FIX-R5-20261020/events.jsonl').read_text(encoding='utf-8').splitlines()]
starts={e['data']['command_id']:e for e in events if e['event_type']=='command_started'}
finished=[{'started':starts[e['data']['command_id']],'finished':e} for e in events if e['event_type']=='command_finished']
dump(E/'command-history-prefix.json',{'qualification':'Finished command prefix; packaging/current command and later control/commit/closure are bound by final external receipt and final Recorder, not fabricated here.','commands':finished})
(E/'handoff.md').write_text('''# Fix R5 handoff

Parent462431a45d60d1de0449a35b2fcf698a894d664b; accepted base6f163927334c39c9c8833eb8222335c661bde673; branch task/LOOP1-GROUP-001; exact assigned root H:/.codex/worktrees/group/IM-platform. Scope registered in PHASE1 and independently read back before PHASE2 code writes.

Auth known schema exit1 remains rejection; all other native/launch/serialization faults fail. Smoke uses escaped PG JSON aggregate and exact two ordered canonical strings, checks owned cleanup native status and retains dual causes/env cleanup; prints PASS after cleanup. No framework or public contract/technology changes. New formal file6methods plus original22 actual28/0skip; real native failures fail, original fixtures35/30 and Auth6/21/15 remain. Real Go14.735s/Java12.515s/old strictTLS31.219s exit0 with owned resources removed and original containers unchanged. Actual PG16.15 verifies count1 comma/newline unknown rows reject and native SQL failure propagates; both own schemas removed with equal before/after lists.

All initial red14FAIL, Task/Docker sandbox denials, PG initial refused connection and A2 external overstrict diagnostic assertion remain immutable raw evidence. The newline runner's ValueError is an actual unexpected failure propagated nonzero, not a known rejection. No runner/SQL migration fix or full DB11 rerun is claimed. Prefix/late ZIPs preserve original bytes; external receipt supplies later actual Development/clean committed Acceptance, commit/SHA/clean/ownedblobs and honest partial Recorder direct closure. Recorder FAIL for incomplete trace is separate from structural validity and product acceptance.

Only this Fix owns twoPS/newformal/Task/current/newfix-r5 evidence. All other19018 initially tracked bytes match initial snapshot. Main unknown work untouched. After one clean fix commit and actual control checks, release source lease. New regularR6 and different specialistR4 on exact finalSHA, then real hosted requiredjobs/steps, protected integration, actual-main and safe main synchronization remain required. Never push/trigger CI from this writer. GROUP remains active/group_product, contract freeze PENDING and S2 OPEN; Go/three clients/G01..G09 are not implemented.
''',encoding='utf-8',newline='\n')
print('Final local evidence/recovery written; actual control/commit/closure and all independent acceptance remain receipt-bound.')