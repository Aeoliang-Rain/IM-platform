import hashlib,json,os,pathlib,re,subprocess,time,uuid
ROOT=pathlib.Path(r'H:\.codex\worktrees\group\IM-platform'); OUT=pathlib.Path(__file__).resolve().parent/'pg-a3'; OUT.mkdir(exist_ok=False)
PY=r'C:\Users\21441\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
PS=r'C:\Users\21441\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\powershell\pwsh.exe'
PGROOT=pathlib.Path(r'H:\IM-platform\.git\worktrees\IM-platform4\group-pg16-20261018'); PSQL=str(PGROOT/'pgsql/bin/psql.exe')
env=os.environ.copy();env.update(PGHOST='127.0.0.1',PGPORT='63830',PGUSER='group_contract_fixture',PGDATABASE='group_contract_20261018',PGSSLMODE='disable',PGPASSFILE=str(PGROOT/'libpq-v2.private'),DB_TEST_ENABLE='1');env.pop('PGPASSWORD',None);env['PATH']=str(PGROOT/'pgsql/bin')+os.pathsep+str(pathlib.Path(PY).parent)+os.pathsep+env['PATH']
commands=[]
def run(label,argv,*,sql=None,environment=None,expected=0,diagnostic=None):
 started=time.monotonic();p=subprocess.run(argv,cwd=ROOT,env=environment or env,input=sql.encode('utf-8') if sql is not None else None,capture_output=True)
 meta={'label':label,'argv':argv,'exit_code':p.returncode,'elapsed_seconds':time.monotonic()-started,'stdin_sql':sql,'raw':{}}
 for channel,data in [('stdout',p.stdout),('stderr',p.stderr)]:
  path=OUT/('pg-'+label+'.'+channel);assert not path.exists();path.write_bytes(data);meta['raw'][channel]={'path':str(path),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
 commands.append(meta);(OUT/'pg-command-history.json').write_text(json.dumps(commands,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
 assert p.returncode==expected,(label,p.returncode,p.stderr.decode('utf-8','replace'))
 if diagnostic: assert diagnostic in p.stderr.decode('utf-8','replace'),(label,p.stderr)
 return p.stdout.decode('utf-8')
def sql(label,text,**kw):return run(label,[PSQL,'-X','-v','ON_ERROR_STOP=1','-q','-A','-t'],sql=text,**kw)
identity=json.loads(sql('identity',"SELECT json_build_object('version',current_setting('server_version'),'database',current_database(),'user',current_user,'port',inet_server_port(),'directory',current_setting('data_directory'),'start',pg_postmaster_start_time());"))
assert identity['version'].startswith('16.15') and identity['database']=='group_contract_20261018' and identity['user']=='group_contract_fixture' and identity['port']==63830,identity
assert pathlib.Path(identity['directory']).resolve().is_relative_to(PGROOT.resolve()),identity
before=sql('schemas-before','SELECT nspname FROM pg_namespace ORDER BY nspname;')
schema='fix_r5_'+uuid.uuid4().hex;owned=env.copy();owned['PGOPTIONS']='-c search_path='+schema
sql('create-own','CREATE SCHEMA '+schema+';')
source=(ROOT/'tests/infrastructure/smoke.ps1').read_text(encoding='utf-8')
start=source.index('    $migrationJson =');end=source.index('    $health =',start);snippet=source[start:end]
probe=OUT/'pg-actual-smoke-ledger.ps1'
q=lambda x:"'"+str(x).replace("'","''")+"'"
probe.write_text("$ErrorActionPreference = 'Stop'\nfunction docker {\n & "+q(PSQL)+" -X -v ON_ERROR_STOP=1 -q -A -t -c $args[-1]\n $global:LASTEXITCODE = $LASTEXITCODE\n}\n"+snippet+"Write-Output 'LEDGER_ACCEPTED'\n",encoding='utf-8',newline='\n')
def check(label,accepted):return run(label,[PS,'-NoProfile','-File',str(probe)],environment=owned,expected=0 if accepted else 1,diagnostic=None if accepted else 'canonical migration')
try:
 run('canonical-up',[PY,'-Xutf8','-B',str(ROOT/'contracts/database/migrate.py'),'up'],environment=owned)
 run('canonical-status',[PY,'-Xutf8','-B',str(ROOT/'contracts/database/migrate.py'),'status'],environment=owned)
 canonical=json.loads(sql('canonical-ledger',"SELECT json_agg(json_build_object('version',version,'checksum',checksum) ORDER BY version) FROM schema_migrations;",environment=owned))
 assert [r['version'] for r in canonical]==['0001_initial','0002_group_operations']
 assert all(re.fullmatch('[0-9a-f]{64}',r['checksum']) for r in canonical)
 check('two-canonical-rows',True)
 for label,value in [('comma','0001_initial,0002_group_operations'),('newline','0001_initial\n0002_group_operations')]:
  literal="'"+value.replace("'","''")+"'"
  sql(label+'-seed',"DELETE FROM schema_migrations; INSERT INTO schema_migrations(version,checksum) VALUES ("+literal+",'fault');",environment=owned)
  observed=json.loads(sql(label+'-actual-count',"SELECT json_build_object('count',count(*),'versions',json_agg(version ORDER BY version)) FROM schema_migrations;",environment=owned));assert observed=={'count':1,'versions':[value]},observed
  run(label+'-runner-refusal',[PY,'-Xutf8','-B',str(ROOT/'contracts/database/migrate.py'),'status'],environment=owned,expected=1,diagnostic='not enough values to unpack' if label=='newline' else 'migration ledger is not a known ordered prefix')
  check(label+'-actual-smoke-refusal',False)
 sql('drop-owned-ledger','DROP TABLE schema_migrations;',environment=owned)
 check('native-query-failure',False)
finally:
 sql('drop-own','DROP SCHEMA '+schema+' CASCADE;')
 after=sql('schemas-after','SELECT nspname FROM pg_namespace ORDER BY nspname;')
 assert before==after,'schema inventory changed beyond own schema'
report={'result':'PASS_LOCAL_LEDGER_BOUNDARY_ONLY','identity':identity,'own_schema':schema,'own_schema_removed':True,'schemas_before_after_equal':True,'credential_handling':'PGPASSFILE path only, never read/printed/copied','commands':commands,'newline_runner_classification':'Unexpected line parsing ValueError propagates CLI nonzero; not a known schema-negative and not reclassified/repaired','qualification':'Actual PG16.15 runner and actual smoke ledger snippet; docker is transport-only shim to real psql. Not full Docker/TLS acceptance.'}
(OUT/'pg-ledger-result.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({k:v for k,v in report.items() if k!='commands'},ensure_ascii=False))