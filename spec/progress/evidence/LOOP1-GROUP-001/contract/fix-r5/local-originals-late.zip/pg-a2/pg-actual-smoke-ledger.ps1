$ErrorActionPreference = 'Stop'
function docker {
 & 'H:\IM-platform\.git\worktrees\IM-platform4\group-pg16-20261018\pgsql\bin\psql.exe' -X -v ON_ERROR_STOP=1 -q -A -t -c $args[-1]
 $global:LASTEXITCODE = $LASTEXITCODE
}
    $migrationJson = @(& docker compose -f $compose -p $project --profile $Profile exec -T postgres psql -U im -d im -Atc 'SELECT json_agg(version ORDER BY version) FROM schema_migrations')
    if ($LASTEXITCODE -ne 0 -or $migrationJson.Count -ne 1) { throw "canonical migration query failed: $migrationJson" }
    $migration = ConvertFrom-Json -InputObject $migrationJson[0] -NoEnumerate
    if (-not ($migration -is [array]) -or $migration.Count -ne 2 -or $migration[0] -cne '0001_initial' -or $migration[1] -cne '0002_group_operations') { throw "canonical migration missing: $migrationJson" }
Write-Output 'LEDGER_ACCEPTED'
