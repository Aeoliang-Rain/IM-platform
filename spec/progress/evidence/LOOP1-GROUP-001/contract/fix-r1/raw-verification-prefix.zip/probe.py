import hashlib
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path('H:/.codex/worktrees/group/IM-platform')
OUT = Path(__file__).resolve().parent
OLD = OUT.parent / 'contract-regular-r1'
checks = {
    'report.md': '390b45395449c39363c5cf26bd414cc8abf45ec6b2d617bf272da7e51c0de902',
    'final-receipt.json': '58fbf816dfa70b2f3f5b5da5058ed49f3860f7067d99cd04cde33848a41c3c62',
    'artifact-manifest.json': '377e0e56ea4b44eb6645d2297451073c3bd760c31ba4b1a532b56c046c08dcae',
}
for name, expected in checks.items():
    assert hashlib.sha256((OLD / name).read_bytes()).hexdigest() == expected, name
spec = importlib.util.spec_from_file_location('group_oracle_fix_probe', ROOT / 'contracts/http/verify-group.py')
oracle = importlib.util.module_from_spec(spec)
spec.loader.exec_module(oracle)
rows = []
for name in ('snapshot-nonfriend', 'snapshot-split-page'):
    source = OLD / f'counterexample-{name}.json'
    case = json.loads(source.read_text(encoding='utf8'))
    try:
        oracle.check_exchange(case)
    except oracle.Invalid as error:
        result, detail = 'REJECTED', str(error)
    else:
        result, detail = 'ACCEPTED_INCORRECT_EXCHANGE', 'R1-P2-001 reproduced'
    rows.append({'fixture': name, 'original_path': str(source), 'sha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'result': result, 'detail': detail})
output = {'phase': sys.argv[1], 'counterexamples': rows, 'all_rejected': all(row['result'] == 'REJECTED' for row in rows)}
(OUT / f'{sys.argv[1]}-counterexamples.json').write_text(json.dumps(output, ensure_ascii=False, indent=2) + '\n', encoding='utf8')
print(json.dumps(output, ensure_ascii=False, indent=2))
sys.exit(0 if output['all_rejected'] else 1)
