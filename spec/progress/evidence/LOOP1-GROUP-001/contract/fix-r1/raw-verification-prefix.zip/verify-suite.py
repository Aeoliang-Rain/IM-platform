import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('H:/.codex/worktrees/group/IM-platform')
OUT = Path(__file__).resolve().parent
PY = Path(sys.executable)
PWSH = Path('C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe')
REC = [str(PY), '-Xutf8', '-B', 'tools/research/recorder.py']
RUN = ['--research-root', str(OUT / 'research'), '--run-id', 'R-GROUP-CONTRACT-FIX-R1-20261018']
os.environ['PATH'] = str(PY.parent) + os.pathsep + os.environ['PATH']
commands = [
    [str(PY), '-Xutf8', '-B', '-m', 'unittest', 'discover', '-s', 'tests/architecture'],
    [str(PY), '-Xutf8', '-B', '-m', 'unittest', 'discover', '-s', 'tests/ci'],
    [str(PWSH), '-NoProfile', '-File', 'contracts/http/verify-auth-user-friend.ps1'],
    [str(PY), '-Xutf8', '-B', 'tools/verify_sync_transport.py'],
    [str(PY), '-Xutf8', '-B', '-m', 'unittest', 'discover', '-s', 'tests/contract', '-p', 'test_sync_transport.py'],
    [str(PY), '-Xutf8', '-B', 'contracts/websocket/verify.py'],
    [str(PY), '-Xutf8', '-B', 'contracts/plugin-api/verify.py'],
    [str(PWSH), '-NoProfile', '-File', 'tools/verify-loop1-ctrl-002.ps1', '-Mode', 'Development'],
    ['git', 'diff', '--check'],
    ['git', 'diff', '--stat'],
    ['git', 'diff', '--', 'contracts/http/verify-group.py', 'tests/contract/group/test_group.py', 'contracts/fixtures/group/exchanges.json'],
]
results = []
for index, argv in enumerate(commands):
    start = time.perf_counter()
    process = subprocess.run(REC + ['run-command'] + RUN + ['--'] + argv, cwd=ROOT, capture_output=True)
    prefix = f'verification-{index:02d}'
    (OUT / f'{prefix}.stdout.txt').write_bytes(process.stdout)
    (OUT / f'{prefix}.stderr.txt').write_bytes(process.stderr)
    result = {'argv': argv, 'exit_code': process.returncode, 'elapsed_seconds': round(time.perf_counter()-start,6), 'stdout': f'{prefix}.stdout.txt', 'stderr': f'{prefix}.stderr.txt'}
    results.append(result)
    print(json.dumps(result), flush=True)
(OUT / 'verification-results.json').write_text(json.dumps(results, indent=2) + '\n', encoding='utf8')
sys.exit(0 if all(row['exit_code'] == 0 for row in results) else 1)
