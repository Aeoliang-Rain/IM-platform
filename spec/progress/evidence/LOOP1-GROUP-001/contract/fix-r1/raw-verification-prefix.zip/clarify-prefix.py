from pathlib import Path
ROOT=Path('H:/.codex/worktrees/group/IM-platform')
path=ROOT/'contracts/http/verify-group.py'
text=path.read_text(encoding='utf8')
old="    limit = query.get('limit',100)\n    require(keys == eligible[:limit],'complete ordered eligible page prefix')\n    has_more = len(eligible) > limit\n"
new="    require(keys == eligible[:len(keys)],'complete ordered eligible page prefix')\n    require(bool(keys) or not eligible,'empty page only when no eligible rows remain')\n    has_more = len(eligible) > len(keys)\n"
assert text.count(old)==1
path.write_text(text.replace(old,new),encoding='utf8',newline='\n')
path=ROOT/'tests/contract/group/test_group.py'
text=path.read_text(encoding='utf8')
text=text.replace("def test_omitting_any_eligible_page_row_is_rejected(self):", "def test_skipped_eligible_rows_and_incomplete_terminal_pages_are_rejected(self):")
text=text.replace("            for index in range(len(original['response']['items'])):\n", "            omitted=range(len(original['response']['items'])-1) if original['response']['hasMore'] else range(len(original['response']['items']))\n            for index in omitted:\n",1)
marker='    def test_more_than_one_page_and_no_total_group_size_cap(self):\n'
test="""    def test_short_ordered_prefix_with_truthful_lookahead_can_reach_terminal(self):
        for limit in (2,None):
            with self.subTest(limit=limit):
                first=self.case('snapshot-split-page');all_rows=self.case('snapshot-nonfriend')['response']['items']
                if limit is None:first['request']['query'].pop('limit')
                first['response']['items']=all_rows[:1]
                first['response']['next']=dict(afterConversationId=all_rows[0]['conversationId'],afterMemberUserId=all_rows[0]['member']['user']['userId'])
                v.check_exchange(first)
                last=copy.deepcopy(first)
                last['request']['query'].update(first['response']['next'])
                last['response'].update(items=all_rows[1:],hasMore=False,next=dict(afterConversationId='',afterMemberUserId=''))
                last['context']['additionalRowExists']=False
                v.check_exchange(last)
                self.assertEqual(first['response']['items']+last['response']['items'],all_rows)

"""
assert text.count(marker)==1
path.write_text(text.replace(marker,test+marker),encoding='utf8',newline='\n')
print('Aligned with unchanged items<=limit authority: contiguous actual-length prefix, no false empty page, truthful remaining-row lookahead; legal short prefix regression added.')
