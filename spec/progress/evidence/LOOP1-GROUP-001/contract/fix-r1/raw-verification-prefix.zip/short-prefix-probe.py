import copy
import importlib.util
import json
from pathlib import Path
import sys
ROOT=Path('H:/.codex/worktrees/group/IM-platform')
OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('short_prefix_oracle',ROOT/'contracts/http/verify-group.py')
oracle=importlib.util.module_from_spec(spec);spec.loader.exec_module(oracle)
fixtures=json.loads((ROOT/'contracts/fixtures/group/exchanges.json').read_text(encoding='utf8'))
case=copy.deepcopy(next(row for row in fixtures['valid'] if row['id']=='snapshot-split-page'))
case['response']['items']=case['response']['items'][:1]
last=oracle.row_key(case['response']['items'][-1])
case['response']['next']=dict(afterConversationId=last[0],afterMemberUserId=last[1])
try:oracle.check_exchange(case)
except oracle.Invalid as error:accepted=False;detail=str(error)
else:accepted=True;detail='legal short ordered prefix accepted with truthful remaining rows'
result={'phase':sys.argv[1],'limit':2,'eligible':3,'items':1,'hasMore':True,'accepted':accepted,'detail':detail,'authority':'Unchanged GET description says items <= limit; no mandatory full-page requirement.'}
(OUT/(sys.argv[1]+'-short-prefix.json')).write_text(json.dumps(result,indent=2)+'\n',encoding='utf8')
print(json.dumps(result));sys.exit(0 if accepted else 1)
