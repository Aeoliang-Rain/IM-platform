import copy
import json
from pathlib import Path
import subprocess

ROOT = Path('H:/.codex/worktrees/group/IM-platform')
assert subprocess.check_output(['git', 'rev-parse', '--show-toplevel'], cwd=ROOT, text=True).strip() == ROOT.as_posix()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == '5aa1632341fd90f30a00a87356ee2d09ee3f9bbe'
task = ROOT / 'spec/tasks/active/LOOP1-GROUP-001.md'
task_text = task.read_text(encoding='utf8')
assert task_text.count('owner: /root/group_contract_impl') == 1
task.write_text(task_text.replace('owner: /root/group_contract_impl','owner: /root/group_contract_fix_r1') + '\n# Fresh Fix R1 In Progress\n\nR1-P2-001 regular-review FAIL at 5aa1632341fd90f30a00a87356ee2d09ee3f9bbe is preserved. Sole source writer now /root/group_contract_fix_r1 in assigned exact root H:/.codex/worktrees/group/IM-platform. Minimal oracle repair only; final candidate, fresh regular review and DIFFERENT fresh error specialist, hosted and main sync remain NEW PENDING. Old implementation/review evidence remains historical and unchanged.\n', encoding='utf8', newline='\n')
current = ROOT / 'spec/progress/current.md'
current_text = current.read_text(encoding='utf8')
current.write_text(current_text.replace('唯一writer /root/group_contract_impl；','唯一writer /root/group_contract_fix_r1；') + '\nFresh Fix R1 in progress: original regular review FAIL R1-P2-001 retained at 5aa1632341fd90f30a00a87356ee2d09ee3f9bbe; new final candidate and both fresh reviews/hosted/main sync PENDING.\n', encoding='utf8', newline='\n')
path = ROOT / 'contracts/http/verify-group.py'
text = path.read_text(encoding='utf8')
old = "    require(body['hasMore'] == context['additionalRowExists'],'hasMore iff lookahead committed row')\n"
new = """    eligible = sorted(tuple(row) for row in context['activeRows']
                      if row[0] in context['ownConversationIds'] and tuple(row) > previous)
    limit = query.get('limit',100)
    require(keys == eligible[:limit],'complete ordered eligible page prefix')
    has_more = len(eligible) > limit
    require(context['additionalRowExists'] == has_more,'fixture lookahead matches eligible rows')
    require(body['hasMore'] == has_more,'hasMore iff lookahead committed row')
"""
assert text.count(old) == 1
path.write_text(text.replace(old, new), encoding='utf8', newline='\n')

path = ROOT / 'contracts/fixtures/group/exchanges.json'
fixtures = json.loads(path.read_text(encoding='utf8'))
def valid(name):
    return copy.deepcopy(next(case for case in fixtures['valid'] if case['id'] == name))

case = valid('snapshot-nonfriend')
case['id'] = 'snapshot-false-empty-terminal'
case['response']['items'] = []
fixtures['invalid'].append(case)
case = valid('snapshot-split-page')
case['id'] = 'snapshot-omitted-first-advancing-cursor'
case['response']['items'] = case['response']['items'][1:]
fixtures['invalid'].append(case)
case = valid('snapshot-split-page')
case['id'] = 'snapshot-hidden-lookahead'
case['context']['additionalRowExists'] = False
case['response'].update(hasMore=False, next={'afterConversationId':'', 'afterMemberUserId':''})
fixtures['invalid'].append(case)
case = valid('snapshot-nonfriend')
case['id'] = 'snapshot-invented-lookahead'
case['context']['additionalRowExists'] = True
last = case['response']['items'][-1]
case['response'].update(hasMore=True, next={'afterConversationId':last['conversationId'], 'afterMemberUserId':last['member']['user']['userId']})
fixtures['invalid'].append(case)
path.write_text(json.dumps(fixtures, ensure_ascii=False, indent=2) + '\n', encoding='utf8', newline='\n')

path = ROOT / 'tests/contract/group/test_group.py'
text = path.read_text(encoding='utf8')
marker = '    def test_more_than_one_page_and_no_total_group_size_cap(self):\n'
tests = """    def test_omitting_any_eligible_page_row_is_rejected(self):
        for name in ('snapshot-nonfriend','snapshot-split-page','snapshot-resume-terminal'):
            original=self.case(name)
            for index in range(len(original['response']['items'])):
                with self.subTest(fixture=name,omitted=index):
                    case=copy.deepcopy(original)
                    del case['response']['items'][index]
                    if case['response']['hasMore'] and case['response']['items']:
                        last=v.row_key(case['response']['items'][-1])
                        case['response']['next']=dict(afterConversationId=last[0],afterMemberUserId=last[1])
                    with self.assertRaises(v.Invalid):v.check_exchange(case)
        case=self.case('snapshot-nonfriend');case['response']['items']=[]
        with self.assertRaises(v.Invalid):v.check_exchange(case)

    def test_lookahead_is_derived_even_when_context_and_response_agree(self):
        for name in ('snapshot-nonfriend','snapshot-split-page'):
            case=self.case(name);more=not case['response']['hasMore']
            case['context']['additionalRowExists']=more
            case['response']['hasMore']=more
            last=v.row_key(case['response']['items'][-1])
            case['response']['next']=dict(afterConversationId=last[0],afterMemberUserId=last[1]) if more else dict(afterConversationId='',afterMemberUserId='')
            with self.subTest(fixture=name),self.assertRaises(v.Invalid):v.check_exchange(case)

    def test_page_prefix_uses_full_tuple_order_and_own_conversation_filter(self):
        case=self.case('snapshot-split-page')
        first,second=case['response']['items']
        later=copy.deepcopy(first);later['conversationId']='30000000-0000-4000-8000-000000000002'
        outside=copy.deepcopy(first);outside['conversationId']='30000000-0000-4000-8000-000000000003'
        case['context']['ownConversationIds'].append(later['conversationId'])
        case['context']['activeRows']=[list(v.row_key(row)) for row in (outside,later,second,first)]
        case['request']['query'].update(afterConversationId=first['conversationId'],afterMemberUserId=first['member']['user']['userId'])
        case['response'].update(items=[second,later],hasMore=False,next=dict(afterConversationId='',afterMemberUserId=''))
        case['context']['additionalRowExists']=False
        v.check_exchange(case)
        for omitted in (0,1):
            incomplete=copy.deepcopy(case);del incomplete['response']['items'][omitted]
            with self.subTest(omitted=omitted),self.assertRaises(v.Invalid):v.check_exchange(incomplete)

"""
assert text.count(marker) == 1
path.write_text(text.replace(marker, tests + marker), encoding='utf8', newline='\n')
print('Applied minimal eligible-prefix/lookahead repair; appended 4 negatives and 3 regression tests; preserved existing fixtures/tests.')
