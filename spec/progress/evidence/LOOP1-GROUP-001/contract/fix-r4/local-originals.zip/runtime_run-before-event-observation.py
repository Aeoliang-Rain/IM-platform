"""Run only existing authorized isolated Compose test entrypoints."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import secrets
import socket
import subprocess
import sys
import time

ROOT = Path('H:/.codex/worktrees/group/IM-platform')
OUT = Path(__file__).resolve().parent
PYTHON = 'C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
PWSH = 'C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'


def docker(*args):
    completed = subprocess.run(['docker', *args], cwd=ROOT, capture_output=True, text=True)
    if completed.returncode:
        raise RuntimeError('Docker query failed: ' + completed.stderr)
    return completed.stdout.strip()


def inventory():
    rows = docker('ps', '-a', '--no-trunc', '--format', '{{.ID}}\t{{.Names}}\t{{.State}}')
    return dict((line.split('\t', 1)[0], line.split('\t')[1:]) for line in rows.splitlines() if line)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('case', choices=('go-smoke', 'java-smoke', 'go-e2e'))
    parser.add_argument('--attempt', type=int, default=1)
    args = parser.parse_args()
    assert args.attempt >= 1
    slug = args.case if args.attempt == 1 else args.case+'-a'+str(args.attempt)
    assert subprocess.check_output(['git', '-c', 'core.excludesFile=.git/info/exclude', 'rev-parse', '--show-toplevel'], cwd=ROOT, text=True).strip() == ROOT.as_posix()
    environment = os.environ.copy()
    environment['PATH'] = str(Path(PYTHON).parent) + os.pathsep + str(Path(PWSH).parent) + os.pathsep + environment['PATH']
    environment['PYTHONDONTWRITEBYTECODE'] = '1'
    environment['PYTHONUTF8'] = '1'
    # Each existing test owns its project. No global Docker cleanup/trust change.
    before = inventory()
    engine = docker('version', '--format', '{{.Server.Version}} {{.Server.Os}}')
    private = OUT/'runtime-private'/slug
    private.mkdir(parents=True, exist_ok=False)
    if args.case.endswith('smoke'):
        profile = args.case.split('-')[0]
        port = 18443 if profile == 'go' else 18444
        with socket.socket() as probe:
            probe.bind(('127.0.0.1', port))
        if profile == 'go':
            config = private/'config'
            config.mkdir()
            (config/'config.json').write_bytes((ROOT/'backend/go/config.example.json').read_bytes())
            password = secrets.token_urlsafe(32)
            (config/'pg_password').write_text(password, encoding='utf-8', newline='\n')
            (config/'jwt_key').write_text(secrets.token_urlsafe(48), encoding='utf-8', newline='\n')
            environment['IM_POSTGRES_PASSWORD'] = password
            environment['IM_GO_CONFIG_DIR'] = str(config)
        else:
            environment.pop('IM_POSTGRES_PASSWORD', None)
        command = [PWSH, '-NoProfile', '-File', str(ROOT/'tests/infrastructure/smoke.ps1'), '-Profile', profile]
    else:
        # The existing E2E creates/removes its own temporary private config and
        # uses its established disposable fixture password, without OS trust.
        environment.pop('IM_POSTGRES_PASSWORD', None)
        command = [PYTHON, '-Xutf8', '-B', str(ROOT/'tests/e2e/go_tls_messaging.py')]
    start = time.monotonic()
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    stdout_path = OUT/(slug+'.stdout.log')
    stderr_path = OUT/(slug+'.stderr.log')
    assert not stdout_path.exists() and not stderr_path.exists(), 'never overwrite prior raw evidence'
    with stdout_path.open('wb') as stdout, stderr_path.open('wb') as stderr:
        process = subprocess.Popen(command, cwd=ROOT, env=environment, stdout=stdout, stderr=stderr)
        running = {'case': args.case, 'attempt': args.attempt, 'pid': process.pid, 'started_at': started, 'command': command, 'state': 'RUNNING', 'private_config_qualification': 'generated disposable secrets are not evidence and are not printed/copied'}
        (OUT/(slug+'.running.json')).write_text(json.dumps(running, indent=2)+'\n', encoding='utf-8', newline='\n')
        code = process.wait()
    elapsed = time.monotonic()-start
    combined = stdout_path.read_bytes()+stderr_path.read_bytes()
    if args.case.endswith('smoke'):
        projects = [f'im-infra-smoke-{args.case.split("-")[0]}-{process.pid}']
    else:
        projects = sorted(set(re.findall(r'im-s1-e2e-'+str(process.pid)+r'-[a-f0-9]{8}', combined.decode(errors='replace'))))
        assert len(projects) == 1, 'unable to bind the single existing E2E project'
    resources = {}
    for project in projects:
        resources[project] = {'containers': docker('ps', '-aq', '--filter', 'label=com.docker.compose.project='+project).split(), 'volumes': docker('volume', 'ls', '-q', '--filter', 'label=com.docker.compose.project='+project).split()}
        assert not resources[project]['containers'] and not resources[project]['volumes'], 'owned Compose resources remain'
    after = inventory()
    assert all(after.get(key) == value for key, value in before.items()), 'preexisting container identity/name/state changed'
    assert set(after) == set(before), 'unexpected container created or removed'
    if args.case == 'go-smoke':
        # Remove only generated private fixture files after the owned project ends.
        for name in ('pg_password', 'jwt_key', 'config.json'):
            (private/'config'/name).unlink()
        (private/'config').rmdir()
    private.rmdir()
    report = dict(running, state='FINISHED', exit_code=code, elapsed_seconds=elapsed, engine=engine, owned_projects=projects, cleanup=resources, preexisting_containers_unchanged=True, before_containers=before, after_containers=after, raw={})
    for path in (stdout_path, stderr_path):
        report['raw'][path.name] = {'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'bytes': path.stat().st_size}
    target = OUT/(slug+'.result.json')
    target.write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n', encoding='utf-8', newline='\n')
    print(json.dumps({key:report[key] for key in ('case','pid','exit_code','elapsed_seconds','engine','owned_projects','cleanup','preexisting_containers_unchanged')}))
    for line in stdout_path.read_text(encoding='utf-8', errors='replace').splitlines():
        if line.startswith(('PASS', 'DEFERRED_BY_HUMAN')):
            print(line)
    if code:
        print(stderr_path.read_text(encoding='utf-8', errors='replace')[-6000:], file=sys.stderr)
    return code


if __name__ == '__main__':
    raise SystemExit(main())
