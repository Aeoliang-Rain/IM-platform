"""Phase 1: coordinator-authorized scope registration, no script writes."""
from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path('H:/.codex/worktrees/group/IM-platform')
OUT = Path(__file__).resolve().parent
TASK = 'spec/tasks/active/LOOP1-GROUP-001.md'
HEAD = '0a9f24a38774760e8003e15cc77ff65e3c0d25ac'


def git(*args):
    return subprocess.check_output(['git', '-c', 'core.excludesFile=.git/info/exclude', *args], cwd=ROOT, text=True).strip()


assert git('rev-parse', '--show-toplevel') == ROOT.as_posix()
assert git('rev-parse', 'HEAD') == HEAD
assert git('branch', '--show-current') == 'task/LOOP1-GROUP-001'
assert git('status', '--porcelain') == ''
path = ROOT / TASK
before = path.read_bytes()
text = before.decode('utf-8')
anchor = '- `.github/workflows/ci.yml`'
assert text.count(anchor) == 1
insert = '''- `tests/infrastructure/smoke.ps1`（当前已授权canonical0001→0002验证输入适配：仅现Go/Java profile迁移ledger的SELECT显式ORDER BY version及精确两项比较；保留LASTEXITCODE、缺失/额外/重复拒绝，以及role/TLS/WSS/Compose/cleanup全部现检查和失败传播）
- `tests/e2e/go_tls_messaging.py`（同一首契约切片的现Go S1 strict TLS E2E迁移ledger输入适配：仅SELECT显式ORDER BY version及精确0001_initial与0002_group_operations两项比较；TLS/hostname反例、Auth/成员/ACK/seq/Outbox/Sync/cleanup及原失败传播保持）
'''
text = text.replace(anchor, insert + anchor)
text += '''
# Deployment verification input adaptation (Fix R4)

2026-10-18 Coordinator先授予PHASE1唯一Task登记lease，落实Allowed Paths原“激活时核对路径，确有新增输入先修Task范围，不在实施后追认”和Public Contract Slice既有独立runner真实部署0001→0002要求。仅登记上述两条验证输入路径；不改Frozen/ADR/公共wire/SQL/Go/clients/CI/Gate或群功能范围，未登记前不实施。

候选0a9f24a38774760e8003e15cc77ff65e3c0d25ac曾经fresh常规r4及different fresh专项r2 PASS，但真实push39115869727/job117641538618和PR39115960616/job117641824783均在Go transport smoke失败：smoke.ps1:60只接受0001_initial，实际合法ledger为0001_initial、0002_group_operations。原raw SHA256分别34fd1cb1e8879f7a9066d25923f2d120acef517a1664090ea81566ef44add247、54a64153e82dd857d02a236d6ec3159150145ac447c601aa736ae91342e09e86；原bindings146d3960cde7d98b0e34ca587d13ecf47b10ca45ab5edc614af709a759fc117c，位于外部OUT的contract-failed-deploy-original-bindings.json，原件保持。

同deploy后续Go S1 strict TLS messaging E2E因前步失败尚未hosted执行；静态核对go_tls_messaging.py:254发现同一旧单项ledger预期，不能称第二hosted失败。外部原snippet与同sql/docker包装注入复现，两处各10例：合法两项在原实现均拒绝；仅在内存proposed比较中接受精确两项，缺失/额外/重复/乱序/大小写错/非零退出仍明确拒绝或RuntimeError。before/proposed报告位于OUT/contract-fix-r4，SHA256分别048cc6f7bad4e3e1a16d1171129c8d2ea4784e3943badb69935ac01fd4eaacd6、6ccea954a2146149d56628a2f4c7d4cf8ccebe0f324bcf45dd589dc01d2049ce。此为隔离注入，不是实际Docker/TLS PASS。

当前代码仍未修改；Task登记读回经Coordinator确认后才可授予PHASE2。拟仅确定排序和明确两项精确比较，不动态接受未来migration；保留所有原检查/失败传播。后续任何新fix SHA都须NEW fresh常规与DIFFERENT NEW fresh专项后才可publication，再exact-head hosted、protected integration、actual-main及保存未知main安全同步。首契约未冻结、产品G01..G09仍PENDING，GROUP active/group_product、S2 OPEN。
'''
after = text.encode('utf-8')
path.write_bytes(after)
assert git('diff', '--name-only').splitlines() == [TASK]
assert git('diff', '--cached', '--name-only') == ''
report = {'phase': 'PHASE1_TASK_SCOPE_ONLY', 'root': ROOT.as_posix(), 'head': HEAD, 'branch': git('branch', '--show-current'), 'path': TASK, 'before_sha256': hashlib.sha256(before).hexdigest(), 'after_sha256': hashlib.sha256(after).hexdigest(), 'repository_changed_paths': git('diff', '--name-only').splitlines(), 'scripts_unchanged': True, 'source_lease': 'PHASE1 only; no script authorization'}
(OUT/'scope-registration.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n', encoding='utf-8', newline='\n')
(OUT/'scope-registration.diff').write_text(git('diff', '--', TASK)+'\n', encoding='utf-8', newline='\n')
print(json.dumps(report, ensure_ascii=False))
