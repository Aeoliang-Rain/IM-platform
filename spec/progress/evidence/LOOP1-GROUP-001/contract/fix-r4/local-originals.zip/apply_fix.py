"""Only the two coordinator-approved deployment assertion input adaptations."""
from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path('H:/.codex/worktrees/group/IM-platform')
OUT = Path(__file__).resolve().parent
TASK = 'spec/tasks/active/LOOP1-GROUP-001.md'
expected = {
    'tests/infrastructure/smoke.ps1': '5f0c6bf0cd387c223e8cae1a5fdf1d47986bef4dc46e18c98cbec17dc17d9496',
    'tests/e2e/go_tls_messaging.py': 'c02aed93c888c73237c5e65d057ad8f0faa7192d66ab86cb5830fe702297be81',
}


def git(*args):
    return subprocess.check_output(['git', '-c', 'core.excludesFile=.git/info/exclude', *args], cwd=ROOT, text=True).strip()


assert git('rev-parse', '--show-toplevel') == ROOT.as_posix()
assert git('rev-parse', 'HEAD') == '0a9f24a38774760e8003e15cc77ff65e3c0d25ac'
assert git('branch', '--show-current') == 'task/LOOP1-GROUP-001'
assert git('diff', '--name-only').splitlines() == [TASK]
assert hashlib.sha256((ROOT/TASK).read_bytes()).hexdigest() == 'bd5728ce38bdbbeac80c9238605ef70bf7bb9d0b90d961a73e841cc99c2d0e82'
report = []
for path, digest in expected.items():
    file = ROOT/path
    before = file.read_bytes()
    assert hashlib.sha256(before).hexdigest() == digest
    if path.endswith('.ps1'):
        old = b"($migration -join '').Trim() -ne '0001_initial'"
        new = b"($migration -join ',').Trim() -cne '0001_initial,0002_group_operations'"
        assert before.count(old) == 1 and before.count(b'SELECT version FROM schema_migrations') == 1
        after = before.replace(b'SELECT version FROM schema_migrations', b'SELECT version FROM schema_migrations ORDER BY version').replace(old, new)
    else:
        old = b"sql('SELECT version FROM schema_migrations') == '0001_initial'"
        new = b"sql('SELECT version FROM schema_migrations ORDER BY version') == '0001_initial\\n0002_group_operations'"
        assert before.count(old) == 1
        after = before.replace(old, new)
    file.write_bytes(after)
    report.append({'path': path, 'before_sha256': digest, 'after_sha256': hashlib.sha256(after).hexdigest(), 'expected_only_replacements': True})
(OUT/'script-edit.json').write_text(json.dumps(report, indent=2)+'\n', encoding='utf-8', newline='\n')
print(json.dumps(report))
