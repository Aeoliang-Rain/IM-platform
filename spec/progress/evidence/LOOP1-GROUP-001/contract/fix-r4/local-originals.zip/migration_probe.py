"""External exact-snippet probes; never edits the repository."""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import subprocess
import textwrap
from types import SimpleNamespace

ROOT = Path('H:/.codex/worktrees/group/IM-platform')
OUT = Path(__file__).resolve().parent
PWSH = 'C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'
SMOKE = 'tests/infrastructure/smoke.ps1'
E2E = 'tests/e2e/go_tls_messaging.py'
OLD_QUERY = 'SELECT version FROM schema_migrations'
NEW_QUERY = OLD_QUERY + ' ORDER BY version'
OLD_COMPARE = "($migration -join '').Trim() -ne '0001_initial'"
NEW_COMPARE = "($migration -join ',').Trim() -cne '0001_initial,0002_group_operations'"
OLD_E2E = "sql('SELECT version FROM schema_migrations') == '0001_initial'"
NEW_E2E = "sql('SELECT version FROM schema_migrations ORDER BY version') == '0001_initial\\n0002_group_operations'"


def source(phase):
    smoke = (ROOT / SMOKE).read_text(encoding='utf-8')
    e2e = (ROOT / E2E).read_text(encoding='utf-8')
    if phase == 'proposed':
        assert smoke.count(OLD_COMPARE) == 1 and smoke.count(OLD_QUERY) == 1
        assert e2e.count(OLD_E2E) == 1
        smoke = smoke.replace(OLD_QUERY, NEW_QUERY).replace(OLD_COMPARE, NEW_COMPARE)
        e2e = e2e.replace(OLD_E2E, NEW_E2E)
    if phase != 'before':
        assert smoke.count(NEW_QUERY) == 1 and smoke.count(NEW_COMPARE) == 1
        assert e2e.count(NEW_E2E) == 1
    return smoke, e2e


def ps_quote(s):
    return "'" + s.replace("'", "''") + "'"


def smoke_probe(smoke, phase, cases):
    guard = next(line.strip() for line in smoke.splitlines() if 'canonical migration missing:' in line)
    rows = []
    for name, versions, code in cases:
        assignment = ','.join(ps_quote(v) for v in versions)
        script = f'''$ErrorActionPreference='Stop'
$migration=@({assignment})
$global:LASTEXITCODE={code}
try {{
    {guard}
    [Console]::WriteLine('ACCEPT')
}} catch {{
    if (-not $_.Exception.Message.StartsWith('canonical migration missing:')) {{ throw }}
    [Console]::WriteLine('REJECT')
}}
'''
        result = subprocess.run([PWSH, '-NoProfile', '-Command', script], capture_output=True, text=True)
        assert result.returncode == 0, result.stderr
        actual = result.stdout.strip()
        if phase == 'before':
            expected = 'ACCEPT' if versions == ['0001_initial'] and code == 0 else 'REJECT'
        else:
            expected = 'ACCEPT' if name == 'canonical-two' else 'REJECT'
        assert actual == expected, (name, actual, expected)
        rows.append(dict(name=name, versions=versions, subprocess_exit=code, decision=actual))
    return {'guard': guard, 'results': rows}


def e2e_probe(e2e, phase, cases):
    tree = ast.parse(e2e)
    main = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'main')
    require_node = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'require')
    defs = [require_node] + [node for node in main.body if isinstance(node, ast.FunctionDef) and node.name in ('docker', 'compose', 'sql')]
    calls = [node for node in ast.walk(main) if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == 'require' and len(node.args) == 2 and isinstance(node.args[1], ast.Constant) and node.args[1].value == 'canonical migration missing']
    assert len(calls) == 1
    checked = ast.Expression(calls[0])
    state = {}

    def fake_run(args, **kwargs):
        state['query'] = args[-1]
        return SimpleNamespace(returncode=state['code'], stdout=state['stdout'], stderr=b'controlled psql failure: probe sentinel')

    namespace = dict(subprocess=SimpleNamespace(run=fake_run, PIPE=subprocess.PIPE), env={}, command=['docker', 'compose', 'controlled-probe'])
    exec(compile(ast.fix_missing_locations(ast.Module(body=defs, type_ignores=[])), E2E, 'exec'), namespace)
    rows = []
    for name, versions, code in cases:
        state.update(code=code, stdout=('\n'.join(versions) + '\n').encode())
        try:
            eval(compile(ast.fix_missing_locations(checked), E2E, 'eval'), namespace)
        except AssertionError as exc:
            assert str(exc) == 'canonical migration missing'
            actual = 'REJECT'
        except RuntimeError as exc:
            assert code != 0 and 'controlled psql failure: probe sentinel' in str(exc)
            actual = 'RUNTIME_FAILURE'
        else:
            actual = 'ACCEPT'
        expected_query = OLD_QUERY if phase == 'before' else NEW_QUERY
        assert state['query'] == expected_query
        if code:
            expected = 'RUNTIME_FAILURE'
        elif phase == 'before':
            expected = 'ACCEPT' if versions == ['0001_initial'] else 'REJECT'
        else:
            expected = 'ACCEPT' if name == 'canonical-two' else 'REJECT'
        assert actual == expected, (name, actual, expected)
        rows.append(dict(name=name, versions=versions, subprocess_exit=code, decision=actual, sql=state['query']))
    return {'assertion': ast.unparse(calls[0]), 'wrapper_source': [ast.unparse(node) for node in defs], 'results': rows}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('phase', choices=('before', 'proposed', 'after'))
    args = parser.parse_args()
    cases = [
        ('canonical-two', ['0001_initial', '0002_group_operations'], 0),
        ('missing-second', ['0001_initial'], 0),
        ('missing-first', ['0002_group_operations'], 0),
        ('empty', [], 0),
        ('extra', ['0001_initial', '0002_group_operations', '0003_future'], 0),
        ('duplicate', ['0001_initial', '0002_group_operations', '0002_group_operations'], 0),
        ('wrong-order', ['0002_group_operations', '0001_initial'], 0),
        ('wrong-case', ['0001_INITIAL', '0002_group_operations'], 0),
        ('nonzero-with-valid-output', ['0001_initial', '0002_group_operations'], 2),
        ('nonzero-with-empty-output', [], 37),
    ]
    smoke, e2e = source(args.phase)
    report = {
        'phase': args.phase,
        'qualification': 'Original extracted snippets or exact in-memory proposed replacements; injected command outputs, not a real Docker or TLS pass.',
        'source_sha256': {path: hashlib.sha256((ROOT/path).read_bytes()).hexdigest() for path in (SMOKE, E2E)},
        'smoke': smoke_probe(smoke, args.phase, cases),
        'e2e': e2e_probe(e2e, args.phase, cases),
    }
    target = OUT / (args.phase + '-migration-probe.json')
    target.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
    print(json.dumps({'phase': args.phase, 'smoke_cases': len(cases), 'e2e_cases': len(cases), 'result': 'PASS', 'report': str(target), 'sha256': hashlib.sha256(target.read_bytes()).hexdigest()}))


if __name__ == '__main__':
    main()
