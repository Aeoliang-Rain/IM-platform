from pathlib import Path
import importlib.util,copy,json,traceback,sys
ROOT=Path('H:/.codex/worktrees/group/IM-platform');OUT=Path('C:/Users/21441/.codex/visualizations/2026/10/18/01a14d96-146d-7f42-9fd8-0fd0c7e399e0/contract-regular-r3')
s=importlib.util.spec_from_file_location('correlation_review',ROOT/'contracts/http/verify-group.py');v=importlib.util.module_from_spec(s);s.loader.exec_module(v);document=json.loads(v.CONTRACT.read_text(encoding='utf-8'));fixtures=json.loads((ROOT/'contracts/fixtures/group/exchanges.json').read_text(encoding='utf-8'));template=next(c for c in fixtures['valid'] if c['id']=='create-a-b');results=[]
for index,payload in enumerate((None,[],42,'decoded scalar JSON')):
 c=copy.deepcopy(template);c['id']='independent-create-nonobject-'+str(index);c['request']['body']=payload;c['status']=400;c['response']={'requestId':'40000000-0000-4000-8000-000000000099','error':{'code':'VALIDATION_FAILED','message':'Request body must be an object.'}}
 derived=v.request_failure(c['operation'],c['request'],c['context'],document);assert derived==(400,'VALIDATION_FAILED')
 v.validate(c['response'],document['paths']['/v1/groups']['post']['responses']['400']['content']['application/json']['schema'],document);v.validate(c['response']['requestId'],{'$ref':'./auth-user-friend.openapi.json#/components/schemas/Id'})
 result={'exchange':c,'decoded_request_json_bytes':json.dumps(payload),'derived_rejection':list(derived),'response_schema':'PASS','requestId_format':'PASS_FRESH_SERVER_UUID','expected':'check_exchange accepts this contract-compliant400 validation response'}
 try:v.check_exchange(c,document)
 except Exception as error:result.update(actual='RAISED',exception_type=type(error).__name__,exception_message=str(error),traceback=traceback.format_exc())
 else:result.update(actual='ACCEPTED')
 results.append(result)
control=copy.deepcopy(results[0]['exchange']);control['id']='independent-object-invalid-control';control['request']['body']={};v.check_exchange(control,document)
summary={'candidate_sha':'bcae6468285bd050bce6a7e53012e66bc15ab962','finding_id':'R3-P2-001','result':'FAIL_CONTRACT_COMPLIANT_REJECTION_EXCHANGES','location':'contracts/http/verify-group.py:226','actual':results,'object_invalid_control':'ACCEPTED_SAME400SERVERUUID','note':'No masking or false success: oracle raises an internalAttributeError after legitimate shape rejection; valid canonical error exchanges are incorrectly rejected.'}
(OUT/'correlation-counterexamples.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(summary,ensure_ascii=False,indent=2));raise SystemExit(1 if any(x['actual']!='ACCEPTED' for x in results) else 0)
