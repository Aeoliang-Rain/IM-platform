import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('H:/.codex/worktrees/group/IM-platform')
OUT = Path(__file__).parent
RESEARCH = OUT / 'research'
RUN = 'R-GROUP-R3-SPEC-SUPPLEMENT-20261018'
expected = {'report.md':'6f232bb60eca13f8d8f7f1699b2bf75d2d3aa9b70091dbd1558d6b4c2c5cef93',
            'findings.json':'3e064d6ecbd10f24e284f839df7a4cca5e2a5a10c2f559f85545b5ca4fe629ba',
            'receipt.json':'f924d3e991096ab135e8cbac58ce810ba7b36a04c0f6be4876a8efbc67a37ff7'}
for name, digest in expected.items():
    assert hashlib.sha256((OUT/name).read_bytes()).hexdigest() == digest, name
records = []
for verb, tail in [('finish-run',['--result','FAIL']),('validate-run',[])]:
    argv = [sys.executable,'-Xutf8','-B',str(ROOT/'tools/research/recorder.py'),verb,'--repo',str(ROOT),'--research-root',str(RESEARCH),'--run-id',RUN,*tail]
    start = time.perf_counter()
    child = subprocess.run(argv,cwd=ROOT,capture_output=True)
    for stream in ('stdout','stderr'):
        (OUT/f'supplement-{verb}.{stream}.txt').write_bytes(getattr(child,stream))
    records.append(dict(argv=argv,exit_code=child.returncode,elapsed_seconds=time.perf_counter()-start,
                        stdout=child.stdout.decode('utf8'),stderr=child.stderr.decode('utf8')))
    print(json.dumps(records[-1]))
    if child.returncode:
        raise SystemExit(child.returncode)
(OUT/'supplement-recorder-close.json').write_text(json.dumps(records,indent=2)+'\n',encoding='utf8',newline='\n')
events = [json.loads(row) for row in (RESEARCH/'runs'/RUN/'events.jsonl').read_text(encoding='utf8').splitlines()]
starts = {event['data']['command_id']:event for event in events if event['event_type']=='command_started'}
commands = [dict(start=starts[event['data']['command_id']],finish=event) for event in events if event['event_type']=='command_finished']
(OUT/'supplement-commands.json').write_text(json.dumps(commands,indent=2)+'\n',encoding='utf8',newline='\n')
git = lambda *args:subprocess.check_output(['git','-C',str(ROOT),*args]).decode().strip()
assert git('rev-parse','HEAD')=='bcae6468285bd050bce6a7e53012e66bc15ab962'
assert git('-c','core.excludesFile=.git/info/exclude','status','--porcelain')==''
hashes = []
for path in sorted(OUT.rglob('*')):
    if path.is_file() and path.name!='supplement-receipt.json':
        hashes.append(dict(path=path.relative_to(OUT).as_posix(),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),bytes=path.stat().st_size))
receipt = dict(axis='spec',result='FAIL',findings=['R3-SPEC-P2-001'],supersedes='receipt.json pre-corner PASS; original immutable',
               original_receipt_sha256=expected['receipt.json'],root=git('rev-parse','--show-toplevel'),head=git('rev-parse','HEAD'),
               branch=git('branch','--show-current'),clean=True,recorder_result='FAIL',recorder_structural_validation='PASS',
               recorder_direct_commands=records,recorded_command_count=len(commands),artifacts=hashes)
(OUT/'supplement-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf8',newline='\n')
print(json.dumps({'result':'FAIL','findings':1,'clean':True,'head':receipt['head'],
                  'report_sha256':hashlib.sha256((OUT/'supplement-report.md').read_bytes()).hexdigest(),
                  'findings_sha256':hashlib.sha256((OUT/'supplement-findings.json').read_bytes()).hexdigest(),
                  'receipt_sha256':hashlib.sha256((OUT/'supplement-receipt.json').read_bytes()).hexdigest()}))
