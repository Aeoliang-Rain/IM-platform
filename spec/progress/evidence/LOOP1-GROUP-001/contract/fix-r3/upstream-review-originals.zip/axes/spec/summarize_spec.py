import hashlib
import json
from pathlib import Path
import subprocess

OUT = Path(__file__).parent
ROOT = Path('H:/.codex/worktrees/group/IM-platform')
checks = json.loads((OUT / 'independent-spec-checks.json').read_text(encoding='utf8'))
for case in checks['fixture_results']:
    response = case.get('response', {})
    body = case['request'].get('body', {})
    summary = {key: case[key] for key in ('category', 'id', 'operation', 'status', 'outcome', 'reason')}
    summary.update(raw_target_count=len(body.get('memberUserIds', [])),
                   error=response.get('error', {}).get('code'),
                   auth_error=case['context'].get('authError'),
                   list_count=len(response.get('items', [])), has_more=response.get('hasMore'))
    print(json.dumps(summary, ensure_ascii=False))
for name in ('contracts/database/migrations/0001_initial.up.sql', 'contracts/database/migrations/0001_initial.down.sql'):
    print('WORKING_BYTES', name, hashlib.sha256((ROOT / name).read_bytes()).hexdigest())
print('FINAL_ROOT', subprocess.check_output(['git', 'rev-parse', '--show-toplevel'], cwd=ROOT).decode().strip())
print('FINAL_HEAD', subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip())
status = subprocess.check_output(['git', '-c', 'core.excludesFile=.git/info/exclude', 'status', '--porcelain'], cwd=ROOT).decode()
assert status == '', status
print('FINAL_CLEAN', True)
