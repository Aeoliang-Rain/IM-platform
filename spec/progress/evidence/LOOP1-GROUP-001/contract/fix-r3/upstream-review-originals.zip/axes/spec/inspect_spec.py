import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess

ROOT = Path('H:/.codex/worktrees/group/IM-platform')
OUT = Path(__file__).parent
BASE = '6f163927334c39c9c8833eb8222335c661bde673'
PARENT = '0190c65cafff7df50492e743761427f214fba951'
HEAD = 'bcae6468285bd050bce6a7e53012e66bc15ab962'


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])


def digest(value):
    return hashlib.sha256(value).hexdigest()


def blob(ref, path):
    return git('show', f'{ref}:{path}')


files = git('diff', '--no-renames', '--name-status', f'{BASE}...HEAD').decode().splitlines()
assert len(files) == 52
changes = [dict(zip(('status', 'path'), row.split('\t', 1))) for row in files]
frozen = ['spec/architecture/frozen-architecture.md', 'scalable-distributed-im-architecture.pdf',
          'contracts/database/migrations/0001_initial.up.sql', 'contracts/database/migrations/0001_initial.down.sql',
          'contracts/http/auth-user-friend.openapi.json', 'contracts/http/sync.openapi.json',
          'contracts/websocket/envelope.schema.json', 'contracts/websocket/sync-v1.schema.json']
preserved = []
for path in frozen:
    before, after = blob(BASE, path), blob(HEAD, path)
    assert before == after, path
    preserved.append({'path': path, 'sha256': digest(after), 'base_equals_head': True})

old_auth = blob(BASE, 'contracts/http/verify-auth-user-friend.ps1').decode()
new_auth = blob(HEAD, 'contracts/http/verify-auth-user-friend.ps1').decode()
expected_old = "if (($globalCodes -join ',') -cne ($expectedCodes -join ','))"
expected_new = "if (($globalCodes -join ',') -cne ((@($expectedCodes) + @('GROUP_REQUEST_CONFLICT')) -join ','))"
assert new_auth == old_auth.replace(expected_old, expected_new)

test_path = 'tests/contract/group/test_group.py'
old_tree = ast.parse(blob(PARENT, test_path).decode())
new_tree = ast.parse(blob(HEAD, test_path).decode())
old_class = next(node for node in old_tree.body if isinstance(node, ast.ClassDef))
new_class = next(node for node in new_tree.body if isinstance(node, ast.ClassDef))
old_methods = {node.name: ast.dump(node, include_attributes=False) for node in old_class.body if isinstance(node, ast.FunctionDef)}
new_methods = {node.name: ast.dump(node, include_attributes=False) for node in new_class.body if isinstance(node, ast.FunctionDef)}
assert all(new_methods[name] == value for name, value in old_methods.items())
assert len(set(new_methods) - set(old_methods)) == 3
assert blob(PARENT, 'contracts/fixtures/group/exchanges.json') == blob(HEAD, 'contracts/fixtures/group/exchanges.json')
assert blob(PARENT, 'contracts/http/group.openapi.json') == blob(HEAD, 'contracts/http/group.openapi.json')

spec = importlib.util.spec_from_file_location('review_group_oracle', ROOT / 'contracts/http/verify-group.py')
oracle = importlib.util.module_from_spec(spec)
spec.loader.exec_module(oracle)
fixtures = json.loads((ROOT / 'contracts/fixtures/group/exchanges.json').read_text(encoding='utf8'))
summaries = []
for category, cases in fixtures.items():
    if category not in ('valid', 'invalid'):
        continue
    for case in cases:
        try:
            oracle.check_exchange(case)
        except oracle.Invalid as failure:
            outcome = 'REJECTED'
            reason = str(failure)
        else:
            outcome = 'ACCEPTED'
            reason = None
        assert outcome == ('ACCEPTED' if category == 'valid' else 'REJECTED'), case['id']
        item = dict(category=category, id=case['id'], operation=case['operation'], status=case['status'],
                    outcome=outcome, reason=reason, request=case['request'], context=case['context'])
        if 'response' in case:
            item['response'] = case['response']
        if 'observedFailure' in case:
            item['observedFailure'] = case['observedFailure']
        summaries.append(item)

report = dict(root=git('rev-parse', '--show-toplevel').decode().strip(), head=git('rev-parse', 'HEAD').decode().strip(),
              branch=git('branch', '--show-current').decode().strip(), status=git('-c', 'core.excludesFile=.git/info/exclude', 'status', '--porcelain').decode(),
              change_count=len(changes), changes=changes, preserved=preserved,
              auth_only_expected_registry_adaptation=True, original_methods_preserved=len(old_methods),
              appended_test_methods=sorted(set(new_methods) - set(old_methods)),
              fixture_counts={key: len(fixtures[key]) for key in ('valid', 'invalid')},
              fixture_results=summaries)
assert report['head'] == HEAD and report['status'] == ''
(OUT / 'independent-spec-checks.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf8', newline='\n')
print(json.dumps({key: value for key, value in report.items() if key not in ('fixture_results', 'changes')}, ensure_ascii=False, indent=2))
for item in summaries:
    print(json.dumps(item, ensure_ascii=False, separators=(',', ':')))
