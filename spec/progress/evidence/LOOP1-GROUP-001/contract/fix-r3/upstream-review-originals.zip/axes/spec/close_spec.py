import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('H:/.codex/worktrees/group/IM-platform')
OUT = Path(__file__).parent
RESEARCH = OUT / 'research'
RUN = 'R-GROUP-R3-SPEC-20261018'
RECORDER = ROOT / 'tools/research/recorder.py'
records = []
for verb, tail in [('finish-run', ['--result', 'FAIL']), ('validate-run', [])]:
    argv = [sys.executable, '-Xutf8', '-B', str(RECORDER), verb, '--repo', str(ROOT), '--research-root', str(RESEARCH), '--run-id', RUN, *tail]
    start = time.perf_counter()
    child = subprocess.run(argv, cwd=ROOT, capture_output=True)
    elapsed = time.perf_counter() - start
    for stream in ('stdout', 'stderr'):
        (OUT / f'{verb}.{stream}.txt').write_bytes(getattr(child, stream))
    records.append(dict(argv=argv, exit_code=child.returncode, elapsed_seconds=elapsed,
                        stdout=child.stdout.decode('utf8'), stderr=child.stderr.decode('utf8')))
    print(json.dumps(records[-1]))
    if child.returncode:
        (OUT / 'recorder-close.json').write_text(json.dumps(records, indent=2) + '\n', encoding='utf8', newline='\n')
        raise SystemExit(child.returncode)
(OUT / 'recorder-close.json').write_text(json.dumps(records, indent=2) + '\n', encoding='utf8', newline='\n')
directory = RESEARCH / 'runs' / RUN
events = [json.loads(row) for row in (directory / 'events.jsonl').read_text(encoding='utf8').splitlines()]
started = {event['data']['command_id']: event for event in events if event['event_type'] == 'command_started'}
commands = []
for event in events:
    if event['event_type'] == 'command_finished':
        start = started[event['data']['command_id']]
        commands.append(dict(start=start, finish=event))
(OUT / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n', encoding='utf8', newline='\n')
git = lambda *args: subprocess.check_output(['git', '-C', str(ROOT), *args]).decode().strip()
assert git('rev-parse', 'HEAD') == 'bcae6468285bd050bce6a7e53012e66bc15ab962'
assert git('-c', 'core.excludesFile=.git/info/exclude', 'status', '--porcelain') == ''
hashes = []
for path in sorted(OUT.rglob('*')):
    if path.is_file() and path.name != 'receipt.json':
        hashes.append(dict(path=path.relative_to(OUT).as_posix(), sha256=hashlib.sha256(path.read_bytes()).hexdigest(), bytes=path.stat().st_size))
receipt = dict(axis='spec', result='PASS', findings=[], root=git('rev-parse', '--show-toplevel'), head=git('rev-parse', 'HEAD'),
               branch=git('branch', '--show-current'), clean=True, recorder_result='FAIL', recorder_structural_validation='PASS',
               recorder_direct_commands=records, recorded_command_count=len(commands), artifacts=hashes)
(OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf8', newline='\n')
print(json.dumps({'result': 'PASS', 'findings': 0, 'clean': True, 'head': receipt['head'], 'commands': len(commands),
                  'report_sha256': hashlib.sha256((OUT/'report.md').read_bytes()).hexdigest(),
                  'findings_sha256': hashlib.sha256((OUT/'findings.json').read_bytes()).hexdigest(),
                  'receipt_sha256': hashlib.sha256((OUT/'receipt.json').read_bytes()).hexdigest()}))
