import copy
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path('H:/.codex/worktrees/group/IM-platform')
OUT = Path(__file__).parent
spec = importlib.util.spec_from_file_location('null_probe_oracle', ROOT/'contracts/http/verify-group.py')
oracle = importlib.util.module_from_spec(spec)
spec.loader.exec_module(oracle)
document = json.loads(oracle.CONTRACT.read_text(encoding='utf8'))
fixtures = json.loads((ROOT/'contracts/fixtures/group/exchanges.json').read_text(encoding='utf8'))
results = []
for operation, field, value in [('create','body',None), ('create','body',[]), ('create','body','invalid-object'), ('list','query',None), ('list','query',[])]:
    original = next(case for case in fixtures['valid'] if case['id'] == ('create-a-b' if operation=='create' else 'snapshot-nonfriend'))
    case = copy.deepcopy(original)
    case['id'] = 'spec-probe-'+operation+'-'+type(value).__name__
    case['request'][field] = value
    case['status'] = 400
    case['response'] = {'requestId':'90000000-0000-4000-8000-000000000099','error':{'code':'VALIDATION_FAILED','message':'Invalid request shape.'}}
    failure = oracle.request_failure(operation,case['request'],case['context'],document)
    assert failure == (400,'VALIDATION_FAILED'), failure
    oracle.validate(case['response'],document['paths'][oracle.PATHS[operation][0]][oracle.PATHS[operation][1]]['responses']['400']['content']['application/json']['schema'],document)
    try:
        oracle.check_exchange(case,document)
    except Exception as error:
        result = dict(case=case, derived_request_failure=failure, canonical_error_response_schema_valid=True,
                      correct_exchange_accepted=False, exception=type(error).__name__, diagnostic=str(error))
    else:
        result = dict(case=case, derived_request_failure=failure, canonical_error_response_schema_valid=True, correct_exchange_accepted=True)
    results.append(result)
(OUT/'null-correlation-probe.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
for result in results:
    print(json.dumps({key:value for key,value in result.items() if key!='case'}))
sys.exit(1 if any(not result['correct_exchange_accepted'] for result in results) else 0)
