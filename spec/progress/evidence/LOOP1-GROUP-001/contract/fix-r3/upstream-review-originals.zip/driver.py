from pathlib import Path
import subprocess, sys, os, json, time, datetime
ROOT=Path('H:/.codex/worktrees/group/IM-platform')
OUT=Path('C:/Users/21441/.codex/visualizations/2026/10/18/01a14d96-146d-7f42-9fd8-0fd0c7e399e0/contract-regular-r3')
PY=Path('C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe')
RUN='R-GROUP-REGULAR-R3-20261018'
label=sys.argv[1]; cmd=sys.argv[2:]
env=dict(os.environ); env['PATH']=str(PY.parent)+';'+str(Path('C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell'))+';'+env.get('PATH','');env['PYTHONDONTWRITEBYTECODE']='1';env['PYTHONUTF8']='1'
if cmd and cmd[0]=='--pg':
 cmd=cmd[1:]
 for name in ['PGPASSWORD','PGSERVICE','PGSERVICEFILE','PGOPTIONS','DATABASE_URL']:env.pop(name,None)
 env.update(PGHOST='127.0.0.1',PGPORT='63830',PGUSER='group_contract_fixture',PGDATABASE='group_contract_20261018',PGPASSFILE='H:/IM-platform/.git/worktrees/IM-platform4/group-pg16-20261018/libpq-v2.private',PGSSLMODE='disable',DB_TEST_ENABLE='1')
 env['PATH']='H:/IM-platform/.git/worktrees/IM-platform4/group-pg16-20261018/pgsql/bin;'+env['PATH']
argv=[str(PY),'-Xutf8','-B',str(ROOT/'tools/research/recorder.py'),'run-command','--repo',str(ROOT),'--research-root',str(OUT/'research'),'--run-id',RUN,'--',*cmd]
t=time.monotonic();p=subprocess.run(argv,cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(OUT/'commands').mkdir(exist_ok=True)
(OUT/'commands'/f'{label}.stdout.log').write_bytes(p.stdout);(OUT/'commands'/f'{label}.stderr.log').write_bytes(p.stderr)
entry={'label':label,'argv':argv,'inner_argv':cmd,'exit_code':p.returncode,'elapsed_seconds':time.monotonic()-t,'ended_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stdout':f'commands/{label}.stdout.log','stderr':f'commands/{label}.stderr.log'}
with (OUT/'command-history.jsonl').open('a',encoding='utf-8',newline='\n') as f:f.write(json.dumps(entry,ensure_ascii=False)+'\n')
sys.stdout.buffer.write(p.stdout);sys.stderr.buffer.write(p.stderr);print('\nCOMMAND_RESULT '+json.dumps(entry,ensure_ascii=False));raise SystemExit(p.returncode)
