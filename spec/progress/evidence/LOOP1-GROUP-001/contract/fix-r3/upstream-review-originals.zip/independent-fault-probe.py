from pathlib import Path
import importlib.util,unittest,subprocess,json,copy,io,ast
from unittest import mock
ROOT=Path('H:/.codex/worktrees/group/IM-platform');OUT=Path('C:/Users/21441/.codex/visualizations/2026/10/18/01a14d96-146d-7f42-9fd8-0fd0c7e399e0/contract-regular-r3')
s=importlib.util.spec_from_file_location('review_test_group',ROOT/'tests/contract/group/test_group.py');t=importlib.util.module_from_spec(s);s.loader.exec_module(t);t.GroupContractTests.setUpClass();v=t.v;doc=t.GroupContractTests.document
mutations=[lambda d:d['info'].pop('title'),lambda d:d.__setitem__('unknownRoot',1),lambda d:d['paths']['/v1/groups']['post']['responses'].__setitem__('201',42),lambda d:d['paths']['/v1/groups']['post'].__setitem__('unknownOperation',1),lambda d:d['paths']['/v1/conversations']['get']['parameters'][0].__setitem__('in','imaginary')]
def formal_invalid(d):
 op=d['paths']['/v1/groups']['post'];return ('title' not in d['info'] or 'unknownRoot' in d or op['responses']['201']==42 or 'unknownOperation' in op or d['paths']['/v1/conversations']['get']['parameters'][0]['in']=='imaginary')
real=v.subprocess.run
old=subprocess.run(['git','show','0190c65cafff7df50492e743761427f214fba951:tests/contract/group/test_group.py'],cwd=ROOT,check=True,capture_output=True,text=True).stdout
original_names=sorted(n.name for n in ast.walk(ast.parse(old)) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_'));assert len(original_names)==17
all_names=unittest.defaultTestLoader.getTestCaseNames(t.GroupContractTests);assert len(all_names)==20
results=[]
for label,names,expected in [('original_17',original_names,1),('current_20',all_names,2)]:
 calls=[]
 def injected(*args,**kwargs):
  if len(args[0])>1 and str(args[0][1]).endswith('check-openapi-3.1.js') and formal_invalid(json.loads(kwargs['input'])):
   calls.append(args[0]);return subprocess.CompletedProcess(args[0],2,b'independent-checker-stdout',b'independent-checker-internal-crash')
  return real(*args,**kwargs)
 output=io.StringIO()
 with mock.patch.object(v.subprocess,'run',side_effect=injected):result=unittest.TextTestRunner(stream=output,verbosity=2).run(unittest.TestSuite(t.GroupContractTests(n) for n in names))
 assert not result.wasSuccessful() and not result.failures and len(result.errors)==expected
 assert all('RuntimeError' in trace and 'exit 2' in trace and 'independent-checker-internal-crash' in trace for _,trace in result.errors)
 (OUT/f'fault-{label}.log').write_text(output.getvalue(),encoding='utf-8',newline='\n');results.append({'suite':label,'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'injected_crashes':len(calls),'test_suite_success':result.wasSuccessful(),'probe_expected_failure_assertion':'PASS'})
direct=[]
for index,mutate in enumerate(mutations):
 d=copy.deepcopy(doc);mutate(d)
 with mock.patch.object(v.subprocess,'run',return_value=subprocess.CompletedProcess([],2,b'independent-checker-stdout',b'independent-checker-internal-crash')):
  try:v.structural_lint(d)
  except RuntimeError as e:
   assert 'exit 2' in str(e) and 'independent-checker-stdout' in str(e) and 'independent-checker-internal-crash' in str(e);direct.append({'formal_mutation':index,'result':'RuntimeError','diagnostic':str(e)})
  else:raise AssertionError('internal crash normalized as schema rejection or success')
summary={'candidate_sha':'bcae6468285bd050bce6a7e53012e66bc15ab962','result':'PASS_INDEPENDENT_FAULT_PROBE','suite_outcomes':results,'all_five_formal_inputs':direct,'scope':'process-execution distinction only; not specialized acceptance'}
(OUT/'independent-fault-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(summary,ensure_ascii=False,indent=2))
