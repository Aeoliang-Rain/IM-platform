# Independent regular review: FAIL_REGULAR_REVIEW_ONLY

One actionable P2 finding remains in the first public group-contract slice at `bcae6468285bd050bce6a7e53012e66bc15ab962`. Standards has 0 findings; Spec has 1. This is a regular-review failure, not an error-specialist result, server runtime defect, contract freeze, Task completion or S2 verdict.

Fresh reviewer `/root/group_contract_regular_r3` neither implemented nor fixed the candidate and did not participate in earlier reviews. Both axes are separate new contexts. Assigned exact Git root `H:/.codex/worktrees/group/IM-platform`, branch `task/LOOP1-GROUP-001`; accepted base `6f163927334c39c9c8833eb8222335c661bde673`, parent `0190c65cafff7df50492e743761427f214fba951`. Reviewed the complete three-commit range `git diff --no-renames 6f163927334c39c9c8833eb8222335c661bde673...HEAD`, including 52 changed paths (51 present, one deleted backlog Task), and the final fix delta. The clean committed checkout and exact root/HEAD were independently verified before and after the work. No source, Task/current, Git index/commit, push, PR, CI trigger, merge, synchronization, clone or worktree mutation was made.

## R3-P2-001 — accept canonical errors for non-object JSON bodies

At `contracts/http/verify-group.py:226`, correlation extraction assumes `request.body` is an object and calls `.get('requestId')` unconditionally. An authenticated create request with decoded JSON `null`, `[]`, `42` or a string is a legitimate malformed-shape request. The oracle's own `request_failure` correctly derives `(400, VALIDATION_FAILED)`. A canonical 400 ErrorResponse using a fresh server UUID passes both response schema and UUID validation, then `check_exchange` raises `AttributeError` instead of accepting the correct rejection.

A concrete primary counterexample is `operation=create`, `request={"body":null}`, actor `10000000-0000-4000-8000-000000000001` with friend `10000000-0000-4000-8000-000000000002`, and `status=400`, `response={"requestId":"40000000-0000-4000-8000-000000000099","error":{"code":"VALIDATION_FAILED","message":"Request body must be an object."}}`. Expected: the exchange validates. Actual: line226 raises `'NoneType' object has no attribute 'get'`. The same response with invalid object body `{}` is accepted as a control.

Task line127 assigns fields, error codes and correlation IDs to contracts; line167 requires actual schema/positive-negative fixture coverage. New OpenAPI line6 explicitly states shape errors return400 and otherwise uses a fresh server UUID when no valid request ID is available. The current oracle therefore incorrectly rejects contract-compliant error exchanges. This does not claim an implemented server returns the wrong status and is not a swallowed-exception or false-success finding.

The aggregator independently reproduced four POST cases with complete inputs/results/tracebacks in `correlation-counterexamples.json`; the actual command exits1. The Spec axis independently reproduced five cases, including modeled non-object GET query containers, in its supplemental evidence. Finding alias is `R3-SPEC-P2-001`; this is one finding, not two.

Smallest repair: read a correlation ID only from an actual object; otherwise follow the existing uncorrelatable-request/server-UUID path. Add positive error exchanges for null/scalar/array bodies and negative controls for incorrect success/error results. Retain propagation of unknown/internal failures. No broad catch, new framework, wire change, old checker rewrite, pagination change, migration, backend or client work is required.

## Independent verification and preservation

Normal group verification passes35valid/30invalid fixtures and20tests. Those existing cases omit the new corner and do not erase the failure. The previous EH-R1-P2-001 repair is independently supported: selective exit2 injection makes the preserved original17suite report1error and current20suite report2errors; each of five formal invalid documents raises RuntimeError with exit/stdout/stderr. New regression tests also cover exit37/-9, unavailable Node, unchanged launch exception identity and actual checker exit0/1. All17old tests/19methods+helpers AST and all35/30fixtures are unchanged from parent; the other12validator functions, including eligible-prefix/lookahead and legal-short-page behavior, remain exact.

Own baseline: Frozen/planning/all-architecture checks exit0;88architecture tests (1 applicability skip),35CI tests (4 applicability skips), oldAuth21negatives/15mutations, Sync verifier+4tests, WSS and Plugin verifiers all exit0. Clean committed recovery Acceptance exits0 in26.422s. Exact argv, native exit, elapsed times and raw output references are in `command-history.jsonl` and Recorder blobs. The counterexample command is preserved with its real exit1.

Real dedicated PostgreSQL16.15 runs11migration tests in10.894s, zero skips, covering empty-to0002, existing0001upgrade, historical checksum/data/ledger preservation, reentry, mismatch/unknown ledger, receipt constraints/original results, all-pending-batch rollback, real advisory-lock waiters/stale-state failure and highest-only down/re-up. A separate owned random schema executes status/up/status/repeat-up/down0002/status/re-up/status successfully and is dropped. Only session search_path and owned schemas were used; the coordinator-owned server remains running. Credential contents were never read, printed or copied.

All243upstream fix artifacts, supplied receipt/report/manifest hashes,52owned blob/diff bindings and disk/commit identities match. Original0001up/down bytes and historical text checksum are unchanged. Frozen/ADR/domain/invariants/acceptance, all Go/Java/client trees, old wire authorities and pinned checker are unchanged from accepted base. Source responsibilities/imports and minimality were inspected beyond static checks: narrow persistent original-result receipts serve current replay requirements; the independent runner retains one advisory-lock transaction and full under-lock ledger recheck; Auth changes one ordered15+GROUP comparison; CI changes exactly two calls with immediate nonzero propagation, retaining existing Go up and real database compatibility execution. No new sensitive technology, generic framework or speculative product mechanism was introduced.

The Standards receipt and85declared artifacts and Spec supplemental receipt and96declared artifacts were independently hash-checked. Spec's initial pre-corner PASS is preserved byte-for-byte and is explicitly superseded by the supplemental FAIL; its old receipt is never used as the final result. `axes-verification.json`, `upstream-seal-and-scope-proof.json` and `source-coverage.json` bind these facts.

## Standards

Standards: PASS — 0 documented violations.

Fresh independent Standards axis; no implementation, fix, or prior-review participation. Reviewed clean committed bcae6468285bd050bce6a7e53012e66bc15ab962 on task/LOOP1-GROUP-001 in H:/.codex/worktrees/group/IM-platform, full diff 6f163927334c39c9c8833eb8222335c661bde673...HEAD.

Read AGENTS.md/CLAUDE.md, hash-verified canonical authority, referenced ADRs/domain/invariants/acceptance, and governance standards. Inspected all changed executable logic, public schemas/fixtures, migration/CI responsibilities and recovery evidence. All52 paths conform to allowed scope; authority/backend/client source is unchanged. Receipt storage serves current original-result replay without a speculative framework. Original0001up/down bytes and historical checksum are preserved. The existing independent runner keeps ordered atomic ledger/schema work and the original advisory lock. Existing shared CI gains only two guarded commands.

The structural checker maps only explicit schema-rejection exit1 to Invalid; absent Node, abnormal exits and launch/internal defects fail with diagnostics. Existing narrow Invalid catches serve declared schema alternatives, known request rejection/correlation and negative-fixture checks.

Local verification: Frozen/planning/all-architecture exit0; architecture88tests(skip1), CI35tests(skip4), group verifier35valid/30invalid, group20tests, migration static3tests all pass. PostgreSQL was reserved for the aggregator and was not run by this axis.

Nonblocking observation, excluded from Standards findings: a null mutation body correctly derives400 but correlation at verify-group.py:226 raises AttributeError. This oracle limitation fails loudly; supplied to the aggregator for separate Spec assessment.

Own Recorder is prospective_resume/partial, with startup/helper/communications and yielded-session overlap disclosed; finish FAIL is intentional and structural validation is reported separately. No source writes. GROUP remains active/group_product and S2 OPEN; this axis does not establish contract freeze, error-specialist acceptance, hosted CI or integration.

## Spec

Spec axis final result: FAIL — one P2 finding. This supplement supersedes the pre-corner PASS in `report.md`; the original report, receipt and Recorder run remain unchanged.

**[P2] Correct malformed-body error exchanges crash the oracle.** `contracts/http/verify-group.py:226` calls `.get('requestId')` on the supplied body/query without first checking that it is an object. With a current authorized actor and POST JSON body `null`, `[]` or a string, `request_failure` correctly derives `(400, VALIDATION_FAILED)` and the expected ErrorResponse with a fresh server UUID validates against the canonical response schema. Nevertheless, `check_exchange` then raises `AttributeError` instead of accepting that correct rejection. Modeled GET query `null`/`[]` has the same defect. The independent probe reproduces all five cases and exits 1.

Task `spec/tasks/active/LOOP1-GROUP-001.md:127` requires “字段/成功结果/错误码/分页资源界限/关联ID/幂等冲突/权限/兼容负例以contracts/唯一机器定义”; line 167 requires the verifier/suite to “真实覆盖群schema/正负fixtures”. New canonical `contracts/http/group.openapi.json:6` explicitly says “self/shape errors return 400” and, when no valid request ID is decodable, “otherwise use a fresh server UUID”. This is a current first-slice oracle defect: a legitimate contract error outcome cannot be verified. It is not error masking and does not establish a server implementation defect.

Minimal fix: extract the correlation ID only from an actual object; otherwise use the existing uncorrelatable-request path. Add null/non-object body regression exchanges proving the correct 400/server UUID passes and malformed success/error outcomes fail. Keep unknown/internal exceptions propagating; do not add a broad catch.

No other missing first-slice requirement or unrequested scope expansion was found. Earlier local checks remain successful, including 35 valid/30 invalid fixtures and 20 group tests; their coverage omitted this case. Final candidate remains clean `bcae6468285bd050bce6a7e53012e66bc15ab962`, root `H:/.codex/worktrees/group/IM-platform`. Parent review owns PostgreSQL verification. Supplemental Recorder remains explicitly partial and finishes FAIL; structural validation is separate.

## Research limits and next action

Research run `R-GROUP-REGULAR-R3-20261018` is `prospective_resume`, pre_recorder_trace_complete=false, and honestly finished FAIL. Direct finish and structural validate both exit0:88events,41commands started/41finished,0unmatched. Mandatory startup and later secondary authority rereads, early broad-display truncation and a corrected UTF8 display issue, external helper authoring, communication, final report packaging and sealing are not a complete prospective trace. Commands after the driver was established were serialized; trace was never edited. Both axes also disclose partial capture and their own overlap/startup limitations. Research structural validity is separate from the regular review failure and from product acceptance.

The final source state remains clean at bca on the assigned branch/root. This external read-only handoff supplies the coordinator's required Task/current update. Preserve this candidate and every original failure, allocate a different fresh Fix for the bounded correlation extraction/regression change, then obtain NEW fresh regular and DIFFERENT fresh error-specialist reviews on the new final SHA. No push or CI-triggering PR before both pass. Exact-head hosted jobs/steps must later prove group verifier, actual suite and real PG execution, followed by protected integration, actual-main audit and safe main synchronization preserving unknown work. No new contract acceptance seal exists; GROUP stays active/group_product, S2 OPEN; last known accepted/synchronized main remains6f163927334c39c9c8833eb8222335c661bde673. Go/three-client/G01..G09 product work remains pending and is not a first-slice omission.

Findings: Standards0; Spec1. Worst issue: P2 canonical malformed-body error exchanges crash correlation extraction.
