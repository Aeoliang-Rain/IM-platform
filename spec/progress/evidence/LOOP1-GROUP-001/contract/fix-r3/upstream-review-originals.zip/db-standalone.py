from pathlib import Path
import os,sys,uuid,subprocess,json,time
ROOT=Path('H:/.codex/worktrees/group/IM-platform');OUT=Path('C:/Users/21441/.codex/visualizations/2026/10/18/01a14d96-146d-7f42-9fd8-0fd0c7e399e0/contract-regular-r3');schema='regular_r3_'+uuid.uuid4().hex;env=os.environ.copy();results=[]
def call(label,argv,*,sql=None,context=env):
 start=time.monotonic();p=subprocess.run(argv,cwd=ROOT,env=context,input=sql,text=True,encoding='utf-8',capture_output=True);(OUT/f'db-standalone-{label}.stdout.log').write_text(p.stdout,encoding='utf-8',newline='\n');(OUT/f'db-standalone-{label}.stderr.log').write_text(p.stderr,encoding='utf-8',newline='\n');results.append({'label':label,'argv':argv,'sql':sql,'exit_code':p.returncode,'elapsed_seconds':time.monotonic()-start});assert p.returncode==0,(label,p.stderr);return p.stdout
psql=['psql','-X','-v','ON_ERROR_STOP=1','-q','-A','-t'];call('version',['psql','--version']);call('create-schema',psql,sql=f'CREATE SCHEMA {schema};')
scoped=dict(env,PGOPTIONS='-c search_path='+schema)
try:
 runner=[sys.executable,'-Xutf8','-B',str(ROOT/'contracts/database/migrate.py')]
 assert call('status-empty',runner+['status'],context=scoped).count('pending')==2
 call('up',runner+['up'],context=scoped)
 assert call('status-up',runner+['status'],context=scoped).count('applied')==2
 assert 'already applied' in call('repeat-up',runner+['up'],context=scoped)
 call('down-0002',runner+['down','--allow-data-loss'],context=scoped)
 assert call('status-down',runner+['status'],context=scoped)=='0001_initial: applied\n0002_group_operations: pending\n'
 assert call('schema-down',psql,sql="SELECT to_regclass('users') IS NOT NULL AND to_regclass('group_operation_receipts') IS NULL AND (SELECT count(*) FROM schema_migrations)=1;",context=scoped).strip()=='t'
 call('re-up',runner+['up'],context=scoped)
 assert call('status-re-up',runner+['status'],context=scoped).count('applied')==2
 assert call('schema-re-up',psql,sql="SELECT to_regclass('group_operation_receipts') IS NOT NULL AND (SELECT count(*) FROM schema_migrations)=2;",context=scoped).strip()=='t'
finally:call('drop-own-schema',psql,sql=f'DROP SCHEMA {schema} CASCADE;')
summary={'result':'PASS_LIVE_STANDALONE_SEQUENCE','candidate_sha':'bcae6468285bd050bce6a7e53012e66bc15ab962','schema':schema,'isolation':'new random schema; per-session search_path; only own schema dropped','credential_handling':'libpq PGPASSFILE path inherited; credential file never read/printed/copied','commands':results}
(OUT/'db-standalone-summary.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps(summary,indent=2))
