from pathlib import Path
import hashlib,json,subprocess,ast,fnmatch
ROOT=Path('H:/.codex/worktrees/group/IM-platform');OUT=Path('C:/Users/21441/.codex/visualizations/2026/10/18/01a14d96-146d-7f42-9fd8-0fd0c7e399e0/contract-regular-r3');UP=OUT.parent/'contract-fix-r2';BASE='6f163927334c39c9c8833eb8222335c661bde673';HEAD='bcae6468285bd050bce6a7e53012e66bc15ab962';PARENT='0190c65cafff7df50492e743761427f214fba951'
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*a):return subprocess.run(['git',*a],cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True).stdout
def readj(p):return json.loads(p.read_text(encoding='utf-8'))
r=readj(UP/'final-receipt.json');m=readj(UP/'artifact-manifest.json')
assert sha((UP/'final-receipt.json').read_bytes())=='dea618f83ce81b2d5bcba9292174728800df231cbe17ff1cc3fb4debbb5fb419'
assert sha((UP/'report.md').read_bytes())=='b7635dcc404504ce5d8fe9623854002fac83dfe6056e16edaf16ea1dbbdaa404'
assert sha((UP/'artifact-manifest.json').read_bytes())=='9d4a92eef67dd3d4afb4e16b3c79e60d83be6a8a89bc169056a303e428938514'
assert r['candidate_sha']==HEAD and r['parent_sha']==PARENT and r['base_sha']==BASE and r['branch']=='task/LOOP1-GROUP-001' and r['source_write_lease']=='SOURCE WRITE LEASE RELEASED' and r['clean'] is True
assert len(m['artifacts'])==r['manifest_artifact_count']==m['artifact_count']==243
verified=[]
for e in m['artifacts']:
 p=(UP/e['path']).resolve();assert p.is_relative_to(UP.resolve())
 b=p.read_bytes();assert len(b)==e['bytes'] and sha(b)==e['sha256'],e['path'];verified.append(dict(e,match=True))
assert git('rev-parse','--show-toplevel').decode().strip().replace('\\','/')==str(ROOT).replace('\\','/')
assert git('rev-parse','HEAD').decode().strip()==HEAD
assert git('rev-parse','HEAD~1').decode().strip()==PARENT
assert git('branch','--show-current').decode().strip()==r['branch']
assert git('status','--porcelain=v1','-uall')==b''
actual={line.split('\t',1)[1]:line.split('\t',1)[0] for line in git('diff','--no-renames','--name-status',BASE+'...HEAD').decode().splitlines()}
assert len(actual)==52 and len(r['owned_blobs'])==52 and actual=={e['path']:e['status'] for e in r['owned_blobs']}
blobs=[]
for e in r['owned_blobs']:
 if e['status']=='D':
  assert e['git_blob'] is None and not (ROOT/e['path']).exists();blobs.append({'path':e['path'],'status':'D','matches':True});continue
 b=git('show',HEAD+':'+e['path']);blob=git('rev-parse',HEAD+':'+e['path']).decode().strip();disk=(ROOT/e['path']).read_bytes()
 assert blob==e['git_blob'] and len(b)==e['bytes'] and sha(b)==e['sha256'] and sha(disk)==e['worktree_sha256']==sha(b),e['path']
 blobs.append({'path':e['path'],'status':e['status'],'git_blob':blob,'bytes':len(b),'sha256':sha(b),'disk_equals_commit':True})
protected=['spec/architecture','spec/domain','spec/invariants','spec/acceptance','backend/go','backend/java','clients','contracts/websocket','contracts/plugin-api','contracts/http/auth-user-friend.openapi.json','contracts/http/sync.openapi.json','contracts/http/check-openapi-3.1.js','contracts/database/migrations/0001_initial.up.sql','contracts/database/migrations/0001_initial.down.sql']
assert git('diff','--name-only',BASE,HEAD,'--',*protected)==b''
initial=[]
for name in ('0001_initial.up.sql','0001_initial.down.sql'):
 p='contracts/database/migrations/'+name;b=(ROOT/p).read_bytes();assert b==git('show',BASE+':'+p);initial.append({'path':p,'bytes':len(b),'sha256':sha(b),'unchanged_from_base':True})
assert sha((ROOT/'contracts/database/migrations/0001_initial.up.sql').read_text(encoding='utf-8').encode())=='e62294fdbdc5346c3a7b88b33777c50941a9b30df6bc6fa6e5f5b031bb11d098'
testpath='tests/contract/group/test_group.py'
def funcs(text):return {n.name:ast.dump(n,include_attributes=False) for n in ast.walk(ast.parse(text)) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
old=funcs(git('show',PARENT+':'+testpath).decode());new=funcs((ROOT/testpath).read_text(encoding='utf-8'))
assert all(new.get(k)==v for k,v in old.items());assert len([k for k in old if k.startswith('test_')])==17;assert len([k for k in new if k.startswith('test_')])==20
vpath='contracts/http/verify-group.py';vo=funcs(git('show',PARENT+':'+vpath).decode());vn=funcs((ROOT/vpath).read_text(encoding='utf-8'));assert all(vn[k]==v for k,v in vo.items() if k!='structural_lint')
assert git('show',PARENT+':contracts/fixtures/group/exchanges.json')==(ROOT/'contracts/fixtures/group/exchanges.json').read_bytes()
for name,args in [('full-review.diff',('diff','--no-renames',BASE+'...HEAD')),('fix-delta.diff',('diff','--no-renames',PARENT+'..HEAD')),('review-commits.txt',('log',BASE+'..HEAD','--oneline'))]:(OUT/name).write_bytes(git(*args))
result={'candidate_sha':HEAD,'base_sha':BASE,'parent_sha':PARENT,'branch':r['branch'],'assigned_git_root':str(ROOT),'clean':True,'upstream_receipt_sha256':sha((UP/'final-receipt.json').read_bytes()),'upstream_manifest_sha256':sha((UP/'artifact-manifest.json').read_bytes()),'upstream_artifacts_verified':len(verified),'artifact_checks':verified,'diffset_equals_owned':True,'changed_paths':52,'present_paths':51,'deleted_paths':1,'owned_blobs':blobs,'unchanged_protected_scopes':protected,'0001':initial,'historic_0001_ledger_checksum':'e62294fdbdc5346c3a7b88b33777c50941a9b30df6bc6fa6e5f5b031bb11d098','preserved_old_test_methods':17,'total_test_methods':20,'preserved_old_functions_and_helpers':len(old),'unchanged_validator_functions_except_structural_lint':len(vo)-1,'fixtures_unchanged_from_parent':True}
(OUT/'upstream-seal-and-scope-proof.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n');print(json.dumps({k:v for k,v in result.items() if k not in ('artifact_checks','owned_blobs')},indent=2))
