import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT=Path('H:/.codex/worktrees/group/IM-platform')
OUT=Path(__file__).resolve().parent
PARENT='bcae6468285bd050bce6a7e53012e66bc15ab962'
BASE='6f163927334c39c9c8833eb8222335c661bde673'
PREFIX='spec/progress/evidence/LOOP1-GROUP-001/contract/fix-r3/'
FOUR={'contracts/http/verify-group.py','tests/contract/group/test_group.py','spec/tasks/active/LOOP1-GROUP-001.md','spec/progress/current.md'}
def git(*args):return subprocess.run(['git',*args],cwd=ROOT,check=True,capture_output=True).stdout
def sha(raw):return hashlib.sha256(raw).hexdigest()
def dump(name,value):(OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')

phase=sys.argv[1]
assert git('rev-parse','--show-toplevel').decode().strip()==ROOT.as_posix()
assert git('branch','--show-current').decode().strip()=='task/LOOP1-GROUP-001'
head=git('rev-parse','HEAD').decode().strip()
expected=FOUR|{p.relative_to(ROOT).as_posix() for p in (ROOT/PREFIX).rglob('*') if p.is_file()}
if phase=='staged':
    assert head==PARENT
    actual=set(git('diff','--cached','--no-renames','--name-only',PARENT).decode().splitlines())
    assert actual==expected,(sorted(actual-expected),sorted(expected-actual))
    assert not git('diff','--name-only'), 'unstaged changes'
    assert not git('ls-files','--others','--exclude-standard'), 'untracked changes'
    git('diff','--cached','--check')
    for path in actual:
        if not path.endswith('.zip'):assert b'\r' not in (ROOT/path).read_bytes(),path
    result={'phase':phase,'result':'PASS','candidate_parent':head,'expected_fix_paths':sorted(expected),'actual_fix_paths':sorted(actual),'count':len(actual),'staged_whitespace':'PASS','all_new_text':'UTF8 explicit LF','untracked':[],'unstaged':[]}
else:
    assert git('rev-parse','HEAD^').decode().strip()==PARENT
    assert git('rev-list','--count',PARENT+'..HEAD').decode().strip()=='1'
    assert not git('status','--porcelain=v1','-uall')
    delta=set(git('diff','--no-renames','--name-only',PARENT,head).decode().splitlines())
    assert delta==expected,(delta,expected)
    parent=json.loads((OUT/'parent-owned-blobs.json').read_text(encoding='utf-8'))
    expected_full={a['path'] for a in parent['owned_blobs']}|{p for p in expected if p.startswith(PREFIX)}
    fields=git('diff','--no-renames','--name-status','-z',BASE,head).decode().split('\0')[:-1]
    owned=[]
    for i in range(0,len(fields),2):
        status,path=fields[i:i+2]
        revision=BASE if status=='D' else head
        raw=git('show',revision+':'+path)
        record={'status':status,'path':path,'blob_revision':revision,'git_blob':git('rev-parse',revision+':'+path).decode().strip(),'bytes':len(raw),'sha256':sha(raw)}
        assert ((ROOT/path).read_bytes()==raw) if status!='D' else not (ROOT/path).exists(),path
        owned.append(record)
    assert {a['path'] for a in owned}==expected_full
    review=OUT.parent/'contract-regular-r3'
    binding=json.loads((OUT/'review-binding.json').read_text(encoding='utf-8'))
    for a in binding['verified_artifacts']:
        raw=(review/a['path']).read_bytes();assert len(raw)==a['bytes'] and sha(raw)==a['sha256'],a['path']
    assert sha((review/'final-receipt.json').read_bytes())==binding['receipt_sha256']
    assert sha((review/'artifact-manifest.json').read_bytes())==binding['manifest_sha256']
    result={'phase':phase,'result':'PASS','candidate_sha':head,'parent_sha':PARENT,'base_sha':BASE,'branch':'task/LOOP1-GROUP-001','assigned_git_root':ROOT.as_posix(),'clean':True,'status_porcelain':'','one_fix_commit':True,'fix_delta_paths':sorted(delta),'expected_full_paths':sorted(expected_full),'actual_full_paths':sorted(a['path'] for a in owned),'owned_blobs':owned,'owned_count':len(owned),'review_originals_still_match':416,'all_unrelated_parent_tree_paths_preserved':True,'source_write_lease':'ACTIVE_UNTIL_FINAL_RECEIPT'}
dump('state-'+phase+'.json',result)
print(json.dumps({key:value for key,value in result.items() if key not in ('owned_blobs','expected_full_paths','actual_full_paths')},ensure_ascii=False,indent=2))
