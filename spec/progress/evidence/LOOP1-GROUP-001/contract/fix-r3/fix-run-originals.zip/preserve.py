import ast
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('H:/.codex/worktrees/group/IM-platform')
OUT = Path(__file__).resolve().parent
PARENT = 'bcae6468285bd050bce6a7e53012e66bc15ab962'
EDITED = {'contracts/http/verify-group.py', 'tests/contract/group/test_group.py', 'spec/tasks/active/LOOP1-GROUP-001.md', 'spec/progress/current.md'}
PREFIX = 'spec/progress/evidence/LOOP1-GROUP-001/contract/fix-r3/'

def git(*args):
    return subprocess.run(['git',*args], cwd=ROOT, check=True, capture_output=True).stdout

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

path = 'contracts/http/verify-group.py'
old = git('show',PARENT + ':' + path).decode('utf-8')
new = (ROOT / path).read_text(encoding='utf-8')
before = "    supplied = request.get('query',{}).get('requestId') if operation == 'list' else request.get('body',{}).get('requestId')\n"
after = "    supplied_fields = request.get('query') if operation == 'list' else request.get('body')\n    supplied = supplied_fields.get('requestId') if isinstance(supplied_fields,dict) else None\n"
assert new == old.replace(before,after), 'Verifier change exceeds the authorized extraction'
old_ast,new_ast = ast.parse(old),ast.parse(new)
unchanged_functions=[]
for node in old_ast.body:
    if isinstance(node,ast.FunctionDef) and node.name != 'check_exchange':
        other=next(value for value in new_ast.body if isinstance(value,ast.FunctionDef) and value.name == node.name)
        assert ast.dump(node,include_attributes=False) == ast.dump(other,include_attributes=False),node.name
        unchanged_functions.append(node.name)
path = 'tests/contract/group/test_group.py'
old_ast = ast.parse(git('show',PARENT + ':' + path))
new_ast = ast.parse((ROOT / path).read_text(encoding='utf-8'))
old_class = next(node for node in old_ast.body if isinstance(node,ast.ClassDef))
new_class = next(node for node in new_ast.body if isinstance(node,ast.ClassDef))
old_methods = [node for node in old_class.body if isinstance(node,ast.FunctionDef)]
for method in old_methods:
    other=next(node for node in new_class.body if isinstance(node,ast.FunctionDef) and node.name == method.name)
    assert ast.dump(method,include_attributes=False) == ast.dump(other,include_attributes=False),method.name
assert len([node for node in old_methods if node.name.startswith('test_')]) == 20
assert len([node for node in new_class.body if isinstance(node,ast.FunctionDef) and node.name.startswith('test_')]) == 22
fixtures = 'contracts/fixtures/group/exchanges.json'
assert (ROOT / fixtures).read_bytes() == git('show',PARENT + ':' + fixtures)
cases = json.loads((ROOT / fixtures).read_text(encoding='utf-8'))
assert [len(cases[k]) for k in ('valid','invalid')] == [35,30]
changes = git('diff','--no-renames','--name-only',PARENT).decode().splitlines()
untracked = git('ls-files','--others','--exclude-standard').decode().splitlines()
assert all(path in EDITED or path.startswith(PREFIX) for path in changes + untracked),(changes,untracked)
protected=[]
for path in ('contracts/database/migrations/0001_initial.up.sql','contracts/database/migrations/0001_initial.down.sql'):
    if not (ROOT/path).exists():
        matches = [p for p in git('ls-tree','-r','--name-only',PARENT,'contracts/database/migrations').decode().splitlines() if p.split('/')[-1].startswith('0001')]
        protected = [{'path':p,'sha256':sha((ROOT/p).read_bytes()),'bytes':len((ROOT/p).read_bytes())} for p in matches]
        for p in matches:assert (ROOT/p).read_bytes() == git('show',PARENT + ':' + p)
        break
    raw=(ROOT/path).read_bytes();assert raw == git('show',PARENT + ':' + path)
    protected.append({'path':path,'sha256':sha(raw),'bytes':len(raw)})
result = {'result':'PASS','parent_sha':PARENT,'verifier_delta':'exact one-line replaced by two object-aware extraction lines','other_verifier_functions_unchanged':unchanged_functions,'old_test_methods_unchanged':20,'old_methods_and_helpers_unchanged':len(old_methods),'current_tests':22,'golden_fixtures_unchanged':{'valid':35,'invalid':30},'changed_tracked_paths':changes,'new_paths':untracked,'protected_0001':protected,'protection':'git diff from bca restricts every tracked source/evidence byte change to four declared paths and new fix-r3 evidence; all other parent tree entries remain unchanged'}
destination=OUT/('source-preservation'+('-'+sys.argv[1] if len(sys.argv)>1 else '')+'.json')
assert not destination.exists(),destination
destination.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
