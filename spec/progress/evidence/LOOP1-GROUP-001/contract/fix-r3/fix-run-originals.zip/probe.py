import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import traceback

ROOT = Path('H:/.codex/worktrees/group/IM-platform')
OUT = Path(__file__).resolve().parent
SOURCE = OUT.parent / 'contract-regular-r3/correlation-counterexamples.json'
raw = SOURCE.read_bytes()
assert hashlib.sha256(raw).hexdigest() == '88c0ac8fbb5216fd437dbfe2db15a239ac2b23eb69d6624d1952ef1e69b0d225'
spec = importlib.util.spec_from_file_location('probe_group', ROOT / 'contracts/http/verify-group.py')
v = importlib.util.module_from_spec(spec)
spec.loader.exec_module(v)
document = json.loads(v.CONTRACT.read_text(encoding='utf-8'))
results = []
for item in json.loads(raw)['actual']:
    case = copy.deepcopy(item['exchange'])
    assert v.request_failure(case['operation'], case['request'], case['context'], document) == (400, 'VALIDATION_FAILED')
    v.validate(case['response'], document['paths']['/v1/groups']['post']['responses']['400']['content']['application/json']['schema'], document)
    outcome = {'id': case['id'], 'decoded_body': case['request']['body'], 'derived_failure': [400, 'VALIDATION_FAILED'], 'canonical_response_schema': 'PASS'}
    try:
        v.check_exchange(case, document)
    except AttributeError as error:
        outcome.update(result='ERROR', exception_type=type(error).__name__, message=str(error), traceback=traceback.format_exc())
    else:
        outcome['result'] = 'ACCEPTED_CANONICAL_400'
    results.append(outcome)
result = {'phase': sys.argv[1], 'counterexample_source': str(SOURCE), 'counterexample_sha256': hashlib.sha256(raw).hexdigest(), 'results': results, 'accepted': sum(item['result'] == 'ACCEPTED_CANONICAL_400' for item in results), 'errors': sum(item['result'] == 'ERROR' for item in results)}
(OUT / ('counterexamples-' + sys.argv[1] + '.json')).write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
print(json.dumps(result, ensure_ascii=False, indent=2))
sys.exit(1 if result['errors'] else 0)
