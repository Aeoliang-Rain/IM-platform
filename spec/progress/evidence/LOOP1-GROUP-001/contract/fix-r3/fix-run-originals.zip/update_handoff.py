import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path('H:/.codex/worktrees/group/IM-platform')
OUT = Path(__file__).resolve().parent
EVIDENCE = ROOT / 'spec/progress/evidence/LOOP1-GROUP-001/contract/fix-r3'
assert subprocess.check_output(['git','rev-parse','--show-toplevel'],cwd=ROOT).decode().strip() == ROOT.as_posix()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip() == 'bcae6468285bd050bce6a7e53012e66bc15ab962'
EVIDENCE.mkdir(parents=True,exist_ok=True)

def write(path,text):
    path.write_text(text,encoding='utf-8',newline='\n')

def jwrite(path,value):
    write(path,json.dumps(value,ensure_ascii=False,indent=2)+'\n')

task_path = ROOT/'spec/tasks/active/LOOP1-GROUP-001.md'
task = task_path.read_text(encoding='utf-8').replace('owner: /root/group_contract_fix_r2\n','owner: /root/group_contract_fix_r3\n',1)
start = task.index('# Handoff\n')
end = task.index('# 2026-10-18 Activation / Contract Candidate\n',start)
handoff = '''# Handoff

首契约历史5aa常规FAIL、0190常规R2PASS与专项R1FAIL、bca常规R3FAIL R3-P2-001及Spec初版PASS被supplement FAIL取代的原件全部保留。R3最终receipt SHA a13fb68f86291a800e5f3b1c5068a40f653dba47ddcb46f580ca490a4297d363、report850075eb、manifest246677e3及416原件已逐一核对。fresh Fix r3仅使body/query关联ID提取判定对象，加入2个参数化回归；详见 `spec/progress/evidence/LOOP1-GROUP-001/contract/fix-r3/handoff.md`。唯一当前候选发现路径 `C:/Users/21441/.codex/visualizations/2026/10/18/01a14d96-146d-7f42-9fd8-0fd0c7e399e0/contract-fix-r3/final-receipt.json`；文档生成时finalSHA=PENDING，以该receipt实际clean committed SHA/ownedblobs/Recorder/lease为准，历史bca及旧receipt不可充当新final候选。

regular_review: NEW PENDING final SHA (fresh r4 required)
error_handling_review: DIFFERENT NEW PENDING final SHA (fresh specialist r2 required)
hosted_acceptance: PENDING
main_sync: PENDING
整体GROUP保持active/group_product，S2 OPEN；历史FAIL和Recorder FAIL不抹除。最后已知良好accepted/synchronized main仍6f163927334c39c9c8833eb8222335c661bde673。

# Next Action

Coordinator核fix-r3 receipt原件/hash/cleanSHA/实际--no-renames范围→NEW fresh常规r4→DIFFERENT fresh错误专项r2同finalSHA→exact candidate/PR实际必需jobs/steps（群verifier、实际22tests、真实PG）→protected merge→actual-main hosted/tree→保存782unknown安全主目录同步。两项新审查前禁止push/CI-triggering PR；本Fix不执行push/PR/CI/merge/sync。固定外部contract-acceptance-seal.json仍缺/坏=PENDING，逐项核原件/hash/jobs/sync；全部完成后才fresh产品Agent登记实际contract SHA并继续Go/三端。整个Task不移review/done，S2不PASS。

'''
task = task[:start]+handoff+task[end:]
task += '''
# Fresh Fix R3 Local Outcome

2026-10-18 `/root/group_contract_fix_r3`先只读startup，在R3封存后收到Coordinator明确唯一SOURCE WRITE LEASE GRANTED；assigned exactroot/branch/clean bca已核，最终R3receipt/report/416原件和actual52 no-renames parent paths逐项匹配。R3-P2-001原4个non-object body合法400交换before真实4AttributeError/exit1，after同封存输入4接受/exit0。

仅verify-group.py读取raw body/query后dict才提取requestId，否则走现uncorrelatable/serverUUID路径；schema/UUID/错误优先级及有合法ID的坏对象关联检查保持。无新增catch，不把unknown context/validator defects变为known400。新增2个参数化方法涵盖create/add/list、实际JSON null/array/bool/number/string及空对象对照、非法状态/码/UUID/伪成功与合法ID坏对象关联。新回归在bca原verifier真实15subtest errors/exit1，修后完整22tests0fail0error；原20tests/22methods+helpers AST、另12个verifier函数和35valid30invalidfixtures字节不变，0190分页prefix/lookahead/合法短页/237成员与bca结构checker故障分类完整保留。

Frozen/planning/allarchitecture、88architecture(skip1)/35CI(skip4)与旧Auth/Sync4/WSS/Plugin均exit0；Development/clean committedAcceptance及最终耗时/实际SHA由新receipt绑定。无PG/schema/runner变化，本Fix不重跑也不声称PG通过；R3独立真实11tests/0skip原件保留，未来hosted仍必需真实执行。wire/OpenAPI/JSchecker/errors/SQL/runner/CI/0001bytes、Go/三端/Frozen/ADR/旧sealed保持。

外部red helper首次非隔离调用遇本OUT inspect.py遮蔽标准库inspect而失败，原始exit1保留；用Python -I排除helper目录后才得到真实15errors，不改产品或旧输出。早期工具展示截断而raw完整保存，局部读取复核。Recorder prospective_resume/partial：startup、helperauthoring/通信/最后packaging与封存非完整capture；finish诚实FAIL、direct validate结构结果由receipt单独报告，trace不编辑。全部post-driver命令串行无same-run overlap。单个fixcommit之后释放lease；新finalSHA常规r4/DIFFERENT专项r2、hosted/protected/actual-main/main-sync全部PENDING，GROUPactive/S2OPEN。
'''
write(task_path,task)

current = '''# Current Execution State

Current Loop: Loop 1
Current Stage: S2
Current Gate: S2
Gate Status: OPEN
Current Batch: LOOP1-GROUP-001
Batch Status: CONTRACT_FIX_R3_CANDIDATE_PENDING_NEW_REVIEWS
Current Task: LOOP1-GROUP-001
Current Task State: active
Execution Status: active

## Immediately Relevant Completed Work

GROUP-PLAN/I18N已独立接受/hosted/protected integration/actual-main/安全主目录同步；lastknown good main `6f163927334c39c9c8833eb8222335c661bde673`。首契约5aa常规FAIL、0190常规R2PASS/专项R1FAIL和bca常规R3FAIL均保留。fresh Fix r3最小修复non-object body/query合法400交换在关联ID提取处AttributeError；只dict提取ID，无新增catch或wire改变。

## Current Blockers

新finalSHA fresh regular r4和DIFFERENT specialist r2均NEW PENDING，CI/protected/actual-main/主目录安全同步PENDING。contract-acceptance-seal.json缺失，首契约未独立冻结；Go/三端/G01..G09产品仍PENDING。整体active/group_product，S2 OPEN。

## Verification

- Command: `python -Xutf8 -B contracts/http/verify-group.py`
  - Result: exit0；35valid/30invalid与22tests（原20保持+2参数化）。原封存4反例before4AttributeError/exit1，after4合法400接受/exit0。新增回归对bca原verifier真实15subtest errors/exit1，修后完整suite0fail0error。
  - Evidence: `spec/progress/evidence/LOOP1-GROUP-001/contract/fix-r3/local-verification.json`

Frozen/planning/allarchitecture、88architecture(skip1)/35CI(skip4)、旧Auth/Sync4/WSS/Plugin exit0。Development/clean committedAcceptance及精确耗时由finalreceipt绑定。PG/schema未改本Fix不重跑/不claim，R3独立真实11/0skip保留；hosted仍必须真实执行。local/Recorder不是独立接受。

## Changed Files or Migrations

本Fix仅verify-group.py、group/test_group.py、Task/current与新fix-r3证据；无migration/fixture变化。原20tests/22methods+helpers AST、另12个verifier函数、35/30fixtures、0190完整prefix/lookahead/合法短page/237成员与bca checker故障分类保持；JS/publicwire/OpenAPI/errors/SQL/runner/CI/0001bytes/Go/clients/Frozen/ADR/旧sealed保持。

## Known Failures, Risks, and Assumptions

历史review FAIL与Recorder FAIL不抹除。新增red helper首次因本OUT inspect.py遮蔽标准库inspect失败，原exit1保留；以Python -I隔离helper目录后才得到真实15errors。展示截断的完整raw仍保存并局部复核。Recorder prospective_resume/partial：startup/helperauthoring/通信/最后packaging及封存缺口已公开；finish诚实FAIL，direct validate结构和0unmatched另由receipt报告；post-driver同run命令串行无overlap。未知context/validator defects继续传播；有合法requestId的坏对象仍严格关联。

## Next Exact Action

从 `C:/Users/21441/.codex/visualizations/2026/10/18/01a14d96-146d-7f42-9fd8-0fd0c7e399e0/contract-fix-r3/final-receipt.json`核实际clean committed finalSHA/ownedblobs/Recorder/lease→NEW fresh regular r4→DIFFERENT fresh specialist r2同SHA→exact candidate/PR required jobs/steps（群入口、实际22tests、真实PG）→protected merge→actual-main hosted/tree→保存782unknown安全同步。两项新审查前禁止push/CI-triggering PR。contract-acceptance-seal.json缺/坏=PENDING，不只信seal；全部接受同步后fresh产品Agent登记contract SHA再实施。Task不移review/done，S2不PASS。

## Last Known Good Commit

`6f163927334c39c9c8833eb8222335c661bde673`：已接受、集成并安全同步的规划main。

## Latest Checkpoint

`spec/progress/checkpoints/2026-10-18-group-contract-activation.md`

## Uncommitted Changes / Ownership

唯一writer `/root/group_contract_fix_r3`，assigned exactroot `H:/.codex/worktrees/group/IM-platform`，branch `task/LOOP1-GROUP-001`，parentbca/base6f。仅本Fix拥有本轮4个已列路径和新fix-r3证据；main782unknown与2unknowntracked不采纳/覆盖。单个fixcommit的实际SHA/clean/ownedblobs及SOURCE WRITE LEASE RELEASED由新fixed receipt绑定，提交前PENDING。其他Agent源码只读；新双审/CI/sync均PENDING。

## Architecture Conflicts / ACP / ADR

无新增架构/技术选择；仅修现validator对象关联ID提取，沿用现标准库和pinned Node checker；语言activation仍I18N。
'''
write(ROOT/'spec/progress/current.md',current)

commands=[]
for path in sorted((OUT/'commands').glob('*.json')):
    record=json.loads(path.read_text(encoding='utf-8'))
    commands.append(record)
jwrite(EVIDENCE/'local-verification.json',{'role':'fresh_fix','actor':'/root/group_contract_fix_r3','parent_sha':'bcae6468285bd050bce6a7e53012e66bc15ab962','candidate_sha':'PENDING_EXTERNAL_FINAL_RECEIPT','group_fixtures':{'valid':35,'invalid':30,'bytes_unchanged':True},'group_tests':22,'original_counterexamples':{'before_exit':1,'before_errors':4,'after_exit':0,'after_accepted':4},'new_tests_against_parent':{'corrected_isolated_exit':1,'subtest_errors':15,'initial_helper_shadowing_failure_preserved':True},'PG':'NOT_RUN_NO_PG_CODE_CHANGE; independent Review r3 11/0skip preserved, hosted execution pending','commands':commands,'development_and_clean_acceptance':'Actual final results bound by external final-receipt.json; local evidence is not acceptance'})
write(EVIDENCE/'handoff.md','''# Fresh Fix r3 handoff

R3-P2-001 is locally repaired by selecting raw body/query and reading requestId only from a dict. Non-object malformed requests use the existing server UUID path. All response schema/status/code/UUID validation and correlation for a valid supplied requestId remain active. No catch, wire/schema/fixture, checker, pagination, database, CI or product change was added.

The sealed Review r3 receipt/report/manifest and all416 original artifacts were verified. The original4 cases reproduce4AttributeError before (exit1) and accept4canonical400 outcomes after (exit0). Two focused parameterized test methods cover create/add/list and actualJSON null/array/bool/number/string plus empty-object control, wrong status/code/UUID/success and malformed objects retaining valid requestIds. Their run against the bca verifier fails with15subtest errors; all22current tests pass. Original20test methods/22methods+helpersAST,12other verifier functions and35valid/30invalidgolden bytes are preserved. The initial red helper had a standard-library name shadowing failure; its raw output is retained and isolated Python -I produced the actual red evidence.

Frozen/planning/all-architecture,88architecture(skip1)/35CI(skip4),oldAuth/Sync4/WSS/Plugin pass locally. Development/clean committedAcceptance/finalSHA/clean/actualownedblobs are bound by the external final receipt; source docs deliberately do not self-predict a commitSHA. NoPG code changed, so this Fix did not rerunPG or claim a newPG result; independent Review r3's real11tests/0skip remains original evidence, and hosted must execute it again.

Research capture is prospective_resume/partial. Startup and helperauthoring/communications/finalpackaging/sealing gaps are disclosed; finish is honestlyFAIL and structural validation/0unmatched are reported separately. No trace was altered. Public raw outputs and commands are preserved byte-for-byte in the accompanying archive and bound by SHA256/bytes; all new loose text is explicitUTF8LF.

Only the declared4paths and newfix-r3evidence are owned. Parentbca,acceptedbase6f and allhistoricalFAIL/sealed artifacts remain preserved. One task-ownedfixcommit is followed by cleanAcceptance and finalexternal sealing. SOURCE WRITE LEASE RELEASED is asserted only in the finalexternalreceipt after completion. No push/PR/CI/merge/synchronization occurred. NewfinalSHA regularr4 and different fresh specialistr2 are PENDING, as are hosted/protectedintegration/actualmain/safemainsync/contractfreeze. GROUP staysactive/group_product;S2OPEN;Go/three-client products remainPENDING.

Latest actual candidate discovery: C:/Users/21441/.codex/visualizations/2026/10/18/01a14d96-146d-7f42-9fd8-0fd0c7e399e0/contract-fix-r3/final-receipt.json.
''')
review = OUT.parent/'contract-regular-r3'
manifest=json.loads((review/'artifact-manifest.json').read_text(encoding='utf-8'))
items=manifest['artifacts']+[{'path':'artifact-manifest.json'},{'path':'final-receipt.json'}]
bindings=[]
archive=EVIDENCE/'upstream-review-originals.zip'
assert not archive.exists()
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for item in sorted(items,key=lambda x:x['path']):
        raw=(review/item['path']).read_bytes()
        if 'sha256' in item:assert len(raw)==item['bytes'] and hashlib.sha256(raw).hexdigest()==item['sha256']
        z.writestr(item['path'],raw)
        bindings.append({'path':item['path'],'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
jwrite(EVIDENCE/'upstream-review-bindings.json',{'source':str(review),'receipt_sha256':'a13fb68f86291a800e5f3b1c5068a40f653dba47ddcb46f580ca490a4297d363','report_sha256':'850075eb7876e7784012095763ae06f9f8be73c1d7add0cbf7d3db45afa77f91','manifest_sha256':'246677e384f985543c2931521e22d4bfdcc79a2fcfbd8ce1af674f99b569374c','archive':{'path':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},'artifact_count':len(bindings),'artifacts':bindings})
print('Updated only Task/current and new fix-r3 evidence; preserved byte-exact Review r3 archive (416 artifacts plus manifest/receipt)')
