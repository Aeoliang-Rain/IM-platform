import hashlib
import json
from pathlib import Path
import zipfile

ROOT=Path('H:/.codex/worktrees/group/IM-platform')
OUT=Path(__file__).resolve().parent
EVIDENCE=ROOT/'spec/progress/evidence/LOOP1-GROUP-001/contract/fix-r3'

def sha(raw):return hashlib.sha256(raw).hexdigest()
def write(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')

records=[json.loads(p.read_text(encoding='utf-8')) for p in sorted((OUT/'commands').glob('*.json'))]
summary=json.loads((EVIDENCE/'local-verification.json').read_text(encoding='utf-8'))
summary['commands']=records
summary['development']={key:value for key,value in next(r for r in records if r['label']=='development').items() if key in ('argv','exit_code','elapsed_seconds','cwd','python3_path_prepend')}
summary['precommit_snapshot']='All completed command outputs before package-evidence; later commit/Acceptance/finished Recorder bound by external final receipt'
write(EVIDENCE/'local-verification.json',summary)
raw=(OUT/'source-preservation-final.json').read_bytes()
assert b'\r' not in raw
(EVIDENCE/'source-preservation.json').write_bytes(raw)

files=sorted(p for p in OUT.rglob('*') if p.is_file() and 'research' not in p.relative_to(OUT).parts)
archive=EVIDENCE/'fix-run-originals.zip'
assert not archive.exists()
bindings=[]
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for path in files:
        relative=path.relative_to(OUT).as_posix()
        raw=path.read_bytes()
        z.writestr(relative,raw)
        bindings.append({'path':relative,'bytes':len(raw),'sha256':sha(raw)})
write(EVIDENCE/'fix-run-bindings.json',{'source':str(OUT),'archive':{'path':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes())},'cutoff':'Completed public artifacts before package-evidence. The running package command and subsequent commit/Acceptance/final research seal are intentionally external and bound by final-receipt.json. Recorder mutable run excluded from precommit ZIP; final immutable external Recorder is manifest-bound.','artifact_count':len(bindings),'artifacts':bindings})
for archive_name,binding_name in (('upstream-review-originals.zip','upstream-review-bindings.json'),('fix-run-originals.zip','fix-run-bindings.json')):
    data=json.loads((EVIDENCE/binding_name).read_text(encoding='utf-8'))
    with zipfile.ZipFile(EVIDENCE/archive_name) as z:
        assert sorted(z.namelist())==sorted(a['path'] for a in data['artifacts'])
        for a in data['artifacts']:
            raw=z.read(a['path']);assert len(raw)==a['bytes'] and sha(raw)==a['sha256'],a['path']
    assert sha((EVIDENCE/archive_name).read_bytes())==data['archive']['sha256']
print('PASS: both byte-exact archives and all bindings verified; original failures preserved, new loose UTF8 LF evidence ready')
