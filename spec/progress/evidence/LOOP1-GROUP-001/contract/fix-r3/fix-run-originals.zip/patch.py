from pathlib import Path
import subprocess

ROOT = Path('H:/.codex/worktrees/group/IM-platform')
assert subprocess.check_output(['git', 'rev-parse', '--show-toplevel'], cwd=ROOT).decode().strip() == ROOT.as_posix()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip() == 'bcae6468285bd050bce6a7e53012e66bc15ab962'
assert not subprocess.check_output(['git', 'status', '--porcelain=v1', '-uall'], cwd=ROOT)
path = ROOT / 'contracts/http/verify-group.py'
source = path.read_text(encoding='utf-8')
old = "    supplied = request.get('query',{}).get('requestId') if operation == 'list' else request.get('body',{}).get('requestId')\n"
new = "    supplied_fields = request.get('query') if operation == 'list' else request.get('body')\n    supplied = supplied_fields.get('requestId') if isinstance(supplied_fields,dict) else None\n"
assert source.count(old) == 1
path.write_text(source.replace(old, new), encoding='utf-8', newline='\n')
path = ROOT / 'tests/contract/group/test_group.py'
source = path.read_text(encoding='utf-8')
marker = "\n\nif __name__=='__main__':unittest.main()\n"
addition = '''
    def test_nonobject_requests_accept_canonical_errors_and_reject_bad_responses(self):
        for name,field in (('create-a-b','body'),('member-b-adds-nonfriend-c','body'),('snapshot-nonfriend','query')):
            for encoded in ('null','[]','true','42','"decoded scalar JSON"','{}'):
                with self.subTest(fixture=name,json=encoded):
                    original=self.case(name);case=copy.deepcopy(original)
                    case['request'][field]=json.loads(encoded)
                    case['status']=400
                    case['response']={'requestId':'40000000-0000-4000-8000-000000000099','error':{'code':'VALIDATION_FAILED','message':'Request validation failed.'}}
                    self.assertEqual(v.request_failure(case['operation'],case['request'],case['context'],self.document),(400,'VALIDATION_FAILED'))
                    v.check_exchange(case,self.document)
                    mutations=[
                        ('status',lambda c:c.__setitem__('status',401)),
                        ('code',lambda c:c['response']['error'].__setitem__('code','AUTH_REQUIRED')),
                        ('requestId',lambda c:c['response'].__setitem__('requestId','not-a-uuid')),
                        ('success',lambda c:c.update(status=original['status'],response=original['response'])),
                    ]
                    for label,mutate in mutations:
                        invalid=copy.deepcopy(case);mutate(invalid)
                        with self.subTest(mutation=label),self.assertRaises(v.Invalid):v.check_exchange(invalid,self.document)

    def test_malformed_objects_with_valid_request_ids_still_require_correlation(self):
        for name,field in (('create-a-b','body'),('member-b-adds-nonfriend-c','body'),('snapshot-nonfriend','query')):
            with self.subTest(fixture=name):
                case=self.case(name);request_id=case['request'][field]['requestId']
                case['request'][field]={'requestId':request_id,'limit':0} if field=='query' else {'requestId':request_id,'memberUserIds':[]}
                case['status']=400
                case['response']={'requestId':request_id,'error':{'code':'VALIDATION_FAILED','message':'Request validation failed.'}}
                v.check_exchange(case,self.document)
                case['response']['requestId']='40000000-0000-4000-8000-000000000099'
                with self.assertRaises(v.Invalid):v.check_exchange(case,self.document)
'''
assert source.count(marker) == 1
path.write_text(source.replace(marker, '\n' + addition + marker), encoding='utf-8', newline='\n')
print('Applied only object-aware correlation extraction and two focused parameterized regression methods; no fixture/wire changes')
