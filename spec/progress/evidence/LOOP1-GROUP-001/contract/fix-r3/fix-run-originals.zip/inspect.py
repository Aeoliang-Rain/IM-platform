import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path('H:/.codex/worktrees/group/IM-platform')
OUT = Path(__file__).resolve().parent
REVIEW = OUT.parent / 'contract-regular-r3'
PARENT = 'bcae6468285bd050bce6a7e53012e66bc15ab962'
BASE = '6f163927334c39c9c8833eb8222335c661bde673'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')

def git(*args):
    return subprocess.run(['git', *args], cwd=ROOT, check=True, capture_output=True).stdout

if sys.argv[1] == 'bind':
    expected = {'final-receipt.json': 'a13fb68f86291a800e5f3b1c5068a40f653dba47ddcb46f580ca490a4297d363', 'report.md': '850075eb7876e7784012095763ae06f9f8be73c1d7add0cbf7d3db45afa77f91', 'artifact-manifest.json': '246677e384f985543c2931521e22d4bfdcc79a2fcfbd8ce1af674f99b569374c'}
    for name, digest in expected.items():
        assert sha((REVIEW / name).read_bytes()) == digest, name
    manifest = json.loads((REVIEW / 'artifact-manifest.json').read_text(encoding='utf-8'))
    verified = []
    assert len(manifest['artifacts']) == manifest['artifact_count'] == 416
    for artifact in manifest['artifacts']:
        raw = (REVIEW / artifact['path']).read_bytes()
        assert len(raw) == artifact['bytes'] and sha(raw) == artifact['sha256'], artifact['path']
        verified.append(artifact)
    receipt = json.loads((REVIEW / 'final-receipt.json').read_text(encoding='utf-8'))
    assert receipt['candidate_sha'] == PARENT and receipt['clean'] and receipt['result'] == 'FAIL_REGULAR_REVIEW_ONLY'
    assert git('rev-parse', '--show-toplevel').decode().strip() == ROOT.as_posix()
    assert git('rev-parse', 'HEAD').decode().strip() == PARENT
    assert not git('status', '--porcelain=v1', '-uall')
    write('review-binding.json', {'review_directory': str(REVIEW), 'candidate_sha': PARENT, 'receipt_sha256': expected['final-receipt.json'], 'report_sha256': expected['report.md'], 'manifest_sha256': expected['artifact-manifest.json'], 'result': receipt['result'], 'finding': receipt['findings']['ids'], 'verified_count': len(verified), 'verified_artifacts': verified})
    fields = git('diff', '--no-renames', '--name-status', '-z', BASE, PARENT).decode().split('\0')[:-1]
    owned = []
    for i in range(0, len(fields), 2):
        status, path = fields[i:i + 2]
        item = {'status': status, 'path': path}
        revision = BASE if status == 'D' else PARENT
        raw = git('show', revision + ':' + path)
        item.update({'blob_revision': revision, 'git_blob': git('rev-parse', revision + ':' + path).decode().strip(), 'bytes': len(raw), 'sha256': sha(raw)})
        if status != 'D':
            assert (ROOT / path).read_bytes() == raw, path
        else:
            assert not (ROOT / path).exists(), path
        owned.append(item)
    assert len(owned) == 52
    write('parent-owned-blobs.json', {'base_sha': BASE, 'parent_sha': PARENT, 'count': len(owned), 'owned_blobs': owned})
    print('PASS: sealed Review r3 receipt/report/416 artifacts, exact root/clean bca and actual 52 no-renames parent paths verified')
elif sys.argv[1] == 'source':
    for relative in sys.argv[2:]:
        print('\nFILE ' + relative)
        for number, line in enumerate((ROOT / relative).read_text(encoding='utf-8').splitlines(), 1):
            print(f'{number}: {line}')
else:
    raise ValueError(sys.argv[1])
