import importlib.util
from pathlib import Path
import subprocess
import types
import unittest

ROOT = Path('H:/.codex/worktrees/group/IM-platform')
filename = ROOT / 'contracts/http/verify-group.py'
parent_source = subprocess.check_output(['git','show','bcae6468285bd050bce6a7e53012e66bc15ab962:contracts/http/verify-group.py'], cwd=ROOT)
parent = types.ModuleType('parent_group')
parent.__file__ = str(filename)
exec(compile(parent_source, str(filename), 'exec'), parent.__dict__)
spec = importlib.util.spec_from_file_location('new_group_tests', ROOT / 'tests/contract/group/test_group.py')
tests = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tests)
tests.v = parent
suite = unittest.TestSuite(tests.GroupContractTests(name) for name in (
    'test_nonobject_requests_accept_canonical_errors_and_reject_bad_responses',
    'test_malformed_objects_with_valid_request_ids_still_require_correlation',
))
result = unittest.TextTestRunner(verbosity=2).run(suite)
raise SystemExit(0 if result.wasSuccessful() else 1)
