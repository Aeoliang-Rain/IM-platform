import datetime
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('H:/.codex/worktrees/group/IM-platform')
OUT = Path(__file__).resolve().parent
PY = Path('C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe')
RUN = 'R-GROUP-FIX-R3-20261018'

def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')

if __name__ == '__main__':
    label, *command = sys.argv[1:]
    if command[0] == '--':
        command = command[1:]
    folder = OUT / 'commands'
    folder.mkdir(exist_ok=True)
    if (folder / (label + '.json')).exists():
        raise RuntimeError('Command label already exists: ' + label)
    argv = [str(PY), '-Xutf8', '-B', str(ROOT / 'tools/research/recorder.py'), 'run-command', '--repo', str(ROOT), '--research-root', str(OUT / 'research'), '--run-id', RUN, '--', *command]
    env = os.environ.copy()
    env['PATH'] = str(PY.parent) + os.pathsep + env.get('PATH', '')
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    begin = time.monotonic()
    result = subprocess.run(argv, cwd=ROOT, env=env, capture_output=True)
    elapsed = time.monotonic() - begin
    (folder / (label + '.stdout')).write_bytes(result.stdout)
    (folder / (label + '.stderr')).write_bytes(result.stderr)
    record = {'label': label, 'argv': command, 'recorder_argv': argv, 'cwd': str(ROOT), 'started_at_utc': started, 'exit_code': result.returncode, 'elapsed_seconds': elapsed, 'python3_path_prepend': str(PY.parent), 'stdout': label + '.stdout', 'stderr': label + '.stderr'}
    write_json(folder / (label + '.json'), record)
    stdout = result.stdout.decode('utf-8', 'replace')
    if len(stdout) <= 60000:
        print(stdout, end='')
    else:
        print('[Large stdout preserved in full at ' + str(folder / (label + '.stdout')) + ']')
    print(result.stderr.decode('utf-8', 'replace'), end='', file=sys.stderr)
    print(json.dumps({'label': label, 'exit_code': result.returncode, 'elapsed_seconds': elapsed}))
    sys.exit(result.returncode)
