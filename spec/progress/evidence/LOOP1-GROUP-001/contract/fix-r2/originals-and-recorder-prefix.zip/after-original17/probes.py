import contextlib, copy, hashlib, importlib.util, json, os, pathlib, subprocess, sys, tempfile, time
OUT=pathlib.Path(__file__).resolve().parent
ROOT=pathlib.Path('H:/.codex/worktrees/group/IM-platform')
PY=sys.executable
PW='C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'
SHA='0190c65cafff7df50492e743761427f214fba951'
BASE='6f163927334c39c9c8833eb8222335c661bde673'
def dump(name,value):
    (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def load(path,name):
    spec=importlib.util.spec_from_file_location(name,ROOT/path); module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
def bindings():
    regular=OUT.parent/'contract-regular-r2'
    expected={'final-receipt.json':'34da73db542ab83252452b54d4dfed2d916f1a763c812d139011927799ac3b07','report.md':'c982a4c2faa34bcca352967a0acba342114db1e747de07a3c9a955f44f1703a9','artifact-manifest.json':'3b71be9c93e9a575cbe57f51cea94441edc8a8014af666cab380071697b98c61'}
    for name,h in expected.items():assert digest(regular/name)==h,name
    receipt=json.loads((regular/'final-receipt.json').read_text(encoding='utf8'))
    assert receipt['candidate_sha']==SHA and receipt['clean'] and receipt['result']=='PASS_REGULAR_REVIEW_ONLY'
    manifest=json.loads((regular/'artifact-manifest.json').read_text(encoding='utf8'))
    print('regular manifest keys',list(manifest))
    items=manifest['artifacts']
    for item in items:
        p=(regular/item['path']).resolve();assert p.is_relative_to(regular.resolve())
        assert p.stat().st_size==item['bytes'] and digest(p)==item['sha256'],item['path']
    assert len(items)==272
    state={k:subprocess.check_output(['git','-c','core.excludesFile=.git/info/exclude',*args],cwd=ROOT,text=True).strip() for k,args in {'root':['rev-parse','--show-toplevel'],'head':['rev-parse','HEAD'],'branch':['branch','--show-current'],'status':['status','--porcelain=v1']}.items()}
    assert state['root']==ROOT.as_posix() and state['head']==SHA and state['branch']=='task/LOOP1-GROUP-001' and not state['status']
    up='contracts/database/migrations/0001_initial.up.sql';down='contracts/database/migrations/0001_initial.down.sql'
    preservation={}
    for path in [up,down,'contracts/http/auth-user-friend.openapi.json','contracts/plugin-api/verify.py']:
        original=subprocess.check_output(['git','show',BASE+':'+path],cwd=ROOT)
        # Git object is LF; worktree bytes may follow CRLF checkout settings.
        final=subprocess.check_output(['git','show',SHA+':'+path],cwd=ROOT)
        assert original==final,path
        preservation[path]={'base_blob_sha256':hashlib.sha256(original).hexdigest(),'candidate_blob_sha256':hashlib.sha256(final).hexdigest(),'worktree_sha256':digest(ROOT/path)}
    result={'actor':'/root/group_contract_error_r1','regular_hashes':expected,'regular_artifacts_verified':len(items),'state':state,'preservation':preservation,'historical_0001_normalized_checksum':hashlib.sha256((ROOT/up).read_text(encoding='utf8').encode()).hexdigest()}
    dump('prerequisite-bindings.json',result);print(json.dumps(result,ensure_ascii=False))
def fixtures():
    data=json.loads((ROOT/'contracts/fixtures/group/exchanges.json').read_text(encoding='utf8'))
    counter=0;start=int(sys.argv[2]);end=int(sys.argv[3])
    for kind in ('valid','invalid'):
        for case in data[kind]:
            if start<=counter<end:print(json.dumps({'kind':kind,**case},ensure_ascii=False,separators=(',',':')))
            counter+=1
def faults():
    v=load('contracts/http/verify-group.py','specialized_group')
    doc=json.loads(v.CONTRACT.read_text(encoding='utf8'))
    cases=json.loads((ROOT/'contracts/fixtures/group/exchanges.json').read_text(encoding='utf8'))
    result=[]
    def expect(label,kind,operation):
        try:operation()
        except kind as exc:result.append({'probe':label,'observed':type(exc).__name__,'message':str(exc),'result':'EXPECTED_FAILURE_PROPAGATED'});return
        raise AssertionError(label+' did not propagate '+kind.__name__)
    def case(name):return copy.deepcopy(next(x for x in cases['valid'] if x['id']==name))
    # Distinguish known fixture rejection from unknown checker defects.
    bad=case('create-a-b');bad['context'].pop('actorId')
    expect('missing-authoritative-context-key',KeyError,lambda:v.check_exchange(bad))
    original_validate=v.validate
    def bug(*args,**kwargs):raise RuntimeError('SPECIALIZED_UNKNOWN_CHECKER_SENTINEL')
    v.validate=bug
    expect('request-validation-runtime-error-not-400',RuntimeError,lambda:v.request_failure('create',case('create-a-b')['request'],case('create-a-b')['context'],doc))
    expect('exchange-runtime-error-at-request-validation',RuntimeError,lambda:v.check_exchange(case('create-a-b')))
    v.validate=original_validate
    supplied=case('create-a-b')['request']['body']['requestId']; count=[0]
    def correlation_bug(value,*args,**kwargs):
        if value==supplied:
            count[0]+=1
            if count[0]==2:raise RuntimeError('SPECIALIZED_CORRELATION_SENTINEL')
        return original_validate(value,*args,**kwargs)
    v.validate=correlation_bug
    expect('correlation-catch-does-not-suppress-runtime-error',RuntimeError,lambda:v.check_exchange(case('create-a-b')))
    assert count[0]==2
    v.validate=original_validate
    saved=v.ORACLE['validate'];v.ORACLE['validate']=bug
    expect('pattern-oneOf-runtime-error-not-alternative-rejection',RuntimeError,lambda:v.check_patterns('ok',{'oneOf':[{'type':'string'}]}))
    v.ORACLE['validate']=saved
    shared_globals=saved.__globals__; shared_original=shared_globals['validate'];shared_globals['validate']=bug
    expect('shared-validator-oneOf-does-not-suppress-runtime-error',RuntimeError,lambda:shared_original('x',{'oneOf':[{'type':'string'}]},{}))
    shared_globals['validate']=shared_original
    old_exchange=v.check_exchange
    def unknown_on_negative(c,d=None):
        if c['id']==cases['invalid'][0]['id']:raise AssertionError('SPECIALIZED_NEGATIVE_ORACLE_SENTINEL')
        return old_exchange(c,d)
    v.check_exchange=unknown_on_negative
    expect('negative-loop-unknown-assertion-not-negative-PASS',AssertionError,lambda:v.verify_fixtures(doc))
    v.check_exchange=old_exchange
    expect('malformed-pattern-is-internal-error',__import__('re').error,lambda:v.validate('a',{'type':'string','pattern':'['}))
    for name in ('old-group-original-result-missing','new-group-original-result-missing'):
        original=case(name);v.check_exchange(original)
        result.append({'probe':name,'result':'TRUE_SERVER_FAILURE_ACCEPTED_WITHOUT_FAKE_RESPONSE'})
        fake=copy.deepcopy(original);fake['status']=409;fake['response']={'requestId':fake['request']['body']['requestId'],'error':{'code':'GROUP_REQUEST_CONFLICT','message':'fake conflict'}}
        expect(name+'-fake409',v.Invalid,lambda:v.check_exchange(fake))
    def child(label,code,expected=None):
        begin=time.monotonic();p=subprocess.run([PY,'-Xutf8','-B','-c',code],cwd=ROOT,capture_output=True)
        (OUT/(label+'.stdout')).write_bytes(p.stdout);(OUT/(label+'.stderr')).write_bytes(p.stderr)
        assert p.returncode!=0 and b'PASS:' not in p.stdout,label
        if expected:assert expected.encode() in p.stderr,label
        result.append({'probe':label,'argv':[PY,'-Xutf8','-B','-c',code],'exit_code':p.returncode,'elapsed_seconds':round(time.monotonic()-begin,6),'stdout':label+'.stdout','stderr':label+'.stderr'})
    path=str(ROOT/'contracts/http/verify-group.py')
    child('cli-negative-internal-defect',f"import runpy; g=runpy.run_path({path!r}); f=g['main'].__globals__; old=f['check_exchange']; f['check_exchange']=lambda c,d=None: (_ for _ in ()).throw(AssertionError('SPECIALIZED_NEGATIVE_ORACLE_SENTINEL')) if c['id']=='{cases['invalid'][0]['id']}' else old(c,d); g['main']()",'SPECIALIZED_NEGATIVE_ORACLE_SENTINEL')
    for label,expression in [('internal-keyerror',"(_ for _ in ()).throw(KeyError('SPECIALIZED_INTERNAL_LEDGER_SENTINEL'))"),('internal-valueerror',"(_ for _ in ()).throw(ValueError('SPECIALIZED_INTERNAL_PARSE_SENTINEL'))"),('external-oserror',"(_ for _ in ()).throw(OSError('SPECIALIZED_EXTERNAL_EXEC_SENTINEL'))")]:
        path=str(ROOT/'contracts/database/migrate.py')
        child('migration-cli-'+label,f"import runpy,sys;g=runpy.run_path({path!r});g['main'].__globals__['run']=lambda direction: {expression};sys.argv=['migrate.py','up'];sys.exit(g['main']())",'SPECIALIZED_')
    m=load('contracts/database/migrate.py','specialized_migrate')
    m.psql=lambda sql,**kw:'unexpected'
    expect('unexpected-existence-output-not-empty-ledger',RuntimeError,m.applied)
    n=[0]
    def malformed(sql,**kw):n[0]+=1;return 't' if n[0]==1 else 'bad-row-without-separator'
    m.psql=malformed
    expect('malformed-ledger-row-is-not-pending-state',ValueError,m.applied)
    dump('fault-probes.json',result);print(json.dumps(result,ensure_ascii=False,indent=2))
def workflow():
    text=(ROOT/'.github/workflows/ci.yml').read_text(encoding='utf8')
    lines=text.splitlines(); start=next(i for i,l in enumerate(lines) if l.strip()=='python3 -B contracts/http/verify-group.py')
    body='\n'.join(l.strip() for l in lines[start:start+4])
    assert 'unittest discover -s tests/contract/group' in body
    results=[]
    for failure_at,exit_code in ((1,37),(2,41),(0,0)):
        marker=OUT/f'workflow-{failure_at}.markers'
        script=OUT/f'workflow-{failure_at}.ps1'
        prelude=f'''$ErrorActionPreference='Stop'
$script:count=0
function python3 {{
    $script:count++
    [IO.File]::AppendAllText('{marker.as_posix()}', ([string]$script:count)+[Environment]::NewLine)
    $probeCode=if ($script:count -eq {failure_at}) {{ {exit_code} }} else {{ 0 }}
    & '{PY}' -c "import sys; sys.exit($probeCode)"
    $global:LASTEXITCODE=$LASTEXITCODE
}}
'''
        script.write_text(prelude+body+'\n',encoding='utf8')
        begin=time.monotonic();p=subprocess.run([PW,'-NoProfile','-File',str(script)],capture_output=True,cwd=ROOT)
        (OUT/f'workflow-{failure_at}.stdout').write_bytes(p.stdout);(OUT/f'workflow-{failure_at}.stderr').write_bytes(p.stderr)
        assert p.returncode==exit_code,(failure_at,p.returncode,p.stderr)
        called=marker.read_text().splitlines();assert len(called)==(failure_at or 2)
        results.append({'failure_at_call':failure_at,'native_exit_code':p.returncode,'calls_observed':len(called),'elapsed_seconds':round(time.monotonic()-begin,6),'executed_exact_block':body,'scope':'isolated shell failure propagation; no hosted claim'})
    dump('workflow-failure-probes.json',results);print(json.dumps(results,indent=2))
def structural_internal_fault():
    import io,unittest
    tests=load('tests/contract/group/test_group.py','specialized_group_tests')
    tests.GroupContractTests.setUpClass()
    validator=tests.v
    original=validator.subprocess.run
    observations=[]
    def checker_crash(argv,**kw):
        observations.append({'argv':argv,'injected_exit_code':2,'stderr':'SPECIALIZED_OPENAPI_INTERNAL_SENTINEL'})
        return subprocess.CompletedProcess(argv,2,stdout=b'',stderr=b'SPECIALIZED_OPENAPI_INTERNAL_SENTINEL')
    try:
        validator.subprocess.run=checker_crash
        stream=io.StringIO()
        suite=unittest.TestSuite([tests.GroupContractTests('test_formal_openapi_structure_negative_controls')])
        result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
        (OUT/'structural-internal-fault.unittest.raw').write_text(stream.getvalue(),encoding='utf8')
        report={'candidate_sha':SHA,'location':'contracts/http/verify-group.py:108-112 and tests/contract/group/test_group.py:28-38','injected_failure':'checker subprocess exit2, genuine checker/internal failure branch; no schema validation result','negative_test_result':result.wasSuccessful(),'tests_run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'checker_crashes_seen':len(observations),'observations':observations,'issue_reproduced':result.wasSuccessful() and len(observations)==5,'consequence':'all five negative structural controls count checker-internal failure as expected Invalid rejection'}
        assert report['issue_reproduced'],report
        dump('structural-internal-fault.json',report);print(json.dumps(report,indent=2))
    finally:validator.subprocess.run=original
def structural_full_suite_fault():
    import io,unittest
    tests=load('tests/contract/group/test_group.py','specialized_full_group_tests')
    validator=tests.v;original=validator.subprocess.run;observations=[]
    def checker_crash_on_invalid_input(argv,**kw):
        document=json.loads(kw['input'])
        op=document.get('paths',{}).get('/v1/groups',{}).get('post',{})
        listing=document.get('paths',{}).get('/v1/conversations',{}).get('get',{})
        negative=('title' not in document.get('info',{}) or 'unknownRoot' in document or op.get('responses',{}).get('201')==42 or 'unknownOperation' in op or any(p.get('in')=='imaginary' for p in listing.get('parameters',[])))
        if negative:
            observations.append({'argv':argv,'injected_exit_code':2,'stderr':'SPECIALIZED_INPUT_DEPENDENT_CHECKER_BUG'})
            return subprocess.CompletedProcess(argv,2,stdout=b'',stderr=b'SPECIALIZED_INPUT_DEPENDENT_CHECKER_BUG')
        return original(argv,**kw)
    try:
        validator.subprocess.run=checker_crash_on_invalid_input
        stream=io.StringIO();suite=unittest.TestSuite(tests.GroupContractTests(name) for name in ORIGINAL_TESTS)
        result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
        (OUT/'structural-full-suite-fault.unittest.raw').write_text(stream.getvalue(),encoding='utf8')
        report={'candidate_sha':SHA,'tests_run':result.testsRun,'negative_input_checker_crashes':len(observations),'suite_success':result.wasSuccessful(),'failures':len(result.failures),'errors':len(result.errors),'observations':observations,'real_validator_for_positive_and_other_inputs':True,'issue_reproduced':result.wasSuccessful() and len(observations)==5}
        dump('structural-full-suite-fault.json',report);assert report['issue_reproduced'],report;print(json.dumps(report,indent=2))
    finally:validator.subprocess.run=original
if __name__=='__main__':globals()[sys.argv[1]]()
