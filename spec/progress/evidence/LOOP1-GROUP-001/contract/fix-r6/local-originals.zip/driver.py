from pathlib import Path
import json
import os
import subprocess
import sys
import time

ROOT = Path('H:/.codex/worktrees/group/IM-platform')
OUT = Path(__file__).resolve().parent
PYTHON = Path('C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe')
RECORDER = ROOT / 'tools/research/recorder.py'
RUN_ID = 'R-GROUP-FIX-R6-20261020'
RESEARCH = OUT / 'research'
ENV = dict(os.environ)
ENV['PATH'] = str(PYTHON.parent) + os.pathsep + ENV['PATH']
ENV['PYTHONUTF8'] = '1'
ENV['PYTHONDONTWRITEBYTECODE'] = '1'

def direct(label, args):
    started = time.monotonic()
    result = subprocess.run([str(PYTHON), '-X', 'utf8', '-B', str(RECORDER), *args], cwd=ROOT, env=ENV, capture_output=True)
    (OUT / (label + '.stdout')).write_bytes(result.stdout)
    (OUT / (label + '.stderr')).write_bytes(result.stderr)
    print(json.dumps({'label': label, 'exit': result.returncode, 'elapsed_seconds': time.monotonic()-started, 'stdout_path': str(OUT / (label + '.stdout')), 'stderr_path': str(OUT / (label + '.stderr')), 'stdout_tail': result.stdout[-600:].decode('utf-8', errors='replace'), 'stderr_tail': result.stderr[-600:].decode('utf-8', errors='replace')}, ensure_ascii=False))
    return result.returncode

def run(label, args):
    return direct(label, ['run-command', '--repo', str(ROOT), '--research-root', str(RESEARCH), '--run-id', RUN_ID, '--', *args])

if __name__ == '__main__':
    if sys.argv[1] == 'init':
        prompt = OUT / 'visible-prompt.txt'
        prompt.write_text('Coordinator assignment to fresh Fix R6: Repair two independently reproduced current defects for LOOP1-GROUP-001 first contract slice. Phase 0 is read-only; source write lease is NONE. Assigned managed worktree H:/.codex/worktrees/group/IM-platform, branch task/LOOP1-GROUP-001, clean HEAD e218cacbfff2f88bfd162440dcfb2745d9934895, parent 462431a45d60d1de0449a35b2fcf698a894d664b, accepted base/main 6f163927334c39c9c8833eb8222335c661bde673. Complete mandatory startup and authority/hash checks, minimum baseline, then propose Phase 1 Task-only registration before source changes. Defects: migration applied() parses unescaped tab/newline text and accepts one physical poisoned ledger row as two canonical rows; Go strict TLS E2E compares flattened version text and cannot distinguish real rows from an embedded newline. Preserve original evidence, all SQL, public contracts, original tests, locks, error propagation, Go/client product and CI/Gate. No PostgreSQL or Docker operations before Coordinator authorization. Proposed minimal scope is unambiguous current record reading, exact prefix/checksum validation and direct boundary/real database regressions. Final fix needs one commit, Development plus clean committed Acceptance, honest Recorder closure, report/manifest/owned blobs/final receipt, clean source root and released lease. No push, PR, CI, merge or synchronization. This registered text is a task-assignment excerpt; the full Human AGENTS instructions and platform messages are not asserted to be a complete captured prompt.', encoding='utf-8', newline='\n')
        common = ['--repo', str(ROOT), '--research-root', str(RESEARCH)]
        code = direct('register-prompt', ['register-prompt', *common, '--task-id', 'LOOP1-GROUP-001', '--file', str(prompt), '--source', 'coordinator_assignment_excerpt', '--prompt-id', 'P-GROUP-FIX-R6-20261020'])
        if code: raise SystemExit(code)
        code = direct('start-run', ['start-run', *common, '--task-id', 'LOOP1-GROUP-001', '--role', 'fix', '--capture-mode', 'prospective_resume', '--pre-recorder-work', '--prompt-id', 'P-GROUP-FIX-R6-20261020', '--run-id', RUN_ID, '--related-run-id', 'R-GROUP-REGULAR-R6-20261020', '--experiment-group', 'full_governance', '--fresh-context', 'true', '--agent-harness', 'Codex desktop'])
        if code: raise SystemExit(code)
        code = direct('startup-warning', ['record-event', *common, '--run-id', RUN_ID, '--event-type', 'instrumentation_warning', '--data-json', json.dumps({'warning': 'Partial trace: mandatory startup direct reads, Recorder discovery, external helper authoring and coordination occurred before run start. Visible prompt is an assignment excerpt. Some tool displays were truncated and pertinent sections reread. No source/Task writes and no PostgreSQL/Docker operations occurred before start. No complete prospective trace or Task acceptance is claimed.'})])
        raise SystemExit(code)
    if sys.argv[1] == 'run':
        raise SystemExit(run(sys.argv[2], sys.argv[3:]))
    raise SystemExit('unknown driver operation')
