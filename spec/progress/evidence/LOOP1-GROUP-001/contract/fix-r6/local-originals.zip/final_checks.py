from pathlib import Path
import json
import time
import driver

python = [str(driver.PYTHON), '-X', 'utf8', '-B']
pwsh = 'C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'
commands = [
    ('final-frozen', python + ['tools/verify_frozen_architecture.py']),
    ('final-planning', python + ['ci/check_s2_planning.py']),
    ('final-architecture', python + ['ci/check_architecture.py', '--scope', 'all', '--json']),
    ('final-architecture-tests', python + ['-m', 'unittest', 'discover', '-s', 'tests/architecture']),
    ('final-ci-tests', python + ['-m', 'unittest', 'discover', '-s', 'tests/ci']),
    ('final-group-verifier', python + ['contracts/http/verify-group.py']),
    ('final-auth-verifier', [pwsh, '-NoProfile', '-File', 'contracts/http/verify-auth-user-friend.ps1']),
    ('final-sync-verifier', python + ['tools/verify_sync_transport.py']),
    ('final-sync-tests', python + ['-m', 'unittest', 'discover', '-s', 'tests/contract', '-p', 'test_sync_transport.py']),
    ('final-wss-verifier', python + ['contracts/websocket/verify.py']),
    ('final-plugin-verifier', python + ['contracts/plugin-api/verify.py']),
]
results = []
for label, argv in commands:
    started = time.monotonic()
    exit_code = driver.run(label, argv)
    results.append({'label': label, 'argv': argv, 'exit': exit_code, 'recorder_wrapper_elapsed_seconds': time.monotonic()-started, 'stdout': label+'.stdout', 'stderr': label+'.stderr'})
    (driver.OUT / 'final-checks.json').write_text(json.dumps(results, ensure_ascii=False, indent=2)+'\n', encoding='utf-8', newline='\n')
    if exit_code:
        raise SystemExit(exit_code)
print(json.dumps({'result': 'PASS', 'commands': len(results)}))
