from pathlib import Path
import ast
import hashlib
import json
import subprocess
import sys

from test_additions import DB_TEST, E2E_TEST

ROOT = Path('H:/.codex/worktrees/group/IM-platform')
OUT = Path(__file__).resolve().parent
PATHS = ['contracts/database/migrate.py', 'tests/database/test_migrations.py', 'tests/e2e/go_tls_messaging.py', 'tests/contract/group/test_verification_failures.py']

def git(*args):
    return subprocess.run(['git', '-c', 'core.excludesFile=.git/info/exclude', *args], cwd=ROOT, capture_output=True, check=True).stdout

def write(path, text):
    target = ROOT / path
    raw = target.read_bytes()
    newline = '\r\n' if b'\r\n' in raw else '\n'
    target.write_bytes(text.replace('\n', newline).encode('utf-8'))

assert git('rev-parse', '--show-toplevel').decode().strip() == 'H:/.codex/worktrees/group/IM-platform'
assert git('branch', '--show-current').decode().strip() == 'task/LOOP1-GROUP-001'
assert git('rev-parse', 'HEAD').decode().strip() == 'e218cacbfff2f88bfd162440dcfb2745d9934895'
if sys.argv[1] == 'tests':
    assert git('diff', '--name-only').decode().splitlines() == ['spec/tasks/active/LOOP1-GROUP-001.md']
    bindings = {}
    for path in PATHS:
        raw = (ROOT / path).read_bytes()
        bindings[path] = {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    (OUT / 'source-before.json').write_text(json.dumps(bindings, indent=2)+'\n', encoding='utf-8', newline='\n')
    path = 'tests/database/test_migrations.py'
    text = (ROOT / path).read_text(encoding='utf-8')
    marker = '    def test_failure_in_0002_rolls_back_whole_pending_batch(self):'
    assert text.count(marker) == 1
    write(path, text.replace(marker, DB_TEST + marker))
    path = 'tests/contract/group/test_verification_failures.py'
    text = (ROOT / path).read_text(encoding='utf-8')
    marker = "\n\nif __name__ == '__main__':"
    assert text.count(marker) == 1
    write(path, text.replace(marker, '\n' + E2E_TEST + marker))
elif sys.argv[1] == 'probe-bytes':
    path = 'tests/contract/group/test_verification_failures.py'
    text = (ROOT / path).read_text(encoding='utf-8')
    old = "import sys;sys.stdout.write(sys.argv[1]);sys.stderr.write('E2E_LEDGER_NATIVE_SENTINEL');sys.exit(int(sys.argv[2]))"
    new = "import sys;sys.stdout.buffer.write(sys.argv[1].encode('utf-8'));sys.stderr.write('E2E_LEDGER_NATIVE_SENTINEL');sys.exit(int(sys.argv[2]))"
    assert text.count(old) == 1
    write(path, text.replace(old, new))
elif sys.argv[1] == 'fix':
    path = 'contracts/database/migrate.py'
    text = (ROOT / path).read_text(encoding='utf-8')
    old = '''    output = psql("SELECT version || E'\\\\t' || checksum FROM schema_migrations ORDER BY version;",capture=True)
    known = {}
    for line in output.splitlines():
        version,digest = line.split('\\t')'''
    new = '''    output = psql("SELECT COALESCE(json_agg(json_build_array(version,checksum) ORDER BY version),'[]'::json) FROM schema_migrations;",capture=True)
    known = {}
    for version,digest in json.loads(output):'''
    assert text.count(old) == 1, repr(old)
    write(path, text.replace(old, new))
    path = 'tests/e2e/go_tls_messaging.py'
    text = (ROOT / path).read_text(encoding='utf-8')
    old = "require(sql('SELECT version FROM schema_migrations ORDER BY version') == '0001_initial\\n0002_group_operations', 'canonical migration missing')"
    new = "require(json.loads(sql('SELECT json_agg(version ORDER BY version) FROM schema_migrations')) == ['0001_initial', '0002_group_operations'], 'canonical migration missing')"
    assert text.count(old) == 1
    write(path, text.replace(old, new))
else:
    raise SystemExit('unknown edit operation')
for path in PATHS:
    ast.parse((ROOT / path).read_text(encoding='utf-8'))
print(json.dumps({'result': 'EDIT_COMPLETE', 'operation': sys.argv[1], 'paths': git('diff', '--name-only').decode().splitlines()}))
