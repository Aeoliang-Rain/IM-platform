from pathlib import Path
import ast
import hashlib
import json
import subprocess

ROOT = Path('H:/.codex/worktrees/group/IM-platform')
OUT = Path(__file__).resolve().parent
BASE = 'e218cacbfff2f88bfd162440dcfb2745d9934895'
ALLOWED = {'contracts/database/migrate.py', 'tests/database/test_migrations.py', 'tests/e2e/go_tls_messaging.py', 'tests/contract/group/test_verification_failures.py', 'spec/tasks/active/LOOP1-GROUP-001.md', 'spec/progress/current.md'}
EVIDENCE = 'spec/progress/evidence/LOOP1-GROUP-001/contract/fix-r6/'

def git(*args):
    return subprocess.run(['git', '-c', 'core.excludesFile=.git/info/exclude', *args], cwd=ROOT, capture_output=True, check=True).stdout

snapshot = json.loads((OUT.parent / 'contract-fix-r6-phase1-before-coordinator.json').read_text(encoding='utf-8'))
assert snapshot['head'] == BASE and snapshot['tracked_count'] == 19041
protected = 0
for name, binding in snapshot['files'].items():
    if name in ALLOWED:
        continue
    target = ROOT / name
    assert binding['kind'] == 'file', (name, binding)
    raw = target.read_bytes()
    assert len(raw) == binding['bytes'] and hashlib.sha256(raw).hexdigest() == binding['sha256'], name
    protected += 1
changed = git('diff', BASE, '--name-only', '--no-renames').decode().splitlines()
assert all(name in ALLOWED or name.startswith(EVIDENCE) for name in changed), changed
untracked = git('ls-files', '--others', '--exclude-standard').decode().splitlines()
assert all(name.startswith(EVIDENCE) for name in untracked), untracked

def methods(tree):
    found = {}
    for node in tree.body:
        if isinstance(node, ast.ClassDef):
            found.update({node.name + '.' + child.name: ast.dump(child, include_attributes=False) for child in node.body if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef))})
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            found[node.name] = ast.dump(node, include_attributes=False)
    return found

preserved = {}
for path, additional in (
    ('tests/database/test_migrations.py', {'GroupMigrationPostgreSQLTests.test_single_physical_ledger_record_cannot_alias_canonical_rows'}),
    ('tests/contract/group/test_verification_failures.py', {'VerificationFailureTests.test_e2e_ledger_assertion_preserves_records_and_native_failures'}),
):
    previous = methods(ast.parse(git('show', BASE + ':' + path).decode()))
    current = methods(ast.parse((ROOT / path).read_text(encoding='utf-8')))
    assert set(current) - set(previous) == additional, (path, set(current) - set(previous))
    assert not (set(previous) - set(current)), path
    assert all(current[key] == value for key, value in previous.items()), path
    preserved[path] = {'all_old_methods_helpers_ast_equal': True, 'old_test_methods': sum(key.split('.')[-1].startswith('test_') for key in previous), 'added': sorted(additional)}
path = 'contracts/database/migrate.py'
previous = methods(ast.parse(git('show', BASE + ':' + path).decode()))
current = methods(ast.parse((ROOT / path).read_text(encoding='utf-8')))
assert set(previous) == set(current)
assert {key for key in previous if previous[key] != current[key]} == {'applied'}
path = 'tests/e2e/go_tls_messaging.py'
old = git('show', BASE + ':' + path).decode()
new = (ROOT / path).read_text(encoding='utf-8')
oldline = "require(sql('SELECT version FROM schema_migrations ORDER BY version') == '0001_initial\\n0002_group_operations', 'canonical migration missing')"
newline = "require(json.loads(sql('SELECT json_agg(version ORDER BY version) FROM schema_migrations')) == ['0001_initial', '0002_group_operations'], 'canonical migration missing')"
assert old.count(oldline) == new.count(newline) == 1
assert old.replace(oldline, newline) == new
result = {'result': 'PASS', 'base': BASE, 'tracked_before': 19041, 'non_allowed_tracked_physical_files_verified': protected, 'non_allowed_bytes_unchanged': True, 'changed_paths': changed, 'untracked_evidence_only': untracked, 'old_test_preservation': preserved, 'runner_functions_changed_only': ['applied'], 'e2e_changes_only': 'one existing ledger query/assertion', 'public_sql_frozen_go_clients_ci_old_evidence_preserved': True}
(OUT / 'scope-proof.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8', newline='\n')
print(json.dumps(result, ensure_ascii=False))
