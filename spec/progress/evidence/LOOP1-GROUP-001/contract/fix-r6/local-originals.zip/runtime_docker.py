from pathlib import Path
import json
import os
import re
import secrets
import subprocess
import sys
import tempfile
import time

ROOT = Path('H:/.codex/worktrees/group/IM-platform')
OUT = Path(__file__).resolve().parent
if len(sys.argv) > 1:
    OUT = OUT / ('runtime-' + sys.argv[1])
    OUT.mkdir(exist_ok=False)
PWSH = Path('C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe')
environment = os.environ.copy()
environment['PATH'] = str(Path(sys.executable).parent) + os.pathsep + environment['PATH']
environment['PYTHONUTF8'] = '1'
environment['PYTHONDONTWRITEBYTECODE'] = '1'
environment.pop('IM_POSTGRES_PASSWORD', None)
fixture = tempfile.TemporaryDirectory(prefix='r6-smoke-config-')
configuration = Path(fixture.name)
(configuration / 'config.json').write_bytes((ROOT / 'backend/go/config.example.json').read_bytes())
(configuration / 'pg_password').write_text('local-development-only', encoding='utf-8')
(configuration / 'jwt_key').write_text(secrets.token_urlsafe(48), encoding='utf-8')
environment['IM_GO_CONFIG_DIR'] = str(configuration)

def docker(*args):
    result = subprocess.run(['docker', *args], cwd=ROOT, env=environment, capture_output=True)
    if result.returncode:
        raise RuntimeError(f'Docker observer exit {result.returncode}: {result.stderr.decode(errors="replace")}')
    return result.stdout.decode().splitlines()

def containers():
    rows = docker('ps', '-a', '--no-trunc', '--format', '{{.ID}}|{{.Names}}|{{.State}}|{{.Label "com.docker.compose.project"}}')
    return sorted([dict(zip(('id', 'name', 'state', 'project'), row.split('|'))) for row in rows], key=lambda row: row['id'])

def volumes():
    rows = docker('volume', 'ls', '--format', '{{.Name}}|{{.Label "com.docker.compose.project"}}')
    return sorted([dict(zip(('name', 'project'), row.split('|'))) for row in rows], key=lambda row: row['name'])

before = {'containers': containers(), 'volumes': volumes()}
results = []
children = []
try:
    for label, argv, profile in (
        ('go-smoke', [str(PWSH), '-NoProfile', '-File', 'tests/infrastructure/smoke.ps1', '-Profile', 'go'], 'go'),
        ('java-smoke', [str(PWSH), '-NoProfile', '-File', 'tests/infrastructure/smoke.ps1', '-Profile', 'java'], 'java'),
        ('go-e2e', [sys.executable, '-X', 'utf8', '-B', 'tests/e2e/go_tls_messaging.py'], 'go'),
    ):
        started = time.monotonic()
        child = subprocess.Popen(argv, cwd=ROOT, env=environment, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        children.append((label, child.pid, profile))
        stdout, stderr = child.communicate(timeout=600)
        (OUT / (label + '.stdout')).write_bytes(stdout)
        (OUT / (label + '.stderr')).write_bytes(stderr)
        entry = {'label': label, 'argv': argv, 'pid': child.pid, 'exit': child.returncode, 'elapsed_seconds': time.monotonic()-started, 'stdout': label+'.stdout', 'stderr': label+'.stderr'}
        results.append(entry)
        print(json.dumps(entry), flush=True)
        if child.returncode:
            raise RuntimeError(f'{label} failed with exit {child.returncode}; raw output preserved')
finally:
    remaining_containers = containers()
    remaining_volumes = volumes()
    owned_projects = set()
    for label, pid, profile in children:
        if label.endswith('smoke'):
            owned_projects.add(f'im-infra-smoke-{profile}-{pid}')
        else:
            pattern = re.compile(r'im-s1-e2e-' + str(pid) + r'-[0-9a-f]{8}')
            owned_projects.update(row['project'] for row in remaining_containers + remaining_volumes if pattern.fullmatch(row['project']))
    before_projects = {row['project'] for row in before['containers'] + before['volumes']}
    assert not (owned_projects & before_projects), 'owned project collides with preexisting resource'
    emergency = []
    for project in sorted(owned_projects):
        if any(row['project'] == project for row in remaining_containers + remaining_volumes):
            profile = 'java' if project.startswith('im-infra-smoke-java-') else 'go'
            docker('compose', '-f', str(ROOT/'deploy/compose.yaml'), '-p', project, '--profile', profile, 'down', '--volumes', '--remove-orphans')
            emergency.append(project)
    after = {'containers': containers(), 'volumes': volumes()}
    assert before == after, {'before': before, 'after': after}
    receipt = {'commands': results, 'before': before, 'after': after, 'preexisting_id_name_state_preserved': before == after, 'owned_projects': sorted(owned_projects), 'owned_containers_volumes_remaining': [], 'emergency_cleanup': emergency, 'global_docker_configuration_changed': False, 'result': 'PASS' if len(results) == 3 and all(row['exit'] == 0 for row in results) else 'FAIL'}
    (OUT / 'docker-runtime.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2)+'\n', encoding='utf-8', newline='\n')
    print(json.dumps(receipt), flush=True)
    fixture.cleanup()
