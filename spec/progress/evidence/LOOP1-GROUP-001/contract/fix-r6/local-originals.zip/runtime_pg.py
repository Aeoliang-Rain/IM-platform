from pathlib import Path
import importlib.util
import json
import os
import re
import subprocess
import sys
import time
import unittest

ROOT = Path('H:/.codex/worktrees/group/IM-platform')
OUT = Path(__file__).resolve().parent
BASE = Path('H:/IM-platform/.git/worktrees/IM-platform4/group-pg16-20261018')
environment = os.environ.copy()
for key in ('PGPASSWORD', 'PGSERVICE', 'PGSERVICEFILE', 'PGOPTIONS', 'DATABASE_URL'):
    environment.pop(key, None)
environment.update(PGHOST='127.0.0.1', PGPORT='63830', PGUSER='group_contract_fixture', PGDATABASE='group_contract_20261018', PGPASSFILE=str(BASE / 'libpq-v2.private'), PGSSLMODE='disable', DB_TEST_ENABLE='1')
environment['PATH'] = str(BASE / 'pgsql/bin') + os.pathsep + str(Path(sys.executable).parent) + os.pathsep + environment['PATH']

def query(sql):
    result = subprocess.run([str(BASE / 'pgsql/bin/psql.exe'), '-X', '-v', 'ON_ERROR_STOP=1', '-q', '-A', '-t'], input=sql, text=True, capture_output=True, env=environment)
    if result.returncode:
        raise RuntimeError(f'owned PostgreSQL query exit {result.returncode}: {result.stderr}')
    return result.stdout.strip()

identity = json.loads(query("SELECT json_build_object('version',current_setting('server_version'),'data_directory',current_setting('data_directory'),'port',current_setting('port'),'user',current_user,'database',current_database());"))
assert identity['version'] == '16.15', identity
assert identity['data_directory'].replace('\\', '/').lower() == str(BASE / 'data-v2').replace('\\', '/').lower(), identity
assert identity['port'] == '63830' and identity['user'] == 'group_contract_fixture' and identity['database'] == 'group_contract_20261018', identity
inventory_sql = "SELECT COALESCE(json_agg(nspname ORDER BY nspname),'[]'::json) FROM pg_namespace WHERE nspname !~ '^pg_' AND nspname <> 'information_schema';"
before = json.loads(query(inventory_sql))
created = []
os.environ.update(environment)
for key in ('PGPASSWORD', 'PGSERVICE', 'PGSERVICEFILE', 'PGOPTIONS', 'DATABASE_URL'):
    os.environ.pop(key, None)
spec = importlib.util.spec_from_file_location('r6_database_suite', ROOT / 'tests/database/test_migrations.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
original_group = module.GroupMigrationPostgreSQLTests.psql
original_old = module.PostgreSQLMigrationTests.psql.__func__

def observed_group(self, sql, *args, **kwargs):
    value = original_group(self, sql, *args, **kwargs)
    match = re.match(r'CREATE SCHEMA (group_db_test_[0-9a-f]{32});', sql)
    if match:
        created.append(match.group(1))
    return value

def observed_old(cls, sql, *args, **kwargs):
    value = original_old(cls, sql, *args, **kwargs)
    match = re.match(r'CREATE SCHEMA (db_test_[0-9a-f]{32});', sql)
    if match:
        created.append(match.group(1))
    return value

module.GroupMigrationPostgreSQLTests.psql = observed_group
module.PostgreSQLMigrationTests.psql = classmethod(observed_old)
suite = (unittest.TestSuite([module.GroupMigrationPostgreSQLTests('test_single_physical_ledger_record_cannot_alias_canonical_rows')])
         if sys.argv[1].startswith('red') else unittest.defaultTestLoader.loadTestsFromModule(module))
started = time.monotonic()
emergency = []
try:
    result = unittest.TextTestRunner(verbosity=2).run(suite)
finally:
    for schema in created:
        assert re.fullmatch(r'(group_db_test_|db_test_)[0-9a-f]{32}', schema), schema
        if query(f"SELECT to_regnamespace('{schema}') IS NOT NULL;") == 't':
            query('DROP SCHEMA ' + schema + ' CASCADE;')
            emergency.append(schema)
    after = json.loads(query(inventory_sql))
    assert before == after, {'before': before, 'after': after}
receipt = {'mode': sys.argv[1], 'identity': identity, 'credentials': 'libpq file path only; contents never read/printed/copied', 'tests_run': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors), 'skipped': len(result.skipped), 'elapsed_seconds': time.monotonic()-started, 'result': 'PASS' if result.wasSuccessful() else 'FAIL', 'owned_schema_allocations': created, 'before_inventory': before, 'after_inventory': after, 'inventories_equal': True, 'emergency_cleanup': emergency, 'server_left_running': True}
(OUT / ('pg-' + sys.argv[1] + '.json')).write_text(json.dumps(receipt, ensure_ascii=False, indent=2)+'\n', encoding='utf-8', newline='\n')
print(json.dumps(receipt, ensure_ascii=False))
assert not result.skipped, 'PG tests were unexecuted, not acceptance'
raise SystemExit(0 if result.wasSuccessful() else 1)
