from pathlib import Path
p=Path('H:/.codex/worktrees/st/IM-platform/spec/progress/current.md')
s=p.read_text(encoding='utf-8')
lines=s.splitlines()
for i,line in enumerate(lines):
    if line.startswith('- Command:'):
        lines[i]='- Command: `python -Xutf8 -B ci/check_architecture.py --scope all --json`'
    if line.startswith('  - Evidence:'):
        lines[i]='  - Evidence: `spec/progress/evidence/LOOP1-CLIENT-STATE-001/acceptance-20261011/acceptance.md`'
p.write_bytes(('\r\n'.join(lines)+'\r\n').encode('utf-8'))
print('Current verification Command/Evidence now use the exact prescribed single-value line format.')
