from pathlib import Path
ROOT=Path('H:/.codex/worktrees/st/IM-platform')
PREFIX='spec/progress/evidence/LOOP1-CLIENT-STATE-001/acceptance-20261011/'
p=ROOT/'spec/progress/current.md'
content=p.read_text(encoding='utf-8')
old='- Administrative baseline architecture all/frozen/planning/Recovery Development PASS. Initial unsupported Recorder role and Windows PowerShell tool/stderr failures are preserved; bundled Python UTF8/pwsh corrected execution PASS. Required after-edit checks and clean committed Recovery Acceptance are sealed with actual administrative SHA externally.'
new='''- Command: `python -Xutf8 -B ci/check_architecture.py --scope all --json`; `python -Xutf8 -B tools/verify_frozen_architecture.py`; `python -Xutf8 -B ci/check_s2_planning.py`; `pwsh -NoProfile -File tools/verify-loop1-ctrl-002.ps1 -Mode Development` (bundled Python PATH / PYTHONUTF8=1).
  - Result: baseline PASS; after-edit frozen/planning/architecture PASS. Recovery Development and clean committed Acceptance actual results are indexed with the administrative local and external sealed candidate receipts; local output does not establish independent acceptance.
  - Evidence: `spec/progress/evidence/LOOP1-CLIENT-STATE-001/acceptance-20261011/acceptance.md`; administrative original command/event output is sealed alongside the actual administrative SHA externally.'''
assert old in content
content=content.replace(old,new)
content=content.replace('Historical FAIL/527PNG/pause/Recorder preserved.', 'Historical FAIL/527PNG/pause/Recorder preserved. Administrative newline-aware Task transition and missing Command/Result/Evidence metadata initially failed local checks, then were corrected without changing checkers/tests; original failures are preserved.')
p.write_bytes(content.replace('\n','\r\n').encode('utf-8'))
task=ROOT/'spec/tasks/done/LOOP1-CLIENT-STATE-001.md'
task.write_bytes(task.read_text(encoding='utf-8').replace('\n','\r\n').encode('utf-8'))
evidence=ROOT/PREFIX/'acceptance.md'
text=evidence.read_text(encoding='utf-8')
text+='\nAdministrative after-edit originals also preserve the initial newline-aware Task metadata mismatch and the subsequent missing current.md Command/Result/Evidence failure; both are bounded administrative authoring repairs, without checker/test/product changes. Final actual local results are administrative-local-verification.json and externally sealed clean committed Acceptance.\n'
evidence.write_text(text,encoding='utf-8',newline='\n')
print('Recovery Verification fields repaired; Task historical newline representation preserved.')
