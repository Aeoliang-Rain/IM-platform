import json, subprocess, pathlib
base=pathlib.Path('C:/Users/21441/.codex/visualizations/2026/10/10/01a124ec-bca5-7c72-a720-88c39f75ff47/state-close')
py='C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
args=[py,'-Xutf8','-B','tools/research/recorder.py']
common=['--run-id','R-STATE-CLOSE-20261011','--research-root',str(base/'research')]
warning={'administrative_role':'administrative_closure','recorded_role':'implementation','prior_start_failure':'invalid role, capture_mode, or experiment_group; exit 1','pre_recorder_trace_complete':False,'startup_read_commands_before_recorder':'unrecorded original tool output remains conversation evidence','prompt_limitation':'registered source=delegation is assignment summary; full Human prompt unavailable'}
r=subprocess.run(args+['record-event']+common+['--event-type','instrumentation_warning','--data-json',json.dumps(warning)],capture_output=True)
(base/'warning-record.out').write_bytes(r.stdout+r.stderr)
print('warning event exit',r.returncode)
commands=[[py,'-Xutf8','-B','tools/verify_frozen_architecture.py'],[py,'-Xutf8','-B','ci/check_s2_planning.py'],['powershell','-NoProfile','-ExecutionPolicy','Bypass','-File','tools/verify-loop1-ctrl-002.ps1','-Mode','Development']]
for i,cmd in enumerate(commands):
 r=subprocess.run(args+['run-command']+common+['--']+cmd,capture_output=True)
 (base/f'baseline-{i}.out').write_bytes(r.stdout+r.stderr)
 print(json.dumps({'argv':cmd,'exit':r.returncode,'bytes':len(r.stdout)+len(r.stderr)}))