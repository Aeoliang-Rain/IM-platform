from pathlib import Path
import hashlib, json, zipfile, subprocess

ROOT = Path('H:/.codex/worktrees/st/IM-platform')
PRIVATE = Path('C:/Users/21441/.codex/visualizations/2026/10/10/01a124ec-bca5-7c72-a720-88c39f75ff47')
DEST = ROOT / 'spec/progress/evidence/LOOP1-CLIENT-STATE-001/acceptance-20261011'
CANDIDATE = 'a3c768ef97cf689c202e005ba417597e5f98f6a3'
MAIN = 'aab1c5907d5886816b4969013912c9fbd1be492b'
PREFIX = 'spec/progress/evidence/LOOP1-CLIENT-STATE-001/acceptance-20261011/'

def git(*args):
    return subprocess.check_output(['git', '-c', 'core.excludesFile=.git/info/exclude', *args], cwd=ROOT).decode().strip()

assert Path(git('rev-parse', '--show-toplevel')).resolve() == ROOT.resolve()
assert git('rev-parse', 'HEAD') == MAIN
assert git('branch', '--show-current') == 'task/LOOP1-CLIENT-STATE-001'
assert not git('status', '--porcelain=v1')

copies = [
 ('state-review-b/report.md', 'independent-review.md', '65d3ef4365905f296d99417060f6de7ebcffec8eecb7300feb5141c34e0aa7f3'),
 ('state-architect-b/architect-review.md', 'architect-review.md', '2bb10895a069b57682709e1500f7066515308bcfa47f16f073f5932933aee531'),
 ('state-ci-acceptance/candidate-acceptance.md', 'candidate-acceptance.md', 'd96d63012447e535598ea5e1ebf4af520691d48baedd32d18b7b3a652cfc5bf7'),
 ('state-ci-acceptance/main-acceptance.md', 'main-acceptance.md', '956a6a57ca555b31731f8b41283690586eb6d61e4ca476a5628766c20e48039f'),
 ('state-ci-acceptance/product-acceptance.md', 'product-acceptance.md', '78ba71f08cfcfa79e8a9800917b33a3341b061c8b881690013d46ed131932a27'),
 ('state-ci-acceptance/preserved-proof.json', 'preserved-proof.json', '89ec7676da0130aa7e2954e92c4d907799437fb7834f172b4497382f63fd5358'),
 ('state-product-main-sync-aab1/main-sync.json', 'main-sync.json', '8e9ab5aed91ffff0e3417a8ba6c6457571c74475f75785cc88d5c76e7e55edff'),
]
DEST.mkdir(parents=True, exist_ok=False)
bindings = []
for source, name, expected in copies:
    data = (PRIVATE / source).read_bytes()
    actual = hashlib.sha256(data).hexdigest()
    assert actual == expected, (source, actual)
    (DEST / name).write_bytes(data)
    bindings.append({'source_actor_file': source, 'durable_file': name, 'sha256': actual, 'bytes': len(data), 'copy': 'byte-exact'})

sources = []
for path in sorted((PRIVATE / 'state-ci-acceptance').glob('*.json')):
    sources.append((path, 'ci/' + path.name))
sources.append((PRIVATE / 'state-ci-acceptance/candidate-progress.md', 'ci/candidate-progress.md'))
for name in ['state-product-pr-api-original.json', 'state-merge-pr33-result.json']:
    sources.append((PRIVATE / name, 'integration/' + name))
for actor, names in {
 'state-review-b': ['verification.json', 'private-verification.json', 'audit-result.json', 'command-summary.json', 'recorder-finalization.json', 'release.json'],
 'state-architect-b': ['independent-audit.json', 'sealed-audit.json'],
}.items():
    for name in names:
        sources.append((PRIVATE / actor / name, actor + '/' + name))
for path in sorted((PRIVATE / 'state-review-b').glob('*.txt')):
    if path.name != 'prompt.txt':
        sources.append((path, 'state-review-b/' + path.name))
# Preserve pre-closure task bytes without changing inherited historical entries.
task_before = (ROOT / 'spec/tasks/review/LOOP1-CLIENT-STATE-001.md').read_bytes()
archive = DEST / 'audit-originals.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as z:
    for source, member in sources:
        data = source.read_bytes()
        z.writestr(member, data)
        bindings.append({'source_actor_file': str(source.relative_to(PRIVATE)).replace('\\', '/'), 'archive_member': member, 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)})
    z.writestr('history/pre-closure-task.md', task_before)
    bindings.append({'source_actor_file': 'accepted product main task', 'archive_member': 'history/pre-closure-task.md', 'sha256': hashlib.sha256(task_before).hexdigest(), 'bytes': len(task_before)})
with zipfile.ZipFile(archive) as z:
    for item in bindings:
        if 'archive_member' in item:
            assert hashlib.sha256(z.read(item['archive_member'])).hexdigest() == item['sha256']
manifest = {'product_candidate_sha': CANDIDATE, 'integrated_product_main_sha': MAIN, 'archive': 'audit-originals.zip', 'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'files': bindings, 'unknown_work_disclosure': 'No before/after unknown path lists or file contents included. Public synchronization receipt and independent preservation proof expose counts/results/hashes only.', 'administrative_acceptance': 'PENDING fresh independent Review/exact-head hosted CI/protected integration/actual-main/safe synchronization; actual administrative SHA belongs to external sealed receipt.'}
(DEST / 'original-bindings.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

acceptance = '''# STATE 产品接受与行政闭合候选

产品候选 `a3c768ef97cf689c202e005ba417597e5f98f6a3` 已经 fresh independent Reviewer B、Architect B 和精确候选 hosted CI 接受，经普通受保护 [PR33](https://github.com/nilesthump/IM-platform/pull/33) 合入实际 main `aab1c5907d5886816b4969013912c9fbd1be492b`。实际 main 自身 CI 与 H:/IM-platform 安全同步已由独立 auditor 核对，最终 [product-acceptance.md](product-acceptance.md) 判定 PASS。S1 PASS / S2 OPEN；UI-REF、I18N 与 S2 Stage Gate 未启动。

[独立 Review](independent-review.md)、[Architect](architect-review.md)、[候选 hosted](candidate-acceptance.md)、[实际 main hosted](main-acceptance.md)、[安全同步](main-sync.json)、[独立保存证明](preserved-proof.json) 均按原始 SHA256 字节复制。[original-bindings.json](original-bindings.json) 映射每份原件和 [audit-originals.zip](audit-originals.zip) 的成员哈希。档案包含 actual run/jobs/steps、每个成功作业原始 log、真实 classifier、PR/protection/tree identity API、审查本地输出与释放/Recorder 结果；早期 running/pending 原件保留时间语义。before/after 的完整未知工作路径与内容保持私有。

候选 push38114933747 实际14作业 SUCCESS；PR38115051079 实际10 selected SUCCESS / 4 classifier-false 正常 inactive。PR synthetic checkout b641 与 candidate a3c 的身份区别及同树证据原样保留。实际 main push38115677911 的10 selected 作业都 checkout aab1 并 SUCCESS，4未选择作业正常 inactive；非缺失、失败、取消或异常 skip。CI aggregate gate PASS 不等于 S2 Stage Gate。真实 STATE A/B、排序、恢复、好友和 OS 表面由独立 B 审查接受，hosted fixture 不替代这些真实行为证据。

Root 安全 two-tree 同步实际 exit0；独立 auditor 实时核对3451已变文件 Git blob和1删除、781未知文件完整 bytes/status/cached diff/index flags/原 branch，零 overlap、零 mismatch。主仓库仍保有 `recovery/s1-handoff-20261001`，已同步 product main aab1。所有历史 FAIL、527 原始 PNG、Review/Architect A、暂停/恢复及旧 Recorder 不修改；Machine pre-import snapshot 不可用、历史 GUI/tool 数量差异和 Human 删除命令 PID/exit 不可用的局限仍完整保留。

本行政候选仅封存已接受产品链、将 STATE 唯一队列记为 done 并修复当前恢复记录；产品 Completion Metadata 绑定已接受 a3c/aab1/syncPASS。行政候选自身仍待全新 independent Review、自己的 exact-head hosted CI、protected integration、actual-main 核验和安全同步，不能使用产品审查自我接受。行政实际 SHA/clean/独立审计/最终同步由 Coordinator 外部 sealed receipt 与对应 PR 绑定，不预填未来 SHA。当前仍停于 STATE 收口，不激活下一任务。

行政本地检查与 Recorder 输出将在提交前/干净提交后分别封存；它们仅为本地证据。Recorder prospective_resume 的启动读取/直接工具/私有 authoring 缺口、摘要 delegation prompt、首次不支持角色启动失败，以及两次 Windows PowerShell baseline FAIL 均保留；随后 bundled pwsh/Python UTF8 baseline PASS。Recorder PASS 不提供产品或阶段接受。
'''
(DEST / 'acceptance.md').write_text(acceptance, encoding='utf-8')

task = task_before.decode('utf-8')
task = task.replace('status: review\n', 'status: done\n', 1).replace('owner: /root/state_fix_b\n', 'owner: /root/state_close (administrative closure; product independently accepted)\n', 1)
header = '''# Current Resume State (independently accepted product, administrative closure candidate 2026-10-11)

STATE product candidate a3c768ef97cf689c202e005ba417597e5f98f6a3 is independently accepted by fresh Reviewer B/Architect B and exact hosted candidate/PR/main CI, normal protected PR33 integration to actual main aab1c5907d5886816b4969013912c9fbd1be492b, and safe H:/IM-platform synchronization independently audited for all task blobs and781unknown bytes/status/index/branch. Product Task PASS; S1 PASS/S2 OPEN. Durable original reports, hosted API/logs, receipt hashes and preservation proof: spec/progress/evidence/LOOP1-CLIENT-STATE-001/acceptance-20261011/acceptance.md.

This sole-writer administrative candidate changes only Task/evidence/current/checkpoint. Its own fresh independent Review, exact-head hosted CI, protected integration, actual-main verification and safe synchronization remain PENDING; actual administrative SHA is externally sealed after commit. No self-acceptance or automatic UI-REF/I18N/S2 Gate activation. All prior local/pending/backlog statements below are historical snapshots, not current resume instructions. Original FAIL/PNG/Recorder and disclosed provenance limits remain immutable.

# Historical Fix B local verification (2026-10-11)
'''
task = task.replace('# Current Resume State (Fix B local verification 2026-10-11)\n', header, 1)
task = task.replace('当前未执行产品验收；local/Recorder PASS不是Task/Stage PASS。', '当前产品独立接受/受保护集成/actual-main hosted和主仓库安全同步PASS，见acceptance-20261011/acceptance.md；行政候选自身接受仍待新独立链。local/Recorder PASS不是Task/Stage PASS。', 1)
task = task.replace('acceptance_result: PENDING\naccepted_candidate_sha: unavailable\nintegrated_main_sha: unavailable\nmain_sync_result: PENDING\nindependent_review_evidence: unavailable\nhosted_acceptance_evidence: unavailable\nmain_sync_evidence: unavailable', f'acceptance_result: PASS\naccepted_candidate_sha: {CANDIDATE}\nintegrated_main_sha: {MAIN}\nmain_sync_result: PASS\nindependent_review_evidence: {PREFIX}independent-review.md\nhosted_acceptance_evidence: {PREFIX}product-acceptance.md\nmain_sync_evidence: {PREFIX}main-sync.json', 1)
task = task.replace('# Handoff\n\n仅backlog', f'''# Handoff

Product candidate {CANDIDATE} / protectedPR33 actualmain {MAIN} is independently accepted and synchronized; full original evidence: {PREFIX}acceptance.md. Task queue done records this completed product chain. Administrative closure is sole-owned by /root/state_close in assigned root H:/.codex/worktrees/st/IM-platform, task branch task/LOOP1-CLIENT-STATE-001; its actual commit/clean state is external sealed evidence and still requires fresh independent Review/exact-head CI/protected integration/actual-main/safe sync before overall closure. Main781unknown preserved. S1 PASS/S2 OPEN; no architecture/contract/schema change. Stable product recovery point aab1; historical failures and Recorder remain untouched.

Historical backlog handoff (superseded by product activation and acceptance; preserved):

仅backlog''', 1)
task = task.replace('# Next Action\n\n保持backlog。', '''# Next Action

Coordinator obtains fresh independent administrative Review, exact-head hosted CI, normal protected integration, actual-main audit and safe main synchronization for the externally sealed administrative commit. Then STOP at completed STATE; UI-REF/I18N remain backlog, S2 Gate OPEN and not evaluated. Product acceptance does not accept future administrative bytes.

Historical backlog instruction (superseded; preserved):

保持backlog。''', 1)
old = ROOT / 'spec/tasks/review/LOOP1-CLIENT-STATE-001.md'
new = ROOT / 'spec/tasks/done/LOOP1-CLIENT-STATE-001.md'
assert not new.exists()
new.write_text(task, encoding='utf-8')
old.unlink()

checkpoint = 'spec/progress/checkpoints/2026-10-11-loop1-client-state-001-product-accepted.md'
(ROOT / checkpoint).write_text(f'''# STATE independently accepted product recovery point

Date: 2026-10-11. Task: LOOP1-CLIENT-STATE-001. S1 PASS / S2 OPEN.

Accepted product candidate: `{CANDIDATE}`; branch `task/LOOP1-CLIENT-STATE-001`; full product baseline `3eaf256790e9e6b7190326714be3f011edb24401`. Protected PR33 actual main: `{MAIN}`, parents3eaf/a3c and same product tree. Candidate push38114933747 / PR38115051079 and actual-main38115677911 independently accepted; safe H:/IM-platform sync and live independent preservation audit PASS.

Evidence: `{PREFIX}acceptance.md`; original Review/Architect/hosted/product/sync reports with exact hashes and raw logs/API archive. Product source/native build input547514 bindings and actual repaired state/friends/OS evidence remain inherited and independently accepted. Public contracts/schema/canonical efbe04c7/v1.1 unchanged; historical PDF546915 and original FAIL/527 PNG/Recorder remain immutable. Unknown781files/status/index/branch preserved; private unknown lists are not published. Machine pre-import snapshot unavailable, historical GUI/tool-count discrepancy and Human deletion PID/exit unavailable remain disclosed.

STATE done records the completed product chain. This administrative documentation candidate has not accepted itself: new independent Review/exact-head hosted/protected integration/actual-main/safe sync required, with actual administrative SHA/clean state in Coordinator external sealed receipt. UI-REF/I18N backlog; no S2 Stage Gate evaluation. Next exact action is that administrative acceptance chain, then stop at STATE closure.
''', encoding='utf-8')
(ROOT / 'spec/progress/current.md').write_text(f'''# Current Execution State

Current Loop: Loop 1
Current Stage: S2
Current Gate: S2
Gate Status: OPEN
Current Batch: LOOP1-CLIENT-STATE-001
Batch Status: PRODUCT_ACCEPTED_ADMINISTRATIVE_CLOSURE_PENDING
Current Task: LOOP1-CLIENT-STATE-001
Current Task State: done
Execution Status: ADMINISTRATIVE_CLOSURE_REVIEW_PENDING

## Immediately Relevant Completed Work

STATE product candidate a3c768e independently accepted by fresh Reviewer B/Architect B, candidate/PR hosted CI, protectedPR33 actualmain aab1c5907d5886816b4969013912c9fbd1be492b hosted CI, safe H:/IM-platform synchronization and independent live preservation audit. Actual A/B/seq/restart/history/friends/OS evidence and exact owned trust/resource rollback accepted; historical FAILs remain preserved. S1 PASS / S2 OPEN.

## Current Blockers

No product blocker. This administrative closure candidate still needs new independent Review, its exact-head hosted CI, protected integration, actual-main verification and safe synchronization. Product acceptance does not accept these new documentation bytes.

## Verification

- Product independent chain: `{PREFIX}product-acceptance.md`; exact candidate push38114933747 (14SUCCESS), PR38115051079 and actualmain38115677911 (10selectedSUCCESS/4normalinactive).
- Administrative baseline architecture all/frozen/planning/Recovery Development PASS. Initial unsupported Recorder role and Windows PowerShell tool/stderr failures are preserved; bundled Python UTF8/pwsh corrected execution PASS. Required after-edit checks and clean committed Recovery Acceptance are sealed with actual administrative SHA externally.

## Changed Files or Migrations

Administrative Task/evidence/current/checkpoint only; product source, contracts, schema and frozen authority unchanged. Product behavior changes and command/PNG matrices remain indexed in inherited verification-matrix.md and fix-b/fix-summary.md.

## Known Failures, Risks, and Assumptions

Historical FAIL/527PNG/pause/Recorder preserved. Machine pre-import snapshot unavailable, old GUI76/tool75 discrepancy unresolved and Human deletion command PID/exit unavailable remain disclosed in independent reports. Recorder startup/direct authoring gaps and condensed delegated prompt are explicit; Recorder PASS is not acceptance. No current owned trust/runtime residue per accepted bounded cleanup.

## Next Exact Action

Fresh independent administrative Review of the externally sealed actual commit, then exact-head hosted CI, normal protected integration, actual-main audit and safe main synchronization. Stop after STATE closure; UI-REF/I18N backlog and S2 Gate OPEN, no activation or Gate evaluation.

## Last Known Good Commit

`{MAIN}` is the independently accepted, integrated and safely synchronized product main; accepted candidate `{CANDIDATE}`. Administrative commit SHA is sealed externally after creation, not invented here.

## Latest Checkpoint

`{checkpoint}`

## Uncommitted Changes / Ownership

Assigned root H:/.codex/worktrees/st/IM-platform; branch task/LOOP1-CLIENT-STATE-001. /root/state_close owns this administrative candidate exclusively until commit/seal/release. Root and others readonly. Main781unknown work stays untouched, original recovery/s1-handoff-20261001 branch/status/index/complete bytes independently preserved. Exact clean administrative committed ownership/result belongs to the external sealed receipt.

## Architecture Conflicts / ACP / ADR

None. Canonical efbe04c7/v1.1 and approved HTTP/TLS scope unchanged. S1 PASS/S2 OPEN.
''', encoding='utf-8')
print(json.dumps({'result': 'prepared', 'original_files': len(bindings), 'archive_sha256': manifest['archive_sha256'], 'product_candidate': CANDIDATE, 'product_main': MAIN}))
