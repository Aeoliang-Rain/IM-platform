from pathlib import Path
import json, hashlib, zipfile, subprocess
P=Path('C:/Users/21441/.codex/visualizations/2026/10/10/01a124ec-bca5-7c72-a720-88c39f75ff47/state-close')
R=Path('H:/.codex/worktrees/st/IM-platform')
D=R/'spec/progress/evidence/LOOP1-CLIENT-STATE-001/acceptance-20261011'
results=json.loads((P/'after-edit-checks.json').read_text(encoding='utf-8'))
assert results['result']=='PASS'
files=[]
for pattern in ['*.stdout','*.stderr','*.out','*checks.json','warning-record.out','*.py','delegated-prompt.txt']:
    for p in P.glob(pattern):
        if p not in files: files.append(p)
for p in (P/'research').rglob('*'):
    if p.is_file(): files.append(p)
manifest=[]
archive=D/'administrative-local-originals.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(files):
        member=p.relative_to(P).as_posix()
        data=p.read_bytes()
        z.writestr(member,data)
        manifest.append({'member':member,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
with zipfile.ZipFile(archive) as z:
    for entry in manifest: assert hashlib.sha256(z.read(entry['member'])).hexdigest()==entry['sha256']
results.update({'administrative_candidate_sha':'external sealed receipt after commit','archive':'administrative-local-originals.zip','archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_members':manifest,'snapshot':'pre-commit; archived own Recorder remains running/partial here, final finished/validated Recorder and clean committed Acceptance are separately externally sealed','preserved_failures':['unsupported administrative_closure Recorder role, then supported implementation role','WindowsPowerShell Get-FileHash missing, then native stderr Stop; corrected bundled pwsh/Python UTF8','initial sandbox ORIG_HEAD.lock denied; authorized worktree ff escalation succeeded','newline-aware task queue/status/metadata replacement failure','missing current Command/Result/Evidence fields and subsequent single-value line-format failure'],'independent_acceptance':'PENDING for this administrative candidate; local PASS never self-acceptance'})
(D/'administrative-local-verification.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({'local_result':'PASS','archive_members':len(manifest),'archive_sha256':results['archive_sha256']}))
