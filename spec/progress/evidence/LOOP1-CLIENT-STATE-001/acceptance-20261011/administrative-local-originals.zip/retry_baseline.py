import subprocess,pathlib,os,json
base=pathlib.Path('C:/Users/21441/.codex/visualizations/2026/10/10/01a124ec-bca5-7c72-a720-88c39f75ff47/state-close')
py='C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
env=os.environ.copy(); env['PYTHONUTF8']='1'; env['PATH']=str(pathlib.Path(py).parent)+os.pathsep+env['PATH']
cmd=['C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe','-NoProfile','-ExecutionPolicy','Bypass','-Command','Import-Module Microsoft.PowerShell.Utility; & ./tools/verify-loop1-ctrl-002.ps1 -Mode Development']
r=subprocess.run([py,'-Xutf8','-B','tools/research/recorder.py','run-command','--run-id','R-STATE-CLOSE-20261011','--research-root',str(base/'research'),'--']+cmd,capture_output=True,env=env)
(base/'baseline-development-pwsh.out').write_bytes(r.stdout+r.stderr)
print(json.dumps({'argv':cmd,'exit':r.returncode,'output':r.stdout.decode('utf-8',errors='replace')[-1500:],'stderr':r.stderr.decode('utf-8',errors='replace')[-1500:]}))