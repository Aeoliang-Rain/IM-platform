from pathlib import Path
import os, subprocess, json, hashlib, time
P = Path('C:/Users/21441/.codex/visualizations/2026/10/10/01a124ec-bca5-7c72-a720-88c39f75ff47/state-close')
PY = 'C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
PW = 'C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'
env = os.environ.copy()
env['PYTHONUTF8'] = '1'
env['PATH'] = str(Path(PY).parent) + os.pathsep + env['PATH']
commands = [
 [PY,'-Xutf8','-B','tools/verify_frozen_architecture.py'],
 [PY,'-Xutf8','-B','ci/check_s2_planning.py'],
 [PY,'-Xutf8','-B','ci/check_architecture.py','--scope','all','--json'],
 [PW,'-NoProfile','-File','tools/verify-loop1-ctrl-002.ps1','-Mode','Development'],
]
results = []
for i, cmd in enumerate(commands):
    started = time.monotonic()
    r = subprocess.run([PY,'-Xutf8','-B','tools/research/recorder.py','run-command','--run-id','R-STATE-CLOSE-20261011','--research-root',str(P/'research'),'--']+cmd,env=env,capture_output=True)
    elapsed = time.monotonic()-started
    name = f'after-edit-{i}'
    (P/(name+'.stdout')).write_bytes(r.stdout)
    (P/(name+'.stderr')).write_bytes(r.stderr)
    row = {'argv': cmd, 'exit': r.returncode, 'elapsed_seconds':elapsed,'stdout':name+'.stdout','stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr':name+'.stderr','stderr_sha256':hashlib.sha256(r.stderr).hexdigest()}
    results.append(row)
    print(json.dumps({'index':i,'exit':r.returncode,'elapsed_seconds':elapsed,'tail':(r.stdout+r.stderr).decode('utf-8',errors='replace')[-1200:] if r.returncode else 'PASS'}),flush=True)
(P/'after-edit-checks.json').write_text(json.dumps({'result':'PASS' if all(x['exit']==0 for x in results) else 'FAIL','commands':results},indent=2)+'\n',encoding='utf-8')
raise SystemExit(0 if all(x['exit']==0 for x in results) else 1)
