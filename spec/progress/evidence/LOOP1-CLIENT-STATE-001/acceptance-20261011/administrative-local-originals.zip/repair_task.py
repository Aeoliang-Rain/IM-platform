from pathlib import Path
import zipfile
ROOT=Path('H:/.codex/worktrees/st/IM-platform')
PRIVATE=Path('C:/Users/21441/.codex/visualizations/2026/10/10/01a124ec-bca5-7c72-a720-88c39f75ff47')
PREFIX='spec/progress/evidence/LOOP1-CLIENT-STATE-001/acceptance-20261011/'
CANDIDATE='a3c768ef97cf689c202e005ba417597e5f98f6a3'
MAIN='aab1c5907d5886816b4969013912c9fbd1be492b'
with zipfile.ZipFile(ROOT/PREFIX/'audit-originals.zip') as z:
    task_before=z.read('history/pre-closure-task.md')
code=(PRIVATE/'state-close/prepare_closure.py').read_text(encoding='utf-8')
portion=code[code.index("task = task_before.decode('utf-8')"):code.index("old = ROOT /")]
portion=portion.replace("task_before.decode('utf-8')", "task_before.decode('utf-8').replace('\\r\\n', '\\n')")
exec(portion)
seal=str(PRIVATE/'state-administrative-final-acceptance.json').replace('\\','/')
discovery=f'''\n\nAdministrative final recovery discovery: fixed external seal `{seal}` is created only by Coordinator after fresh independent administrative Review, exact administrative candidate hosted CI, protected integration, actual-main hosted/audit and safe main synchronization all PASS. Before it exists and those actual SHA/evidence/results are verified, this is an administrative-pending snapshot. Once its actual independent chain is verified, this STATE scope is closed and the next exact action is STOP; do not repeat product verification or automatically select UI-REF/I18N/Gate. The seal binds actual administrative candidate/main SHA without self-referential commits. Missing, incomplete or mismatched seal cannot establish PASS.\n'''
(ROOT/'spec/tasks/done/LOOP1-CLIENT-STATE-001.md').write_text(task+discovery,encoding='utf-8',newline='\n')
for rel in [PREFIX+'acceptance.md','spec/progress/current.md','spec/progress/checkpoints/2026-10-11-loop1-client-state-001-product-accepted.md']:
    p=ROOT/rel
    content=p.read_text(encoding='utf-8')
    p.write_text(content+discovery,encoding='utf-8',newline='\n')
print('Repaired Task newline-aware replacements; preserved original archive and disclosed fixed final-seal recovery rule.')
