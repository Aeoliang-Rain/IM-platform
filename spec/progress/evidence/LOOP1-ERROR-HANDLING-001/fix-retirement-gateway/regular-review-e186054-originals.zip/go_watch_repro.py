from pathlib import Path
import json,subprocess,os,time
EXT=Path(__file__).parent;ROOT=Path('H:/.codex/worktrees/err/IM-platform')
overlay={'Replace':{str(ROOT/'backend/go/gateway/watch_review_test.go'):str(EXT/'watch_review_test.go')}}
(EXT/'go-overlay.json').write_text(json.dumps(overlay),encoding='utf-8')
env=os.environ.copy();env['GOCACHE']=str(EXT/'go-cache');env['GOTOOLCHAIN']='local'
args=['H:/go/bin/go.exe','test','-overlay='+str(EXT/'go-overlay.json'),'./gateway','-run','TestReviewWatchUnavailableDatabaseEmitsRevoked','-count=1','-v']
print('actual argv',json.dumps(args),flush=True);started=time.time();result=subprocess.run(args,cwd=ROOT/'backend/go',env=env)
(EXT/'go-watch-command.json').write_text(json.dumps({'argv':args,'cwd':str(ROOT/'backend/go'),'exit':result.returncode,'elapsed':time.time()-started,'source_mutation':False,'test_injection':'read-only Go overlay mapping external test into actual current package'}),encoding='utf-8')
raise SystemExit(result.returncode)
