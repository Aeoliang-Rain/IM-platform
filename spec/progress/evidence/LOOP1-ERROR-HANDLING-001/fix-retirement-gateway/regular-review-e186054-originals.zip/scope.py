from pathlib import Path
import json,hashlib,collections,subprocess
ROOT=Path('H:/.codex/worktrees/err/IM-platform'); EXT=Path(__file__).parent
inv=json.loads((ROOT/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001/production-inventory.json').read_text('utf-8'))
nav=json.loads((ROOT/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-refresh-owner/current-navigation.json').read_text('utf-8'))
rows=[]
for idx,item in enumerate(inv['files'],1):
 raw=(ROOT/item['path']).read_bytes(); check=hashlib.sha256(raw).hexdigest()==item['sha256']
 try:lines=len(raw.decode('utf-8-sig').splitlines())
 except UnicodeError:lines=None
 rows.append({'ordinal':idx,'path':item['path'],'lines':lines,'bytes':len(raw),'kind':item['kind'],'sha256':hashlib.sha256(raw).hexdigest(),'inventory_hash_equal':check,'retained_count':sum(r['path']==item['path'] for r in nav['records'])})
 print(idx,item['path'],lines,len(raw),item['kind'],'retained',rows[-1]['retained_count'],'hash',check)
(EXT/'scope-inputs.json').write_text(json.dumps(rows,indent=2),encoding='utf-8')
print('TOTAL',len(rows),'bytes',sum(r['bytes'] for r in rows),'lines',sum(r['lines'] or 0 for r in rows),'KINDS',collections.Counter(r['kind'] for r in rows))
