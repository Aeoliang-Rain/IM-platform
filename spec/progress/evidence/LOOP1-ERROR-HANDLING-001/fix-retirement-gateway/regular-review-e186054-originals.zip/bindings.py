from pathlib import Path
import json,hashlib,subprocess,zipfile,struct,tomllib,runpy,re,collections
ROOT=Path('H:/.codex/worktrees/err/IM-platform');EXT=Path(__file__).parent;BASE='35bd6f5f1091503f95a0282f730ed04233b0b6ea';HEAD='e186054d964e11755e7bc48ae71f95d1ea125f2f'
def git(*args):return subprocess.check_output(['git','-c','core.excludesFile=NUL',*args],cwd=ROOT)
tracked=git('ls-files','-z').decode().split('\0');tracked=[p for p in tracked if p]
selected=[p for p in tracked if p.startswith(('backend/','clients/','deploy/','plugins/')) and not ('/tests/' in p or '/androidTest/' in p or '/test/' in p or p.endswith('_test.go'))]
selected+=['contracts/database/migrate.py','contracts/database/migrations/0001_initial.up.sql','contracts/database/migrations/0001_initial.down.sql','tools/build_language_packs.py']
rows=json.loads((EXT/'scope-inputs.json').read_text());assert set(selected)=={r['path'] for r in rows}, {'missing':set(selected)-{r['path'] for r in rows},'extra':{r['path'] for r in rows}-set(selected)}
assert git('rev-parse','HEAD').decode().strip()==HEAD
categories=[];base_paths=set(git('ls-tree','-r','--name-only',BASE).decode().splitlines())
for row in rows:
 p=ROOT/row['path'];raw=p.read_bytes();base=git('show',BASE+':'+row['path']) if row['path'] in base_paths else None
 result={'path':row['path'],'sha256':hashlib.sha256(raw).hexdigest(),'base_equal':raw==base}
 if p.name=='.gitkeep':assert raw.strip()==b'';result['category']='empty_placeholder'
 elif row['lines'] is None:
  result['category']='binary_integrity'
  assert raw==base
  if p.suffix=='.png':assert raw.startswith(b'\x89PNG\r\n\x1a\n');result['dimensions']=struct.unpack('>II',raw[16:24])
  elif p.suffix=='.ico':reserved,kind,count=struct.unpack('<HHH',raw[:6]);assert reserved==0 and kind==1 and count>0;assert len(raw)>=6+16*count;result['icon_entries']=count
  elif p.suffix=='.jar':
   with zipfile.ZipFile(p) as z:assert z.testzip() is None;assert any(n.endswith('GradleWrapperMain.class') for n in z.namelist());result['entries']=len(z.namelist())
 elif p.name in ['package-lock.json','Cargo.lock','go.sum']:
  result['category']='lock_integrity';assert raw==base
  if p.name=='package-lock.json':data=json.loads(raw);assert data['lockfileVersion']==3;result['packages']=len(data['packages'])
  elif p.name=='Cargo.lock':data=tomllib.loads(raw.decode());assert data['version'] in [3,4];result['packages']=len(data['package'])
  else:assert all(len(line.split())==3 and line.split()[2].startswith('h1:') for line in raw.decode().splitlines());result['entries']=len(raw.splitlines())
 elif '/i18n/' in row['path'] and p.stem in ['en','zh-CN','ja-JP','zhCN','jaJP']:
  result['category']='literal_language_data';assert raw==base
  if p.suffix=='.ts':text=raw.decode();assert text.startswith('export default ');data=json.loads(text.removeprefix('export default ').strip().removesuffix(';'));assert all(isinstance(k,str) and isinstance(v,str) for k,v in data.items());result['keys']=len(data)
  else:
   text=raw.decode();pairs=re.findall(r'("(?:[^"\\]|\\.)*") to ("(?:[^"\\]|\\.)*")',text);assert len(pairs)>0;tail=re.sub(r'("(?:[^"\\]|\\.)*") to ("(?:[^"\\]|\\.)*")','PAIR',text);assert re.fullmatch(r'package im\.platform\.client\.ui\.i18n\s+val \w+:Map<String,String>\s*=\s*mapOf\(\s*(?:PAIR,?\s*)+\)\s*',tail);result['keys']=len(pairs)
 else:result['category']='semantic_logic_config_document'
 categories.append(result)
counts=collections.Counter(x['category'] for x in categories);assert counts=={'semantic_logic_config_document':148,'empty_placeholder':17,'binary_integrity':6,'lock_integrity':5,'literal_language_data':9},counts
ns=runpy.run_path(str(ROOT/'tools/build_language_packs.py'));ns['sources'](ROOT)
manifest=json.loads((ROOT/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-refresh-owner/protected-inputs.json').read_text())
protected=[]
for item in manifest['files']:
 name=item['path'];raw=(ROOT/name).read_bytes();before=git('show',BASE+':'+name);pre=git('show','27cdd93e30a72527bba9f3b0d611b13ba860e92f:'+name)
 check={'path':name,'sha256':hashlib.sha256(raw).hexdigest(),'manifest_equal':hashlib.sha256(raw).hexdigest()==item['sha256'],'exact_prior27':raw==pre,'whole_base_equal':raw==before}
 if name.endswith('/storage/repository.ts'):
  pattern=rb'  async contiguous\(.*?(?=  async conversationIds\()';assert re.sub(pattern,b'READ_MAPPER_ONLY',raw,flags=re.S)==re.sub(pattern,b'READ_MAPPER_ONLY',before,flags=re.S);check['outside_read_mapper_base_equal']=True
 elif name.endswith('/storage/Repository.kt'):
  pattern=rb'    fun contiguous\(.*?(?=    fun conversationIds\()';assert re.sub(pattern,b'READ_MAPPER_ONLY',raw,flags=re.S)==re.sub(pattern,b'READ_MAPPER_ONLY',before,flags=re.S);check['outside_read_mapper_base_equal']=True
 else:assert raw==before
 assert check['manifest_equal'] and check['exact_prior27'];protected.append(check)
assert len(protected)==65 and sum(x['whole_base_equal'] for x in protected)==63
nav=json.loads((ROOT/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-refresh-owner/current-navigation.json').read_text())['records']
seen=set();navchecks=[]
for record in nav:
 raw=(ROOT/record['path']).read_bytes();line=raw.decode('utf-8-sig').splitlines()[record['line']-1];identity=record['composite_identity'];assert identity not in seen;seen.add(identity);assert line==record['source'];assert hashlib.sha256(raw).hexdigest()==record['source_sha256'];assert line[record['column']-1:].startswith(record['token']);assert all(record[k].strip() for k in ['specific_fault','present_authority','actual_recovery_or_failure']);navchecks.append({'identity':identity,'source_hash_line_column_token_match':True,'executable':record['executable']})
assert len(navchecks)==323 and sum(n['executable'] for n in navchecks)==288
out={'candidate':HEAD,'base':BASE,'scope_185_independently_reconstructed':True,'categories':dict(counts),'files':categories,'protected_65':protected,'navigation_binding_only':navchecks,'note':'Automated byte/coordinate/structure proofs are not semantic acceptance; literal data/lock/binary inputs do not claim manual executable semantics.'}
(EXT/'bindings.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print('PASS independent185 selection/hash/classification and65 protected63wholebase+2mapper-only;323 coordinate/source/token bindings288exec35nonexec. Semantic judgments remain separate.')
