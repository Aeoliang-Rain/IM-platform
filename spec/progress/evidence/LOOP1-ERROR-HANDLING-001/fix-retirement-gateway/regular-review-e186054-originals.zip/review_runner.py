from pathlib import Path
import subprocess, sys, json, hashlib, time, os
ROOT=Path('H:/.codex/worktrees/err/IM-platform')
EXT=Path(__file__).parent
PY=Path('C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe')
os.environ['PATH']=str(PY.parent)+os.pathsep+'H:/node.js'+os.pathsep+os.environ.get('PATH','')
BASE=[str(PY),'-Xutf8','-B',str(ROOT/'tools/research/recorder.py')]
COMMON=['--repo',str(ROOT),'--research-root',str(EXT/'research'),'--run-id','R-REGULAR-E186054']
def event(kind,data):
    return subprocess.run(BASE+['record-event']+COMMON+['--event-type',kind,'--data-json',json.dumps(data,ensure_ascii=False)],cwd=ROOT).returncode
def run(label,args,cwd=None):
    argv=BASE+['run-command']+COMMON+['--']+args
    started=time.time()
    result=subprocess.run(argv,cwd=cwd or ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    output=result.stdout
    (EXT/(label+'.txt')).write_bytes(output)
    with (EXT/'commands.jsonl').open('a',encoding='utf-8') as f:
        f.write(json.dumps({'label':label,'argv':args,'cwd':str(cwd or ROOT),'exit':result.returncode,'elapsed':time.time()-started,'output':label+'.txt','sha256':hashlib.sha256(output).hexdigest()},ensure_ascii=False)+'\n')
    sys.stdout.buffer.write(output)
    return result.returncode
if __name__=='__main__':
    if sys.argv[1]=='event':sys.exit(event(sys.argv[2],json.loads(sys.argv[3])))
    sys.exit(run(sys.argv[1],sys.argv[2:]))
