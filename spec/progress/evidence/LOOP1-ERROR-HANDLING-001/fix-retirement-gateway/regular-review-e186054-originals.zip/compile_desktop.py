from pathlib import Path
import json,subprocess,hashlib
EXT=Path(__file__).parent;ROOT=Path('H:/.codex/worktrees/err/IM-platform');old=EXT.parent/'fix-read-origin'
config=json.loads((old/'tsconfig.json').read_text('utf-8'));config['compilerOptions']['outDir']=str(EXT/'desktop-build');(EXT/'tsconfig.json').write_text(json.dumps(config,indent=2),encoding='utf-8');(EXT/'package.json').write_text('{"type":"module"}',encoding='utf-8')
compiler=old/'node_modules/typescript/bin/tsc';version=json.loads((compiler.parent.parent/'package.json').read_text('utf-8'))['version'];assert version=='5.9.3'
subprocess.run(['H:/node.js/node.exe',str(compiler),'-p',str(EXT/'tsconfig.json')],cwd=ROOT,check=True)
stub=EXT/'desktop-build/node_modules/@tauri-apps/api';stub.mkdir(parents=True,exist_ok=True);(stub/'package.json').write_text('{"type":"module","exports":{"./core":"./core.js"}}',encoding='utf-8');(stub/'core.js').write_text('export const invoke=(...args)=>globalThis.window.__TAURI_INTERNALS__.invoke(...args);',encoding='utf-8');(EXT/'desktop-build/package.json').write_text('{"type":"module"}',encoding='utf-8')
inputs={str(p.relative_to(ROOT)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for folder in ['clients/desktop/src','clients/shared/protocol-sdk/src'] for p in (ROOT/folder).rglob('*') if p.is_file() and p.suffix in ['.ts','.tsx']}
(EXT/'desktop-compile-inputs.json').write_text(json.dumps({'compiler_version':version,'compiler_sha256':hashlib.sha256(compiler.read_bytes()).hexdigest(),'actual_product_inputs':inputs,'limitations':'Native IPC link only; no live native credential/SQLite/WSS acceptance.'},indent=2),encoding='utf-8')
print('PASS independent strict current source Desktop TypeScript compile; only runtime IPC link stub')
