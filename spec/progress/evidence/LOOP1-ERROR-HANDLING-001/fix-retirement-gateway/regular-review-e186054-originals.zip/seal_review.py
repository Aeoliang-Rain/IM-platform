from pathlib import Path
import hashlib, json, subprocess, datetime

EXT=Path(__file__).parent
ROOT=Path('H:/.codex/worktrees/err/IM-platform')
HEAD='e186054d964e11755e7bc48ae71f95d1ea125f2f'
BASE='35bd6f5f1091503f95a0282f730ed04233b0b6ea'
def sha(raw): return hashlib.sha256(raw).hexdigest()
def save(name,obj): (EXT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
bindings=json.loads((EXT/'bindings.json').read_text())
readlog=[json.loads(x) for x in (EXT/'read-log.jsonl').read_text().splitlines() if x]

def responsibility(path):
    if '/core/' in path: return 'Core application and business persistence; session/message/social/Sync authority remains Core-owned'
    if '/gateway/' in path: return 'Gateway connection, binding, forwarding and delivery; no Core business decision ownership'
    if path.endswith('InfraPlaceholder.java'): return 'Java infrastructure placeholder only; no business implementation or imported Go responsibility'
    if '/backend/' in '/'+path or path.startswith('backend/'): return 'Existing backend runtime, shared infrastructure/configuration, or plugin-host infrastructure'
    if '/src-tauri/' in path: return 'Existing Tauri native capability / SQLx atomic SQLite adapter; TypeScript keeps Repository intent'
    if path.endswith('/application/ui/workspace.ts') or path.endswith('/ui/WorkspaceViewModel.kt'): return 'Application owner/generation, authenticated UI projection, mandatory account retirement and operation consumers'
    if path.endswith('/application/ui/auth.ts') or path.endswith('/ui/Auth.kt'): return 'Current native client authentication, credential ownership, request decoding and refresh/logout lifecycle'
    if '/storage/' in path: return 'Local models/Repository/transaction intent and approved contiguous READ mapper; SQLite WRITE policy/drafts excluded'
    if '/send/' in path or path.endswith('/application/send.ts') or path.endswith('/application/accountSend.ts'): return 'Existing Send protocol/application identity, failure state, queue ownership and read-origin boundary'
    if '/sync/' in path: return 'Existing Sync HTTP/wire/application convergence, stream cleanup, cursor and read-origin boundary'
    if '/ui/' in path: return 'Current UI components, callbacks, preference/display rules, localization adapter or build entry'
    if path.startswith('contracts/database/'): return 'Accepted database contract/migration tooling; schema/SQL authority unchanged'
    if path.startswith('deploy/'): return 'Existing deployment/runtime configuration; no changed architecture choice'
    if path.startswith('tools/'): return 'Existing literal language-pack builder, input validation and canonical output preservation'
    return 'Existing project/build/configuration asset or empty placeholder; no new runtime/dependency selection'

coverage=[]
for x in bindings['files']:
    p=x['path']; category=x['category']; rows=[r for r in readlog if r['path']==p]
    linecount=len((ROOT/p).read_bytes().decode('utf-8').splitlines()) if category=='semantic_logic_config_document' else None
    covered=set()
    for r in rows: covered.update(range(r['lines'][0],r['lines'][1]+1))
    fullread=all(i in covered for i in range(1,linecount+1)) if linecount is not None else None
    finding=[]
    if p.endswith('/application/ui/workspace.ts'): finding=['F1-DESKTOP-RETIREMENT-CONSUMERS']
    if p in ('backend/go/gateway/gateway.go','backend/go/gateway/session.go'): finding=['F2-GATEWAY-DB-FAILURE-AS-REVOCATION']
    if category=='semantic_logic_config_document':
        method='Full actual source/config/document read, including imports and neighboring consumers; requirement/minimality/dependency review. Runtime claims separately bounded by commands.'
        result='FINDING' if finding else 'NO_ADDITIONAL_FINDING_IN_SCOPE'
    elif category=='empty_placeholder': method='Actual empty/whitespace placeholder bytes and hash checked'; result='EMPTY_PLACEHOLDER_ONLY'
    elif category=='lock_integrity': method='Parsed lock integrity plus accepted-base exact equality; no manual executable semantics claimed'; result='UNCHANGED_LOCK_INTEGRITY'
    elif category=='binary_integrity': method='PNG/ICO/JAR format structure and hash/accepted-base equality; no manual executable semantics claimed'; result='UNCHANGED_BINARY_INTEGRITY'
    else: method='Pure literal language-data grammar/structure, cross-end value parity and accepted-base equality; no manual executable semantics claimed'; result='UNCHANGED_LITERAL_STRUCTURE'
    excluded_note='SQLite WRITE failures, schema/init/transactions/writes and draft protection remain explicitly excluded. Byte preservation proof is separate from semantic acceptance of those excluded paths.' if ('/storage/' in p or 'Composer' in p or p.endswith('/database.rs')) else None
    coverage.append({**x,'responsibility':responsibility(p),'inspection_method':method,'actual_read_ranges':[r['lines'] for r in rows],'full_source_read_log_coverage':fullread,'result':result,'findings':finding,'excluded_scope_note':excluded_note})
missing=[x['path'] for x in coverage if x['category']=='semantic_logic_config_document' and not x['full_source_read_log_coverage']]
save('whole-production-review.json',{'reviewer':'/root/regular_review_e186054','candidate':HEAD,'base':BASE,'range':BASE+'..'+HEAD,'independent_scope_reconstructed':True,'counts':bindings['categories'],'inputs':185,'not_a_runtime_execution_count':True,'read_log_missing_or_partial':missing,'files':coverage})

nav=json.loads((ROOT/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-refresh-owner/current-navigation.json').read_text())['records']
judgments=[]
for i,r in enumerate(nav,1):
    fault=r['specific_fault'].split(' Trigger source:')[0]
    if not r['executable']:
        verdict='NONEXECUTABLE_TOKEN_ONLY'
        note='Actual source is display text, type/data/config/comment syntax rather than an executable catch/fallback. Kept for navigation completeness; no recovery mechanism inferred.'
    elif i in (86,87):
        verdict='FAIL_INCOMPLETE_CONSUMER_GROUND'
        note='F1: quoted cleanup/finally guarantee is conditional on stop() succeeding. Current real observer failure from stop() bypasses this boundary. Expiry skips Auth.clear entirely; logout stops waiting the already-started real Auth.logout and skips busy finalization.'
    elif i in (26,27,94) or 'EXCLUDED' in r.get('disposition','') or 'excluded' in fault.lower() or 'protected' in fault.lower():
        verdict='PRESERVED_EXCLUDED_SCOPE_ONLY'
        note='Scope exclusion/protected bytes is a preservation finding, not acceptance of excluded SQLite WRITE/draft error semantics. No change to that policy is requested.'
    else:
        verdict='RETAIN_JUSTIFIED_AT_THIS_BOUNDARY'
        note='Independently matched the stated concrete producer and present authority to actual source/imports and immediate consumers. This retained handling implements the stated failure/cleanup/display behavior without a new framework or speculative compatibility branch.'
        if i in (319,320): note+=' The stop boundary itself preserves its roots and attempts close; F1 is in adjacent expiry/logout callers, so this local conclusion is not whole-lifecycle PASS.'
        if i in (85,321,322,323): note+=' Current refresh-owner gates, null-session fact and cleanup/root preservation were checked against normal and retired-owner paths; no credential retry is added.'
        if i in (13,14,15,16,17,18,19,20): note+=' Necessary connection retirement/uncertain-commit behavior is retained. F2 separately concerns the safety-watch event classification, outside this token claim.'
    judgments.append({'ordinal':i,'composite_identity':r['composite_identity'],'path':r['path'],'id':r['id'],'line':r['line'],'column':r['column'],'source_sha256':r['source_sha256'],'token':r['token'],'token_class':r['token_class'],'executable':r['executable'],'binding_verified':True,'concrete_fault_reviewed':fault,'current_authority_reviewed':r['present_authority'],'claimed_actual_recovery_or_failure_reviewed':r['actual_recovery_or_failure'],'independent_judgment':verdict,'review_note':note})
save('retained-323-independent-review.json',{'candidate':HEAD,'records':323,'executable':288,'nonexecutable':35,'not_catch_count':True,'identity':'ordinal + path + ID; RH294 duplicates deliberately remain distinct','local_disposition_not_inherited':True,'judgments':judgments})

receipt=EXT.parent/'recover-refresh-owner-finish/final-receipt.json'
raw=receipt.read_bytes(); assert sha(raw)=='93cf45babf08e1ca9fb76587dd61aef67e7c9a8c05e16e396f2d696e8a33cee2'
prior=json.loads(raw);verified=[]
for x in prior['artifacts']:
    p=receipt.parent/x['path']; b=p.read_bytes()
    assert len(b)==x['bytes'] and sha(b)==x['sha256'], x['path']
    verified.append({'path':x['path'],'bytes':len(b),'sha256':sha(b)})
save('fix-evidence-binding.json',{'receipt':str(receipt),'receipt_sha256':sha(raw),'artifact_count':len(verified),'all_listed_artifact_bytes_verified':True,'candidate':prior['candidate_sha'],'independence_note':'Producer-owned test outputs are evidence with their original runtime/source-graph limits. No local verdict or prior review verdict is inherited. No Android emulator run performed by this reviewer.','artifacts':verified})

save('ci-coverage.json',{
 'candidate':HEAD,'review_scope':'Actual current workflow and direct/indirect test-entry call graph, not a hosted run',
 'verified_entry_facts':[
  'Desktop Windows workflow builds current client and runs tests/clients/gui/auth.mjs; cargo locked library checks and packaging are separate entries.',
  'Existing Linux SQLite/Send/Sync verifiers execute existing acceptance entries. Desktop send entry invokes errors/desktop_reads.mjs, desktop_native_reads.mjs and desktop_render.mjs.',
  'Shared Sync and Web regression entries import stream cleanup regressions.',
  'Mobile SQLite/Send/Sync verifier entry builds Storage/Send/Sync instrumentation; original Send/Sync runners call added read-origin/contiguous checks.',
  'Mobile GUI workflow invokes tests/clients/gui/android.py and GuiInstrumentation. Inspected GuiInstrumentation does not invoke ErrorHandlingInstrumentation or RefreshOwnerInstrumentation.'
 ],
 'no_verified_hosted_call_edge':['tests/clients/errors/desktop_parallel.mjs','tests/clients/errors/desktop_owner_retirement.mjs','Android ErrorHandlingInstrumentation','Android RefreshOwnerInstrumentation'],
 'conclusion':'Dedicated regressions above are local/current-source evidence unless a later actual hosted entry proves invocation. No independent finding solely from missing wiring: current acceptance does not explicitly require every local regression to become a new CI job. Applicable exact-head hosted required jobs remain pending and cannot be inferred from local PASS.',
 'existing_assertion_review':'Changed existing test hunks inspected: producer fixtures narrowed to real DOMException/NativeCapabilityFailure/transport-origin types, original assertions retained; additional unknown/mixed/read/observer checks do not weaken old assertions.',
 'evidence':['ci-entry-read.txt','existing-test-delta.patch','desktop-owner12.txt','desktop-parallel37.txt','fix-evidence-binding.json']})

findings=[{
 'id':'F1-DESKTOP-RETIREMENT-CONSUMERS','priority':'P2','file':'clients/desktop/src/application/ui/workspace.ts','lines':[96,97],
 'title':'Finish required expiry/logout cleanup when stop reports an observer failure',
 'trigger':'Actual current Workspace publication observer throws during stop() after the owner projection is set null; actual current Sync.close still runs.',
 'observable':'expire() exits before owner.clear(): zero credential_remove calls, both saved pointers and old Auth.session remain. logout() exits before awaiting the already-started actual Auth.logout; a later unknown literal native_https failure becomes an unhandled rejection rather than a root of the logout result, and busy stays true.',
 'producer_consumer_proof':'logout_retirement_repro.mjs compiles and uses current actual Auth, Workspace, SendApplication and SyncApplication. Only literal native IPC is controlled. Normal expiry control removes both pointers and nulls Auth.session. Actual defect outputs in desktop-logout-expiry-repro.txt.',
 'authority':['spec/governance/error-handling.md:7','spec/governance/error-handling.md:9','spec/governance/error-handling.md:11','Frozen 6.1/7.1 and approved ADR-0009 current credential lifecycle'],
 'minimal_required_outcome':'Attempt already-required Auth cleanup despite stop rejection, wait every already-started logout operation, clear busy for the current operation and preserve all distinct original/retirement roots through the normal operation result. Keep owner/generation guards, one close and no credential retry.',
 'minimum_production_paths':['clients/desktop/src/application/ui/workspace.ts'],
 'regression_requirements':['Actual Auth/Workspace+Send/Sync stop observer failure with normal and unknown late logout result; caller waits it, no unhandled root, no busy residue','Expiry same producer still attempts both required credential removals; normal expiry unchanged','Single/falsy/distinct roots and retired-owner gates remain intact; existing owner12 and parallel37 assertions retained'],
 'excluded':'No native credential implementation, Repository/SQLite WRITE/draft policy or Android analog change is required by this finding.'
},{
 'id':'F2-GATEWAY-DB-FAILURE-AS-REVOCATION','priority':'P2','file':'backend/go/gateway/gateway.go','lines':[219,223],
 'related_file':'backend/go/gateway/session.go:64-71',
 'title':'Do not emit authoritative session revocation for a database availability failure',
 'trigger':'An already-bound connection safety watch gets an actual default pgx connection-refusal error while checking PostgreSQL. authenticate returns the real non-shared.Error database error.',
 'observable':'watch routes every non-nil error into revocationReason, which maps this unknown session state to REVOKED, then h.revoke emits session.revoked and closes all connections for the session. Current client consumers treat that frame as authentication expiry and start credential cleanup. A transport/database failure has established no committed revocation.',
 'producer_consumer_proof':'External read-only Go overlay adds watch_review_test.go to the actual current package. Signed current public fixture token and modeled already-bound connection use real validator/default pgx failed connection producer, actual hub.watch/revoke and real loopback Gorilla WebSocket client. The emitted session.revoked/REVOKED frame is asserted. Not a real PostgreSQL acceptance run and not a TLS claim.',
 'authority':['contracts/websocket/README.md:5','contracts/websocket/envelope.schema.json SessionRevoked semantic identity','Frozen 7.2 session invalidation / 7.3 PostgreSQL authoritative session state','spec/governance/error-handling.md:7','spec/governance/error-handling.md:9'],
 'minimal_required_outcome':'Retain mandatory fail-closed connection retirement when validation is unavailable. Do not turn the database root into an authoritative session.revoked event; retain actual known invalidation/replacement/logout event behavior and truthful failure observability. No contract, security-boundary or auth-decision authority expansion.',
 'minimum_production_paths':['backend/go/gateway/gateway.go'],
 'conditional_adjacent_path':'backend/go/gateway/session.go only if the fix changes the reason-classification boundary; no architecture change is authorized.',
 'regression_requirements':['Actual default pgx refused/unavailable producer closes current connection without session.revoked','Existing known revoked/epoch/replaced/logout behavior and rejection/write-failure retirement still hold','Unknown/internal database error must not become normal success or invented auth cause'],
 'excluded':'Do not keep an unverified connection active, add retry/backoff/cache or change machine contracts.'
}]
save('findings.json',{'candidate':HEAD,'base':BASE,'result':'FAIL','findings':findings,'all_findings_collected_after_whole_scope_review':True,'no_speculative_android_logout_finding':'The analogous stop-before-await shape alone is not a finding: no actual permitted nonexcluded stop failure producer has been established for that Android path.'})

commands=[json.loads(x) for x in (EXT/'commands.jsonl').read_text().splitlines() if x]
save('command-index.json',{'recorder_command_count':len(commands),'commands':commands,'additional_actual_go_overlay_child_argv':json.loads((EXT/'go-watch-command.json').read_text()),'note':'Exact executed argv/exit/elapsed and immutable Recorder raw outputs retained. Direct startup/diagnostic/helper-edit gaps disclosed in report; no complete prospective trace claim.'})
print(json.dumps({'whole_inputs':len(coverage),'categories':bindings['categories'],'read_log_missing_or_partial':missing,'navigation':len(judgments),'fix_receipt_artifacts':len(verified),'findings':len(findings)},ensure_ascii=False))
