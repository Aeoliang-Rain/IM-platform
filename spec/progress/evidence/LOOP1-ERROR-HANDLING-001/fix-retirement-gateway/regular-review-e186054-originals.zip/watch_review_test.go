package gateway

import (
 "context"
 "net"
 "net/http"
 "net/http/httptest"
 "strconv"
 "strings"
 "testing"
 "time"
 "github.com/gorilla/websocket"
 "github.com/jackc/pgx/v5/pgxpool"
 "im-platform/backend/go/shared"
)

func TestReviewWatchUnavailableDatabaseEmitsRevoked(t *testing.T) {
 listener,err:=net.Listen("tcp","127.0.0.1:0");if err!=nil{t.Fatal(err)}
 port:=listener.Addr().(*net.TCPAddr).Port;if err=listener.Close();err!=nil{t.Fatal(err)}
 cfg,err:=pgxpool.ParseConfig("host=127.0.0.1 port="+strconv.Itoa(port)+" user=public_fixture dbname=public_fixture sslmode=disable connect_timeout=1");if err!=nil{t.Fatal(err)}
 pool,err:=pgxpool.NewWithConfig(context.Background(),cfg);if err!=nil{t.Fatal(err)};defer pool.Close()
 codec:=&shared.Codec{Key:[]byte("public-controlled-fixture-key-32-bytes"),Now:time.Now}
 cl:=shared.Claims{UserID:"11111111-1111-4111-8111-111111111111",SessionID:"22222222-2222-4222-8222-222222222222",ClientType:"DESKTOP",SessionEpoch:1,IssuedAt:time.Now().Unix(),ExpiresAt:time.Now().Add(time.Hour).Unix()}
 token,err:=codec.Sign(cl);if err!=nil{t.Fatal(err)}
 validator:=&validator{db:pool,codec:codec,now:time.Now}
 if _,err=validator.authenticate(context.Background(),token);err==nil{t.Fatal("actual default pgx producer unexpectedly authenticated unreachable database")}
 if _,known:=err.(shared.Error);known{t.Fatal("database producer is not an auth error")}
 h:=newHub(validator)
 server:=httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter,r *http.Request){
  upgraded,e:=(&websocket.Upgrader{}).Upgrade(w,r,nil);if e!=nil{return}
  c:=&connection{ws:upgraded,done:make(chan struct{}),bound:&cl,token:token};h.add(cl.SessionID,c)
  // Model the already-bound current connection before a later DB outage.
  h.watch(c,cl)
 }));defer server.Close()
 client,_,err:=websocket.DefaultDialer.Dial(strings.Replace(server.URL,"http:","ws:",1),nil);if err!=nil{t.Fatal(err)};defer client.Close()
 if err=client.SetReadDeadline(time.Now().Add(5*time.Second));err!=nil{t.Fatal(err)}
 var frame struct{Type string `json:"type"`;Payload struct{SessionID string `json:"sessionId"`;Reason string `json:"reason"`} `json:"payload"`}
 if err=client.ReadJSON(&frame);err!=nil{t.Fatal(err)}
 if frame.Type!="session.revoked"||frame.Payload.SessionID!=cl.SessionID||frame.Payload.Reason!="REVOKED"{t.Fatalf("unexpected frame %+v",frame)}
 t.Log("OBSERVED actual default pgx connection failure, no auth Error/revocation evidence, yet actual watch -> revoke -> client frame session.revoked/REVOKED; unit local transport only, no claim of live PostgreSQL acceptance")
}
