from pathlib import Path
import json,sys
ROOT=Path('H:/.codex/worktrees/err/IM-platform')
records=json.loads((ROOT/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-refresh-owner/current-navigation.json').read_text('utf-8'))['records']
a,b=map(int,sys.argv[1:])
for index,r in enumerate(records[a-1:b],a):
 print(f"{index}. {r['composite_identity']} @ {r['line']}:{r['column']} executable={r['executable']} token={r['token_class']}")
 print(' fault: '+r['specific_fault'].split(' Trigger source:')[0])
 print(' authority: '+r['present_authority'])
 print(' result: '+r['actual_recovery_or_failure'])
