# Independent regular review: FAIL

Reviewed clean committed candidate `e186054d964e11755e7bc48ae71f95d1ea125f2f` on `task/LOOP1-ERROR-HANDLING-001`, against accepted base `35bd6f5f1091503f95a0282f730ed04233b0b6ea` (`35bd6f5..e186054`). Assigned and Git-resolved root: `H:/.codex/worktrees/err/IM-platform`. Reviewer: `/root/regular_review_e186054`, a fresh regular independent Review Agent with no implementation, Fix, or previous review participation. This is the full regular review, not the later independent specialist review.

Two P2 findings remain. The whole requested scope is reviewed; this is not a partial review. No product/source/Task/current/queue changes, push, PR, hosted CI, integration, or main synchronization were performed. Review FAIL is not Task/Gate acceptance. Source lease is read-only and RELEASED after the sealed final receipt.

## Findings

### F1 — Complete expiry/logout cleanup after a retirement observer failure (P2)

`clients/desktop/src/application/ui/workspace.ts:96-97` awaits `stop()` before entering the cleanup/error/finally boundaries. Current `stop()` correctly attempts the old Sync close when publication throws, then propagates that real observer root. Its callers do not finish the operations they already own when this happens.

The actual current compiled Auth/Workspace/SendApplication/SyncApplication reproducer controls only the literal native IPC producer. An actual Workspace listener throws during the session-null publication:

- `expire()` retires the Workspace and closes Sync, but exits before `owner.clear()`. The normal expiry control removes both credential pointers and nulls Auth.session; the failing case makes **zero credential_remove calls**, retains both pointers and the old Auth.session, and loses the Workspace reference to that Auth.
- `logout()` starts actual `Auth.logout()`, then rejects with the observer root before awaiting that request. A later unknown native HTTPS rejection escapes as an unhandled rejection instead of a root in the logout operation result. `busy` remains true because the current finally is never entered. Auth's own parallel credential removal still runs; it does not repair the caller's incomplete error graph.

This violates the present normal-call-chain/root-preservation and mandatory-cleanup requirements in `spec/governance/error-handling.md:7,9,11`, together with the current approved native credential lifecycle (Frozen §6.1/§7.1 and ADR-0009). This is a real existing observer producer, including the same producer class accepted by the new refresh-owner tests; it is not a hypothetical future throwable or SQLite WRITE failure.

Minimum production path: `clients/desktop/src/application/ui/workspace.ts`. Complete the already-required expiry/logout cleanup despite retirement failure, await every already-started logout operation, finalize busy for the current operation, and retain distinct original/retirement roots. Keep ownership gates, single close and no credential-removal retry. Extend the current owner regression with actual Auth/Workspace expiry/logout cases, including normal control, late unknown root, no unhandled rejection and no busy residue. Existing owner12/parallel37 assertions must remain.

Evidence: `logout_retirement_repro.mjs`, `desktop-logout-expiry-repro.txt`, fresh `desktop-compile-inputs.json`, `desktop-compile.txt`, `final-authority-consumer-corrected-read.txt`. The earlier narrower logout reproduction remains preserved in `desktop-logout-repro.txt`.

### F2 — Database unavailability must not become an authoritative session revocation (P2)

`backend/go/gateway/gateway.go:219-223` sends every safety-watch authentication error into `revocationReason()`. At `session.go:64-71`, a real database error with no auth classification becomes `REVOKED`; `h.revoke()` then sends `session.revoked` and closes every current connection for that session.

A read-only Go overlay compiled the actual current package. It uses a real default pgx connection-refusal producer, a signed public fixture token, an explicitly modeled already-bound connection, actual validator/watch/revoke logic and an actual loopback Gorilla WebSocket consumer. The database error is verified **not** to be `shared.Error`. The client receives `session.revoked` with `REVOKED` despite there being no successful authoritative session read or committed revocation fact. Current Desktop/Android/Web consumers treat that frame as actual expiry and start account/credential retirement.

The current WSS contract (`contracts/websocket/README.md:5`) associates `session.revoked` with a revoked/replaced session; Frozen §7.2/§7.3 keeps session facts authoritative in PostgreSQL. Error-handling governance §7/§9 prohibits distorted categories and retains account-isolation cleanup. **Fail-closed connection retirement remains required.** A database outage does not establish the session event that this code emits. Existing tests expecting a conservative `REVOKED` string are implementation assertions, not authority for turning unavailability into a business fact.

Minimum production path: `backend/go/gateway/gateway.go`; touch `session.go` only if the narrow reason boundary requires it. On validation unavailability, keep the connection closed without inventing `session.revoked`; preserve current actual revocation/replacement/logout behavior and truthful failure observability. Do not change contracts/security boundaries, leave an unverified socket active, or add retry/cache/framework mechanisms. Regress with the actual default pgx refused-connection producer and assert closed transport without a revocation frame, alongside existing genuine invalidation and write-failure controls.

Evidence: `watch_review_test.go`, `go-overlay.json`, `go-watch-command.json`, `go-watch-repro.txt`, `outbox-producer-final-read.txt`, and contract/consumer reads. This is a controlled local transport test, not real PostgreSQL/TLS/full acceptance.

## Complete production and retained-handler coverage

`whole-production-review.json` records all 185 exact current input hashes, responsibilities, inspection classes, individual results and actual read ranges. The inventory was reconstructed independently from tracked inputs and compared to the current manifest. All 148 semantic logic/config/document inputs have complete logged actual-source read coverage, including imports and neighboring consumers; 17 empty placeholders were checked as empty. Five locks, six binaries and nine literal language-data inputs received appropriate integrity/structure/base-equality or cross-end parity checks. These latter classes are not represented as manual executable-semantics review or native execution.

The review covers Go root/Core/Gateway/shared/plugin-host; the Java nonbusiness infrastructure placeholder; Web/Desktop/Android application/UI/Send/Sync; shared SDK; existing native capability/SQLx adapter; and required build/deployment/language/migration inputs, including files with no navigation hit. Existing imports and responsibilities remain within the authorized Go/Core/Gateway/shared and Java SRC-06 boundaries; TypeScript, Kotlin/Compose, Tauri/Rust/SQLx remain existing choices. No new dependency/framework/runtime or architecture authority was introduced. Actual current Outbox mixed errors preserve every unknown/internal branch; known-only default connection failures retain the pending batch and existing tick retry.

`retained-323-independent-review.json` independently judges every composite **ordinal/path/ID** identity, with exact source SHA/line/column/token binding and the specific fault → present authority → actual recovery/failure claim. There are **288 executable and 35 nonexecutable navigation tokens**, not 323 catches. Both RH294 identities remain distinct. Local disposition/verdict fields were not inherited. RH088/RH089 consumer guarantees fail under F1; the correct local stop/refresh root handling is retained and distinguished from its incomplete callers. Necessary transaction rollback, cleanup, FAILED, protocol rejection, account isolation, uncertain-commit and frozen preference defaults are retained. Nonexecutable and excluded write/draft tokens are explicitly classified accordingly. The corrected 22 native/display/SyncWire/approved-READ grounds were matched to actual current source and authority rather than the previous local labels.

`bindings.json` proves all 65 protected inputs equal the reviewed prior candidate 27cdd93. Sixty-three are wholly byte-equal to accepted base35; the two previously Human-approved shared/mobile contiguous READ mappers are equal to base outside that mapper. Their SELECT SQL is unchanged, absent row remains legitimate zero and existing NULL/invalid values fail. All schema/init/transaction/write/draft bytes and SQL are preserved. Excluded SQLite WRITE/draft semantics are not accepted or reopened by this review.

`change-scope.json` covers all 1,737 base-to-candidate changed paths against actual Task allowed_paths. Frozen, approved ADR and public contract bytes are unchanged. The governance delta, four examples, Task/template workflow, fresh two-role exact-SHA pre-CI gate, and architecture positive/negative controls were inspected. Existing test assertion changes were read: producer fixtures use real boundary types; original acceptance assertions were not weakened. Detailed evidence remains in `governance-diff.txt`, `existing-test-delta.patch` and actual source reads.

## Verification and evidence limits

Exact argv, exit code, elapsed time and output hashes are in `commands.jsonl`, the final `command-index.json` and the immutable own Recorder command events. Fresh checks include:

| Check | Observed result |
| --- | --- |
| Frozen resolver/hash and planning | PASS |
| Architecture all-scope checker | PASS |
| Architecture controls | 82 tests, PASS; one pre-existing Windows skip |
| Development and clean committed Acceptance verifier | PASS, exit 0; about 17.4s and 17.2s |
| Exact current Desktop strict compile | PASS |
| Current actual owner12 and parallel37 regressions | PASS, all assertions retained |
| Desktop expiry/logout actual-consumer reproducer | Defect reproduced; process exit 0 means its defect assertions succeeded |
| Gateway default-pgx/watch/WebSocket overlay reproducer | Defect reproduced; process exit 0 means its defect assertions succeeded |
| Bounded current Outbox tests | Five top-level tests / 18 classifier subcases PASS, no skip, actual default producer controls |
| 185/323/65 bindings and original Fix receipt | PASS; all 133 listed original Fix artifact bytes verified |

No fresh Android/native/full Go/SQLx acceptance run is claimed here. Current producer-owned API34 owner10/HTTP32/WSS21 outputs and their sealed source graph were read as qualified evidence, not inherited independent verdicts or reviewer execution. Unchanged older Send/Sync/read graphs remain historical qualified reuse. No GUI visual change is present. Applicable exact-head hosted CI, protected integration and actual main synchronization remain pending.

`ci-coverage.json` records actual direct/indirect entry inspection. READ and stream-cleanup regression paths are wired through existing entries. New Desktop owner/parallel and Android ErrorHandling/RefreshOwner runners have no verified current hosted invocation; their current runtime evidence is local. This is a stated coverage limit, not a standalone finding: the present Task does not explicitly require each dedicated local regression to become a new hosted job. A later hosted job PASS must not be claimed to have executed these runners without an actual call edge.

The analogous Android logout structural shape was examined but not elevated: no actual permitted nonexcluded stop-failure producer was established. This review requests no speculative Android or excluded SQLite WRITE/draft expansion.

## Recorder, failures and handoff

Own run `R-REGULAR-E186054`, role `review`, fresh context, parent `R-ERROR-INTEGRATION-COORD-20261013`, prompt `P-REGULAR-E186054`, capture `prospective_resume`. Original startup reads briefly targeted main's handoff/current before restarting the required startup sequence in the assigned root. An invalid initial role was rejected, then a legal new run was started; no historical start was fabricated. Direct startup/diagnostic/helper preparation and some output-truncation/re-read gaps are disclosed; this is not a claim of a complete prospective trace. The full canonical/task/contract/domain/governance startup and exact root were then read and checked before this review's actual production assessment.

Two external binding collector failures (Windows path separator, then literal Kotlin grammar) remain raw before corrected passing collectors. One Recorder-routed rg invocation failed access denied; later direct diagnostics and recorded Python reads supplied the evidence. One late confirmation read used the wrong `contracts/wss` path and failed; the corrected actual `contracts/websocket` read passed. Direct diagnostic rg glob failures and tool/session output observability gaps were not promoted to successful product tests. These were evidence-collection failures, not hidden or rewritten. Own Recorder is finished with review result FAIL and validated structurally; structural validation is not Task PASS. The final receipt seals the resulting events and exact final clean Git state.

Next action is a new fresh Fix Agent for F1/F2 within the listed narrow paths and current Task allowed_paths, followed by a **new fresh complete regular reviewer** and a **different new independent specialist** on the resulting final clean SHA. This reviewer cannot serve as the subsequent specialist. Task remains review, S2 OPEN; no push/CI-triggering PR is authorized by this FAIL. Coordinator alone updates repository recovery/Task state. The final receipt supplies artifact count, hashes, final Recorder validation and read-only RELEASED lease.
