import json,sys,hashlib
from pathlib import Path
ROOT=Path('H:/.codex/worktrees/err/IM-platform')
for name in sys.argv[1:]:
 raw=(ROOT/name).read_bytes(); data=json.loads(raw)
 print('FILE',name,'SHA256',hashlib.sha256(raw).hexdigest())
 if name.endswith('auth-user-friend.openapi.json'):
  for key,value in data.items():
   print(key,json.dumps(value,ensure_ascii=False,separators=(',',':')))
 else:print(json.dumps(data,ensure_ascii=False,separators=(',',':')))
