from pathlib import Path
import sys,json,hashlib
ROOT=Path('H:/.codex/worktrees/err/IM-platform')
EXT=Path(__file__).parent
for arg in sys.argv[1:]:
    parts=arg.split('::')
    path=ROOT/parts[0]
    raw=path.read_bytes()
    lines=raw.decode('utf-8-sig').splitlines()
    start,end=(int(parts[1]),int(parts[2])) if len(parts)>1 else (1,len(lines))
    print('\nFILE '+parts[0]+' SHA256 '+hashlib.sha256(raw).hexdigest()+' LINES '+str(start)+'-'+str(end))
    for num in range(start,min(end,len(lines))+1):print(str(num)+': '+lines[num-1])
    with (EXT/'read-log.jsonl').open('a',encoding='utf-8') as out:out.write(json.dumps({'path':parts[0],'sha256':hashlib.sha256(raw).hexdigest(),'lines':[start,min(end,len(lines))],'kind':'printed-for-human-agent-inspection'})+'\n')
