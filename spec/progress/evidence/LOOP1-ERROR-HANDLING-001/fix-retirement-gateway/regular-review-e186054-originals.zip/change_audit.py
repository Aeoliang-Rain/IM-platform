from pathlib import Path
import subprocess,re,fnmatch,json,hashlib
ROOT=Path('H:/.codex/worktrees/err/IM-platform');EXT=Path(__file__).parent;BASE='35bd6f5f1091503f95a0282f730ed04233b0b6ea'
def git(*args):return subprocess.check_output(['git','-c','core.excludesFile=NUL',*args],cwd=ROOT)
task=(ROOT/'spec/tasks/review/LOOP1-ERROR-HANDLING-001.md').read_text('utf-8');part=task.split('# Allowed Paths')[1].split('# Acceptance')[0];allowed=re.findall(r'^- `([^`]+)`',part,re.M)
changed=git('diff','--name-only','--no-renames',BASE+'...HEAD').decode().splitlines()
bad=[p for p in changed if not any(fnmatch.fnmatchcase(p,a) for a in allowed)];assert not bad,bad
authority=git('diff','--name-only',BASE+'...HEAD','--','spec/architecture','contracts').decode().splitlines();assert not authority,authority
num=[]
for line in git('diff','--numstat',BASE+'...HEAD').decode().splitlines():
 add,delete,path=line.split('\t',2)
 if not path.startswith(('spec/progress/evidence/','spec/progress/checkpoints/')):num.append({'path':path,'add':add,'delete':delete})
(EXT/'change-scope.json').write_text(json.dumps({'base':BASE,'head':git('rev-parse','HEAD').decode().strip(),'changed_count':len(changed),'allowed_path_violations':bad,'authority_delta':authority,'non_evidence_changes':num},indent=2),encoding='utf-8')
for row in num:print(row['add'],row['delete'],row['path'])
existingtests=[r['path'] for r in num if r['path'].startswith(('tests/','clients/mobile/app/src/androidTest/')) and r['delete']!='0']
patch=git('diff','--unified=2',BASE+'...HEAD','--',*existingtests);(EXT/'existing-test-delta.patch').write_bytes(patch)
print('SCOPE PASS',len(changed),'changed paths all allowed; Frozen/ADR/contracts unchanged. Existing test delta saved, paths',len(existingtests))
