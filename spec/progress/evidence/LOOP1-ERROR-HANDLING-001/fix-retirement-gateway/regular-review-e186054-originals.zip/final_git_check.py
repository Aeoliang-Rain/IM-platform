from pathlib import Path
import subprocess,json,hashlib
ROOT=Path('H:/.codex/worktrees/err/IM-platform');EXT=Path(__file__).parent
results=[]
def git(*args):
 p=subprocess.run(['git',*args],cwd=ROOT,capture_output=True)
 results.append({'argv':['git',*args],'cwd':str(ROOT),'exit':p.returncode,'stdout':p.stdout.decode('utf-8','replace'),'stderr':p.stderr.decode('utf-8','replace')})
 if p.returncode:raise RuntimeError(results[-1])
 return p.stdout.decode('utf-8','replace').strip()
root=git('rev-parse','--show-toplevel');head=git('rev-parse','HEAD');branch=git('branch','--show-current');status=git('status','--porcelain=v1');diff=git('diff','--stat');cached=git('diff','--cached','--stat')
assert Path(root).resolve()==ROOT.resolve()
assert head=='e186054d964e11755e7bc48ae71f95d1ea125f2f' and branch=='task/LOOP1-ERROR-HANDLING-001'
assert not status and not diff and not cached
data={'root':root,'candidate':head,'branch':branch,'clean':True,'status':status,'diff':diff,'cached_diff':cached,'commands':results,'reviewer_source_writes':False,'main_write_or_sync':False,'source_lease':'READ_ONLY_RELEASED_AFTER_SEALED_RECEIPT'}
(EXT/'final-git-state.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in data.items() if k!='commands'}))
