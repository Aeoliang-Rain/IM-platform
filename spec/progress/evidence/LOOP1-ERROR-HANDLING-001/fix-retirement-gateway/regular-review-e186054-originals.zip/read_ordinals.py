from pathlib import Path
import json,sys,runpy
EXT=Path(__file__).parent
rows=json.loads((EXT/'scope-inputs.json').read_text('utf-8'))
numbers=[]
for item in sys.argv[1:]:
 if '-' in item:
  a,b=map(int,item.split('-'));numbers+=range(a,b+1)
 else:numbers.append(int(item))
sys.argv=[str(EXT/'read_inputs.py')]+[rows[n-1]['path'] for n in numbers]
runpy.run_path(str(EXT/'read_inputs.py'),run_name='__main__')
