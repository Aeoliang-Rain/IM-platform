from pathlib import Path
import json
EXT=Path(__file__).parent
scope=json.loads((EXT/'scope-inputs.json').read_text('utf-8')); logs=[json.loads(x) for x in (EXT/'read-log.jsonl').read_text('utf-8').splitlines()]
covered={x['path'] for x in logs if x['lines'][0]==1}
for x in scope:
 p=x['path']
 special=(p.endswith('.gitkeep') or p.endswith('lock.json') or p.endswith('Cargo.lock') or p.endswith('go.sum') or x['lines'] is None or '/i18n/' in p and Path(p).stem in ['en','zh-CN','ja-JP','zhCN','jaJP'])
 if p not in covered and not special:print(x['ordinal'],p,x['lines'])
print('printed-from-line-one',len(covered),'special',sum((x['path'].endswith('.gitkeep') or x['path'].endswith('lock.json') or x['path'].endswith('Cargo.lock') or x['path'].endswith('go.sum') or x['lines'] is None or '/i18n/' in x['path'] and Path(x['path']).stem in ['en','zh-CN','ja-JP','zhCN','jaJP']) for x in scope))
