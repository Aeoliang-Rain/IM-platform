from pathlib import Path
import json,subprocess,sys,time,hashlib,datetime
EXT=Path(__file__).parent;ROOT=Path('H:/.codex/worktrees/err/IM-platform')
PY='C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe'
HEAD='e186054d964e11755e7bc48ae71f95d1ea125f2f';BASE='35bd6f5f1091503f95a0282f730ed04233b0b6ea'
COMMON=['--repo',str(ROOT),'--research-root',str(EXT/'research'),'--run-id','R-REGULAR-E186054']
calls=[]
def digest(raw):return hashlib.sha256(raw).hexdigest()
def call(label,sub,args):
 argv=[PY,'-Xutf8','-B',str(ROOT/'tools/research/recorder.py'),sub,*COMMON,*args]
 started=time.time();p=subprocess.run(argv,cwd=ROOT,capture_output=True);elapsed=time.time()-started
 (EXT/(label+'.stdout.txt')).write_bytes(p.stdout);(EXT/(label+'.stderr.txt')).write_bytes(p.stderr)
 calls.append({'label':label,'argv':argv,'cwd':str(ROOT),'exit':p.returncode,'elapsed':elapsed,'stdout':label+'.stdout.txt','stderr':label+'.stderr.txt','stdout_sha256':digest(p.stdout),'stderr_sha256':digest(p.stderr)})
 print(label,'exit',p.returncode,'elapsed',round(elapsed,3),flush=True)
 if p.returncode:print(p.stdout.decode('utf-8','replace'),p.stderr.decode('utf-8','replace'));raise SystemExit(p.returncode)
 return p

assert json.loads((EXT/'final-git-state.json').read_text())['clean']
assert json.loads((EXT/'whole-production-review.json').read_text())['read_log_missing_or_partial']==[]
for sub,label,data in [
 ('record-event','instrumentation-disclosure-final',{'type':'instrumentation_warning','result':'DISCLOSED_PARTIAL_OBSERVABILITY','details':'Startup first read main handoff/current before assigned-root restart; invalid role rejected before legal review start. Direct startup/diagnostic/helper preparation, tool truncation/re-read/session-output gaps, rg direct diagnostic failures and external helper edits are not a complete prospective trace. All Recorder/collector failures retained. No historical events rewritten.'}),
 ('record-event','finding-F1',{'type':'finding_created','id':'F1-DESKTOP-RETIREMENT-CONSUMERS','priority':'P2','candidate':HEAD,'evidence':'desktop-logout-expiry-repro.txt','result':'REPRODUCED'}),
 ('record-event','finding-F2',{'type':'finding_created','id':'F2-GATEWAY-DB-FAILURE-AS-REVOCATION','priority':'P2','candidate':HEAD,'evidence':'go-watch-repro.txt','result':'REPRODUCED','security':'Preserve fail-closed retirement; do not invent authoritative revocation on DB failure.'}),
 ('record-event','review-finished',{'type':'review_finished','result':'FAIL','candidate':HEAD,'base':BASE,'whole_inputs':185,'navigation_records':323,'executable':288,'nonexecutable':35,'protected_inputs':65,'findings':['F1-DESKTOP-RETIREMENT-CONSUMERS','F2-GATEWAY-DB-FAILURE-AS-REVOCATION'],'coverage':'complete read/structure coverage, runtime limits separately disclosed','independent':True,'source_writes':False})
]:
 event=data.pop('type');call(label,sub,['--event-type',event,'--data-json',json.dumps(data,ensure_ascii=False)])
call('recorder-finish','finish-run',['--result','FAIL'])
call('recorder-validate','validate-run',[])
(EXT/'recorder-final-commands.json').write_text(json.dumps(calls,indent=2)+'\n',encoding='utf-8')
run=EXT/'research/runs/R-REGULAR-E186054'
events=[json.loads(x) for x in (run/'events.jsonl').read_text().splitlines()]
assert events[-1]['event_type']=='run_finished'
commands=[json.loads(x) for x in (EXT/'commands.jsonl').read_text().splitlines() if x]
(EXT/'command-index.json').write_text(json.dumps({'recorder_wrapped_commands':commands,'final_event_finish_validation_commands':calls,'go_overlay_child':json.loads((EXT/'go-watch-command.json').read_text()),'direct_gaps':'Explicitly disclosed; not a complete prospective trace.'},indent=2)+'\n',encoding='utf-8')
files=[]
for p in sorted(EXT.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(EXT).as_posix()
 if rel.startswith('go-cache/') or rel in ('final-receipt.json','final-receipt.sha256','receipt-verify.txt'):continue
 b=p.read_bytes();files.append({'path':rel,'bytes':len(b),'sha256':digest(b)})
receipt={'result':'INDEPENDENT_REGULAR_REVIEW_FAIL','candidate_sha':HEAD,'base':BASE,'branch':'task/LOOP1-ERROR-HANDLING-001','diff_range':BASE+'..'+HEAD,'assigned_root':str(ROOT),'reviewer':'/root/regular_review_e186054','fresh_regular_independent':True,'implementation_fix_or_prior_review_participation':False,'source_lease':'RELEASED','read_only':True,'git_clean':True,'source_repository_writes':False,'main_synchronization':'NOT_PERFORMED','review_scope':{'production_inputs':185,'categories':json.loads((EXT/'bindings.json').read_text())['categories'],'full_semantic_read_log_missing':[],'navigation_tokens':323,'executable_tokens':288,'nonexecutable_tokens':35,'not_catch_count':True,'protected_inputs':65,'whole_base_exact':63,'approved_read_mapper_only_exceptions':2},'findings':['F1-DESKTOP-RETIREMENT-CONSUMERS','F2-GATEWAY-DB-FAILURE-AS-REVOCATION'],'recorder':{'run_id':'R-REGULAR-E186054','events':len(events),'last_seq':events[-1]['seq'],'last_event':'run_finished','run_result':'FAIL','structural_validation_exit':0,'meaning':'Structural validation only, never Task/Gate PASS','trace_limit':'prospective_resume with startup/direct diagnostic gaps disclosed'},'fix_producer_evidence_receipt_sha256':'93cf45babf08e1ca9fb76587dd61aef67e7c9a8c05e16e396f2d696e8a33cee2','fix_producer_133_artifacts_verified':True,'task_state':'review','stage':'S2','gate':'OPEN','hosted_ci_protected_integration_actual_main':'PENDING_NOT_PERFORMED','artifact_count':len(files),'artifact_bytes':sum(x['bytes'] for x in files),'artifact_scope_exclusions':{'go-cache/**':'Disposable derived Go compiler cache, not review evidence; every relevant command/source/output is sealed','final-receipt.json':'The manifest cannot hash itself; SHA in final-receipt.sha256 and parent handoff','final-receipt.sha256':'Manifest digest sidecar','receipt-verify.txt':'Postseal independent byte-verification output'},'artifacts':files,'sealed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
raw=(json.dumps(receipt,indent=2)+'\n').encode();(EXT/'final-receipt.json').write_bytes(raw);h=digest(raw);(EXT/'final-receipt.sha256').write_text(h+'  final-receipt.json\n',encoding='ascii')
print(json.dumps({'result':receipt['result'],'artifact_count':len(files),'receipt_sha256':h,'recorder_events':len(events),'source_lease':'RELEASED'}))
