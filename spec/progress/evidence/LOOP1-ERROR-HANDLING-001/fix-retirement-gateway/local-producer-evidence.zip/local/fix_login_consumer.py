from run import *
p=ROOT/'clients/desktop/src/application/ui/workspace.ts';s=p.read_text(encoding='utf-8')
start=s.index('  async login(');end=s.index('  async restore(',start)
new='''  async login(endpoint:string,username:string,password:string){if(this.state.busy)return;const op=++this.operation;let failed=false,failure:unknown;
    try{this.publish({busy:true,error:null});await this.stop();await this.auth?.clear();if(op!==this.operation)return;const base=origin(endpoint);this.publish({endpoint:base});const owner=new Auth(base);this.auth=owner;const session=await owner.login(username,password);if(op===this.operation)await this.bind(session,op);}catch(error){failed=true;failure=error;}
    finally{if(op===this.operation)try{this.publish({busy:false});}catch(error){failure=failed&&error!==failure?new AggregateError([failure,error],"Login and observer failed"):error;failed=true;}}
    if(failed)try{this.failure(failure,op===this.operation);}catch(error){if(error===failure)throw error;throw new AggregateError([failure,error],"Login failure and observer failed");}
  }
'''
p.write_text(s[:start]+new+s[end:],encoding='utf-8',newline='\n')
p=ROOT/'tests/clients/errors/desktop_retirement_consumers.mjs';s=p.read_text(encoding='utf-8')
needle='assert.deepEqual(unhandled,[]);process.off(\'unhandledRejection\',onUnhandled);'
addition='''for(const [name,options,wanted] of [
  ['retirement-observer',{observer},[observer]],
  ['retirement-and-final',{observer,finalObserver},[observer,finalObserver]],
  ['falsy-retirement',{observer:0},[0]]
]){
  const f=fixture(options);let rejected=false,error;await f.w.login(f.auth.endpoint,'fixture','fixture').catch(root=>{rejected=true;error=root;});
  assert(rejected);const graph=roots(error);for(const root of wanted)assert(graph.has(root));if(wanted.length===1)assert.equal(error,wanted[0]);
  assert.equal(f.w.state.busy,false);assert.equal(f.w.state.session,null);assert.equal(f.w.auth,f.auth,'failed stop retains original Auth owner before clear/new login');assert.equal(f.auth.session,session);assert.equal(f.w.sync,null);assert.equal(f.sync.state.status,'retired');assert.equal(f.closes,1);assert.equal(f.w.refreshTimer,null);assert.deepEqual(f.calls,[],'no clear or new Auth operation started after retirement failure');
  checks++;console.log('LOGIN '+name+' PASS');
}
'''
assert needle in s;s=s.replace(needle,addition+needle,1);p.write_text(s,encoding='utf-8',newline='\n')
print('Current same F1 login consumer now finalizes current busy and preserves stop/final/error-publication roots; actual three controls added; no new Auth request, cleanup retry or unrelated mechanism.')
