from run import *
EVID=ROOT/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-retirement-gateway';ip=ROOT/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001/production-inventory.json';inv=json.loads(ip.read_text(encoding='utf-8'));np=EVID/'current-navigation.json';nav=json.loads(np.read_text(encoding='utf-8'))
path='clients/desktop/src/application/ui/workspace.ts';data=(ROOT/path).read_bytes();lines=data.decode('utf-8').splitlines();digest=hashlib.sha256(data).hexdigest();assert len(nav['records'])==333
def region(method):
    start=next(n for n,line in enumerate(lines,1) if line.startswith('  async '+method+'('));ends=[n for n in range(start+1,len(lines)+1) if lines[n-1].startswith('  async ')];return range(start,min(ends) if ends else len(lines)+1)
def locate(method,token):
    hits=[n for n in region(method) if token in lines[n-1]];assert len(hits)==1,(method,token,hits);n=hits[0];return n,lines[n-1].index(token)+1
mapping={'RH084':'register','RH094':'search','RH095':'add'}
authority='Frozen §6.1/§7.1/ADR-0009 and error-handling.md operation/observer primary-root propagation; current actualAuth.request503 + existing failure observer A and final busy observer B producer'
for r,i in zip(nav['records'],inv['retained_sites']):
    if r['path']!=path:continue
    if r['id'] in mapping:
        method=mapping[r['id']];n,c=locate(method,'catch(error){failed=true;failure=error;')
        r.update(specific_fault='Actual '+method+' operation fails, possibly followed by existing failure projection observer',present_authority=authority,actual_recovery_or_failure='Retain original root through existing known failure publication and final busy cleanup. Known-only recovery remains normal failed UI; unknown or observer roots reject with full graph. Registration bool, search generation/results, add owner/revision gates remain.')
    else:
        hits=[n for n,line in enumerate(lines,1) if line==r['source']];assert len(hits)==1,(r['id'],hits);n=hits[0];c=r['column']
    r.update(line=n,column=c,source=lines[n-1],source_sha256=digest)
    for k in ['line','column','source','source_sha256','specific_fault','present_authority','actual_recovery_or_failure']:i[k]=r[k]
    i['actual_source']=r['source'];i['specific_ground_and_recovery']=' → '.join(r[k] for k in ['specific_fault','present_authority','actual_recovery_or_failure']);i['authority']=r['present_authority']
for method in ['register','search','add']:
    for token,fault,recovery in [
        ('catch(propagated)','Actual known failure publisher throws primary+observer graph, or unknown operation rejects','Retain existing Workspace.failure result before mandatory finally. Unknown remains explicit rejection; handled known primary is still retained if final observer later fails, so primary/A cannot be replaced by B.'),
        ('catch(error){failure=failed&&error!==failure?','Actual final busy=false publication throws after operation/failure-publication root','Assign current operation/generation busy=false first, preserve distinct final observer with original graph and falsy roots. Throw exact singleton or standard AggregateError only when actual distinct roots exist; normal return/gates unchanged.')]:
        n,c=locate(method,token);ordinal=len(nav['records'])+1;identity='RH'+str(ordinal)
        r={'original_ordinal':ordinal,'original_id':identity,'id':identity,'composite_identity':str(ordinal)+'|'+path+'|'+identity,'path':path,'line':n,'column':c,'source':lines[n-1],'source_sha256':digest,'token':'catch','token_class':'catch','executable':True,'specific_fault':fault,'present_authority':authority,'actual_recovery_or_failure':recovery,'disposition':'LOCAL_RETAINED_CURRENT_GROUND_PENDING_INDEPENDENT_REVIEW','decision':'FIX_LOCAL_CURRENT_BINDING_NOT_INDEPENDENT_ACCEPTANCE','current_candidate_binding':nav['binding']}
        nav['records'].append(r);inv['retained_sites'].append({'id':identity,'path':path,'line':n,'column':c,'source':r['source'],'actual_source':r['source'],'source_sha256':digest,'operation':'Workspace.'+method,'specific_fault':fault,'present_authority':authority,'actual_recovery_or_failure':recovery,'specific_ground_and_recovery':' → '.join([fault,authority,recovery]),'authority':authority,'disposition':r['disposition']})
nav['counts']={'records':339,'executable':304,'nonexecutable':35};assert len(nav['records'])==339
inv['counts']['retained_sites']=339;f=next(f for f in inv['files'] if f['path']==path);f.update(sha256=digest,bytes=len(data));inv['fix_retirement_gateway']['new_records']='16 necessary actual consumer/settled/watch token records;339=304exec35nonexec, never catch count';inv['fix_retirement_gateway']['same_F1_consumer_family']+=' Actual register/search/add503 failure-observerA/finalB reproduced; retain all three roots and existing normal result/revision/account guards.'
ip.write_text(json.dumps(inv,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');np.write_text(json.dumps(nav,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
p=EVID/'production-hashes.json';d=json.loads(p.read_text(encoding='utf-8'));f=next(f for f in d['files'] if f['path']==path);f.update(sha256=digest,bytes=len(data));p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
p=EVID/'runtime-source-bindings.json';d=json.loads(p.read_text(encoding='utf-8'));d['desktop_current']='Fresh all-family-final strict compile + original owner12/parallel37/Auth + new39 actual Auth/Workspace/Send/Sync controls, including register/search/add primary/A/finalB roots; exact compiler/input/output graph sealed.';p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
compiled=[{'path':str(p.relative_to(EXT)).replace('\\','/'),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in (EXT/'desktop-build').rglob('*') if p.is_file()]
(EXT/'desktop-compiled-output-bindings.json').write_text(json.dumps({'source_inputs':'all-family-final-desktop-compile-inputs.json','outputs':compiled,'runtime_link_stub':'Only literal Tauri IPC forwarding; no native credentials/DB acceptance.'},indent=2)+'\n',encoding='utf-8')
for p in [EVID/'handoff.md',ROOT/'spec/progress/current.md',ROOT/'spec/tasks/review/LOOP1-ERROR-HANDLING-001.md',ROOT/'spec/progress/checkpoints/2026-10-15-error-handling-retirement-gateway-review-candidate.md']:
    t=p.read_text(encoding='utf-8').replace('333','339').replace('298','304').replace('New36','New39').replace('new36','new39').replace('Desktop36','Desktop39').replace('stable36actual','stable39actual').replace('ten necessary','sixteen necessary')
    if p.name=='handoff.md':
        t=t.replace('These are direct current literal lifecycle captures, not a new error framework.','Actual register/search/add Auth.request503 plus failure observer A/final busy observer B also reproduced before repair. Their direct existing catch/finally boundaries now preserve original/A/B while keeping known failure-publication order and normal register boolean, search generation/results, friend-add owner/revision guards. These are direct current literal lifecycle captures, not a new error framework.')
    p.write_text(t,encoding='utf-8')
print('Final185/339=304exec35nonexec metadata and fresh39 controls bound; all323 original identities,65 protected and79 Android graph unchanged.')
