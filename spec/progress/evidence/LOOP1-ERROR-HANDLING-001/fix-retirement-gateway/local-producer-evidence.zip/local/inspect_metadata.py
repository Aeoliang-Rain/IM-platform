from run import *
inv=json.loads((ROOT/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001/production-inventory.json').read_text(encoding='utf-8'))
nav=json.loads((ROOT/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-refresh-owner/current-navigation.json').read_text(encoding='utf-8'))
print('INV KEYS',list(inv))
for key in ['files','retained_sites','inputs']:
    if key in inv:print('INV SAMPLE',key,json.dumps(inv[key][0],ensure_ascii=False))
print('NAV KEYS',list(nav))
for key,value in nav.items():
    if isinstance(value,list) and value and isinstance(value[0],dict):
        print('NAV ARRAY',key,'count',len(value),'sample',json.dumps(value[0],ensure_ascii=False))
        relevant=[{k:r.get(k) for k in ['original_ordinal','id','path','line','column','token','source','specific_fault','present_authority','actual_recovery_or_failure']} for r in value if r.get('path') in ['backend/go/gateway/gateway.go','backend/go/gateway/session.go','clients/desktop/src/application/ui/workspace.ts']]
        print('AFFECTED',json.dumps(relevant,ensure_ascii=False))
protected=ROOT/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-refresh-owner/protected-inputs.json'
data=json.loads(protected.read_text(encoding='utf-8'));print('PROTECTED KEYS',list(data));print('PROTECTED SAMPLE',json.dumps(data,ensure_ascii=False)[:1200])
