from run import *
import zipfile
EVID=ROOT/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-retirement-gateway';BASE_SHA='e186054d964e11755e7bc48ae71f95d1ea125f2f'
inv=json.loads((ROOT/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001/production-inventory.json').read_text(encoding='utf-8'))
nav=json.loads((EVID/'current-navigation.json').read_text(encoding='utf-8'))
old=json.loads((ROOT/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-refresh-owner/current-navigation.json').read_text(encoding='utf-8'))
assert len(inv['files'])==185 and len(nav['records'])==len(inv['retained_sites'])==339
assert [r['composite_identity'] for r in nav['records'][:323]]==[r['composite_identity'] for r in old['records']]
changed=[]
for f in inv['files']:
    data=(ROOT/f['path']).read_bytes();assert hashlib.sha256(data).hexdigest()==f['sha256'] and len(data)==f['bytes'],f['path']
    if data!=subprocess.check_output(['git','show',BASE_SHA+':'+f['path']],cwd=ROOT):changed.append(f['path'])
assert sorted(changed)==['backend/go/gateway/gateway.go','clients/desktop/src/application/ui/workspace.ts']
seen=set()
for r,i in zip(nav['records'],inv['retained_sites']):
    key=r['composite_identity'];assert key not in seen;seen.add(key)
    data=(ROOT/r['path']).read_bytes();line=data.decode('utf-8').splitlines()[r['line']-1]
    assert hashlib.sha256(data).hexdigest()==r['source_sha256'] and line==r['source']
    assert line[r['column']-1:].startswith(r['token']),key
    for field in ['id','path','line','column','source_sha256','specific_fault','present_authority','actual_recovery_or_failure']:assert r[field]==i[field],(key,field)
protected=json.loads((EVID/'protected-inputs.json').read_text(encoding='utf-8'))
for f in protected['files']:
    data=(ROOT/f['path']).read_bytes();assert hashlib.sha256(data).hexdigest()==f['sha256']
    assert data==subprocess.check_output(['git','show',BASE_SHA+':'+f['path']],cwd=ROOT)
assert len(protected['files'])==65
archive=json.loads((EVID/'original-review-archive.json').read_text(encoding='utf-8'))
with zipfile.ZipFile(EVID/archive['archive']) as z:
    assert len(z.namelist())==316
    for entry in archive['entries']:
        data=z.read(entry['path']);assert len(data)==entry['bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256']
pyc=ROOT/'ci/__pycache__/check_s2_planning.cpython-313.pyc'
if pyc.exists():
    assert pyc.resolve()==(ROOT/'ci/__pycache__/check_s2_planning.cpython-313.pyc').resolve()
    target=EXT/'owned-generated';target.mkdir(exist_ok=True);data=pyc.read_bytes();destination=target/pyc.name;assert not destination.exists()
    destination.write_bytes(data);assert hashlib.sha256(destination.read_bytes()).digest()==hashlib.sha256(pyc.read_bytes()).digest();pyc.unlink()
    (EXT/'generated-output-preservation.json').write_text(json.dumps({'source':str(pyc),'destination':str(destination),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'ownership':'initial clean e186 before own verifier baseline','method':'exact leaf copy, verify SHA then unlink; first atomic cross-drive move failed and was preserved','other_paths_or_acl_changed':False},indent=2)+'\n',encoding='utf-8')
runtime=json.loads((EVID/'runtime-source-bindings.json').read_text(encoding='utf-8'))
checks={'production185':True,'only2_production_delta_from_e186054':changed,'navigation':nav['counts'],'all323_original_composite_identities_preserved':True,'all339_sourcehash_line_column_token_ground_verified':True,'protected65_exact_e186054':True,'whole_base63_plus_prior2_read_exceptions':True,'android_current_graph_equal':runtime['android_qualified_historical_reuse']['all_current_graph_inputs_verified'],'prior315plusreceipt_archive_verified':True,'independent_whole_scope_semantic_acceptance':False}
(EVID/'input-checks.json').write_text(json.dumps(checks,indent=2)+'\n',encoding='utf-8')
print(json.dumps(checks))
