from run import *
p=ROOT/'backend/go/gateway/gateway.go';s=p.read_text(encoding='utf-8')
needle='\t\tif err == context.DeadlineExceeded {\n\t\t\tknown = true\n\t\t}\n';assert s.count(needle)==1
s=s.replace(needle,'');p.write_text(s,encoding='utf-8',newline='\n')
p=ROOT/'backend/go/gateway/watch_failure_test.go';s=p.read_text(encoding='utf-8')
s=s.replace('if !strings.Contains(string(output), "panic:") || !strings.Contains(string(output), "not-an-epoch") {','if !strings.Contains(string(output), "panic: ERROR: cached plan must not change result type (SQLSTATE 0A000)") || !strings.Contains(string(output), "created by im-platform/backend/go/gateway.(*hub).serve") {')
s=s.replace('watch closes transport and original scan failure escapes goroutine; child failure expected','watch closes transport and original cached-plan PgError0A000 escapes actual serve goroutine; child failure expected')
insert='''func TestWatchActualClosedPoolReturnsExactInternalRoot(t *testing.T) {
\tpool := watchPool(t, "127.0.0.1", 1)
\tpool.Close()
\th, cl, token := watchFixture(t, pool)
\t_, original := h.auth.authenticate(context.Background(), token)
\tif original == nil || watchTransportFailure(original) {
\t\tt.Fatal("actual closed-pool producer was not an internal failure")
\t}
\tresult := observeWatchFailure(t, h, cl, token)
\tif result != original || watchTransportFailure(result) {
\t\tt.Fatal("watch replaced or recovered actual closed-pool root")
\t}
\tt.Log("actual closed pool remains exact internal error after fail-closed transport retirement; no invented auth cause")
}

'''
at=s.index('func TestWatchDefaultPGXInternalAndMixedRootsRemainFailures');s=s[:at]+insert+s[at:]
p.write_text(s,encoding='utf-8',newline='\n')
p=ROOT/'backend/go/tests/revocation_fallback_test.go';s=p.read_text(encoding='utf-8')
s=s.replace('"net/http/httptest"','"net/http/httptest"\n "net"\n "sync/atomic"\n "github.com/jackc/pgx/v5"',1)
s=s.replace('// Token expiry and Session authority failure must still notify and close, even\n// without a business revocation fact or realtime event.','// Token expiry retains its known invalidation frame. Database transport failure\n// closes the unverified connection without inventing a Session revocation fact.')
needle='\t\t\tgatewayDB, err := pgxpool.New(ctx, "")'
assert s.count(needle)==1
replacement='''\t\t\tlistener, err := net.Listen("tcp4", "127.0.0.1:0")
\t\t\tif err != nil { t.Fatal(err) }
\t\t\tdefer listener.Close()
\t\t\tport := uint16(listener.Addr().(*net.TCPAddr).Port)
\t\t\tvar unavailable atomic.Bool
\t\t\tcfg, err := pgxpool.ParseConfig("")
\t\t\tif err != nil { t.Fatal(err) }
\t\t\tcfg.BeforeConnect = func(_ context.Context, config *pgx.ConnConfig) error {
\t\t\t\tif unavailable.Load() { config.Host = "127.0.0.1"; config.Port = port; config.Fallbacks = nil }
\t\t\t\treturn nil
\t\t\t}
\t\t\tgatewayDB, err := pgxpool.NewWithConfig(ctx, cfg)'''
s=s.replace(needle,replacement,1)
s=s.replace('''\t\t\tif cause == "database" {
\t\t\t\tgatewayDB.Close()
\t\t\t}''','''\t\t\tif cause == "database" {
\t\t\t\t// Keep the live pool valid; its next default pgx Dial sees a real
\t\t\t\t// unavailable transport, rather than an internal use-after-close.
\t\t\t\tif err = listener.Close(); err != nil { t.Fatal(err) }
\t\t\t\tunavailable.Store(true)
\t\t\t\tgatewayDB.Reset()
\t\t\t}''',1)
needle='''\t\t\t_ = conn.SetReadDeadline(time.Now().Add(4 * time.Second))
\t\t\tif err = conn.ReadJSON(&event); err != nil {'''
replacement='''\t\t\t_ = conn.SetReadDeadline(time.Now().Add(4 * time.Second))
\t\t\tif cause == "database" {
\t\t\t\tif err = conn.ReadJSON(&event); err == nil { t.Fatalf("unavailable database invented a frame: %v", event) }
\t\t\t\tif failure, ok := err.(net.Error); ok && failure.Timeout() { t.Fatal("unverified socket remained open") }
\t\t\t\treturn
\t\t\t}
\t\t\tif err = conn.ReadJSON(&event); err != nil {'''
assert s.count(needle)==1;s=s.replace(needle,replacement,1)
p.write_text(s,encoding='utf-8',newline='\n')
subprocess.run(['H:/go/bin/gofmt.exe','-w',str(ROOT/'backend/go/gateway/gateway.go'),str(ROOT/'backend/go/gateway/watch_failure_test.go'),str(p)],check=True)
print('Removed redundant deadline assertion; preserved exact closed-pool internal-root control; corrected actual cached-plan panic assertion and F2 availability fixture/expectation only. Genuine expiry/replaced/logout controls unchanged.')
