from run import *
p=ROOT/'tests/clients/errors/desktop_retirement_consumers.mjs'
assert not p.exists()
p.write_bytes((EXT/p.name).read_bytes())
print('Added focused actual-consumer regression; original owner12/parallel37 files unchanged.')
