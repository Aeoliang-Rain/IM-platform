from run import *
nav=json.loads((ROOT/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-refresh-owner/current-navigation.json').read_text(encoding='utf-8'))
for r in nav['records']:
    if r['path'] in ['clients/desktop/src/application/ui/workspace.ts','backend/go/gateway/gateway.go','backend/go/gateway/session.go']:
        print(r['original_ordinal'],r['id'],r['path'],r['line'],r['column'],repr(r.get('token')),r['source'].strip()[:200])
print('COUNTS',nav['counts'])
