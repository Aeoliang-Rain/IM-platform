from run import *
old=TOP/'regular-review-e186054'
for name in ['logout_retirement_repro.mjs','watch_review_test.go']:
    (EXT/name).write_bytes((old/name).read_bytes())
overlay={'Replace':{str(ROOT/'backend/go/gateway/watch_review_test.go'):str(EXT/'watch_review_test.go')}}
(EXT/'go-overlay.json').write_text(json.dumps(overlay),encoding='utf-8')
for label,args,cwd in [
 ('desktop-red-compile',[PY,'-Xutf8','-B',EXT/'desktop_compile.py','red'],ROOT),
 ('desktop-review-defects-reproduced',[NODE,EXT/'logout_retirement_repro.mjs'],ROOT),
 ('gateway-review-defect-reproduced',['H:/go/bin/go.exe','test','-mod=readonly','-overlay',str(EXT/'go-overlay.json'),'-count=1','-run','^TestReviewWatchUnavailableDatabaseEmitsRevoked$','-v','./gateway'],ROOT/'backend/go')]:
    code=run(label,args,cwd)
    if code:sys.exit(code)
print('Both independent factual defects reproduced on unchanged e186 production; reproducer exit0 means defect assertions, not acceptance.')
