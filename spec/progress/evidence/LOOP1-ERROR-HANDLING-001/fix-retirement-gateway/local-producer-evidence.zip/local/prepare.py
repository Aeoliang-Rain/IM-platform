from run import *
import zipfile
EVID=ROOT/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-retirement-gateway'
EVID.mkdir(parents=True,exist_ok=False)
review=TOP/'regular-review-e186054'
receipt=review/'final-receipt.json'
assert hashlib.sha256(receipt.read_bytes()).hexdigest()=='0b367d78822ffb0f584b2dbf034d3a6839e6008309ef25b27cf114df0e9ccb6d'
seal=json.loads(receipt.read_text(encoding='utf-8'))
assert seal['source_lease']=='RELEASED' and seal['candidate_sha']=='e186054d964e11755e7bc48ae71f95d1ea125f2f'
items=list(seal['artifacts'])+[{'path':'final-receipt.json','bytes':receipt.stat().st_size,'sha256':hashlib.sha256(receipt.read_bytes()).hexdigest()}]
assert len(items)==316
archive=EVID/'regular-review-e186054-originals.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for entry in items:
        source=review/entry['path'];data=source.read_bytes()
        assert len(data)==entry['bytes'] and hashlib.sha256(data).hexdigest()==entry['sha256'],entry['path']
        z.writestr(entry['path'],data)
manifest={'source':'regular-review-e186054','source_receipt_sha256':hashlib.sha256(receipt.read_bytes()).hexdigest(),'review_artifacts':315,'receipt_plus_artifacts':316,'archive':archive.name,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_git_blob_oid':subprocess.check_output(['git','hash-object','--',str(archive)],cwd=ROOT,text=True).strip(),'entries':items,'entry_git_oids_not_claimed':True,'original_external_directory_immutable':True,'no_recursive_full_history_diff_regeneration':True}
(EVID/'original-review-archive.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
task=ROOT/'spec/tasks/review/LOOP1-ERROR-HANDLING-001.md'
t=task.read_text(encoding='utf-8').replace('owner: fresh recovery Fix Agent /root/recover_refresh_owner_finish','owner: fresh Fix Agent /root/fix_retirement_gateway',1)
section='''# Current retirement/Gateway Fix (2026-10-15)

Sole write-capable fresh Fix /root/fix_retirement_gateway resumes formal independent regular Review e186054 FAIL, findings F1-DESKTOP-RETIREMENT-CONSUMERS/P2 and F2-GATEWAY-DB-FAILURE-AS-REVOCATION/P2. Original315 artifacts plus receipt are preserved byte-for-byte in fix-retirement-gateway/regular-review-e186054-originals.zip with per-entry SHA/bytes and archive GitOID; original external directory remains immutable. Prior candidate is not accepted. Assigned and git-resolved root H:/.codex/worktrees/err/IM-platform; branch task/LOOP1-ERROR-HANDLING-001; clean starting SHA e186054d964e11755e7bc48ae71f95d1ea125f2f. Last accepted main35bd6f5f1091503f95a0282f730ed04233b0b6ea; main782unknown/two tracked edits untouched.

Authorized current production scope is only Desktop application/ui/workspace.ts and Go gateway/gateway.go; session.go only if actual narrow reason boundary requires it. Complete already-required expiry/logout cleanup despite observer retirement failure, await started requests, reset current busy and preserve distinct/falsy roots without retry. On safety-watch unavailability retire unverified transport without inventing session.revoked; retain genuine invalidation/replaced/logout/epoch and truthful failure propagation. No generic framework/dependency/cache/retry, contract/security/ACK/Frozen/ADR change. Android/Auth/Preferences/storage/native DB/Repository/SQL/all writes/Composer/drafts remain exact e186; no excluded SQLite WRITE or draft work.

Baseline frozen/PDF, architecture all, planning and Development exit0 before first task/source write, exact command history in fix-retirement-gateway/command-history.json (final snapshot follows). New targeted actual compiled Desktop producer/consumer controls preserve original owner12/parallel37; default pgx unavailable and actual watch/loopback WebSocket regression plus genuine invalidation/write-failure controls and applicable real PG/NATS Go tests required. Local result is not acceptance. Current Task remains review/S2 OPEN; NEW complete regular then DIFFERENT NEW specialized audit SAME final clean SHA, exact-head hosted CI/protected integration/actual-main/safe main synchronization all PENDING. No push/PR/CI/main write by Fix. Own Recorder R-FIX-RETIREMENT-GATEWAY prospective_resume parentR-ERROR-INTEGRATION-COORD-20261013 relatedR-REGULAR-E186054; startup direct/truncated-read/helper preparation gaps disclosed, old runs immutable. Next exact action: reproduce F1/F2 RED, minimal fix, current185 hashes/navigation/65 protected binding, targeted/local minimum checks, task-owned clean commit/Acceptance and sealed RELEASED handoff to Coordinator.

'''
t=t.replace('# Handoff\n','# Handoff\n\nCurrent sole Fix /root/fix_retirement_gateway; formal e186054 regular FAIL, F1/F2 repair IN_PROGRESS. Current record below and fix-retirement-gateway/handoff.md control this iteration; prior candidate-specific sections are immutable history. FinalSHA reviews/CI/integration/main/sync PENDING.\n\n'+section,1)
task.write_text(t,encoding='utf-8',newline='\n')
current=ROOT/'spec/progress/current.md'
c=current.read_text(encoding='utf-8')
c=c.replace('Execution Status: AWAITING_NEW_FINAL_SHA_REGULAR_REVIEW_AND_SPECIALIZED_AUDIT','Execution Status: FIXING_FORMAL_E186054_REGULAR_REVIEW_FINDINGS')
c=c.replace('## Immediately Relevant Completed Work\n','## Immediately Relevant Completed Work\n\nFormal fresh regular e186054 FAIL (two actual P2 findings) is immutable and archived with315 artifacts+receipt. New sole Fix /root/fix_retirement_gateway is repairing only Desktop expiry/logout retirement consumers and Gateway watch DB-unavailable classification; no source changes yet. Starting clean e186054/task branch and exact assigned root verified; frozen/PDF/architectureall/planning/Development baseline PASS. Current iteration: spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-retirement-gateway/handoff.md.\n',1)
c=c.replace('Sole /root/recover_refresh_owner_finish owns exact known-owned assigned task delta until clean commit/releasedreceipt.','Sole /root/fix_retirement_gateway owns this iteration task/source/evidence delta until clean commit/releasedreceipt.')
c=c.replace('Coordinator receives clean finalSHA/sealedreceipt/sourcelease RELEASED.','Fix completes minimal F1/F2 repairs, actual regressions,185/navigation/65 bindings and clean task-owned commit/Acceptance; Coordinator then receives new finalSHA/sealedreceipt/sourcelease RELEASED.')
current.write_text(c,encoding='utf-8',newline='\n')
(EVID/'handoff.md').write_text('''# Retirement/Gateway Fix recovery

IN_PROGRESS; fresh sole actor /root/fix_retirement_gateway; exact assigned root H:/.codex/worktrees/err/IM-platform, task/LOOP1-ERROR-HANDLING-001, clean base e186054d964e11755e7bc48ae71f95d1ea125f2f. Formal regular e186 FAIL F1/F2 preserved in original-review-archive.json. Startup baseline frozen/PDF/architectureall/planning/Development PASS; command-history final snapshot follows. No production writes at initial recovery registration. Task review/S2 OPEN; both new finalSHA reviews/hosted/integration/actual-main/safe main sync PENDING. Last accepted35bd6f5. No excluded SQLite WRITE/draft work. Sourcelease remains exclusively owned until clean committed sealed receipt.
''',encoding='utf-8')
event('repair_started',{'findings':['F1-DESKTOP-RETIREMENT-CONSUMERS','F2-GATEWAY-DB-FAILURE-AS-REVOCATION'],'base':'e186054d964e11755e7bc48ae71f95d1ea125f2f','actor':'/root/fix_retirement_gateway','scope':'Desktop Workspace lifecycle consumers; Gateway watch only, adjacent session reason only if necessary','task_state':'review','gate':'S2 OPEN','original_315_plus_receipt_verified':True})
print(json.dumps({'archive_entries':len(items),'archive_bytes':archive.stat().st_size,'source_lease':'EXCLUSIVE_FIX','task_state':'review'}))
