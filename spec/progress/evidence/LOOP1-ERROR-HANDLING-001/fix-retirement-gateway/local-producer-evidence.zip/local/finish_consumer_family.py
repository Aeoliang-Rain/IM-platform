from run import *
p=ROOT/'clients/desktop/src/application/ui/workspace.ts';s=p.read_text(encoding='utf-8')
old='''    this.publish({error:authentication?authentication.message:"Operation unavailable"});if(authentication?.kind==="session_expired")void this.expire();}'''
new='''    try{this.publish({error:authentication?authentication.message:"Operation unavailable"});}catch(observer){if(observer===error)throw error;throw new AggregateError([error,observer],"Operation and observer failed");}if(authentication?.kind==="session_expired")void this.expire();}'''
assert old in s;s=s.replace(old,new,1)
s=s.replace('''    if(failed)try{this.failure(failure,op===this.operation);}catch(error){if(error===failure)throw error;throw new AggregateError([failure,error],"Login failure and observer failed");}''','''    if(failed)this.failure(failure,op===this.operation);''',1)
start=s.index('  async restore(');end=s.index('  async refresh(',start)
new='''  async restore(endpoint:string){if(this.state.busy)return;const op=++this.operation;let failed=false,failure:unknown;
    try{this.publish({busy:true,error:null});await this.stop();const base=origin(endpoint);this.publish({endpoint:base});const auth=new Auth(base);this.auth=auth;const account=await auth.savedAccount();if(op!==this.operation)return;
      if(!account)this.publish({error:"No saved session for this server"});
      else{const repo=accountRepository(account);await repo.initialize();const ids=await repo.conversationIds(),selected="",messages:ReadonlyArray<ReadonlyArray<string|null>>=[];if(op!==this.operation)return;this.offlineRepository=repo;this.publish({offlineAccount:account,conversations:ids,selected,messages,error:"Showing saved history while the secure session resumes"});await this.updateList(repo,this.generation);const session=await auth.refresh();if(op===this.operation)await this.bind(session,op);}
    }catch(error){failed=true;failure=error;}
    finally{if(op===this.operation)try{this.publish({busy:false});}catch(error){failure=failed&&error!==failure?new AggregateError([failure,error],"Restore and observer failed"):error;failed=true;}}
    if(failed)this.failure(failure,op===this.operation);
  }
'''
s=s[:start]+new+s[end:]
s=s.replace('''let failed=false,failure:unknown;this.publish({busy:true,error:null});try{const session=await owner.refresh();''','''let failed=false,failure:unknown;try{this.publish({busy:true,error:null});const session=await owner.refresh();''',1)
s=s.replace('''      try{this.failure(failure,op===this.operation);}catch(error){if(error===failure)throw error;throw new AggregateError([failure,error],"Logout and observer failed");}}''','''      this.failure(failure,op===this.operation);}
''',1)
p.write_text(s,encoding='utf-8',newline='\n')
p=ROOT/'tests/clients/errors/desktop_retirement_consumers.mjs';s=p.read_text(encoding='utf-8')
needle="assert.deepEqual(unhandled,[]);process.off('unhandledRejection',onUnhandled);"
addition='''for(const [name,options,wanted] of [
  ['retirement-observer',{observer},[observer]],
  ['retirement-and-final',{observer,finalObserver},[observer,finalObserver]],
  ['falsy-retirement',{observer:undefined},[undefined]]
]){
  const f=fixture(options);let rejected=false,error;await f.w.restore(f.auth.endpoint).catch(root=>{rejected=true;error=root;});assert(rejected);const graph=roots(error);for(const root of wanted)assert(graph.has(root));if(wanted.length===1)assert.equal(error,wanted[0]);assert.equal(f.w.state.busy,false);assert.equal(f.w.state.session,null);assert.equal(f.w.auth,f.auth);assert.equal(f.closes,1);assert.equal(f.sync.state.status,'retired');assert.deepEqual(f.calls,[]);checks++;console.log('RESTORE '+name+' PASS');
}
{
  let primary;globalThis.window={__TAURI_INTERNALS__:{invoke:async command=>{if(command==='credential_read')return 'public-fixture';assert.equal(command,'native_https');return [503,{'content-type':'application/json'},[...new TextEncoder().encode('{"error":{"code":"REQUEST_FAILED"}}')]];}}};
  const auth=new Auth('https://fixture.invalid');auth.session=session;auth.slot='public-fixture';const request=auth.request.bind(auth);auth.request=async(...args)=>{try{return await request(...args)}catch(error){primary=error;throw error;}};
  const w=new Workspace();w.auth=auth;w.state.session=session;const observer=new Error('actual known failure observer');w.observe(()=>{if(w.state.error)throw observer});let error;await w.refresh().catch(root=>error=root);assert(primary);const graph=roots(error);assert(graph.has(primary));assert(graph.has(observer));assert.equal(w.state.busy,false);assert.equal(w.auth,auth);assert.equal(w.state.session,session);checks++;console.log('REFRESH actual503 and error-publication observer roots PASS');
}
{
  const w=new Workspace();const auth=new Auth('https://fixture.invalid');auth.session=session;w.auth=auth;w.state.session=session;const first=new Error('initial busy observer'),last=new Error('final busy observer');w.observe(()=>{throw w.state.busy?first:last});let error;await w.refresh().catch(root=>error=root);const graph=roots(error);assert(graph.has(first));assert(graph.has(last));assert.equal(w.state.busy,false);assert.equal(w.auth,auth);assert.equal(auth.session,session);checks++;console.log('REFRESH initial and final busy observer roots PASS');
}
'''
assert needle in s;s=s.replace(needle,addition+needle,1);p.write_text(s,encoding='utf-8',newline='\n')
print('Actual restore/failure-boundary defects repaired within same Workspace; current literal stop consumer family retains final observer roots. Removed duplicate per-caller failure-publication wrappers; no generic framework.')
