from run import *
EVID=ROOT/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-retirement-gateway'
handoff='''# Retirement/Gateway local Fix handoff

Task LOOP1-ERROR-HANDLING-001 remains review, S2 OPEN. Sole fresh Fix /root/fix_retirement_gateway; assigned and Git-resolved root H:/.codex/worktrees/err/IM-platform, branch task/LOOP1-ERROR-HANDLING-001, clean starting e186054d964e11755e7bc48ae71f95d1ea125f2f. Last accepted main35bd6f5f1091503f95a0282f730ed04233b0b6ea. Exact new committed candidate/clean Acceptance/postclean and released lease are in external fix-retirement-gateway/final-receipt.json; this document never accepts itself. Main782unknown/two tracked edits untouched. No push/PR/hosted CI/integration/actual-main/synchronization performed by Fix.

## Formal Review and minimum repairs

Fresh independent /root/regular_review_e186054 full185/323/65 regular Review FAIL is preserved: original315 artifacts plus receipt,316 archive entries, exact per-entry SHA/bytes and archive GitOID in original-review-archive.json. Original receiptSHA0b367d78822ffb0f584b2dbf034d3a6839e6008309ef25b27cf114df0e9ccb6d. No historical raw artifact or verdict changed; no new recursive50MB full-history diff generated.

F1 actual compiled Auth/Workspace/Send/Sync and literal IPC reproduces expiry stop-observer failure skipping every Auth.clear (zero removes, both pointers/Auth.session retained) and logout stop-observer failure abandoning a launched Auth.logout (late native HTTPS unknown unhandled, busy true). New expiry always settles stop then attempts its original clear once. Logout waits its already-owned Auth.logout and stop with standard allSettled. Current operation busy=false publication is attempted and distinct primary/retirement/falsy/observer roots survive; single root retains identity, no credential retry or second close.

Same literal stop consumer family was inspected and actual producers reproduced before repair: login stop ran before its finally and left busy true; restore finally busy observer replaced stop observer; actual Auth.request503 refresh known ApiFailure was replaced by Workspace.failure publication observer. Login/restore now capture original operation through current busy finalization. Missing saved account preserves existing explicit message without an early return swallowing final observer failure. Refresh initial busy publication is inside existing operation boundary; its existing operation+generation+Auth owner+null-session retirement gate is unchanged. Existing Workspace.failure preserves an original known graph plus distinct observer once; duplicate per-caller publication captures removed. Bind errors flow through these current callers. These are direct current literal lifecycle captures, not a new error framework. Existing resources, owner/generation guards and known unavailable messages remain. No detached new owner/credential retry is added.

F2 actual default pgx refused connection previously became session.revoked/REVOKED without an authoritative session fact. Watch now defers existing idempotent connection close, returns original non-shared.Error unchanged and never consults revocationReason for it. Actual known authentication invalidation retains the existing exact-identity reason and revoke path. The existing serve goroutine closes known-only transport with a safe constant observation; every branch of a current pgx multi-error tree must be known network failure. Mixed/internal trees panic with original error at that real goroutine boundary. net.Error already includes deadline errors; redundant explicit deadline branch removed. No Core import, new shared API, new dependency, retry/backoff/cache, security policy or contract change. session.go remains exact e186.

## Current tests and evidence limits

Fresh exact current Desktop strict compile with locked TypeScript5.9.3; original owner12, parallel37 and full Auth/Workspace/appearance/native/UTF8/account controls PASS with all original assertions. Original Auth is linked only by replacing its compiled-output import prefix to isolated current output; original test source unchanged. New36 actual compiled Auth/Workspace/Send/Sync controls cover expiry/logout/login/restore/refresh: normal controls, late unknown, primitive0/null/undefined/false/empty string, distinct observer/close/cleanup/final roots, same-root identity/no cycles, actual credential intent counts, one close/timer cancelled, no unhandled late root and newer operation publication guard. Only literal IPC/socket/observer producers are controlled. No installed GUI, native credential incidence, native DB/SQLite WRITE/draft or visual acceptance is claimed.

Go final focused real default pgx refused/internal-only/mixed joined roots, exact actual closed-pool sentinel identity, nine complete-tree controls, known expiry and existing write-failure/reason tests PASS. Final go test -mod=readonly -race -count=1 ./... and go vet -mod=readonly ./... PASS. The ordinary no-DB suite has explicit integration skips and is not live acceptance. Actual disposable PostgreSQL16/NATS2.10 DB_TEST_ENABLE=1 full Go suite PASS with no skip, including canonical existing Auth/WSS/Message/Sync/Outbox and REPLACED/LOGOUT/REPLACED_THEN_LOGOUT/expiry controls.

One existing revocation_fallback_test hunk corrects F2's erroneous assertion: old database branch called gatewayDB.Close (internal use-after-close) and demanded REVOKED. That is not authority to announce a session fact under WSS README5/Frozen7.2/7.3. The corrected branch first actually binds against live PG, then test-only existing pgx BeforeConnect+Reset switches default Dial to its owned closed loopback port; it strictly requires transport closure without any JSON frame, and rejects timeout. Genuine expiry/replaced/logout assertions are retained. Closed-pool coverage is retained separately: actual pool.Close -> authenticate -> watch returns the exact original internal sentinel, is never classified as transport, and closes without a frame. No string matching or new puddle dependency legalizes it.

Real serve->watch unknown/internal propagation is tested in a child Go test process after successful actual auth.bind. Parent creates only a fresh watch_<UUID> schema with a minimal six-column test fixture sessions; child search_path is exactly that schema. It changes that isolated table's epoch type; locked default pgx detects cached-plan type change first. Child result strictly matches original PgError SQLSTATE0A000 plus created-by-actual-hub.serve stack, not arbitrary panic/close. Parent checks successful DROP SCHEMA for its exact fresh schema even after child panic; shared public.sessions is untouched. No additional catalog query is claimed. Outer Docker resources have exact own-project labels verified before down; own containers/volumes/networks and unique migrate tag removed. Whole disposable fixture DB destroyed; public shared images/build cache preserved. This is local HTTP/WS/PostgreSQL evidence, not hosted/TLS/full-client acceptance.

Final frozen/PDF, architecture --scope all, planning,82 architecture tests(one existing Windows skip) and Development are required; exact observed final results live in final-static.json/command-history.json. Clean committed Acceptance/postclean follows external sealed receipt. A prior pre-family static PASS is labelled by its actual command; it does not stand for final current source without the fresh final result. Local/Recorder validity never establishes independent Task/Gate PASS.

## Inputs, protected bytes and research

185 production inputs, current333 composite ordinal/path/ID navigation records=298 executable+35 nonexecutable (not333 catches). Original323 identities including both RH294 remain; ten necessary current literal captures/settled/watch boundaries added. RH089 truthfully maps to the existing central failure-publication catch after duplicate logout capture removal. All current hashes/line/column/token and fault→present authority→actual recovery agree with production-inventory.json. These are local bindings, not inherited semantic acceptance. Only workspace.ts and gateway.go production differ from e186;183 other production inputs unchanged.65 protected inputs exact e186:63 whole accepted35 baseline plus two earlier Human contiguous READ mapper exceptions; same SELECT SQL and every other Repository byte unchanged. Android/Auth/Preferences/storage/nativeDB/Repository/schema/init/transactions/all writes/Composer/drafts unchanged; no SQLite WRITE failure or draft problem handled.

All79 current Android main/androidTest/build graph inputs exactly match prior sealed e186 producer evidence. Prior owned API34/5612 owner10/HTTP32/WSS21 and historical unchanged Send66+Read21/Sync69+Read33+contiguous18 remain qualified old observations, never fresh executions or independent verdicts. No unrelated native/Android rebuild. Current Desktop source/compiled graph is freshly sealed; Go dependencies unchanged.

Own R-FIX-RETIREMENT-GATEWAY prospective_resume parentR-ERROR-INTEGRATION-COORD-20261013 relatedR-REGULAR-E186054, visible Human prompt SHAaa099ee739463e81b69740faa173dfa3a314967d043f225c448a609ffa985698. Direct startup/read-only diagnostics/external helper preparation and truncated tool output gaps disclosed; no complete trace/hidden metadata claimed. All real Recorder command outcomes/raw failures retained. Initial Go cwd failure corrected with explicit go -C. New test first incorrectly expected observer-only identity when actual known cleanup plus observer requires both roots; corrected only that new expectation and added error-observer proof. First live suite correctly exposed actual PgError0A000 before expected scan and old closed-pool REVOKED assertion; root/producer expectations corrected as above. First binding completed metadata then its cross-drive atomic generated-pyc move failed; exact leaf copy+hash+unlink preserved only this run's generated bytecode externally. Child Python bytecode disabled thereafter. Live-driver status JSON is latest snapshot; original first failing outer command output remains immutable; unavailable first per-child timing is not backfilled. Old research runs and root run untouched.

Repository command/research snapshot is explicitly bounded before own final finish; external final receipt seals finished Recorder+structural validation and all final artifacts. Recorder PASS means structure/local completion only.

## Required next action

Coordinator receives final clean task-owned commit and RELEASED receipt. NEW fresh complete regular185/333/65 review then DIFFERENT NEW uninvolved specialized audit on SAME final SHA; any Fix repeats both. Both PASS precede push/CI-triggering PR. Then exact-head actual required hosted jobs, protected integration, actual-main and safe H:/IM-platform synchronization preserving unknown work. Taskdone/S2PASS/mainSHA/synchronization all PENDING. Source lease remains exclusive until clean committed sealed receipt; no worktree commit is completion.
'''
(EVID/'handoff.md').write_text(handoff,encoding='utf-8')
current='''# Current Execution State

Current Loop: Loop 1
Current Stage: S2
Current Gate: S2
Gate Status: OPEN
Current Batch: LOOP1-ERROR-HANDLING-001
Batch Status: REVIEW_PENDING
Current Task: LOOP1-ERROR-HANDLING-001
Current Task State: review
Execution Status: FINALIZING_RETIREMENT_GATEWAY_FIX_FOR_NEW_FINAL_SHA_REVIEWS

## Immediately Relevant Completed Work

Formal fresh regular e186054 FAIL F1/F2 archived315+receipt. Fresh sole Fix /root/fix_retirement_gateway repairs actual Desktop retirement consumers/final observer roots and Gateway DB-unavailable false revocation. Current185/333(298 executable35 nonexecutable)/65protected bound; only2 production files differ e186, Android79graph unchanged. Actual fresh Desktop36+owner12+parallel37/Auth and Go default producer/closedpool/internal/genuine invalidation controls PASS; real PG16/NATS2.10 fullGo noSKIP, finalrace/vet PASS. Full current method/results/limits: spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-retirement-gateway/handoff.md.

## Current Blockers

NEW complete regular then DIFFERENT NEW specialized audit SAME final clean SHA PENDING. Exact-head hosted CI/protected integration/actual-main/safe H:/IM-platform synchronization PENDING. No push/CI-triggering PR before both reviews PASS. Taskdone/S2PASS forbidden; local evidence is not acceptance.

## Verification

- Command: `python -Xutf8 -B tools/verify_frozen_architecture.py`
  - Result: final current frozen/PDF/architectureall/planning/82tests results recorded in final-static.json; local only, one existing Windows skip.
  - Evidence: `spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-retirement-gateway/final-static.json`
- Command: `pwsh -NoProfile -File tools/verify-loop1-ctrl-002.ps1 -Mode Development`
  - Result: final current Development/clean committed Acceptance/postclean results follow command-history and sealed external receipt; local only.
  - Evidence: `spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-retirement-gateway/command-history.json`

## Changed Files or Migrations

Production only Desktop ui/workspace.ts and Go gateway/gateway.go relativee186. Focused actual tests and F2 false fixture/expectation correction; no weakening genuine revoked/replaced/logout/expiry/write-failure assertions. Inventory/navigation/evidence/recovery metadata only.65protected exacte186:63wholeaccepted35 plus2prior Human READmapper exceptions; SQL/allotherRepo bytes unchanged. No Android/Auth/Prefs/nativeDB/SQL/write/Composer/draft/Frozen/ADR/contracts/security/ACK/dependency change.

## Known Failures, Risks, and Assumptions

Preserved cwd failure, expectedRED, newtest mistaken observer-only identity, real0A000 preceding intendedscan, oldclosedpoolfalseREVOKED expectation, cross-drive generated-pyc move failure; exact fixes/limits in handoff. Own latest live-driver snapshots do not reconstruct unavailable first per-child timing; outer raw failure output preserved. Startup/direct diagnostic/helper/truncated-read gaps disclosed. Qualified old API34graphs are not new runtime observations. Local full-scope bindings are not independent semantic acceptance.

## Next Exact Action

Complete final static/Development, task-owned clean commit/Acceptance/postclean, sealed RELEASED receipt. Coordinator NEW complete regular185/333/65 -> DIFFERENT NEW specialist SAME finalSHA; any Fix repeats both. BothPASS then exact-head required hostedCI/protectedintegration/actual-main/safe main sync. All acceptance/mainSHA/synchronization PENDING.

## Last Known Good Commit

`35bd6f5f1091503f95a0282f730ed04233b0b6ea` accepted I18N/main. Candidate exact committed task HEAD is externally sealed; candidate commit is not main acceptance/sync.

## Latest Checkpoint

`spec/progress/checkpoints/2026-10-15-error-handling-retirement-gateway-review-candidate.md` local recovery only.

## Uncommitted Changes / Ownership

Sole /root/fix_retirement_gateway owns this iteration until clean commit/released receipt. Exact assigned root H:/.codex/worktrees/err/IM-platform, branch task/LOOP1-ERROR-HANDLING-001. Main H:/IM-platform782unknown/two tracked edits untouched. Own disposable PG/NATS resources removed by verified labels; owned generated bytecode preserved externally. No private device/globaltrust/ACL/main write.

## Architecture Conflicts / ACP / ADR

None. Existing authorized TypeScript/Go and literal lifecycle boundaries only. Both final reviews/CI/integration/main/sync PENDING; S2 OPEN.
'''
(ROOT/'spec/progress/current.md').write_text(current,encoding='utf-8')
task=ROOT/'spec/tasks/review/LOOP1-ERROR-HANDLING-001.md';t=task.read_text(encoding='utf-8')
start=t.index('# Current retirement/Gateway Fix (2026-10-15)');end=t.index('# Current refresh owner recovery',start)
t=t[:start]+'''# Current retirement/Gateway Fix (2026-10-15)

Fresh sole Fix /root/fix_retirement_gateway repairs formal full regular e186054 FAIL F1-DESKTOP-RETIREMENT-CONSUMERS/P2 and F2-GATEWAY-DB-FAILURE-AS-REVOCATION/P2. Exact assigned and Git-resolved root H:/.codex/worktrees/err/IM-platform, branch task/LOOP1-ERROR-HANDLING-001, clean starting e186054d964e11755e7bc48ae71f95d1ea125f2f. Original315+receipt316archive entries verified, immutable receiptSHA0b367d78822ffb0f584b2dbf034d3a6839e6008309ef25b27cf114df0e9ccb6d. Full local repair, per-hunk test correction, authority/minimality, actual commands/limits/failures/isolation/history: spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-retirement-gateway/handoff.md.

Only2 production changes: Workspace mandatory expiry clear/logout settlement and actual same login/restore/refresh/failure-publication observer roots; Gateway safety-watch raw DB error closes without session.revoked, original unknown/internal root escapes real serve goroutine, complete known-network tree closes safely. No new error framework/cache/retry/dependency/contract/security/ACK or session.go change. Current185/333(298exec35nonexec) exact input/navigation;65protected exacte186,63accepted whole+2prior Human contiguous READ exceptions, same SQL/allotherRepo bytes. Android/Auth/Prefs/nativeDB/Repository/schema/init/transactions/all writes/Composer/drafts exacte186. No SQLite WRITE/draft issue work.

Fresh Desktop strictcompile/new36/originalowner12/parallel37/Auth PASS. Actual defaultpgx refused/mixed/internal/closedpool/knownexpiry/writefail PASS; actual disposablePG16/NATS2.10 DB_TEST_ENABLE1 fullGo noSKIP PASS, finalrace/vet PASS. Existing F2 database test now models actual defaultDial unavailable and strictly requiresclose/noJSON/notimeout; genuine expiry/replaced/logout assertions retained, exactactualclosedpoolinternal control retained. New realserve->watch child originalPgError0A000/actualserve stack strictPASS; only ownrandomschema changed, parentcheckedDROP, sharedpublic.sessions untouched, entireownedfixtureproject removed. Android79graph binds qualified prior API34owner10/HTTP32/WSS21, no unnecessary native execution. Finalstatic/Development/clean committedAcceptance/postclean and exact finalSHA in commandhistory/externalsealedreceipt; local/Recorder not acceptance.

Preserved all raw failures including initialcwd/expectedRED/newtestexpectation/live0A000+closedpool/move-crossdrive; exact current limitations/gaps in handoff. Own Recorder R-FIX-RETIREMENT-GATEWAY prospective_resume parentR-ERROR-INTEGRATION-COORD-20261013 relatedR-REGULAR-E186054, incompleteprestart; never edits/finishes old/root runs. Lastaccepted35bd6f5; main782unknown/two tracked edits untouched. Sourcelease exclusive until final clean receipt RELEASED.

Task remains review/S2 OPEN. NEW complete regular185/333/65 then DIFFERENT NEW specialist SAMEfinalcleanSHA PENDING; anyFix repeatsboth. No push/CI-triggeringPR until bothPASS; exacthead hostedrequiredjobs/protectedintegration/actual-main/safe H:/IM-platform sync/mainSHA allPENDING. Taskdone/S2PASS forbidden. New stable localcheckpoint 2026-10-15-error-handling-retirement-gateway-review-candidate.md. Everything below is historical prior-candidate recovery, not current acceptance.

'''+t[end:]
task.write_text(t,encoding='utf-8')
checkpoint='''# Local retirement/Gateway review candidate recovery

Task LOOP1-ERROR-HANDLING-001 review; S2 OPEN. Assigned task branch task/LOOP1-ERROR-HANDLING-001. Starting e186054d964e11755e7bc48ae71f95d1ea125f2f; final candidate SHA is exact clean task HEAD in external fix-retirement-gateway/final-receipt.json. Last accepted main35bd6f5f1091503f95a0282f730ed04233b0b6ea. No contract/schema/migration/fixture version transition; Frozen/PDF/contracts unchanged.

Local stable36actual Desktop consumer controls+originalowner12/parallel37/Auth, actualdefaultpgx+WS+realPG16/NATS2.10 fullGo/race/vet;185/333/65 exact current binding, qualified unchanged Android79graph. Full tests/failures/isolation/limitations in fix-retirement-gateway/handoff.md; final minimum verifiers/Acceptance/Recorder bound externally. These are local recovery facts, not Task/Stage acceptance.

NEW full regular then DIFFERENT NEW error specialist SAME finalSHA, hostedCI/protectedintegration/actualmain/safe main synchronization all PENDING. Sourcelease releases only after clean sealed receipt. No main/GitHub writes. Coordinator preserves782unknown/two tracked main edits. Any Fix repeats both finalSHA reviews before CI.
'''
(ROOT/'spec/progress/checkpoints/2026-10-15-error-handling-retirement-gateway-review-candidate.md').write_text(checkpoint,encoding='utf-8')
commands=[json.loads(line) for line in (EXT/'commands.jsonl').read_text(encoding='utf-8').splitlines()]
(EVID/'command-history.json').write_text(json.dumps({'scope':'Bounded precommit command snapshot; final external receipt seals complete run/Acceptance/finish. Raw failed outputs retained.','commands':commands},indent=2)+'\n',encoding='utf-8')
static=[c for c in commands if c['label'].startswith('final-')]
(EVID/'final-static.json').write_text(json.dumps({'scope':'Local observed commands; family-final refresh follows, never hosted acceptance','commands':static},indent=2)+'\n',encoding='utf-8')
print('Task/current/checkpoint/handoff updated review/S2 OPEN, current333 graph and all acceptance pending; exact run snapshot created.')
