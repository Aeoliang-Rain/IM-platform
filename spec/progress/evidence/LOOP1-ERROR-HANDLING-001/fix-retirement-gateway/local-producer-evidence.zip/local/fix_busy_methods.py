from run import *
p=ROOT/'clients/desktop/src/application/ui/workspace.ts';s=p.read_text(encoding='utf-8')
start=s.index('  async register(');end=s.index('  async login(',start)
new='''  async register(username:string,password:string,confirmation:string){
    if(this.state.busy)return false;
    if(password!==confirmation){this.publish({error:"Passwords do not match"});return false;}
    if(!/^[A-Za-z0-9][A-Za-z0-9._-]{2,63}$/.test(username)||[...password].length<12||[...password].length>256){this.publish({error:"Use a 3–64 character username and a 12–256 character password"});return false;}
    const op=++this.operation;let completed=false,failed=false,rejected=false,failure:unknown;
    try{this.publish({busy:true,error:null});await new Auth(this.state.endpoint).register(username,password);completed=op===this.operation;}
    catch(error){failed=true;failure=error;try{this.failure(error,op===this.operation);}catch(propagated){failure=propagated;rejected=true;}}
    finally{if(op===this.operation)try{this.publish({busy:false});}catch(error){failure=failed&&error!==failure?new AggregateError([failure,error],"Registration and observer failed"):error;rejected=true;}}
    if(rejected)throw failure;return completed;
  }
''';s=s[:start]+new+s[end:]
start=s.index('  async search(');end=s.index('  async add(',start)
new='''  async search(query:string){if(!this.auth)return;const auth=this.auth,g=this.generation;let failed=false,rejected=false,failure:unknown;
    try{this.publish({busy:true,results:[],error:null});const results=await auth.search(query);if(g===this.generation)this.publish({results});}
    catch(error){failed=true;failure=error;try{this.failure(error,g===this.generation);}catch(propagated){failure=propagated;rejected=true;}}
    finally{if(g===this.generation)try{this.publish({busy:false});}catch(error){failure=failed&&error!==failure?new AggregateError([failure,error],"Search and observer failed"):error;rejected=true;}}
    if(rejected)throw failure;
  }
''';s=s[:start]+new+s[end:]
start=s.index('  async add(');end=s.rindex('\n}')
new='''  async add(id:string){if(!this.auth)return;const auth=this.auth,g=this.generation;let failed=false,rejected=false,failure:unknown;
    try{this.publish({busy:true,error:null});const conversation=await auth.add(id);if(g!==this.generation)return;const revision=++this.friendRevision;const friends=await auth.friends();if(g!==this.generation||auth!==this.auth)return;if(revision===this.friendRevision)this.publish({friends,conversations:[...new Set([...this.state.conversations,conversation])]});await this.open(conversation);}
    catch(error){failed=true;failure=error;try{this.failure(error,g===this.generation);}catch(propagated){failure=propagated;rejected=true;}}
    finally{if(g===this.generation)try{this.publish({busy:false});}catch(error){failure=failed&&error!==failure?new AggregateError([failure,error],"Friend add and observer failed"):error;rejected=true;}}
    if(rejected)throw failure;
  }
''';s=s[:start]+new+s[end:];p.write_text(s,encoding='utf-8',newline='\n')
p=ROOT/'tests/clients/errors/desktop_retirement_consumers.mjs';s=p.read_text(encoding='utf-8');needle="assert.deepEqual(unhandled,[]);process.off('unhandledRejection',onUnhandled);"
addition='''for(const method of ['register','search','add']){
  let primary;const request=Auth.prototype.request;Auth.prototype.request=async function(...args){try{return await request.apply(this,args)}catch(error){primary=error;throw error;}};
  globalThis.window={__TAURI_INTERNALS__:{invoke:async command=>{assert.equal(command,'native_https');return [503,{'content-type':'application/json'},[...new TextEncoder().encode('{"error":{"code":"REQUEST_FAILED"}}')]];}}};
  const w=new Workspace(),auth=new Auth('https://fixture.invalid');auth.session=session;w.auth=auth;w.state.session=session;let publications=0;const first=new Error('actual failure observer A'),final=new Error('actual busy observer B');w.observe(()=>{if(w.state.error)throw ++publications===1?first:final});let error;
  try{const operation=method==='register'?w.register('fixture-user','fixture-only-input','fixture-only-input'):method==='search'?w.search('fixture'):w.add(session.userId);await operation.catch(root=>error=root);}finally{Auth.prototype.request=request;}
  assert(primary);const graph=roots(error);assert(graph.has(primary));assert(graph.has(first));assert(graph.has(final));assert.equal(publications,2);assert.equal(w.state.busy,false);assert.equal(w.auth,auth);assert.equal(w.state.session,session);checks++;console.log(method.toUpperCase()+' actual503 primary and failure/final observer roots PASS');
}
'''
assert needle in s;s=s.replace(needle,addition+needle,1);p.write_text(s,encoding='utf-8',newline='\n')
print('Actual register/search/add503 observerA/finalB defects repaired with direct existing-operation captures. Register bool, search generation/results and add owner/revision gates preserved. No generic abstraction.')
