from run import *
p=ROOT/'backend/go/gateway/watch_failure_test.go';assert not p.exists()
data=(EXT/p.name).read_text(encoding='utf-8').replace(' "encoding/json"\n','').replace('\nvar _ = json.Valid\n','\n')
p.write_text(data,encoding='utf-8',newline='\n')
subprocess.run(['H:/go/bin/gofmt.exe','-w',str(p)],check=True)
print('Added actual default pgx watch transport/internal/mixed and known-expiry tests, plus live PostgreSQL actual goroutine failure control. Existing tests unchanged.')
