from run import *
p=ROOT/'tests/clients/errors/desktop_retirement_consumers.mjs';s=p.read_text(encoding='utf-8')
s=s.replace("if(nullPublications>1&&'finalObserver' in options)throw options.finalObserver;","if(nullPublications>1&&'finalObserver' in options)throw options.finalObserver;if(nullPublications>2&&'errorObserver' in options)throw options.errorObserver;")
s=s.replace("['known-with-final-observer',{cleanup:'Secure credential storage unavailable',finalObserver},false,[finalObserver]],","['known-with-final-observer',{cleanup:'Secure credential storage unavailable',finalObserver},false,[finalObserver]],\n  ['known-with-error-observer',{cleanup:'Secure credential storage unavailable',errorObserver:finalObserver},false,[finalObserver]],")
s=s.replace("if(wanted.length===1)assert.equal(error,wanted[0]);","if(wanted.length===1&&!('cleanup' in options))assert.equal(error,wanted[0]);if('cleanup' in options&&options.cleanup==='Secure credential storage unavailable')assert([...graph].some(root=>root instanceof Error&&root.message==='Secure credential storage unavailable'),'preserve known cleanup root when observer also fails');")
p.write_text(s,encoding='utf-8',newline='\n')
print('Corrected new test expectation: known cleanup plus observer has two roots, not observer identity alone; added actual error-publication observer control. Product unchanged.')
