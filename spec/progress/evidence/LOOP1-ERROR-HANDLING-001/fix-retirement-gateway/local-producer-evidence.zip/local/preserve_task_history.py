from run import *
path=ROOT/'spec/tasks/review/LOOP1-ERROR-HANDLING-001.md';current=path.read_text(encoding='utf-8');before=subprocess.check_output(['git','show','e186054d964e11755e7bc48ae71f95d1ea125f2f:'+str(path.relative_to(ROOT)).replace('\\','/')],cwd=ROOT).decode('utf-8');marker='# Current refresh owner recovery (2026-10-15)'
old=before[before.index(marker):];prefix=current[:current.index(marker)];modified=current[current.index(marker):]!=old
path.write_text(prefix+old,encoding='utf-8')
assert path.read_text(encoding='utf-8')[path.read_text(encoding='utf-8').index(marker):]==old
print(json.dumps({'historical_suffix_exact_e186054':True,'corrected_any_current_count_replacement_in_historical_suffix':modified,'historical_suffix_sha256':hashlib.sha256(old.encode('utf-8')).hexdigest(),'reason':'Current count updates scoped to current section; prior candidate history preserved byte-exact.'}))
