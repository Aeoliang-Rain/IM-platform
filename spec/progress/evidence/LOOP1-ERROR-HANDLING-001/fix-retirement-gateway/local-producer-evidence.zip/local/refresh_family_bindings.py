from run import *
EVID=ROOT/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-retirement-gateway'
invpath=ROOT/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001/production-inventory.json';inv=json.loads(invpath.read_text(encoding='utf-8'))
navpath=EVID/'current-navigation.json';nav=json.loads(navpath.read_text(encoding='utf-8'))
path='clients/desktop/src/application/ui/workspace.ts';data=(ROOT/path).read_bytes();lines=data.decode('utf-8').splitlines();digest=hashlib.sha256(data).hexdigest()
def locate(anchor,token='catch'):
    found=[n for n,line in enumerate(lines,1) if anchor in line];assert len(found)==1,(anchor,found)
    n=found[0];return n,lines[n-1].index(token)+1
wa='Frozen §6.1/§7.1/ADR-0009 account/credential lifecycle; error-handling.md normal-call-chain primary/retirement/falsy/observer roots and mandatory current operation finalization'
for r,i in zip(nav['records'],inv['retained_sites']):
    if r['path']!=path:continue
    if r['id']=='RH085':
        n,c=locate('const session=await owner.login(username,password);if(op===this.operation)await this.bind(session,op);}')
        r.update(specific_fault='Actual initial login publication, old stop, original Auth cleanup/request or bind fails',present_authority=wa,actual_recovery_or_failure='Capture original root through current busy finalization even when stop throws before Auth.clear/new login. No unstarted request or cleanup is retried; old owner remains referenced after failed stop. Distinct final and known failure-publication observer roots propagate.')
    elif r['id']=='RH086':
        n,c=locate('}catch(error){failed=true;failure=error;}') if False else (0,0)
        start=next(n for n,line in enumerate(lines,1) if line.startswith('  async restore('));end=next(n for n,line in enumerate(lines,1) if line.startswith('  async refresh('))
        n=next(n for n in range(start,end) if '}catch(error){failed=true;failure=error;}' in lines[n-1]);c=lines[n-1].index('catch')+1
        r.update(specific_fault='Actual restore stop/read/refresh/bind or observer fails, including distinct final busy observer',present_authority=wa,actual_recovery_or_failure='Preserve original root and current busy=false observer root. Missing saved account remains the existing explicit message; no pending early return can swallow a captured final observer failure. Existing read and account behavior unchanged, no SQLite WRITE/draft change.')
    elif r['id']=='RH087':
        n,c=locate('async refresh(){if(this.state.busy||!this.auth)return;')
        r.update(specific_fault='Actual refresh initial busy publication or Auth request/bind fails',present_authority=wa,actual_recovery_or_failure='Initial publication is inside same operation catch/finalization. Existing exact operation+generation+Auth owner+null-session retirement remains; all distinct final or error-publication observers preserve the original root. Known-only failures remain honest unavailable UI.')
    elif r['id']=='RH089':
        n,c=locate('try{this.publish({error:authentication?authentication.message:')
        r.update(specific_fault='Actual existing known failure publication listener throws while propagating an operation result',present_authority=wa,actual_recovery_or_failure='The existing Workspace.failure boundary preserves original known operation graph and distinct publication observer in one standard AggregateError; same root keeps identity. Current callers no longer duplicate this capture. Unknown operation roots continue unchanged; no error framework/category/retry added.')
        i['operation']='Workspace.failure (current centralized existing projection boundary)'
    else:
        matches=[n for n,line in enumerate(lines,1) if line==r['source']];assert len(matches)==1,(r['id'],matches)
        n=matches[0];c=r['column']
    r.update(line=n,column=c,source=lines[n-1],source_sha256=digest)
    for key in ['line','column','source','source_sha256','specific_fault','present_authority','actual_recovery_or_failure']:i[key]=r[key]
    i['actual_source']=r['source'];i['specific_ground_and_recovery']=' → '.join(r[k] for k in ['specific_fault','present_authority','actual_recovery_or_failure']);i['authority']=r['present_authority']
for name,anchor,fault,recovery in [
 ('login','"Login and observer failed"','Actual login current busy=false publication observer fails after a captured operation/stop root','Assign current busy=false first; preserve distinct observer with original primary graph and falsy values. Stale operation cannot publish or retire newer owner.'),
 ('restore','"Restore and observer failed"','Actual restore current busy=false observer fails after original stop/read/refresh/bind failure','Capture distinct observer with original root; current no-account path does not bypass this result. Propagate through existing failure gate after finalization; no new IO/retry.')]:
    ordinal=len(nav['records'])+1;identity='RH'+str(ordinal);n,c=locate(anchor)
    r={'original_ordinal':ordinal,'original_id':identity,'id':identity,'composite_identity':str(ordinal)+'|'+path+'|'+identity,'path':path,'line':n,'column':c,'source':lines[n-1],'source_sha256':digest,'token':'catch','token_class':'catch','executable':True,'specific_fault':fault,'present_authority':wa,'actual_recovery_or_failure':recovery,'disposition':'LOCAL_RETAINED_CURRENT_GROUND_PENDING_INDEPENDENT_REVIEW','decision':'FIX_LOCAL_CURRENT_BINDING_NOT_INDEPENDENT_ACCEPTANCE','current_candidate_binding':nav['binding']}
    nav['records'].append(r);inv['retained_sites'].append({'id':identity,'path':path,'line':n,'column':c,'operation':'Workspace.'+name,'source':r['source'],'actual_source':r['source'],'source_sha256':digest,'specific_fault':fault,'present_authority':wa,'actual_recovery_or_failure':recovery,'specific_ground_and_recovery':' → '.join([fault,wa,recovery]),'authority':wa,'disposition':r['disposition']})
nav['counts']={'records':333,'executable':298,'nonexecutable':35};assert len(nav['records'])==333
inv['counts']['retained_sites']=333;f=next(f for f in inv['files'] if f['path']==path);f.update(sha256=digest,bytes=len(data))
inv['fix_retirement_gateway']['new_records']='10 necessary literal lifecycle/settled/watch token records;333=298exec35nonexec, not catches';inv['fix_retirement_gateway']['same_F1_consumer_family']='Actual login/restore skipped/replaced busy roots and actual refresh503 failure publication observer reproduced before repair; existing Workspace.failure preserves roots once, no duplicate caller captures.'
invpath.write_text(json.dumps(inv,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');navpath.write_text(json.dumps(nav,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
p=EVID/'production-hashes.json';d=json.loads(p.read_text(encoding='utf-8'));f=next(f for f in d['files'] if f['path']==path);f.update(sha256=digest,bytes=len(data));p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
p=EVID/'runtime-source-bindings.json';d=json.loads(p.read_text(encoding='utf-8'));d['desktop_current']='Fresh family-final strict compile + original owner12/parallel37/Auth + new36 actual compiled Auth/Workspace/Send/Sync IPC/Socket/observer controls. Same F1 actual login/restore/failure-boundary proofs retained.';p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
compiled=[]
for p in (EXT/'desktop-build').rglob('*'):
    if p.is_file():compiled.append({'path':str(p.relative_to(EXT)).replace('\\','/'),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size})
(EXT/'desktop-compiled-output-bindings.json').write_text(json.dumps({'source_inputs':'family-final-desktop-compile-inputs.json','outputs':compiled,'runtime_link_stub':'Only literal Tauri IPC forwarding; no native credentials/DB acceptance.'},indent=2)+'\n',encoding='utf-8')
print('Current185/333=298exec35nonexec updated after fact-proven F1 same consumer family; all original323 composite identities preserved.')
