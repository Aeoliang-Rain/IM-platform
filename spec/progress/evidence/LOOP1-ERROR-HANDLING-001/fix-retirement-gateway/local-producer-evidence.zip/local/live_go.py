from run import *
import secrets,tempfile
docker='C:/Program Files/Docker/Docker/resources/bin/docker.exe'
project='im-retirement-'+secrets.token_hex(5)
command=[docker,'compose','-f',str(ROOT/'deploy/compose.yaml'),'-p',project]
history=[];cleanup={};image=project+'-migrate:latest'
def execute(args,capture=False):
    begin=time.monotonic();result=subprocess.run(list(map(str,args)),stdout=subprocess.PIPE if capture else None,stderr=subprocess.STDOUT if capture else None)
    history.append({'argv':list(map(str,args)),'exit':result.returncode,'elapsed_seconds':round(time.monotonic()-begin,3)})
    (EXT/'live-command-index.json').write_text(json.dumps({'project':project,'commands':history},indent=2)+'\n',encoding='utf-8')
    if result.returncode:raise subprocess.CalledProcessError(result.returncode,args,result.stdout)
    return result.stdout if capture else None
def inspect_owned():
    owned={}
    for kind,args in [('containers',['ps','-aq','--filter','label=com.docker.compose.project='+project]),('volumes',['volume','ls','-q','--filter','label=com.docker.compose.project='+project]),('networks',['network','ls','-q','--filter','label=com.docker.compose.project='+project])]:
        ids=execute([docker]+args,True).decode().split();owned[kind]=ids
        for ident in ids:
            inspect=[docker]+(['inspect'] if kind=='containers' else ['volume','inspect'] if kind=='volumes' else ['network','inspect'])+[ident]
            record=json.loads(execute(inspect,True))[0]
            labels=record['Config']['Labels'] if kind=='containers' else record['Labels']
            assert labels['com.docker.compose.project']==project
    return owned
try:
    execute(command+['up','-d','--build','postgres','nats','migrate'])
    cleanup['before']=inspect_owned()
    with tempfile.TemporaryDirectory(prefix='retirement-live-fixture-') as temporary:
        envfile=Path(temporary)/'fixture.env'
        envfile.write_text('DB_TEST_ENABLE=1\nPGHOST=postgres\nPGPORT=5432\nPGUSER=im\nPGDATABASE=im\nPGPASSWORD=local-development-only\nNATS_URL=nats://nats:4222\n',encoding='utf-8')
        execute([docker,'run','--rm','--label','im.error-task='+project,'--network',project+'_default','--env-file',str(envfile),'-v',str(ROOT)+':/workspace:ro','-w','/workspace/backend/go','-e','GOPROXY=off','-v','C:/Users/21441/go/pkg/mod/cache/download:/locked-cache:ro','golang:1.25-alpine','sh','-c','mkdir -p /go/pkg/mod/cache/download && cp -R /locked-cache/. /go/pkg/mod/cache/download/ && exec go test -mod=readonly -count=1 -v ./...'])
    print('PASS actual disposable PostgreSQL16/NATS2.10 all Go DB_TEST_ENABLE=1; local evidence, no hosted/TLS acceptance')
finally:
    cleanup['pre_cleanup_verified']=inspect_owned()
    execute(command+['down','--volumes','--remove-orphans'])
    cleanup['after']=inspect_owned()
    assert all(not ids for ids in cleanup['after'].values())
    remaining=execute([docker,'ps','-aq','--filter','label=im.error-task='+project],True).decode().split()
    assert not remaining
    # The ephemeral Compose build uses this exact uniquely generated project tag.
    images=execute([docker,'image','ls','-q',image],True).decode().split()
    if images:execute([docker,'image','rm',image])
    cleanup.update(project=project,remaining_test_containers=remaining,own_migrate_tag_removed=bool(images),private_data_or_trust_access=False)
    (EXT/'runtime-cleanup.json').write_text(json.dumps(cleanup,indent=2)+'\n',encoding='utf-8')
    print('Verified only own ephemeral project containers/volumes/networks and unique migrate tag cleaned')
