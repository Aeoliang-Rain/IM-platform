from run import *
import zipfile
EVID=ROOT/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-retirement-gateway'
commands=[json.loads(line) for line in (EXT/'commands.jsonl').read_text(encoding='utf-8').splitlines()]
development=next(c for c in commands if c['label']=='final-development');assert development['exit']==0
event('repair_finished',{'result':'LOCAL_FIX_COMPLETE_PENDING_INDEPENDENT_REVIEWS','findings':['F1-DESKTOP-RETIREMENT-CONSUMERS','F2-GATEWAY-DB-FAILURE-AS-REVOCATION'],'actual_current_desktop_controls':39,'original_owner_parallel_auth_unchanged':True,'actual_live_PG_NATS_allGo_no_skip':True,'production_inputs':185,'navigation_tokens':339,'protected_inputs_exact_e186054':65,'task_state':'review','gate':'S2 OPEN','acceptance':'PENDING_NEW_FINAL_SHA_BOTH_PLUS_CI_INTEGRATION_MAIN_SYNC'})
(EVID/'command-history.json').write_bytes((json.dumps({'scope':'Bounded precommit snapshot through actual final Development. Final external receipt binds ownedcommit/cleanAcceptance/postclean/Recorderfinish. All raw failures retained.','commands':commands},indent=2)+'\n').encode('utf-8'))
p=ROOT/'spec/progress/current.md';t=p.read_text(encoding='utf-8').replace('final current Development/clean committed Acceptance/postclean results follow command-history and sealed external receipt; local only.','fresh final current Development PASS; clean committed Acceptance/postclean follows sealed external receipt; local only.').replace('Complete final static/Development, task-owned clean commit/Acceptance/postclean, sealed RELEASED receipt.','Final static/Development PASS. Complete task-owned clean commit/Acceptance/postclean and sealed RELEASED receipt.');p.write_bytes(t.encode('utf-8'))
p=EVID/'handoff.md';t=p.read_text(encoding='utf-8').replace('Final Development/clean Acceptance/postclean follow command-history/external receipt.','Final current Development PASS, exit0; clean committed Acceptance/postclean follows external receipt.');p.write_bytes(t.encode('utf-8'))
entries=[];archive=EVID/'local-producer-evidence.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    def append(name,data):
        z.writestr(name,data);entries.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
    for p in sorted(EXT.iterdir()):
        if p.is_file() and p.suffix in ['.py','.mjs','.json','.txt','.jsonl']:
            append('local/'+p.name,p.read_bytes())
    for p in sorted((EXT/'desktop-build').rglob('*')):
        if p.is_file():append('local/'+str(p.relative_to(EXT)).replace('\\','/'),p.read_bytes())
    recorder=TOP/'research/runs/R-FIX-RETIREMENT-GATEWAY'
    snapshot_events=(recorder/'events.jsonl').read_bytes();events=[json.loads(line) for line in snapshot_events.splitlines()]
    for p in sorted(recorder.rglob('*')):
        if p.is_file():append('research-snapshot/'+str(p.relative_to(recorder)).replace('\\','/'),p.read_bytes())
    append('visible-human-prompt.txt',(TOP/'prompt.txt').read_bytes())
manifest={'archive':archive.name,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'archive_git_blob_oid':subprocess.check_output(['git','hash-object','--',str(archive)],cwd=ROOT,text=True).strip(),'entries':entries,'entry_count':len(entries),'research_snapshot':{'run_id':'R-FIX-RETIREMENT-GATEWAY','last_seq':events[-1]['seq'],'last_event':events[-1]['event_type'],'finished':False,'meaning':'Bounded precommit partial snapshot; complete finished stream/validation sealed externally after commit. Never Task/Gate acceptance.'},'no_recursive_history_diff':True,'original_review_archive_separate':True}
(EVID/'local-evidence-manifest.json').write_bytes((json.dumps(manifest,indent=2)+'\n').encode('utf-8'))
with zipfile.ZipFile(archive) as z:
    for e in entries:
        data=z.read(e['path']);assert len(data)==e['bytes'] and hashlib.sha256(data).hexdigest()==e['sha256']
print(json.dumps({'archive_entries':len(entries),'archive_bytes':archive.stat().st_size,'development':'PASS','snapshot_last_seq':events[-1]['seq'],'current_state':'review/S2 OPEN, no acceptance'}))
