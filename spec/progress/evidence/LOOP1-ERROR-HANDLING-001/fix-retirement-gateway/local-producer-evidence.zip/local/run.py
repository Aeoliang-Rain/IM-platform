from pathlib import Path
import hashlib, json, os, subprocess, sys, time
ROOT=Path('H:/.codex/worktrees/err/IM-platform')
EXT=Path(__file__).parent
TOP=EXT.parent
PY=Path('C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe')
NODE='H:/node.js/node.exe'
PWSH='C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'
os.environ['PATH']=str(PY.parent)+os.pathsep+'H:/node.js'+os.pathsep+os.environ.get('PATH','')
os.environ['GOCACHE']=str(EXT/'go-cache')
os.environ['PYTHONDONTWRITEBYTECODE']='1'
BASE=[str(PY),'-Xutf8','-B',str(ROOT/'tools/research/recorder.py')]
COMMON=['--repo',str(ROOT),'--research-root',str(TOP/'research'),'--run-id','R-FIX-RETIREMENT-GATEWAY']
def event(kind,data):
    return subprocess.run(BASE+['record-event']+COMMON+['--event-type',kind,'--data-json',json.dumps(data,ensure_ascii=False)],cwd=ROOT).returncode
def run(label,args,cwd=None):
    started=time.monotonic()
    result=subprocess.run(BASE+['run-command']+COMMON+['--']+list(map(str,args)),cwd=cwd or ROOT,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    output=result.stdout
    path=EXT/(label+'.txt')
    if path.exists():raise RuntimeError('Refusing to overwrite raw output '+str(path))
    path.write_bytes(output)
    record={'label':label,'argv':list(map(str,args)),'cwd':str(cwd or ROOT),'exit':result.returncode,'elapsed_seconds':round(time.monotonic()-started,3),'output':path.name,'sha256':hashlib.sha256(output).hexdigest(),'bytes':len(output)}
    with (EXT/'commands.jsonl').open('a',encoding='utf-8') as f:f.write(json.dumps(record,ensure_ascii=False)+'\n')
    print(json.dumps(record,ensure_ascii=False))
    return result.returncode
if __name__=='__main__':
    if sys.argv[1]=='event':sys.exit(event(sys.argv[2],json.loads(sys.argv[3])))
    sys.exit(run(sys.argv[1],sys.argv[2:]))
