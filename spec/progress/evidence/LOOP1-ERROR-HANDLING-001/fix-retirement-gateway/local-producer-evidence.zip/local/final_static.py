from run import *
suffix='-'+sys.argv[1] if len(sys.argv)>1 else ''
for label,args in [
 ('final-frozen',[PY,'-Xutf8','-B',ROOT/'tools/verify_frozen_architecture.py']),
 ('final-architecture',[PY,'-Xutf8','-B',ROOT/'ci/check_architecture.py','--scope','all','--json']),
 ('final-planning',[PY,'-Xutf8','-B',ROOT/'ci/check_s2_planning.py']),
 ('final-architecture-tests',[PY,'-Xutf8','-B','-m','unittest','discover','-s','tests/architecture','-v'])]:
    code=run(label+suffix,args)
    if code:sys.exit(code)
