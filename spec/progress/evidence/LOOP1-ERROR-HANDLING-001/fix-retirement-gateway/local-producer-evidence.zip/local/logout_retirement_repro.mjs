import assert from 'node:assert/strict';
const build=new URL('./desktop-build/',import.meta.url);
const {Auth}=await import(new URL('desktop/src/application/ui/auth.js',build));
const {Workspace}=await import(new URL('desktop/src/application/ui/workspace.js',build));
const {SendApplication}=await import(new URL('desktop/src/application/send.js',build));
const {SyncApplication}=await import(new URL('desktop/src/application/sync/application.js',build));
const {SyncHttp}=await import(new URL('shared/protocol-sdk/src/sync/http.js',build));
const session={userId:'11111111-1111-4111-8111-111111111111',sessionId:'22222222-2222-4222-8222-222222222222',sessionEpoch:1n,accessToken:'public-controlled-fixture'};
const tick=()=>new Promise(resolve=>setImmediate(resolve));
const unhandled=[];process.on('unhandledRejection',error=>unhandled.push(error));
let rejectRemote,removed=0;const remote=new Promise((_,reject)=>rejectRemote=reject);
globalThis.window={__TAURI_INTERNALS__:{invoke:async(command)=>{if(command==='native_https')return remote;if(command==='credential_remove'){removed++;return;}throw Error('Unexpected command '+command);}}};
const auth=new Auth('https://fixture.invalid');auth.session=session;auth.slot=auth.endpoint+'/'+session.userId+'/'+session.sessionId;
const w=new Workspace();w.auth=auth;w.state.session=session;
const send=new SendApplication({},session);const sync=new SyncApplication(send,new SyncHttp(auth.endpoint,session));w.sync=sync;
const observer=new Error('controlled existing observer failure');const request=new Error('controlled literal IPC request failure');
w.observe(()=>{if(w.state.session===null)throw observer;});
let failed;await w.logout().catch(error=>failed=error);
assert.equal(failed,observer);assert.equal(w.state.session,null);assert.equal(w.auth,null);assert.equal(sync.state.status,'retired');assert.equal(w.state.busy,true);
rejectRemote(request);await tick();await tick();assert.equal(unhandled.length,1);assert.equal(unhandled[0],request);assert.equal(removed,2);
console.log('OBSERVED: actual Workspace.logout rejected only exact observer root before actual Auth.logout settled; remote literal IPC root later escaped as unhandled rejection; busy remained true. Actual Send/Sync owners retired. No product/native DB/credential writes.');
console.log('REPRODUCED F-DESKTOP-LOGOUT-RETIREMENT-ROOT');
for(const fault of [false,true]){
 let deletes=0;const retained=new Map();const owner=new Auth('https://fixture.invalid');owner.session=session;owner.slot=owner.endpoint+'/'+session.userId+'/'+session.sessionId;retained.set(owner.slot,'public-fixture');retained.set(owner.endpoint+'/current',owner.slot);
 globalThis.window={__TAURI_INTERNALS__:{invoke:async(command,args)=>{assert.equal(command,'credential_remove');deletes++;retained.delete(args.slot);}}};
 const workspace=new Workspace();workspace.auth=owner;workspace.state.session=session;const actualSend=new SendApplication({},session);const actualSync=new SyncApplication(actualSend,new SyncHttp(owner.endpoint,session));workspace.sync=actualSync;
 const projection=new Error('controlled existing retirement observer');if(fault)workspace.observe(()=>{if(workspace.state.session===null)throw projection;});
 let error;await workspace.expire().catch(e=>error=e);assert.equal(actualSync.state.status,'retired');assert.equal(workspace.state.session,null);
 if(fault){assert.equal(error,projection);assert.equal(deletes,0);assert.equal(retained.size,2);assert.equal(owner.session,session);console.log('OBSERVED expiry: actual stop observer failure prevents every actual Auth.clear/credential_remove attempt; slot/current and Auth.session remain, despite Workspace detached.');}
 else{assert.equal(error,undefined);assert.equal(deletes,2);assert.equal(retained.size,0);assert.equal(owner.session,null);console.log('CONTROL normal expiry: actual Auth.clear removes both pointers and nulls owner session.');}
}
