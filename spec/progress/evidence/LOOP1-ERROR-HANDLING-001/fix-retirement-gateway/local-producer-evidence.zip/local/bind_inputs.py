from run import *
import copy,difflib,re
BASE_SHA='e186054d964e11755e7bc48ae71f95d1ea125f2f'
ACCEPTED='35bd6f5f1091503f95a0282f730ed04233b0b6ea'
EVID=ROOT/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-retirement-gateway'
invpath=ROOT/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001/production-inventory.json'
inv=json.loads(invpath.read_text(encoding='utf-8'))
nav=json.loads((ROOT/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-refresh-owner/current-navigation.json').read_text(encoding='utf-8'))
assert len(inv['files'])==185 and len(inv['retained_sites'])==323 and len(nav['records'])==323
binding='Final clean committed task HEAD through external fix-retirement-gateway/final-receipt.json; NEW complete regular and DIFFERENT NEW specialized finalSHA reviews PENDING'
hashes=[];changed=[]
for record in inv['files']:
    path=record['path'];current=(ROOT/path).read_bytes();before=subprocess.check_output(['git','show',BASE_SHA+':'+path],cwd=ROOT)
    assert record['sha256']==hashlib.sha256(before).hexdigest(),path
    item={'path':path,'sha256':hashlib.sha256(current).hexdigest(),'bytes':len(current),'e186054_sha256':hashlib.sha256(before).hexdigest(),'byte_equal_e186054':current==before}
    hashes.append(item)
    if current!=before:
        changed.append(path);record.update(sha256=item['sha256'],bytes=len(current),finding='F1-DESKTOP-RETIREMENT-CONSUMERS' if path.startswith('clients/') else 'F2-GATEWAY-DB-FAILURE-AS-REVOCATION',inspection='Current literal producer/consumer lifecycle read and targeted actual regressions; local Fix only, NEW whole-scope independent regular and specialist reviews PENDING.')
assert sorted(changed)==sorted(['clients/desktop/src/application/ui/workspace.ts','backend/go/gateway/gateway.go']),changed
texts={path:(ROOT/path).read_text(encoding='utf-8').splitlines() for path in changed}
maps={}
for path in changed:
    before=subprocess.check_output(['git','show',BASE_SHA+':'+path],cwd=ROOT).decode('utf-8').splitlines();mapping={}
    for block in difflib.SequenceMatcher(None,before,texts[path],autojunk=False).get_matching_blocks():
        for offset in range(block.size):mapping[block.a+offset+1]=block.b+offset+1
    maps[path]=mapping
def locate(path,anchor,token):
    lines=texts[path];matches=[i for i,line in enumerate(lines,1) if anchor in line]
    assert len(matches)==1,(anchor,matches)
    line=matches[0];return line,lines[line-1].index(token)+1
def grounds(record,fault,authority,recovery):
    record.update(specific_fault=fault,present_authority=authority,actual_recovery_or_failure=recovery,disposition='LOCAL_RETAINED_CURRENT_GROUND_PENDING_INDEPENDENT_REVIEW',decision='FIX_LOCAL_CURRENT_BINDING_NOT_INDEPENDENT_ACCEPTANCE')
workspace='clients/desktop/src/application/ui/workspace.ts';gateway='backend/go/gateway/gateway.go'
wa='Frozen §6.1/§7.1 and ADR-0009 application-owned credential lifecycle/account isolation; spec/governance/error-handling.md mandatory cleanup, all started operation results and distinct unknown/falsy roots'
ga='Frozen §3.1/§7.2/§7.3, AUF-D-004/AUF-I-004 and contracts/websocket/README.md session.revoked fact; error-handling.md truthful categories, required cleanup and unknown/internal failure propagation'
for i,record in enumerate(nav['records']):
    path=record['path'];record['current_candidate_binding']=binding
    if path in changed:
        if record['id']=='RH088':
            record['line'],record['column']=locate(path,'try{await owner?.clear();}','catch')
            grounds(record,'Actual expiry owner.clear/secure credential removal fails, possibly after distinct stop/listener/close failure',wa,'Always attempt original owner.clear once after stop settles; preserve distinct roots and existing known cleanup warning. Clear current busy despite cleanup/observer failure. Unknown/falsy/mixed roots propagate, no credential retry or newer-operation publication.')
        elif record['id']=='RH089':
            record['line'],record['column']=locate(path,'try{this.failure(failure,op===this.operation);}','catch')
            grounds(record,'Actual logout collected remote/credential/retirement results fail; existing known failure publication itself may throw an observer root',wa,'Busy=false is attempted first for the current operation. Existing known failure projection remains; unknown original result propagates unchanged. A distinct projection observer is aggregated with original operation roots, never replaces them.')
        else:
            assert record['line'] in maps[path],(record['id'],path,record['line'])
            record['line']=maps[path][record['line']]
        record['source']=texts[path][record['line']-1]
        record['source_sha256']=hashlib.sha256((ROOT/path).read_bytes()).hexdigest()
    current=(ROOT/path).read_bytes();lines=current.decode('utf-8').splitlines()
    assert record['source_sha256']==hashlib.sha256(current).hexdigest(),record['id']
    assert record['source']==lines[record['line']-1],(record['id'],'source')
    assert lines[record['line']-1][record['column']-1:].startswith(record['token']),(record['id'],'token')
    original=inv['retained_sites'][i]
    assert (original['id'],original['path'])==(record['id'],record['path'])
    original.update(line=record['line'],column=record['column'],source=record['source'],actual_source=record['source'],source_sha256=record['source_sha256'])
    for key in ['specific_fault','present_authority','actual_recovery_or_failure']:original[key]=record[key]
    original['specific_ground_and_recovery']=' → '.join(record[key] for key in ['specific_fault','present_authority','actual_recovery_or_failure'])
    original['authority']=record['present_authority']
def add(path,anchor,token,fault,authority,recovery):
    ordinal=len(nav['records'])+1;identity='RH'+str(ordinal);line,column=locate(path,anchor,token)
    r={'original_ordinal':ordinal,'original_id':identity,'id':identity,'composite_identity':str(ordinal)+'|'+path+'|'+identity,'path':path,'line':line,'column':column,'source':texts[path][line-1],'source_sha256':hashlib.sha256((ROOT/path).read_bytes()).hexdigest(),'token':token,'token_class':'catch' if token=='catch' else 'current_source_token','executable':True,'current_candidate_binding':binding}
    grounds(r,fault,authority,recovery);nav['records'].append(r)
    inv['retained_sites'].append({'id':identity,'path':path,'line':line,'column':column,'operation':'Current Workspace retirement' if path==workspace else 'Gateway safety watch','source':r['source'],'actual_source':r['source'],'source_sha256':r['source_sha256'],'disposition':r['disposition'],'specific_fault':fault,'present_authority':authority,'actual_recovery_or_failure':recovery,'specific_ground_and_recovery':' → '.join([fault,authority,recovery]),'authority':authority})
add(workspace,'try{await this.stop();}catch(error){failures.push(error);}','catch','Actual expiry stop publication observer/old Sync close fails after Workspace detached its Auth owner',wa,'Retain stop root, then attempt mandatory original Auth.clear anyway. Existing stop cancels timer/detaches projection and closes once. Final current busy/state publication and all distinct roots remain part of expiry result.')
add(workspace,'error:cleanupFailed?"Session expired; secure credential cleanup failed"','catch','Actual final expiry publication listener throws, possibly after stop or credential cleanup failures',wa,'State busy=false is assigned for the current operation before listener execution; add distinct observer root to original failures. Known-only cleanup retains honest warning, unknown/falsy roots reject through existing failure gate.')
add(workspace,'try{this.publish({busy:true});}catch(error){failures.push(error);}','catch','Actual initial logout busy publication listener throws after auth ownership is captured',wa,'Capture root without abandoning mandatory old-owner logout/stop; both already-owned lifecycle operations still settle, final current busy is cleared, error is propagated with all distinct later roots.')
add(workspace,'const settled=await Promise.allSettled([auth?.logout(),this.stop()]);','Promise.allSettled','Actual logout retirement observer fails before an already-started native logout request or credential cleanup completes',wa,'Wait Auth.logout and stop fully; Auth already waits its own remote+clear. Collect distinct roots including falsy primitives, preserve one-root identity, no unhandled late sibling and no duplicate secure removal/close.')
add(workspace,'this.publish({busy:false,...(!failures.length?{error:null}:{})});','catch','Actual current logout busy=false publication listener throws after remote/cleanup/stop failures settle',wa,'Assign busy=false before callback and preserve distinct observer plus operation/retirement roots. Newer operation retains its busy/session/error and owner; known recovery cannot hide unknown root.')
add(gateway,'if watchTransportFailure(err) {','if watchTransportFailure(err)','Actual current safety-watch returns default pgx refused/timeout transport tree or mixed/unknown internal tree',ga,'Known-only complete transport tree has already closed its unverified connection; emit one safe constant and return. Predicate checks every multi-Unwrap branch, so mixed/internal retains full original error and panics at actual serve goroutine boundary. No retry/cache/business revocation invented.')
add(gateway,'func (h *hub) watch(c *connection, cl shared.Claims) error {','func (h *hub) watch','Actual validation unavailability must retire transport even when it returns a raw internal/transport error',ga,'Watch defers existing idempotent connection.close; no session.revoked frame is emitted for non-authentication error. Known real invalidation still uses existing exact-identity reason/revoke path. Returned original root is unchanged.')
# Bind the actual cleanup statement, not the declaration used only to locate its owner.
r=nav['records'][-1];idx=inv['retained_sites'][-1];line=r['line']+1;assert texts[gateway][line-1]=='\tdefer c.close()';r.update(line=line,column=2,source=texts[gateway][line-1],token='defer');idx.update(line=line,column=2,source=r['source'],actual_source=r['source'])
add(gateway,'if _, known := err.(shared.Error); !known {','if _, known := err.(shared.Error)','Actual default pgx/database/internal error has no authoritative authentication classification',ga,'Cancel the watch query, return exact original error and execute mandatory close. Do not call revocationReason or session.revoked. Known validated auth/session failure alone may invoke existing invalidation path.')
assert len(nav['records'])==331
nav.update(binding=binding,counts={'records':331,'executable':sum(bool(r['executable']) for r in nav['records']),'nonexecutable':sum(not r['executable'] for r in nav['records'])})
assert nav['counts']=={'records':331,'executable':296,'nonexecutable':35}
identities=[r['composite_identity'] for r in nav['records']];assert len(identities)==len(set(identities))
inv['candidate_binding']=binding;inv['counts']['retained_sites']=331
inv['fix_retirement_gateway']={'base':BASE_SHA,'actor':'/root/fix_retirement_gateway','prior_regular':'Formal e186054 FAIL, both F1/F2; original315+receipt archive verified','production_delta':changed,'current_navigation':'fix-retirement-gateway/current-navigation.json','current_reviews':'PENDING_NEW_COMPLETE_REGULAR_THEN_DIFFERENT_NEW_SPECIALIZED_SAME_FINAL_SHA','scope':'No Android/Auth/Preferences/storage/Repository/SQL/nativeDB/write/Composer/draft change','new_records':'8 currently necessary lifecycle/settled/watch boundaries;331 tokens=296exec35nonexec, never catch count','old323_composite_identities_preserved':True}
invpath.write_text(json.dumps(inv,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(EVID/'current-navigation.json').write_text(json.dumps(nav,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(EVID/'production-hashes.json').write_text(json.dumps({'candidate_binding':binding,'count':185,'changed_from_e186054':changed,'files':hashes},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
protection=json.loads((ROOT/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-refresh-owner/protected-inputs.json').read_text(encoding='utf-8'))
whole=0
for entry in protection['files']:
    path=entry['path'];current=(ROOT/path).read_bytes();before=subprocess.check_output(['git','show',BASE_SHA+':'+path],cwd=ROOT)
    assert current==before and hashlib.sha256(current).hexdigest()==entry['sha256'],path
    accepted=subprocess.check_output(['git','show',ACCEPTED+':'+path],cwd=ROOT)
    entry.update(byte_equal_pre_fix=True,e186054_sha256=hashlib.sha256(before).hexdigest(),byte_equal_accepted_whole=current==accepted)
    whole+=current==accepted
assert len(protection['files'])==65 and whole==63
protection.update(against_pre_fix=BASE_SHA,all_exact_pre_fix=True,whole_accepted_equal=63,prior_human_read_mapper_exceptions=2,qualification='Two contiguous READ mappers equal e186 exactly; e186 independent reviewer binding proves same SELECT SQL/all other accepted Repository bytes. No additional exception or write scope.')
(EVID/'protected-inputs.json').write_text(json.dumps(protection,indent=2)+'\n',encoding='utf-8')
oldgraphpath=ROOT/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-refresh-owner/android-build-inputs.json';oldgraph=json.loads(oldgraphpath.read_text(encoding='utf-8'))
for entry in oldgraph['files']:
    data=(ROOT/entry['path']).read_bytes();assert hashlib.sha256(data).hexdigest()==entry['sha256'] and len(data)==entry['bytes'],entry['path']
runtime={'android_qualified_historical_reuse':{'source_graph':str(oldgraphpath.relative_to(ROOT)).replace('\\','/'),'graph_sha256':hashlib.sha256(oldgraphpath.read_bytes()).hexdigest(),'all_current_graph_inputs_verified':len(oldgraph['files']),'actual_prior_runtime':'Owned API34/5612 owner10 and ErrorHandling HTTP32/WSS21 from prior sealed e186 producer evidence; not new runtime observations or inherited independent verdict','prior_input_bindings':'fix-refresh-owner/runtime-source-bindings.json','current_android_changes':0,'prior_send_sync':'Send66+Read21/Sync69+Read33+contiguous18 remain historical qualified unchanged graphs, not newly executed','limits':'No default-provider incidence/full GUI/Go durable-ACK claim. Current task still requires new full reviews and exact-head hosted acceptance.'},'desktop_current':'Current strict compile + original owner12/parallel37/Auth + new28 actual compiled IPC/Socket/observer controls executed fresh','go_current':'Current real default pgx/mixed/internal/closedpool/WS + real PostgreSQL16/NATS2.10 full Go suite and exact serve goroutine PgError0A000; output/commands retained','native_or_android_rebuild_this_fix':False}
(EVID/'runtime-source-bindings.json').write_text(json.dumps(runtime,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
pyc=ROOT/'ci/__pycache__/check_s2_planning.cpython-313.pyc'
if pyc.exists():
    target=EXT/'owned-generated';target.mkdir(exist_ok=True);data=pyc.read_bytes();destination=target/pyc.name;assert not destination.exists();pyc.replace(destination)
    (EXT/'generated-output-preservation.json').write_text(json.dumps({'source':str(pyc),'destination':str(destination),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'ownership':'initial clean e186 before baseline; generated by this own prospective verifier run','other_paths_or_acl_changed':False},indent=2)+'\n',encoding='utf-8')
(EVID/'input-checks.json').write_text(json.dumps({'production185':True,'only2_production_delta_from_e186054':changed,'navigation':nav['counts'],'all323_original_composite_identities_preserved':True,'all331_sourcehash_line_column_token_verified':True,'protected65_exact_e186054':True,'whole_base63_plus_prior2_read_exceptions':True,'android_current_graph_equal':len(oldgraph['files']),'independent_whole_scope_semantic_acceptance':False},indent=2)+'\n',encoding='utf-8')
print(json.dumps({'production':185,'changed':changed,'navigation':nav['counts'],'protected':65,'android_unchanged_inputs':len(oldgraph['files'])}))
