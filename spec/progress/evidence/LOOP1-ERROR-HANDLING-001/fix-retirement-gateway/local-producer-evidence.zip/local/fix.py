from run import *
p=ROOT/'clients/desktop/src/application/ui/workspace.ts';s=p.read_text(encoding='utf-8')
start=s.index('  async expire(){');end=s.index('  closeConversation()',start)
old=s[start:end]
assert old.count('async expire')==1 and old.count('async logout')==1
new='''  async expire(){const op=++this.operation,owner=this.auth;this.auth=null;const failures:unknown[]=[];let cleanupFailed=false;
    try{await this.stop();}catch(error){failures.push(error);}
    try{await owner?.clear();}catch(error){cleanupFailed=true;if(!failures.includes(error))failures.push(error);}
    if(op===this.operation)try{this.publish({busy:false,error:cleanupFailed?"Session expired; secure credential cleanup failed":"Session expired. Sign in again."});}catch(error){if(!failures.includes(error))failures.push(error);}
    if(failures.length)this.failure(failures.length===1?failures[0]:new AggregateError(failures,"Expiry cleanup failed"),false);
  }
  async logout(){const op=++this.operation,auth=this.auth;this.auth=null;const failures:unknown[]=[];
    try{this.publish({busy:true});}catch(error){failures.push(error);}
    const settled=await Promise.allSettled([auth?.logout(),this.stop()]);
    for(const result of settled)if(result.status==="rejected"&&!failures.includes(result.reason))failures.push(result.reason);
    if(op===this.operation)try{this.publish({busy:false,...(!failures.length?{error:null}:{})});}catch(error){if(!failures.includes(error))failures.push(error);}
    if(failures.length){const failure=failures.length===1?failures[0]:new AggregateError(failures,"Logout retirement failed");
      try{this.failure(failure,op===this.operation);}catch(error){if(error===failure)throw error;throw new AggregateError([failure,error],"Logout and observer failed");}}
  }
'''
p.write_text(s[:start]+new+s[end:],encoding='utf-8',newline='\n')
p=ROOT/'backend/go/gateway/gateway.go';s=p.read_text(encoding='utf-8')
s=s.replace('\t"io"\n','\t"io"\n\t"log"\n\t"net"\n',1)
assert '\t\t\tgo h.watch(c, cl)' in s
s=s.replace('\t\t\tgo h.watch(c, cl)','''\t\t\tgo func() {
\t\t\t\tif err := h.watch(c, cl); err != nil {
\t\t\t\t\tif watchTransportFailure(err) {
\t\t\t\t\t\tlog.Print("Session validation transport failed; connection closed")
\t\t\t\t\t\treturn
\t\t\t\t\t}
\t\t\t\t\tpanic(err)
\t\t\t\t}
\t\t\t}()''',1)
start=s.index('func (h *hub) watch(');end=s.index('\nfunc writeError(',start)
new='''func (h *hub) watch(c *connection, cl shared.Claims) error {
\tdefer c.close()
\tticker := time.NewTicker(time.Second)
\tdefer ticker.Stop()
\tfor {
\t\tselect {
\t\tcase <-c.done:
\t\t\treturn nil
\t\tcase <-ticker.C:
\t\t\tctx, cancel := context.WithTimeout(context.Background(), time.Second)
\t\t\t_, err := h.auth.authenticate(ctx, c.token)
\t\t\tif err != nil {
\t\t\t\tif _, known := err.(shared.Error); !known {
\t\t\t\t\tcancel()
\t\t\t\t\treturn err
\t\t\t\t}
\t\t\t\treason := h.auth.revocationReason(ctx, cl, err)
\t\t\t\tcancel()
\t\t\t\th.revoke(cl.SessionID, reason)
\t\t\t\treturn nil
\t\t\t}
\t\t\tcancel()
\t\t}
\t}
}

// Default pgx can join connection attempts. Close the unverified connection
// for known transport failure, but never hide an internal branch of that tree.
func watchTransportFailure(err error) bool {
\tknown := false
\tfor err != nil {
\t\tif joined, ok := err.(interface{ Unwrap() []error }); ok {
\t\t\tbranches := joined.Unwrap()
\t\t\tif len(branches) == 0 {
\t\t\t\treturn false
\t\t\t}
\t\t\tfor _, branch := range branches {
\t\t\t\tif !watchTransportFailure(branch) {
\t\t\t\t\treturn false
\t\t\t\t}
\t\t\t}
\t\t\treturn true
\t\t}
\t\tif _, ok := err.(net.Error); ok {
\t\t\tknown = true
\t\t}
\t\tif err == context.DeadlineExceeded {
\t\t\tknown = true
\t\t}
\t\tif wrapped, ok := err.(interface{ Unwrap() error }); ok {
\t\t\terr = wrapped.Unwrap()
\t\t\tcontinue
\t\t}
\t\treturn known
\t}
\treturn false
}
'''
p.write_text(s[:start]+new+s[end:],encoding='utf-8',newline='\n')
subprocess.run(['H:/go/bin/gofmt.exe','-w',str(p)],check=True)
print('Only Workspace expiry/logout and Gateway watch/goroutine transport boundary changed. No third production file, native/storage/SQL/write/draft/contract changes.')
