from run import *
event('instrumentation_warning',{'summary':'Direct startup reads/status/diff/log and external helper preparation preceded run start. Some large authority outputs were truncated and relevant operative sections were reread separately. This is prospective_resume, not a complete prospective trace; hidden facts remain unavailable. No source writes occurred before run start or baseline.'})
assert Path(subprocess.check_output(['git','rev-parse','--show-toplevel'],cwd=ROOT,text=True).strip()).resolve()==ROOT.resolve()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()=='e186054d964e11755e7bc48ae71f95d1ea125f2f'
assert subprocess.check_output(['git','branch','--show-current'],cwd=ROOT,text=True).strip()=='task/LOOP1-ERROR-HANDLING-001'
assert not subprocess.check_output(['git','status','--porcelain=v1','-uall'],cwd=ROOT,text=True).strip()
for label,args in [
 ('baseline-frozen',[PY,'-Xutf8','-B',ROOT/'tools/verify_frozen_architecture.py']),
 ('baseline-architecture',[PY,'-Xutf8','-B',ROOT/'ci/check_architecture.py','--scope','all','--json']),
 ('baseline-planning',[PY,'-Xutf8','-B',ROOT/'ci/check_s2_planning.py']),
 ('baseline-development',[PWSH,'-NoProfile','-File',ROOT/'tools/verify-loop1-ctrl-002.ps1','-Mode','Development'])]:
    code=run(label,args)
    if code:sys.exit(code)
