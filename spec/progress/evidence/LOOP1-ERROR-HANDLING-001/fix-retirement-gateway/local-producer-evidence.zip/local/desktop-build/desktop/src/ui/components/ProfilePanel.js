import { useText } from "../i18n/context.js";
import React from "react";
export function ProfilePanel({ s, refresh, disconnect, reconnect, testNotification, logout, run }) {
    const t = useText();
    return React.createElement("div", { className: "glass panel" },
        React.createElement("h2", null, t("profile.session")),
        React.createElement("div", { className: "person" },
            React.createElement("span", { className: "avatar" }, s.profile?.displayName[0] ?? "+"),
            React.createElement("div", null,
                React.createElement("strong", null, s.profile?.displayName ?? t("profile.unavailable")),
                React.createElement("small", null, s.profile ? "@" + s.profile.username : s.session ? t("profile.reconnect") : t("profile.signIn")))),
        React.createElement("div", { className: "button-row" },
            React.createElement("button", { disabled: s.busy || (!s.session && !s.offlineAccount), onClick: () => run(refresh()) }, t("auth.refresh")),
            React.createElement("button", { disabled: !s.session, onClick: () => disconnect() }, t("auth.offline")),
            React.createElement("button", { disabled: !s.session, onClick: () => run(reconnect()) }, t("auth.reconnect")),
            React.createElement("button", { onClick: () => run(testNotification()) }, t("auth.testNotification")),
            React.createElement("button", { className: "danger", disabled: s.busy || (!s.session && !s.offlineAccount), onClick: () => run(logout()) }, t("auth.signOut"))),
        React.createElement("p", { className: "muted" }, t("profile.shortcut")));
}
