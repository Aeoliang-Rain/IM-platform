import { WireFailure, object, parse, positive, uuid } from "../../../../shared/protocol-sdk/src/send/wire.js";
import { NativeCapabilityFailure, NativeTransportFailure, nativeFetch, secure } from "./native.js";
export class ApiFailure extends Error {
    kind;
    constructor(kind, message = kind) {
        super(message);
        this.kind = kind;
    }
}
export function origin(value) { const u = new URL(value); if (u.protocol !== "https:" || u.username || u.password || u.search || u.hash || u.pathname !== "/")
    throw new ApiFailure("use_an_https_server_origin", "Use an HTTPS server origin"); return u.origin; }
function user(value) { const o = object(value, ["userId", "username", "displayName"]); if (typeof o.username !== "string" || typeof o.displayName !== "string")
    throw new ApiFailure("invalid_server_response", "Invalid server response"); return { userId: uuid(o.userId), username: o.username, displayName: o.displayName }; }
const metadata = { clientType: "DESKTOP", deviceId: "im-desktop", clientVersion: "0.1.0", protocolVersion: "1" };
export class Auth {
    endpoint;
    session = null;
    slot = "";
    expires = 0;
    generation = 0;
    storage = Promise.resolve();
    constructor(endpoint) {
        this.endpoint = endpoint;
        origin(endpoint);
    }
    async request(path, method = "GET", body, authenticated = true) {
        const headers = { "Content-Type": "application/json" };
        if (authenticated) {
            if (!this.session)
                throw new ApiFailure("session_expired", "Session expired");
            headers.Authorization = "Bearer " + this.session.accessToken;
        }
        const encoded = body === undefined ? undefined : JSON.stringify(body);
        let response;
        try {
            response = await nativeFetch(this.endpoint + path, { method, headers, ...(body === undefined ? {} : { body: encoded }), redirect: "error", cache: "no-store" });
        }
        catch (error) {
            if (error instanceof WireFailure)
                throw new ApiFailure("invalid_server_response", "Invalid server response");
            if (error instanceof NativeTransportFailure || error instanceof DOMException)
                throw new ApiFailure("connection_unavailable", "Connection unavailable");
            throw error;
        }
        if (response.status === 204)
            return null;
        if (!/^application\/json(?:\s*;|$)/i.test(response.headers.get("content-type") ?? ""))
            throw new ApiFailure("invalid_server_response", "Invalid server response");
        const bytes = await response.arrayBuffer();
        let raw;
        try {
            raw = new TextDecoder("utf-8", { fatal: true }).decode(bytes);
        }
        catch (error) {
            if (error instanceof TypeError)
                throw new ApiFailure("invalid_server_response", "Invalid server response");
            throw error;
        }
        let data;
        try {
            data = parse(raw, 1048576);
        }
        catch (error) {
            if (error instanceof WireFailure)
                throw new ApiFailure("invalid_server_response", "Invalid server response");
            throw error;
        }
        if (!response.ok) {
            const code = data?.error?.code;
            throw new ApiFailure(response.status === 401 && code === "AUTH_INVALID_CREDENTIALS" ? "invalid_credentials" : response.status === 401 ? "session_expired" : typeof code === "string" ? code : "request_failed", response.status === 401 && code === "AUTH_INVALID_CREDENTIALS" ? "Invalid username or password" : response.status === 401 ? "Session expired" : typeof code === "string" ? code : "Request failed");
        }
        return data;
    }
    async accept(data, g) {
        if (g !== this.generation)
            throw new ApiFailure("session_expired", "Session expired");
        const result = object(data, ["session", "tokens", "replacedExistingSession"]), s = object(result.session, ["sessionId", "userId", "clientType", "sessionEpoch", "status"]);
        const t = object(result.tokens, ["accessToken", "accessTokenExpiresInSeconds", "refreshToken", "refreshTokenExpiresInSeconds", "refreshTokenDelivery"]);
        if (s.clientType !== "DESKTOP" || s.status !== "ACTIVE" || t.refreshTokenDelivery !== "RESPONSE_BODY_FOR_OS_SECURE_STORAGE" || typeof t.accessToken !== "string" || !t.accessToken || typeof t.refreshToken !== "string" || !t.refreshToken || typeof result.replacedExistingSession !== "boolean")
            throw new ApiFailure("invalid_server_response", "Invalid server response");
        const next = { userId: uuid(s.userId), sessionId: uuid(s.sessionId), sessionEpoch: positive(s.sessionEpoch), accessToken: t.accessToken };
        const slot = this.endpoint + "/" + next.userId + "/" + next.sessionId;
        const refreshToken = t.refreshToken, expires = Number(positive(t.accessTokenExpiresInSeconds));
        positive(t.refreshTokenExpiresInSeconds);
        const write = this.storage.then(async () => { if (g !== this.generation)
            throw new ApiFailure("session_expired", "Session expired"); await secure.write(slot, refreshToken); if (g !== this.generation) {
            await secure.remove(slot);
            throw new ApiFailure("session_expired", "Session expired");
        } await secure.write(this.endpoint + "/current", slot); if (this.slot && this.slot !== slot)
            await secure.remove(this.slot); this.slot = slot; });
        this.storage = write.catch(error => { if (!(error instanceof ApiFailure) && !(error instanceof NativeCapabilityFailure))
            throw error; });
        try {
            await write;
        }
        catch (error) {
            this.session = null;
            if (error instanceof NativeCapabilityFailure && error.code === "Secure credential storage unavailable")
                throw new ApiFailure("secure_credential_storage_unavailable", "Secure credential storage unavailable");
            throw error;
        }
        if (g !== this.generation)
            throw new ApiFailure("session_expired", "Session expired");
        this.session = next;
        this.expires = Date.now() + expires * 1000;
        return next;
    }
    async register(username, password) { const result = object(await this.request("/v1/auth/register", "POST", { username, password, displayName: username }, false), ["user"]); return user(result.user); }
    async login(username, password) { const g = this.generation; return this.accept(await this.request("/v1/auth/login", "POST", { username, password, ...metadata }, false), g); }
    async restore() { return await this.savedAccount() ? this.refresh() : null; }
    async savedAccount() { const g = this.generation, slot = await secure.read(this.endpoint + "/current"); if (g !== this.generation)
        throw new ApiFailure("session_expired", "Session expired"); if (!slot)
        return null; if (!slot.startsWith(this.endpoint + "/"))
        throw new ApiFailure("secure_credential_metadata_invalid", "Secure credential metadata invalid"); const parts = slot.slice(this.endpoint.length + 1).split("/"); if (parts.length !== 2)
        throw new ApiFailure("secure_credential_metadata_invalid", "Secure credential metadata invalid"); uuid(parts[1]); this.slot = slot; return uuid(parts[0]); }
    async refresh() {
        const g = this.generation;
        const token = await secure.read(this.slot);
        if (g !== this.generation)
            throw new ApiFailure("session_expired", "Session expired");
        if (!token) {
            await this.clear();
            throw new ApiFailure("session_expired", "Session expired");
        }
        try {
            return await this.accept(await this.request("/v1/auth/refresh/native", "POST", { refreshToken: token, ...metadata }, false), g);
        }
        catch (error) {
            if (g === this.generation && error instanceof ApiFailure && error.kind === "session_expired") {
                try {
                    await this.clear();
                }
                catch (cleanup) {
                    if (cleanup === error)
                        throw error;
                    throw new AggregateError([error, cleanup], "Refresh cleanup failed");
                }
            }
            throw error;
        }
    }
    needsRefresh() { return !!this.session && Date.now() > this.expires - 60000; }
    async clear() { this.generation++; this.session = null; await this.storage; const slot = this.slot; this.slot = ""; if (slot)
        await secure.remove(slot); await secure.remove(this.endpoint + "/current"); }
    async logout() {
        const remote = this.session ? this.request("/v1/auth/logout", "POST", {}) : Promise.resolve();
        const settled = await Promise.allSettled([this.clear(), remote]);
        const failures = [...new Set(settled.filter(result => result.status === "rejected").map(result => result.reason))];
        if (failures.length === 1)
            throw failures[0];
        if (failures.length > 1)
            throw new AggregateError(failures, "Logout failed");
    }
    async profile() { const o = object(await this.request("/v1/users/me"), ["user"]); return user(o.user); }
    async friends() { const o = object(await this.request("/v1/friends"), ["friends"]); if (!Array.isArray(o.friends))
        throw new ApiFailure("invalid_server_response", "Invalid server response"); return o.friends.map(v => { const f = object(v, ["user", "friendshipId", "directConversationId"]); return { user: user(f.user), friendshipId: uuid(f.friendshipId), directConversationId: uuid(f.directConversationId) }; }); }
    async search(query) { const o = object(await this.request("/v1/users/search?username=" + encodeURIComponent(query)), ["users"]); if (!Array.isArray(o.users))
        throw new ApiFailure("invalid_server_response", "Invalid server response"); return o.users.map(user); }
    async add(userId) { const result = object(await this.request("/v1/friends/" + uuid(userId), "PUT"), ["friendshipId", "normalizedPair", "directConversationId", "memberUserIds", "created"]); return uuid(result.directConversationId); }
}
