import { useText } from "../i18n/context.js";
import React from "react";
import { resizedComposerHeight } from "../composer.js";
export function Composer({ s, draft, setDraft, send, run, textarea, composerHeight, setComposerHeight, resize }) {
    const t = useText();
    return React.createElement(React.Fragment, null,
        React.createElement("form", { className: "composer", onSubmit: e => { e.preventDefault(); if (draft.trim()) {
                run(send(draft));
                setDraft("");
            } } },
            React.createElement("label", { className: "sr-only", htmlFor: "message" }, t("chat.message")),
            React.createElement("div", { className: "composer-editor" },
                React.createElement("textarea", { ref: textarea, style: { height: composerHeight }, id: "message", placeholder: t("chat.write"), value: draft, maxLength: 4096, disabled: !s.selected || !s.session, onChange: e => setDraft(e.target.value), onKeyDown: e => { if (e.key === "Enter" && !e.shiftKey) {
                        e.preventDefault();
                        if (draft.trim()) {
                            run(send(draft));
                            setDraft("");
                        }
                    } } }),
                React.createElement("button", { type: "button", className: "composer-resize", "aria-label": t("chat.resize"), title: t("chat.drag"), onPointerDown: e => { if (e.button !== 0)
                        return; e.preventDefault(); resize.current = { y: e.clientY, height: textarea.current?.getBoundingClientRect().height ?? composerHeight }; e.currentTarget.setPointerCapture(e.pointerId); }, onPointerMove: e => { if (resize.current)
                        setComposerHeight(resizedComposerHeight(resize.current.height, resize.current.y, e.clientY)); }, onPointerUp: () => { resize.current = null; }, onPointerCancel: () => { resize.current = null; }, onLostPointerCapture: () => { resize.current = null; }, onKeyDown: e => { if (e.key === "ArrowUp" || e.key === "ArrowDown") {
                        e.preventDefault();
                        setComposerHeight(value => resizedComposerHeight(value, 0, e.key === "ArrowUp" ? -10 : 10));
                    } } },
                    React.createElement("svg", { width: "14", height: "14", viewBox: "0 0 16 16", fill: "none", stroke: "currentColor", "aria-hidden": "true" },
                        React.createElement("path", { d: "m5 13 8-8m-3 8 3-3" })))),
            React.createElement("button", { className: "primary", disabled: !s.selected || !s.session || !draft.trim() }, t("chat.send"))),
        React.createElement("p", { className: "composer-help" }, t("chat.keyboard")));
}
