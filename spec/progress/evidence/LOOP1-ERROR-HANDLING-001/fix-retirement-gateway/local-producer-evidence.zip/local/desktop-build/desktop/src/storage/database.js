import { invoke } from "@tauri-apps/api/core";
export function accountDatabase(accountId) {
    // Account identity comes from the bound session, never a caller-selected path.
    return {
        transaction: statements => invoke("database_transaction", { accountId, statements }),
        query: (sql, binds) => invoke("database_query", { accountId, sql, binds }),
    };
}
