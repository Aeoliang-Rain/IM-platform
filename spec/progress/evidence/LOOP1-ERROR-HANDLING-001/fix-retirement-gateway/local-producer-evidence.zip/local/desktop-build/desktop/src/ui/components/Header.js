import { useText } from "../i18n/context.js";
import React from "react";
export function Header({ s, prefs, preferences, run }) {
    const t = useText();
    return React.createElement("header", { className: "topbar" },
        React.createElement("div", null,
            React.createElement("small", { className: "eyebrow" }, t("header.connected")),
            React.createElement("h1", null, (s.session || s.offlineAccount || !["Chat", "Friends"].includes(s.page)) ? t("nav." + s.page.toLowerCase()) : t("header.title"))),
        React.createElement("div", { className: "top-actions" },
            React.createElement("span", { className: "sync" }, s.sync === "syncing" ? t("sync.syncing") : s.sync === "failed" ? t("sync.attention") : s.connection === "offline" ? t("sync.local") : t("sync.current")),
            React.createElement("button", { className: "quiet", onClick: () => run(preferences({ ...prefs, theme: prefs.theme === "cold" ? "warm" : "cold" })) }, prefs.theme === "cold" ? t("settings.cold") : t("settings.warm"))));
}
