import { useText } from "../i18n/context.js";
import React from "react";
export function FriendsPanel({ s, query, setQuery, search, add, open, run }) {
    const t = useText();
    return React.createElement("section", { className: "page-content" },
        React.createElement("div", { className: "glass panel" },
            React.createElement("p", { className: "eyebrow" }, t("friends.eyebrow")),
            React.createElement("h2", null, t("friends.reach")),
            React.createElement("p", { className: "muted" }, t("friends.exact")),
            React.createElement("form", { className: "search", onSubmit: e => { e.preventDefault(); run(search(query)); } },
                React.createElement("input", { "aria-label": t("friends.searchLabel"), value: query, onChange: e => setQuery(e.target.value), required: true }),
                React.createElement("button", { className: "primary", disabled: s.busy || !s.session }, s.busy ? t("friends.searching") : t("friends.search"))),
            s.results.length === 0 && query && React.createElement("p", { className: "muted" }, t("friends.check")),
            s.results.map(u => React.createElement("div", { className: "person", key: u.userId },
                React.createElement("span", { className: "avatar" }, u.displayName[0]),
                React.createElement("div", null,
                    React.createElement("strong", null, u.displayName),
                    React.createElement("small", null,
                        "@",
                        u.username)),
                React.createElement("button", { disabled: !s.session || u.userId === (s.session?.userId ?? s.offlineAccount) || s.busy, onClick: () => run(add(u.userId)) }, t("friends.add"))))),
        React.createElement("div", { className: "glass panel" },
            React.createElement("h2", null,
                t("friends.your"),
                React.createElement("small", null, s.friends.length)),
            s.friends.length === 0 ? React.createElement("p", { className: "muted" }, t("friends.grow")) : s.friends.map(f => React.createElement("div", { className: "person", key: f.friendshipId },
                React.createElement("span", { className: "avatar" }, f.user.displayName[0]),
                React.createElement("div", null,
                    React.createElement("strong", null, f.user.displayName),
                    React.createElement("small", null,
                        "@",
                        f.user.username)),
                React.createElement("button", { onClick: () => run(open(f.directConversationId)) }, t("chat.message"))))));
}
