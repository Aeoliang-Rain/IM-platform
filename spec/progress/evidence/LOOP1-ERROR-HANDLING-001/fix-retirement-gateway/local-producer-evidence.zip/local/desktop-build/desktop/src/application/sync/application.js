import { uuid } from "../../../../shared/protocol-sdk/src/send/wire.js";
import { SendStorageFailure } from "../send.js";
import { SyncFailure } from "../../../../shared/protocol-sdk/src/sync/wire.js";
export class SyncApplication {
    send;
    http;
    opened = "";
    generation = 0;
    retired = false;
    stopped = false;
    controller = new AbortController();
    queue = Promise.resolve();
    requested = false;
    listeners = new Set();
    detach;
    detachDelivery;
    wasReady = false;
    poll;
    current = { status: "idle", error: null, unavailable: [] };
    constructor(send, http) {
        this.send = send;
        this.http = http;
        if (!http.matchesSession(s => send.matchesSession(s)))
            throw new SyncFailure("authentication");
        this.detachDelivery = send.observeDelivery(() => { if (send.state.connection === "ready")
            void this.synchronize().catch(error => { if (!(error instanceof SyncFailure || error instanceof SendStorageFailure))
                throw error; }); });
        this.detach = send.observe(s => {
            const ready = s.connection === "ready";
            if (!ready && this.wasReady) {
                this.generation++;
                this.requested = false;
                this.controller.abort();
                this.controller = new AbortController();
                if (!this.stopped)
                    this.publish({ status: "idle", error: null, unavailable: this.current.unavailable });
            }
            if (ready && !this.wasReady && !this.stopped)
                void this.synchronize().catch(error => { if (!(error instanceof SyncFailure || error instanceof SendStorageFailure))
                    throw error; });
            this.wasReady = ready;
        });
        // Low-frequency metadata changes have no message-delivery trigger.
        this.poll = setInterval(() => { if (send.state.connection === "ready" && !this.stopped)
            void this.synchronize().catch(error => { if (!(error instanceof SyncFailure || error instanceof SendStorageFailure))
                throw error; }); }, 10000);
    }
    get state() { return this.current; }
    observe(listener) { this.listeners.add(listener); listener(this.current); return () => this.listeners.delete(listener); }
    publish(s) { if (this.retired)
        return; this.current = Object.freeze({ ...s, unavailable: Object.freeze([...s.unavailable]) }); for (const l of this.listeners)
        l(this.current); }
    async openConversation(c) { const selected = uuid(c); await this.send.openConversation(selected); this.opened = selected; await this.synchronize(); }
    synchronize() {
        if (this.retired || this.stopped)
            return Promise.resolve();
        this.requested = true;
        const job = this.queue.then(async () => {
            if (!this.requested || this.retired || this.stopped)
                return;
            this.requested = false;
            const g = this.generation, signal = this.controller.signal;
            const active = () => !this.retired && !this.stopped && this.generation === g && !signal.aborted;
            this.publish({ status: "syncing", error: null, unavailable: [] });
            const unavailable = [];
            try {
                do {
                    if (!active())
                        return;
                    const cursor = await this.send.repository.cursor(), page = await this.http.user(cursor, signal);
                    if (!active())
                        return;
                    await this.send.mergeUserPage(page, cursor, active);
                    if (!active())
                        return;
                    if (!page.hasMore)
                        break;
                    if (await this.send.repository.cursor() === cursor)
                        throw new SyncFailure("protocol");
                } while (active());
                for (const c of new Set([...(await this.send.repository.conversationIds()), ...(this.opened ? [this.opened] : [])])) {
                    try {
                        do {
                            if (!active())
                                return;
                            const after = await this.send.repository.contiguous(c), page = await this.http.conversation(c, after, signal);
                            if (!active())
                                return;
                            await this.send.mergeMessages(page.messages, active);
                            if (!active())
                                return;
                            if (!page.hasMore)
                                break;
                            if (await this.send.repository.contiguous(c) <= after)
                                throw new SyncFailure("protocol");
                        } while (active());
                    }
                    catch (error) {
                        if (error instanceof SyncFailure && error.kind === "unavailable") {
                            unavailable.push(c);
                            continue;
                        }
                        throw error;
                    }
                }
                if (active())
                    this.publish({ status: "idle", error: null, unavailable });
            }
            catch (error) {
                if (!(error instanceof SyncFailure || error instanceof SendStorageFailure))
                    throw error;
                if (!active())
                    return;
                const kind = error instanceof SendStorageFailure ? "storage" : error.kind;
                if (kind === "authentication") {
                    this.stopped = true;
                    this.generation++;
                    this.controller.abort();
                    this.send.disconnect();
                }
                this.publish({ status: "failed", error: kind, unavailable });
                throw error;
            }
        });
        this.queue = job.catch(error => { if (!(error instanceof SyncFailure || error instanceof SendStorageFailure))
            throw error; });
        return job;
    }
    async idle() { await this.queue; await this.send.idle(); }
    async close() { if (this.retired)
        return; this.retired = true; clearInterval(this.poll); this.generation++; this.controller.abort(); this.detach(); this.detachDelivery(); this.listeners.clear(); this.current = { status: "retired", error: null, unavailable: [] }; this.send.close(); await this.queue; await this.send.idle(); }
}
