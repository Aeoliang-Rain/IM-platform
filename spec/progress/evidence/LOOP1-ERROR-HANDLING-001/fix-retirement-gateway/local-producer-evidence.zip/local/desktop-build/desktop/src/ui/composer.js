export function resizedComposerHeight(height, startY, currentY) { return Math.max(42, Math.min(150, height + startY - currentY)); }
