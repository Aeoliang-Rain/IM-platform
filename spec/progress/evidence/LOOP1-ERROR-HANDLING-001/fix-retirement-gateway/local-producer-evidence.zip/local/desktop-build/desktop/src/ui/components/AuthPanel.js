import { useText } from "../i18n/context.js";
import React from "react";
export function AuthPanel({ s, registering, setRegistering, confirmation, setConfirmation, registered, setRegistered, username, setUsername, password, setPassword, register, login, restore, run }) {
    const t = useText();
    return React.createElement("section", { className: "login-layout" },
        React.createElement("div", { className: "welcome" },
            React.createElement("img", { className: "login-logo", src: "logo.png", alt: t("brand.logo") }),
            React.createElement("p", { className: "eyebrow" }, t("auth.welcomeEyebrow")),
            React.createElement("h2", null,
                t("auth.stayClose"),
                React.createElement("br", null),
                t("auth.thinkBeyond")),
            React.createElement("p", null, t("auth.description"))),
        React.createElement("form", { className: "glass login", onSubmit: e => { e.preventDefault(); if (registering) {
                run(register(username, password, confirmation).then(ok => { if (ok) {
                    setRegistered(true);
                    setRegistering(false);
                    setPassword("");
                    setConfirmation("");
                } }));
            }
            else {
                run(login(s.endpoint, username, password));
                setPassword("");
            } } },
            React.createElement("p", { className: "eyebrow" }, registering ? t("auth.join") : t("auth.welcomeBack")),
            React.createElement("h2", null, registering ? t("auth.createTitle") : t("auth.openTitle")),
            registered && !registering && React.createElement("p", { role: "status" }, t("auth.created")),
            React.createElement("label", null,
                t("auth.username"),
                React.createElement("input", { autoComplete: "username", value: username, onChange: e => setUsername(e.target.value), required: true, minLength: registering ? 3 : undefined, maxLength: 64, pattern: registering ? "[A-Za-z0-9][A-Za-z0-9._-]*" : undefined })),
            React.createElement("label", null,
                t("auth.password"),
                React.createElement("input", { type: "password", autoComplete: registering ? "new-password" : "current-password", value: password, onChange: e => setPassword(e.target.value), required: true, minLength: registering ? 12 : undefined, maxLength: 256 })),
            registering && React.createElement(React.Fragment, null,
                React.createElement("label", null,
                    t("auth.confirmPassword"),
                    React.createElement("input", { type: "password", autoComplete: "new-password", value: confirmation, onChange: e => setConfirmation(e.target.value), required: true, maxLength: 256 })),
                React.createElement("small", null, t("auth.passwordHint"))),
            React.createElement("button", { className: "primary", disabled: s.busy || !username || !password || (registering && !confirmation) }, s.busy ? t("auth.wait") : registering ? t("auth.create") : t("auth.signIn")),
            React.createElement("button", { type: "button", className: "quiet", disabled: s.busy, onClick: () => { setRegistering(!registering); setPassword(""); setConfirmation(""); setRegistered(false); } }, registering ? t("auth.existing") : t("auth.new")),
            !registering && React.createElement("button", { type: "button", className: "quiet resume", disabled: s.busy, onClick: () => run(restore(s.endpoint)) }, t("auth.resume"))));
}
