import { useText } from "../i18n/context.js";
import React from "react";
export function WindowBar({ maximized, windowControl, run }) {
    const t = useText();
    return React.createElement("div", { className: "window-bar" },
        React.createElement("div", { className: "window-drag", onPointerDown: e => { if (e.button === 0)
                run(windowControl("drag")); }, onDoubleClick: () => run(windowControl("maximize")) },
            React.createElement("img", { src: "logo.png", alt: "" }),
            React.createElement("span", null, "IM+ \u00B7 PlugWorldIM")),
        React.createElement("div", { className: "window-actions" },
            React.createElement("button", { title: t("window.minimize"), "aria-label": t("window.minimize"), onClick: () => run(windowControl("minimize")) }, "\u2212"),
            React.createElement("button", { title: maximized ? t("window.restore") : t("window.maximize"), "aria-label": maximized ? t("window.restore") : t("window.maximize"), onClick: () => run(windowControl("maximize")) },
                React.createElement("svg", { width: "18", height: "18", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", "aria-hidden": "true" }, maximized ? React.createElement(React.Fragment, null,
                    React.createElement("path", { d: "M8 5V4a1 1 0 0 1 1-1h11a1 1 0 0 1 1 1v11a1 1 0 0 1-1 1h-1" }),
                    React.createElement("rect", { x: "4", y: "7", width: "13", height: "13", rx: "1" })) : React.createElement("rect", { x: "5", y: "5", width: "14", height: "14", rx: "1" }))),
            React.createElement("button", { className: "window-close", "aria-label": t("window.close"), onClick: () => run(windowControl("close")) }, "\u00D7")));
}
