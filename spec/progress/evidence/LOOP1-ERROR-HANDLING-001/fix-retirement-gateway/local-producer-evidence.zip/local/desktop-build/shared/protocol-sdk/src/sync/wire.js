import { WireFailure, parse, object, uuid, positive, timestamp, content } from "../send/wire.js";
export const MAX_RESPONSE = 6 * 1024 * 1024;
const invalid = () => { throw new SyncFailure("protocol", "Invalid Sync response"); };
const kinds = ["friend.changed", "conversation.changed", "membership.changed", "plugin.changed"];
export function cursor(v) { if (typeof v !== "string" || [...v].length < 1 || [...v].length > 256)
    return invalid(); return v; }
function list(v) { if (!Array.isArray(v) || v.length > 100)
    return invalid(); return v; }
function base(raw, keys, requestId, type) { const p = object(parse(raw, MAX_RESPONSE), keys); if (p.syncVersion !== "1.0" || p.type !== type || uuid(p.requestId) !== requestId || typeof p.hasMore !== "boolean")
    return invalid(); return p; }
export function userPage(raw, requestId, inputCursor) {
    try {
        const p = base(raw, ["syncVersion", "type", "requestId", "events", "nextCursor", "hasMore"], requestId, "sync.user.page");
        const ids = new Set(), cursors = new Set();
        const events = list(p.events).map(v => {
            const e = object(v, ["eventId", "cursor", "kind", "subjectId", "revision"]);
            const eventId = uuid(e.eventId), token = cursor(e.cursor);
            if (ids.has(eventId) || cursors.has(token) || token === inputCursor || typeof e.kind !== "string" || !kinds.includes(e.kind))
                return invalid();
            ids.add(eventId);
            cursors.add(token);
            return { eventId, cursor: token, kind: e.kind, subjectId: uuid(e.subjectId), revision: positive(e.revision) };
        });
        const nextCursor = cursor(p.nextCursor), hasMore = p.hasMore;
        if (events.length ? nextCursor !== events.at(-1).cursor || nextCursor === inputCursor : nextCursor !== inputCursor || hasMore)
            return invalid();
        return { syncVersion: "1.0", type: "sync.user.page", requestId, events, nextCursor, hasMore };
    }
    catch (error) {
        if (error instanceof WireFailure)
            return invalid();
        throw error;
    }
}
export function conversationPage(raw, requestId, conversationId, afterSeq) {
    try {
        const p = base(raw, ["syncVersion", "type", "requestId", "conversationId", "messages", "hasMore"], requestId, "sync.conversation.page");
        if (uuid(p.conversationId) !== conversationId)
            return invalid();
        let next = afterSeq + 1n;
        const ids = new Set(), requests = new Set();
        const messages = list(p.messages).map(v => {
            const m = object(v, ["conversationId", "seq", "messageId", "senderId", "requestId", "createdAt", "content"]);
            const messageId = uuid(m.messageId), rid = uuid(m.requestId), seq = positive(m.seq);
            if (uuid(m.conversationId) !== conversationId || seq !== next++ || ids.has(messageId) || requests.has(rid))
                return invalid();
            ids.add(messageId);
            requests.add(rid);
            return { conversationId, seq, messageId, senderId: uuid(m.senderId), requestId: rid, createdAt: timestamp(m.createdAt), content: content(m.content) };
        });
        if (p.hasMore && !messages.length)
            return invalid();
        return { messages, hasMore: p.hasMore };
    }
    catch (error) {
        if (error instanceof WireFailure)
            return invalid();
        throw error;
    }
}
export class SyncFailure extends Error {
    kind;
    constructor(kind, message = "Sync " + kind + " failure") {
        super(message);
        this.kind = kind;
    }
}
export function errorResponse(raw, requestId, status, conversation) {
    try {
        const p = object(parse(raw, MAX_RESPONSE), ["requestId", "error"]);
        if (uuid(p.requestId) !== requestId)
            return invalid();
        const e = p.error;
        if (!e || typeof e !== "object" || Array.isArray(e) || Object.keys(e).some(k => !["code", "message", "violations"].includes(k)) || typeof e.message !== "string" || !e.message)
            return invalid();
        if (e.violations !== undefined) {
            if (!Array.isArray(e.violations))
                return invalid();
            for (const v of e.violations) {
                const f = object(v, ["field", "reason"]);
                if (typeof f.field !== "string" || !f.field || typeof f.reason !== "string" || !f.reason)
                    return invalid();
            }
        }
        if (typeof e.code !== "string")
            return invalid();
        if (status === 401 && ["AUTH_REQUIRED", "AUTH_TOKEN_INVALID", "AUTH_TOKEN_EXPIRED", "AUTH_SESSION_REVOKED", "AUTH_SESSION_EPOCH_STALE", "AUTH_CLIENT_TYPE_MISMATCH"].includes(e.code))
            return new SyncFailure("authentication");
        if (conversation && status === 403 && e.code === "AUTHORIZATION_DENIED")
            return new SyncFailure("unavailable");
        if (status === 400 && e.code === "VALIDATION_FAILED" || status === 426 && e.code === "PROTOCOL_VERSION_UNSUPPORTED")
            return new SyncFailure("protocol");
        return invalid();
    }
    catch (error) {
        if (error instanceof WireFailure || error instanceof SyncFailure)
            return new SyncFailure("protocol");
        throw error;
    }
}
export function userRequest(requestId, inputCursor) { return JSON.stringify({ syncVersion: "1.0", type: "sync.user.request", requestId: uuid(requestId), cursor: cursor(inputCursor), limit: 100 }); }
export function conversationRequest(requestId, c, afterSeq) { if (afterSeq < 0n)
    return invalid(); return JSON.stringify({ syncVersion: "1.0", type: "sync.conversation.request", requestId: uuid(requestId), conversationId: uuid(c), afterSeq: "SEQ", limit: 100 }).replace('"SEQ"', afterSeq.toString()); }
