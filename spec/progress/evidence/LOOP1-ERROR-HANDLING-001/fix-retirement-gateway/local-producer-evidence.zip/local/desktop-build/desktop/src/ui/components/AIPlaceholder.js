import { useText } from "../i18n/context.js";
import React from "react";
export function AIPlaceholder({}) {
    const t = useText();
    return React.createElement("section", { className: "page-content" },
        React.createElement("div", { className: "glass future" },
            React.createElement("div", { className: "orb" }, "\u2727"),
            React.createElement("p", { className: "eyebrow" }, t("ai.eyebrow")),
            React.createElement("h2", null, t("ai.title")),
            React.createElement("p", null, t("ai.description")),
            React.createElement("span", { className: "badge" }, t("ai.later")),
            React.createElement("p", { className: "muted" }, t("ai.detail"))));
}
