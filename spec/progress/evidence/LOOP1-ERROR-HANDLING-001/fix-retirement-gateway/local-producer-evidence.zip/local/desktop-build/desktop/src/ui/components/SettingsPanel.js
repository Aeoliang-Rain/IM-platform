import { LanguagePanel } from "./LanguagePanel.js";
import { useText } from "../i18n/context.js";
import { ProfilePanel } from "./ProfilePanel.js";
import React from "react";
export function SettingsPanel({ language, selectLanguage, languageStored, s, prefs, preferences, refresh, disconnect, reconnect, testNotification, logout, run }) {
    const t = useText();
    return React.createElement("section", { className: "page-content settings" },
        React.createElement("div", { className: "glass panel" },
            React.createElement("p", { className: "eyebrow" }, t("settings.eyebrow")),
            React.createElement(LanguagePanel, { language: language, selectLanguage: selectLanguage, languageStored: languageStored }),
            React.createElement("h2", null, t("settings.appearance")),
            React.createElement("p", { className: "muted" }, t("settings.independent")),
            React.createElement("fieldset", null,
                React.createElement("legend", null, t("settings.theme")),
                React.createElement("div", { className: "theme-choices" }, ["cold", "warm"].map(theme => React.createElement("button", { key: theme, className: prefs.theme === theme ? "theme-choice active" : "theme-choice", "aria-pressed": prefs.theme === theme, onClick: () => run(preferences({ ...prefs, theme: theme })) },
                    React.createElement("span", { className: "swatch " + theme }),
                    React.createElement("strong", null, theme === "cold" ? t("settings.cold") : t("settings.warm")),
                    React.createElement("small", null, theme === "cold" ? t("settings.coldHint") : t("settings.warmHint")))))),
            React.createElement("label", null,
                t("settings.font"),
                React.createElement("strong", null,
                    prefs.fontSize,
                    "px"),
                React.createElement("input", { type: "range", min: "14", max: "22", step: "1", value: prefs.fontSize, onChange: e => run(preferences({ ...prefs, fontSize: Number(e.target.value) })) })),
            React.createElement("label", null,
                t("settings.spacing"),
                React.createElement("strong", null, prefs.density === 0.8 ? t("settings.compact") : prefs.density === 1.2 ? t("settings.comfort") : t("settings.standard")),
                React.createElement("input", { type: "range", min: "0.8", max: "1.2", step: "0.2", value: prefs.density, onChange: e => run(preferences({ ...prefs, density: Number(e.target.value) })) })),
            React.createElement("p", { className: "muted" }, t("settings.saved"))),
        React.createElement(ProfilePanel, { s: s, refresh: refresh, disconnect: disconnect, reconnect: reconnect, testNotification: testNotification, logout: logout, run: run }));
}
