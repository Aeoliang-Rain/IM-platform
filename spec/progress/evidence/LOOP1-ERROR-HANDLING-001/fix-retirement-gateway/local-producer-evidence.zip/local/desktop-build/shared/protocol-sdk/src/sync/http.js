import { WireFailure } from "../send/wire.js";
import { MAX_RESPONSE, SyncFailure, errorResponse, userRequest, conversationRequest, userPage, conversationPage } from "./wire.js";
export class SyncHttp {
    fetcher;
    id;
    transport;
    session;
    matchesSession(check) { return check(this.session); }
    base;
    token;
    constructor(endpoint, session, fetcher = fetch, id = () => crypto.randomUUID(), transport = error => error instanceof TypeError || error instanceof DOMException) {
        this.fetcher = fetcher;
        this.id = id;
        this.transport = transport;
        this.session = Object.freeze({ ...session });
        const accessToken = this.session.accessToken;
        let url;
        try {
            url = new URL(endpoint);
        }
        catch (error) {
            if (error instanceof TypeError)
                throw new SyncFailure("protocol");
            throw error;
        }
        if (url.protocol !== "https:" || !url.hostname || url.username || url.password || url.search || url.hash || url.pathname !== "/" || !accessToken || /[\r\n]/.test(accessToken))
            throw new SyncFailure("protocol");
        this.base = url.origin;
        this.token = accessToken;
    }
    async post(path, body, requestId, signal) {
        let response;
        try {
            response = await this.fetcher(this.base + path, { method: "POST", headers: { "Authorization": "Bearer " + this.token, "Content-Type": "application/json" }, body, signal, redirect: "error", credentials: "omit", cache: "no-store" });
        }
        catch (error) {
            if (error instanceof WireFailure)
                throw new SyncFailure("protocol");
            if (this.transport(error))
                throw new SyncFailure("transport");
            throw error;
        }
        if (response.redirected || response.headers.get("cache-control") !== "no-store" || !/^application\/json(?:\s*;|$)/i.test(response.headers.get("content-type") ?? ""))
            throw new SyncFailure(response.status >= 500 ? "transport" : "protocol");
        const reader = response.body?.getReader();
        if (!reader)
            throw new SyncFailure("transport");
        const decoder = new TextDecoder("utf-8", { fatal: true });
        let raw = "", size = 0;
        let primary, sourceFailure;
        try {
            for (;;) {
                let item;
                try {
                    item = await reader.read();
                }
                catch (error) {
                    sourceFailure = { error };
                    if (error instanceof TypeError || error instanceof DOMException)
                        throw new SyncFailure("transport");
                    throw error;
                }
                if (item.done)
                    break;
                size += item.value.byteLength;
                if (size > MAX_RESPONSE)
                    throw new SyncFailure("protocol");
                try {
                    raw += decoder.decode(item.value, { stream: true });
                }
                catch (error) {
                    sourceFailure = { error };
                    if (error instanceof TypeError)
                        throw new SyncFailure("protocol");
                    throw error;
                }
            }
            try {
                raw += decoder.decode();
            }
            catch (error) {
                sourceFailure = { error };
                if (error instanceof TypeError)
                    throw new SyncFailure("protocol");
                throw error;
            }
        }
        catch (error) {
            primary = { error };
            throw error;
        }
        finally {
            try {
                await reader.cancel();
            }
            catch (error) {
                if (primary) {
                    if (error === primary.error || (sourceFailure && error === sourceFailure.error))
                        throw primary.error;
                    const causes = new AggregateError([sourceFailure ? sourceFailure.error : primary.error, error], "Response processing and cleanup failed");
                    if (primary.error instanceof SyncFailure && (error instanceof TypeError || error instanceof DOMException)) {
                        const failure = new SyncFailure(primary.error.kind, primary.error.message);
                        Object.defineProperty(failure, "cause", { value: causes });
                        throw failure;
                    }
                    throw causes;
                }
                if (error instanceof TypeError || error instanceof DOMException)
                    throw new SyncFailure("transport");
                throw error;
            }
        }
        if (response.status !== 200) {
            if ([400, 401, 403, 426].includes(response.status))
                throw errorResponse(raw, requestId, response.status, path.endsWith("conversation"));
            throw new SyncFailure("transport");
        }
        return raw;
    }
    async user(inputCursor, signal) { const requestId = this.id(); return userPage(await this.post("/v1/sync/user", userRequest(requestId, inputCursor), requestId, signal), requestId, inputCursor); }
    async conversation(c, afterSeq, signal) { const requestId = this.id(); return conversationPage(await this.post("/v1/sync/conversation", conversationRequest(requestId, c, afterSeq), requestId, signal), requestId, c, afterSeq); }
}
