import { WireFailure, content, decode, envelope, uuid } from "../../../shared/protocol-sdk/src/send/wire.js";
export class SendStorageFailure extends Error {
    constructor(cause) { super("Send storage operation failed", { cause }); }
}
// Each instance owns exactly one account/session. Retiring it cannot publish into
// a replacement account. All Repository operations and confirmations are ordered.
export class SendApplication {
    repository;
    factory;
    timeoutMs;
    id;
    socket = null;
    generation = 0;
    binding = "";
    bound = false;
    retired = false;
    queue = Promise.resolve();
    attempts = new Map();
    known = new Map();
    // RID -> sole Conversation, or null once ambiguous on this connection. Keep
    // settled identities until disconnect so delayed rejects remain unattributable.
    requestConversations = new Map();
    listeners = new Set();
    deliveries = new Set();
    conversation = "";
    current = { connection: "offline", messages: [], error: null };
    session;
    constructor(repository, session, factory = url => new WebSocket(url), timeoutMs = 15000, id = () => crypto.randomUUID()) {
        this.repository = repository;
        this.factory = factory;
        this.timeoutMs = timeoutMs;
        this.id = id;
        this.session = Object.freeze({ ...session, userId: uuid(session.userId), sessionId: uuid(session.sessionId) });
        if (session.sessionEpoch < 1n || !session.accessToken || timeoutMs < 1)
            throw new Error("Invalid send session");
    }
    matchesSession(s) { return s.userId === this.session.userId && s.sessionId === this.session.sessionId && s.sessionEpoch === this.session.sessionEpoch && s.accessToken === this.session.accessToken; }
    get state() { return this.current; }
    observe(listener) { this.listeners.add(listener); listener(this.current); return () => this.listeners.delete(listener); }
    observeDelivery(listener) { this.deliveries.add(listener); return () => this.deliveries.delete(listener); }
    delivered(c, n) { if (!this.retired)
        for (const listener of this.deliveries)
            listener(c, n); }
    publish(state) {
        if (this.retired)
            return;
        this.current = Object.freeze({ ...state, messages: Object.freeze(state.messages.map(r => Object.freeze([...r]))) });
        for (const listener of this.listeners)
            listener(this.current);
    }
    async storage(action) {
        try {
            return await action();
        }
        catch (error) {
            if (typeof error === "string" && ["Storage directory unavailable", "Storage open failed", "Storage read open failed", "Transaction start failed", "Transaction rollback failed", "Transaction commit failed", "Storage statement rejected", "Storage query rejected", "Storage result unavailable", "Storage result type rejected", "Read-only setup failed", "Read-only reset failed"].includes(error))
                throw new SendStorageFailure(error);
            throw error;
        }
    }
    serial(action) {
        const result = this.queue.then(action);
        this.queue = result.catch(error => { if (!(error instanceof SendStorageFailure))
            throw error; this.publish({ ...this.current, error: "storage" }); });
        return result;
    }
    async idle() { await this.queue; }
    async refresh() {
        const messages = this.conversation ? await this.storage(() => this.repository.messages(this.conversation)) : [];
        this.publish({ ...this.current, messages });
    }
    async openConversation(conversationId) {
        return this.serial(async () => { if (this.retired)
            return; this.conversation = uuid(conversationId); await this.refresh(); });
    }
    connect(endpoint) {
        if (this.retired)
            throw new Error("Send application retired");
        const url = new URL(endpoint);
        if (url.protocol !== "wss:" || url.username || url.password || url.search || url.hash)
            throw new Error("Invalid WSS endpoint");
        this.disconnect();
        const generation = ++this.generation;
        this.binding = uuid(this.id());
        this.bound = false;
        const socket = this.factory(url.href);
        this.socket = socket;
        this.publish({ ...this.current, connection: "binding" });
        const active = () => !this.retired && this.socket === socket && this.generation === generation;
        socket.onopen = () => { if (active()) {
            try {
                socket.send(envelope("auth.bind", this.binding, { accessToken: this.session.accessToken }));
            }
            catch (error) {
                if (!(error instanceof DOMException))
                    throw error;
                this.disconnect();
            }
        } };
        socket.onmessage = event => { if (active())
            void this.serial(async () => { if (!active())
                return; if (typeof event.data !== "string") {
                this.protocolFailure();
                return;
            } try {
                await this.receive(event.data, generation);
            }
            catch (error) {
                if (error instanceof WireFailure)
                    this.protocolFailure();
                else
                    throw error;
            } }).catch(error => { if (!(error instanceof SendStorageFailure))
                throw error; }); };
        socket.onerror = socket.onclose = () => { if (active())
            this.disconnect(); };
    }
    protocolFailure() { this.disconnect(); this.publish({ ...this.current, error: "protocol" }); }
    disconnect() {
        const old = this.socket;
        this.socket = null;
        this.bound = false;
        this.generation++;
        this.requestConversations.clear();
        if (old) {
            old.onopen = old.onmessage = old.onclose = old.onerror = null;
            old.close();
        }
        this.publish({ ...this.current, connection: "offline" });
        for (const [key, attempt] of this.attempts) {
            if (attempt.timer)
                clearTimeout(attempt.timer);
            this.attempts.delete(key);
            void this.serial(async () => { await this.storage(() => this.repository.markFailed(attempt.message.conversationId, attempt.message.requestId)); await this.refresh(); }).catch(error => { if (!(error instanceof SendStorageFailure))
                throw error; });
        }
    }
    close() { this.disconnect(); this.retired = true; this.listeners.clear(); this.deliveries.clear(); this.current = { connection: "offline", messages: [], error: null }; }
    async send(conversationId, text) {
        const requestId = uuid(this.id());
        const message = { conversationId: uuid(conversationId), requestId, senderId: this.session.userId, content: content({ kind: "TEXT", text }) };
        await this.start(message);
        return requestId;
    }
    async retry(conversationId, requestId) {
        await this.serial(async () => {
            if (this.retired)
                throw new Error("Send application retired");
            const c = uuid(conversationId), r = uuid(requestId), row = (await this.storage(() => this.repository.messages(c))).find(row => row[0] === r);
            if (!row || row[1] !== this.session.userId)
                throw new Error("Unknown own send");
            if (row[3] === "SENT")
                return;
            await this.begin({ conversationId: c, requestId: r, senderId: row[1], content: content({ kind: "TEXT", text: row[2] }) });
        });
    }
    start(message) { return this.serial(() => this.begin(message)); }
    key(message) { return message.conversationId + "/" + message.requestId; }
    async begin(message) {
        if (this.retired)
            throw new Error("Send application retired");
        await this.storage(() => this.repository.localSend(message));
        this.known.set(this.key(message), message);
        await this.refresh();
        if (this.retired)
            return;
        const key = this.key(message), prior = this.attempts.get(key);
        if (prior?.timer)
            clearTimeout(prior.timer);
        const attempt = { message, generation: this.generation, timer: null, sent: false };
        this.attempts.set(key, attempt);
        if (!this.bound || !this.socket) {
            await this.fail(key, attempt);
            return;
        }
        try {
            this.socket.send(envelope("message.send", message.requestId, { conversationId: message.conversationId, content: message.content }));
            attempt.sent = true;
        }
        catch (error) {
            if (!(error instanceof DOMException))
                throw error;
            await this.fail(key, attempt);
            return;
        }
        const priorConversation = this.requestConversations.get(message.requestId);
        this.requestConversations.set(message.requestId, priorConversation === undefined || priorConversation === message.conversationId ? message.conversationId : null);
        attempt.timer = setTimeout(() => { void this.serial(() => this.fail(key, attempt)).catch(error => { if (!(error instanceof SendStorageFailure))
            throw error; }); }, this.timeoutMs);
    }
    async fail(key, attempt) {
        if (this.attempts.get(key) !== attempt)
            return;
        this.attempts.delete(key);
        await this.storage(() => this.repository.markFailed(attempt.message.conversationId, attempt.message.requestId));
        await this.refresh();
    }
    clear(c, r) { const key = c + "/" + r, a = this.attempts.get(key); if (a?.timer)
        clearTimeout(a.timer); this.attempts.delete(key); }
    async receive(raw, generation) {
        const frame = decode(raw), p = frame.payload;
        if (frame.type === "ping") {
            this.socket?.send(envelope("pong", frame.requestId, {}));
            return;
        }
        if (frame.type === "pong")
            return;
        if (frame.type === "auth.ack") {
            if (frame.requestId !== this.binding || p.status !== "bound" || p.userId !== this.session.userId || p.sessionId !== this.session.sessionId || p.clientType !== "DESKTOP" || p.sessionEpoch !== this.session.sessionEpoch || this.bound) {
                this.protocolFailure();
                return;
            }
            this.bound = true;
            this.publish({ ...this.current, connection: "ready" });
            return;
        }
        if (!this.bound) {
            this.protocolFailure();
            return;
        }
        if (frame.type === "session.revoked") {
            if (p.sessionId !== this.session.sessionId)
                this.protocolFailure();
            else
                this.disconnect();
            return;
        }
        if (frame.type === "message.created") {
            const message = { ...p, requestId: frame.requestId };
            await this.storage(() => this.repository.syncMessages([message]));
            this.clear(message.conversationId, message.requestId);
            await this.refresh();
            this.delivered(message.conversationId, BigInt(message.seq));
            return;
        }
        if (frame.type === "message.ack") {
            if (p.status === "rejected") {
                // Rejection has no Conversation. Ambiguous identities must keep their
                // independent confirmation/timeout paths instead of failing all sends.
                const matches = [...this.attempts].filter(([, a]) => a.message.requestId === frame.requestId && a.sent && a.generation === generation);
                if (matches.length === 1 && this.requestConversations.get(frame.requestId) === matches[0][1].message.conversationId)
                    await this.fail(matches[0][0], matches[0][1]);
            }
            else {
                const c = p.conversationId, key = c + "/" + frame.requestId;
                // An ACK only confirms a send issued by this application; retry reloads
                // the durable intent after restart. Realtime/Sync own other deliveries.
                if (!this.known.has(key))
                    return;
                await this.storage(() => this.repository.committedAck(frame.requestId, p));
                this.clear(c, frame.requestId);
                await this.refresh();
                this.delivered(c, p.seq);
            }
        }
    }
    async mergeMessages(messages, active = () => true, failBeforeAdvance = false) {
        return this.serial(async () => { if (this.retired || !active())
            return; await this.storage(() => this.repository.syncMessages(messages, failBeforeAdvance)); for (const m of messages)
            this.clear(m.conversationId, m.requestId); await this.refresh(); });
    }
    async mergeUserPage(page, expectedCursor, active, failBeforeAdvance = false) {
        return this.serial(async () => { if (this.retired || !active())
            return; await this.storage(() => this.repository.userPage(page, expectedCursor, failBeforeAdvance)); });
    }
}
