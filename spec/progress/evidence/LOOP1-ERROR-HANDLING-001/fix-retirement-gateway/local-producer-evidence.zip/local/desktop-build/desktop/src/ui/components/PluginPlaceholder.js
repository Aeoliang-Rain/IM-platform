import { useText } from "../i18n/context.js";
import React from "react";
export function PluginPlaceholder({}) {
    const t = useText();
    return React.createElement("section", { className: "page-content" },
        React.createElement("div", { className: "glass panel" },
            React.createElement("p", { className: "eyebrow" }, t("plugin.eyebrow")),
            React.createElement("h2", null, t("plugin.title")),
            React.createElement("p", null, t("plugin.description")),
            React.createElement("div", { className: "empty" },
                React.createElement("span", null, "\u229E"),
                React.createElement("h3", null, t("plugin.unavailable")),
                React.createElement("p", null, t("plugin.detail"))),
            React.createElement("span", { className: "badge" }, t("plugin.badge"))));
}
