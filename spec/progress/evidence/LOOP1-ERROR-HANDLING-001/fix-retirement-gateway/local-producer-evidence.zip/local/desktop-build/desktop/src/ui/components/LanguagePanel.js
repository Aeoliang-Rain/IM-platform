import React from "react";
import { useText } from "../i18n/context.js";
import { languageEntry, languageNames, locales } from "../i18n/resources.js";
export function LanguagePanel({ language, selectLanguage, languageStored }) {
    const t = useText();
    return React.createElement("fieldset", { className: "language-panel" },
        React.createElement("legend", null, languageEntry),
        React.createElement("div", { className: "language-list", role: "group", "aria-label": languageEntry }, locales.map((value, index) => React.createElement("button", { type: "button", key: value, lang: value, "aria-pressed": language === value, onClick: () => void selectLanguage(value) }, languageNames[index]))),
        React.createElement("p", { role: "status", className: languageStored ? "muted" : "notice" }, t(languageStored ? "language.saved" : "language.failed")));
}
