import { LanguageContext, useText, useDisplayText } from "../i18n/context.js";
import { WindowBar } from "./WindowBar.js";
import { Navigation } from "./Navigation.js";
import { Header } from "./Header.js";
import { AuthPanel } from "./AuthPanel.js";
import { ConversationList } from "./ConversationList.js";
import { Messages } from "./Messages.js";
import { Composer } from "./Composer.js";
import { FriendsPanel } from "./FriendsPanel.js";
import { AIPlaceholder } from "./AIPlaceholder.js";
import { PluginPlaceholder } from "./PluginPlaceholder.js";
import { SettingsPanel } from "./SettingsPanel.js";
import React, { useEffect, useRef, useState, useSyncExternalStore } from "react";
import { Workspace } from "../../application/ui/workspace.js";
import { windowControl, windowMaximized } from "../../application/ui/native.js";
const app = new Workspace();
export function Shell() {
    const s = useSyncExternalStore(app.observe, app.snapshot);
    useEffect(() => { document.documentElement.lang = s.language; }, [s.language]);
    return React.createElement(LanguageContext.Provider, { value: s.language },
        React.createElement(WorkspaceShell, null));
}
function WorkspaceShell() {
    const t = useText();
    const display = useDisplayText();
    const s = useSyncExternalStore(app.observe, app.snapshot), [registering, setRegistering] = useState(false), [confirmation, setConfirmation] = useState(""), [registered, setRegistered] = useState(false), [username, setUsername] = useState(""), [password, setPassword] = useState(""), [query, setQuery] = useState(""), [draft, setDraft] = useState(""), [maximized, setMaximized] = useState(false);
    const [composerHeight, setComposerHeight] = useState(72), textarea = useRef(null), resize = useRef(null);
    useEffect(() => { void app.start(); }, []);
    useEffect(() => { let active = true; const refresh = () => { void windowMaximized().then(value => { if (active)
        setMaximized(value); }); }; refresh(); window.addEventListener("resize", refresh); return () => { active = false; window.removeEventListener("resize", refresh); }; }, []);
    const add = app.add.bind(app), disconnect = app.disconnect.bind(app), login = app.login.bind(app), logout = app.logout.bind(app), open = app.open.bind(app), page = app.page.bind(app), preferences = app.preferences.bind(app), reconnect = app.reconnect.bind(app), refresh = app.refresh.bind(app), register = app.register.bind(app), restore = app.restore.bind(app), retry = app.retry.bind(app), search = app.search.bind(app), send = app.send.bind(app), testNotification = app.testNotification.bind(app);
    const prefs = s.appearance, friend = s.friends.find(f => f.directConversationId === s.selected), title = friend?.user.displayName ?? (s.selected ? t("chat.conversationId", { id: s.selected.slice(0, 8) }) : t("chat.your"));
    const run = (p) => { void p; };
    const authenticated = !!(s.session || s.offlineAccount);
    return React.createElement("div", { className: "app-window " + prefs.theme, style: { "--font": prefs.fontSize + "px", "--density": prefs.density } },
        React.createElement(WindowBar, { maximized: maximized, windowControl: windowControl, run: run }),
        React.createElement("div", { className: "workspace " + (authenticated ? "authenticated" : "anonymous") },
            authenticated && React.createElement(Navigation, { s: s, page: page }),
            React.createElement("main", null,
                authenticated && React.createElement(Header, { s: s, prefs: prefs, preferences: preferences, run: run }),
                s.error && React.createElement("div", { className: "notice", role: "alert" },
                    React.createElement("span", null, display(s.error)),
                    s.session && React.createElement("button", { disabled: !s.session, onClick: () => run(reconnect()) }, t("auth.reconnect"))),
                !authenticated ? React.createElement(AuthPanel, { s: s, registering: registering, setRegistering: setRegistering, confirmation: confirmation, setConfirmation: setConfirmation, registered: registered, setRegistered: setRegistered, username: username, setUsername: setUsername, password: password, setPassword: setPassword, register: register, login: login, restore: restore, run: run }) :
                    s.page === "Chat" ? React.createElement("section", { className: "chat-layout" },
                        React.createElement(ConversationList, { s: s, page: page, open: open, run: run }),
                        React.createElement("div", { className: "chat-pane glass" }, s.selected && React.createElement(React.Fragment, null,
                            React.createElement("div", { className: "chat-heading" },
                                React.createElement("span", { className: "avatar" }, friend?.user.displayName[0] ?? "#"),
                                React.createElement("div", null,
                                    React.createElement("h2", null, title),
                                    React.createElement("small", null, s.connection === "ready" ? t("sync.connected") : t("sync.offline"))),
                                React.createElement("button", { className: "quiet", disabled: !s.session, onClick: () => run(reconnect()) }, t("auth.reconnect"))),
                            React.createElement(Messages, { s: s, retry: retry, run: run }),
                            React.createElement(Composer, { s: s, draft: draft, setDraft: setDraft, send: send, run: run, textarea: textarea, composerHeight: composerHeight, setComposerHeight: setComposerHeight, resize: resize })))) :
                        s.page === "Friends" ? React.createElement(FriendsPanel, { s: s, query: query, setQuery: setQuery, search: search, add: add, open: open, run: run }) :
                            s.page === "AI" ? React.createElement(AIPlaceholder, null) :
                                s.page === "Plugin" ? React.createElement(PluginPlaceholder, null) :
                                    React.createElement(SettingsPanel, { selectLanguage: app.selectLanguage.bind(app), language: s.language, languageStored: s.languageStored, s: s, prefs: prefs, preferences: preferences, refresh: refresh, disconnect: disconnect, reconnect: reconnect, testNotification: testNotification, logout: logout, run: run }))));
}
