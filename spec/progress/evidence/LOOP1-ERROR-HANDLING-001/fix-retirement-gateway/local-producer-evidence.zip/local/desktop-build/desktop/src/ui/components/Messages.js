import { LanguageContext, useText } from "../i18n/context.js";
import React from "react";
function stateKey(state) { switch (state) {
    case "SENT": return "chat.sent";
    case "SENDING": return "chat.sending";
    case "FAILED": return "chat.failed";
    default: throw new Error("Unknown message state");
} }
export function Messages({ s, retry, run }) {
    const t = useText();
    const locale = React.useContext(LanguageContext);
    return React.createElement("div", { className: "messages", role: "log", "aria-live": "polite" }, !s.selected ? React.createElement("div", { className: "empty" },
        React.createElement("span", null, "\u2727"),
        React.createElement("h3", null, t("chat.place")),
        React.createElement("p", null, t("chat.choose"))) : s.messages.length === 0 ? React.createElement("div", { className: "empty" },
        React.createElement("h3", null, t("chat.fresh")),
        React.createElement("p", null, t("chat.hello"))) : s.messages.map(m => { const identity = m[0] ?? m[4]; if (identity == null)
        throw new Error("Message identity missing"); if (m[2] == null)
        throw new Error("Message content missing"); const key = stateKey(m[3]); return React.createElement("div", { key: identity, className: m[1] === (s.session?.userId ?? s.offlineAccount) ? "message own" : "message" },
        React.createElement("div", { className: "bubble" }, m[2]),
        React.createElement("small", null,
            m[6] ? new Date(m[6]).toLocaleTimeString(locale, { hour: "2-digit", minute: "2-digit" }) : t("chat.now"),
            " \u00B7 ",
            t(key),
            m[3] === "FAILED" && m[1] === (s.session?.userId ?? s.offlineAccount) && m[0] && React.createElement("button", { disabled: !s.session, onClick: () => run(retry(m[0])) }, t("chat.retry")))); }));
}
