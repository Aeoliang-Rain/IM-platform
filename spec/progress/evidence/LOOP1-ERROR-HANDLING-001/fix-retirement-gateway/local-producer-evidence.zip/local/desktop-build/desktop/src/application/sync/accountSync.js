import { accountSend } from "../accountSend.js";
import { SyncHttp } from "../../../../shared/protocol-sdk/src/sync/http.js";
import { SyncApplication } from "./application.js";
// The existing account factory owns native SQLx binding and local-first loading.
export async function accountSync(session, endpoint) {
    const owner = Object.freeze({ ...session });
    const http = new SyncHttp(endpoint, owner);
    return new SyncApplication(await accountSend(owner), http);
}
