import React from "react";
import { translate, displayText } from "./resources.js";
export const LanguageContext = React.createContext("en");
export function useText() { const locale = React.useContext(LanguageContext); return (key, params = {}) => translate(locale, key, params); }
export function useDisplayText() { const locale = React.useContext(LanguageContext); return (value) => displayText(locale, value); }
