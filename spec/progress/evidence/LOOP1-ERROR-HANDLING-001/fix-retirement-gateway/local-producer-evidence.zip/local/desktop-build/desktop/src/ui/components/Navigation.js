import { useText } from "../i18n/context.js";
import React from "react";
export function Navigation({ s, page: navigate }) {
    const t = useText();
    return React.createElement("aside", { className: "rail" },
        React.createElement("div", { className: "brand", "aria-label": t("brand.name") },
            React.createElement("img", { src: "logo.png", alt: t("brand.logo") }),
            "IM",
            React.createElement("span", null, "+")),
        React.createElement("div", { className: "brand-caption" }, "PLUGWORLDIM"),
        React.createElement("nav", { "aria-label": t("nav.main") }, ["Chat", "Friends", "AI", "Plugin"].map((page, i) => React.createElement("button", { key: page, className: s.page === page ? "nav selected" : "nav", onClick: () => navigate(page) },
            React.createElement("span", { className: "nav-icon", "aria-hidden": "true" }, ["◫", "♧", "✧", "⊞"][i]),
            t("nav." + page.toLowerCase()),
            page === "AI" && React.createElement("small", null, t("nav.soon"))))),
        React.createElement("div", { className: "rail-bottom" },
            React.createElement("div", { className: "connection", title: s.session ? t("nav.signedIn") : t("nav.local") },
                React.createElement("span", { className: "dot " + (s.connection === "ready" ? "ready" : "offline") }),
                s.connection === "ready" ? t("connection.ready") : s.connection === "binding" ? t("connection.connecting") : t("connection.offlineShort")),
            React.createElement("button", { className: "nav", onClick: () => navigate("Settings") }, t("nav.settings")),
            React.createElement("div", { className: "identity" },
                React.createElement("span", { className: "avatar" }, s.profile?.displayName[0] ?? "+"),
                React.createElement("div", null,
                    React.createElement("strong", null, s.profile?.displayName ?? t("nav.workspace")),
                    React.createElement("small", null, s.session ? t("nav.personal") : t("nav.signIn"))))));
}
