import { useText } from "../i18n/context.js";
import React from "react";
export function ConversationList({ s, page, open, run }) {
    const t = useText();
    return React.createElement("aside", { className: "conversation-list glass" },
        React.createElement("div", { className: "section-heading" },
            React.createElement("h2", null, t("chat.messages")),
            React.createElement("button", { className: "quiet", onClick: () => page("Friends") }, t("chat.new"))),
        React.createElement("p", { className: "muted list-caption" }, t("chat.caption")),
        s.conversations.length === 0 ? React.createElement("div", { className: "empty" },
            React.createElement("span", null, "\u25EB"),
            React.createElement("h3", null, t("chat.next")),
            React.createElement("p", null, t("chat.addHint")),
            React.createElement("button", { onClick: () => page("Friends") }, t("chat.find"))) : s.conversations.map(id => { const f = s.friends.find(f => f.directConversationId === id); return React.createElement("button", { key: id, className: s.selected === id ? "conversation active" : "conversation", onClick: () => run(open(id)) },
            React.createElement("span", { className: "avatar" }, f?.user.displayName[0] ?? "#"),
            React.createElement("div", null,
                React.createElement("strong", null, f?.user.displayName ?? t("chat.conversationId", { id: id.slice(0, 8) })),
                React.createElement("small", null, s.unavailable.includes(id) ? t("chat.access") : s.previews[id]?.text || t("chat.noMessages")))); }));
}
