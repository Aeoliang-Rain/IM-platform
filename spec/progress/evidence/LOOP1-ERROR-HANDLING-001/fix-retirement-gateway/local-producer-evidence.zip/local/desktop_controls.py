from run import *
build=(EXT/'desktop-build').as_uri()+'/'
suffix='-'+sys.argv[1] if len(sys.argv)>1 else ''
source=ROOT/'tests/clients/gui/auth.mjs'
text=source.read_text(encoding='utf-8')
assert text.count('../../../clients/desktop/dist/')>=2
linked=text.replace('../../../clients/desktop/dist/',build)
target=EXT/'original-auth-linked.mjs';target.write_text(linked,encoding='utf-8')
(EXT/'original-auth-link.json').write_text(json.dumps({'source':'tests/clients/gui/auth.mjs','source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'linked_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'only_change':'relative compiled-output import prefix -> isolated current strict build; all original assertions byte retained'},indent=2)+'\n',encoding='utf-8')
for label,command in [
 ('desktop-original-owner12',[NODE,ROOT/'tests/clients/errors/desktop_owner_retirement.mjs',build]),
 ('desktop-original-parallel37',[NODE,ROOT/'tests/clients/errors/desktop_parallel.mjs',build]),
 ('desktop-original-auth',[NODE,target])]:
    code=run(label+suffix,command)
    if code:sys.exit(code)
