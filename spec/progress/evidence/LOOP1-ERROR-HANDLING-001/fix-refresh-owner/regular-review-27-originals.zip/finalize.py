import json,pathlib,hashlib,subprocess,collections,sys
E=pathlib.Path(__file__).parent
R=pathlib.Path('H:/.codex/worktrees/err/IM-platform')
def put(name,v): (E/name).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
if sys.argv[1]=='history':
 events=[json.loads(x) for x in (E/'research/runs/R-ERROR-REGULAR-27CDD93/events.jsonl').read_text().splitlines()]
 starts={x['data']['command_id']:x for x in events if x['event_type']=='command_started'}
 history=[]
 for x in events:
  if x['event_type']=='command_finished':
   s=starts[x['data']['command_id']];history.append({'start':s['timestamp'],'end':x['timestamp'],**s['data'],**x['data']})
 put('command-history.json',history)
 coverage=json.loads((E/'semantic-coverage185.json').read_text())
 print(json.dumps(dict(commands=len(history),exit_counts=dict(collections.Counter(str(x['exit_code']) for x in history)),inspection_counts=dict(collections.Counter(x['inspection_kind'] for x in coverage['files'])))))
elif sys.argv[1]=='seal':
 head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
 status=subprocess.check_output(['git','status','--porcelain=v1'],cwd=R,text=True)
 assert head=='27cdd93e30a72527bba9f3b0d611b13ba860e92f' and not status
 put('final-clean.json',dict(head=head,git_status=status,read_only_released=True))
 files=[dict(path=p.relative_to(E).as_posix(),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(E.rglob('*')) if p.is_file() and p.name not in ['final-receipt.json','final-receipt.sha256']]
 receipt=dict(review_result='FAIL',reviewer='/root/regular_review_27cdd93',candidate_sha=head,base_sha='35bd6f5f1091503f95a0282f730ed04233b0b6ea',branch='task/LOOP1-ERROR-HANDLING-001',assigned_git_root=str(R),clean=True,read_only_released=True,findings=[dict(id='F-EXPIRY-CLEANUP-OWNER',priority=1,platforms=['Desktop','Android']),dict(id='F-RETAINED-GROUND-MISMATCH',priority=2,exact_corrections=22)],coverage=dict(production_inputs=185,retained_records=318,executable=283,nonexecutable=35,protected_files=65,classification_file='semantic-coverage185.json',grounds_file='current-retained318.json',corrections_file='ground-corrections.json'),recorder=dict(run='R-ERROR-REGULAR-27CDD93',finished_result='FAIL',validation='PASS_STRUCTURAL_ONLY',trace_limitation='pre-Recorder startup and some direct reads/helper preparation disclosed; not complete prospective trace'),verification_limits=['Development and Acceptance fresh attempts exit1: child python resolves G:/Python27; raw preserved, not counted PASS','Focused Android JVM consumer reproduction, not full Android/emulator acceptance','Controlled Desktop IPC/sync owner substitutes, not native credential integration','Prior Fix Acceptance0 and other historical behavior runs not newly executed','Binary integrity, lock graphs and structural literal map checks are separately classified'],product_acceptance=False,hosted_ci_executed=False,push_pr_merge_main_sync=False,artifact_count=len(files),artifacts=files)
 put('final-receipt.json',receipt)
 digest=sha(E/'final-receipt.json');(E/'final-receipt.sha256').write_text(digest+'  final-receipt.json\n')
 print(json.dumps(dict(receipt_sha256=digest,artifact_count=len(files),candidate=head,result='FAIL',released=True)))
