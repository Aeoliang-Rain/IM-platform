import sys,json,pathlib,hashlib,subprocess
root=pathlib.Path('H:/.codex/worktrees/err/IM-platform')
ev=root/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001'
mode=sys.argv[1]
if mode=='read':
 for name in sys.argv[2:]:
  p=root/name
  print('\nFILE '+name+'\n'+p.read_text(encoding='utf-8'))
elif mode=='source':
 items=json.loads((ev/'production-inventory.json').read_text(encoding='utf-8'))['files']
 for i in range(int(sys.argv[2]),min(int(sys.argv[3]),len(items))):
  x=items[i];p=root/x['path']; b=p.read_bytes();h=hashlib.sha256(b).hexdigest()
  print('\nFILE',i,x['path'],'HASH',h,'MATCH',h==x['sha256'])
  if p.suffix in ('.png','.ico','.jar'): print('Binary artifact; hash inspected; no executable source');continue
  if p.name=='Cargo.lock':
   import tomllib
   d=tomllib.loads(b.decode());print('LOCK PACKAGES',[(v['name'],v['version']) for v in d['package']]);continue
  if p.name=='package-lock.json':
   d=json.loads(b);print('LOCK PACKAGES',[(k,v.get('version'),v.get('dependencies',{})) for k,v in d['packages'].items()]);continue
  lines=b.decode('utf-8').splitlines()
  lo=int(sys.argv[4]) if len(sys.argv)>4 else 1
  hi=int(sys.argv[5]) if len(sys.argv)>5 else len(lines)
  print(''.join(f'{n}: {v}\n' for n,v in enumerate(lines,1) if lo<=n<=hi))
elif mode=='list':
 items=json.loads((ev/'production-inventory.json').read_text(encoding='utf-8'))['files']
 for i,x in enumerate(items): print(i,x['path'],x['bytes'])
elif mode=='data':
 import re
 items=json.loads((ev/'production-inventory.json').read_text())['files']
 for i in [68,69,71,112,113,114,159,160,162]:
  x=items[i];p=root/x['path'];b=p.read_bytes();s=b.decode();entries=[];other=[]
  for line in s.splitlines():
   m=re.fullmatch(r'\s*"([^"\\]+)"\s*(?::|to)\s*"((?:[^"\\]|\\.)*)"\s*,?\s*',line)
   if m:entries.append(m.groups())
   else:other.append(line)
  old=subprocess.check_output(['git','show','35bd6f5:'+x['path']],cwd=root)
  print(i,x['path'],'HASH',hashlib.sha256(b).hexdigest(),'entries',len(entries),'unique',len(set(k for k,v in entries)),'unchanged',b==old,'NON_LITERAL_LINES',other)
elif mode=='schema':
 for name in sys.argv[2:]:
  d=json.loads((root/name).read_text());print('CONTRACT',name)
  def walk(v,p=''):
   if isinstance(v,dict):
    flat={k:x for k,x in v.items() if not isinstance(x,(dict,list)) and k not in ['description','title','example']}
    if flat:print(p,flat)
    for k,x in v.items():
     if isinstance(x,list) and k in ['required','enum']:print(p,k,x)
     elif isinstance(x,(dict,list)):walk(x,p+'/'+k)
   elif isinstance(v,list):
    for i,x in enumerate(v):walk(x,p+'/'+str(i))
  walk(d)
elif mode=='nav':
 items=json.loads((ev/'fix-android-wss-cleanup/current-navigation.json').read_text(encoding='utf-8'))['records']
 for x in items[int(sys.argv[2]):int(sys.argv[3])]:
  print(x['composite_identity'],x['line'],'EXEC' if x['executable'] else 'NONEXEC')
  print('FAULT:',x['specific_fault'].split('Trigger source:')[0],'AUTH:',x['present_authority'],'RESULT:',x['actual_recovery_or_failure'])
elif mode=='git':
 for args in [['rev-parse','--show-toplevel'],['rev-parse','HEAD'],['branch','--show-current'],['status','--porcelain=v1'],['diff','--stat'],['log','-6','--oneline'],['diff','--stat','35bd6f5f1091503f95a0282f730ed04233b0b6ea..HEAD']]:
  r=subprocess.run(['git',*args],cwd=root,capture_output=True,text=True);print(args,r.returncode,r.stdout,r.stderr)
