import pathlib,json,hashlib,subprocess,re
R=pathlib.Path('H:/.codex/worktrees/err/IM-platform');E=pathlib.Path(__file__).parent;D=R/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001';BASE='35bd6f5f1091503f95a0282f730ed04233b0b6ea';HEAD='27cdd93e30a72527bba9f3b0d611b13ba860e92f'
def h(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=R)
assert git('rev-parse','HEAD').decode().strip()==HEAD
assert pathlib.Path(git('rev-parse','--show-toplevel').decode().strip()).resolve()==R.resolve()
assert not git('status','--porcelain')
inv=json.loads((D/'production-inventory.json').read_text());nav=json.loads((D/'fix-android-wss-cleanup/current-navigation.json').read_text())['records'];pro=json.loads((D/'fix-android-wss-cleanup/protected-inputs.json').read_text())['files']
for x in inv['files']:assert h((R/x['path']).read_bytes())==x['sha256'];assert (R/x['path']).read_bytes()==git('show',HEAD+':'+x['path'])
for x in nav:
 b=(R/x['path']).read_bytes();assert h(b)==x['source_sha256'];assert b.decode().splitlines()[x['line']-1][x['column']-1:].startswith(x['token'])
protected=[]
for x in pro:
 path=x['path'];b=(R/path).read_bytes();base=git('show',BASE+':'+path);pre=git('show','8f5f2b42:'+path);assert h(b)==x['sha256'];assert b==pre
 equal=b==base
 if not equal:
  assert path.endswith(('storage/repository.ts','storage/Repository.kt'))
  source=b.decode();old=base.decode()
  pattern=r'  async contiguous\(.*?(?=  async conversationIds)' if path.endswith('.ts') else r'    fun contiguous\(.*?(?=    fun conversationIds)'
  assert re.sub(pattern,'READ_MAPPER',source,flags=re.S)==re.sub(pattern,'READ_MAPPER',old,flags=re.S)
  # Complete SQL literal changed nowhere, including mapper.
  quote=r'"SELECT [^"\n]*"';assert re.findall(quote,source)==re.findall(quote,old)
 protected.append(dict(path=path,sha256=h(b),whole_baseline_equal=equal,pre_fix_equal=True,exception='Human contiguous readonly mapper only' if not equal else None))
assert len(protected)==65 and sum(x['whole_baseline_equal'] for x in protected)==63
paths=[x['path'] for x in inv['files']]+['ci/check_architecture.py','tests/architecture','AGENTS.md','spec/governance','spec/tasks/TASK_TEMPLATE.md','spec/handoff/agent-context.md']
diff=git('diff','--no-ext-diff',BASE+'..'+HEAD,'--',*paths);(E/'source-governance.diff').write_bytes(diff)
(E/'protected65.json').write_text(json.dumps(protected,indent=2))
(E/'binding-checks.json').write_text(json.dumps(dict(sha=HEAD,base=BASE,clean=True,production185=True,nav318=True,executable=sum(x['executable'] for x in nav),protected65=True,diff_sha256=h(diff),diff_lines=len(diff.splitlines())),indent=2))
print('Exact clean candidate;185 SHA+GitBlob,318 actual token coordinates,65 protected(63 exactbaseline +2 readonlyMapper-only SQLunchanged) verified; diff lines',len(diff.splitlines()))
