import json,pathlib,hashlib,subprocess
E=pathlib.Path(__file__).parent;R=pathlib.Path('H:/.codex/worktrees/err/IM-platform');D=R/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001';SHA='27cdd93e30a72527bba9f3b0d611b13ba860e92f'
nav=json.loads((D/'fix-android-wss-cleanup/current-navigation.json').read_text())['records'];inv=json.loads((D/'production-inventory.json').read_text())['files']
corrections={}
def correct(n,f,a,r):corrections[n]=dict(specific_fault=f,present_authority=a,actual_recovery_or_failure=r)
N='Frozen6.1; ADR0009 existing narrow native adapter'
L='Frozen6.6; ADR0012 literal locale resources and display-only interpolation'
S='contracts/websocket/sync-v1.schema.json and contracts/http/sync.openapi.json; Frozen11.5 and SP-I-001/004'
correct(28,'Response omits Content-Length; content_length() returns None',N,'None makes only the preallocation size guard false. Chunk-by-chunk MAX_BODY enforcement still rejects oversize bytes; no native error is caught at this expression.')
correct(29,'window_control receives action outside the four authorized strings',N,'Return Window action invalid and reject the command; do not perform an OS action or substitute success.')
correct(30,'Language file bytes fail UTF8 or exact en/zh-CN/ja-JP enum',L,'Return en as expressly authorized invalid language fallback. Does not handle window/credential/native command errors.')
correct(31,'Tray menu event ID differs from open/hide/quit',N,'No app action for an unowned menu ID. Current owned IDs dispatch show/hide/exit; window failures panic. This is menu dispatch, not capability-failure recovery.')
correct(107,'Display interpolation parameter is missing from params by placeholder name',L,'String(params[name] ?? literal placeholder) keeps the placeholder visible. No native operation occurs; missing English resource key throws before interpolation.')
wire={150:('cursor value is not a nonempty string <=256 codepoints','throw SyncFailure(protocol), never an empty cursor'),151:('messages/events is not an array or exceeds page cap100','throw SyncFailure(protocol), never an empty page'),152:('user event kind is not a String','throw SyncFailure(protocol), never a UI placeholder'),153:('user page parser raises actual SendWire.WireFailure','convert only this known peer-invalid category to SyncFailure(protocol)'),154:('user event revision cannot fit existing signed64 storage','ArithmeticException becomes SyncFailure(protocol), not a fabricated revision'),155:('conversation page parser raises actual SendWire.WireFailure','convert known invalid external message/page to SyncFailure(protocol)'),156:('external message seq cannot fit existing signed64 storage','ArithmeticException becomes SyncFailure(protocol); do not materialize the page'),157:('error object or violation is not the required map/list shape','reject malformed error as SyncFailure(protocol)'),158:('violation field object values are not nonempty strings','reject malformed error as SyncFailure(protocol)'),159:('error response strict parser raises SendWire.WireFailure','return SyncFailure(protocol), no successful request'),160:('error response validation itself raises SyncFailure','return the known protocol failure category; valid401/403 paths return authentication/unavailable without throwing')}
for n,(f,r) in wire.items():correct(n,f,S,r+'; unrecognized exceptions escape and no UI label/data fallback exists at this site.')
correct(226,'Selected locale table or requested translation key is absent',L,'Use English entry only; does not catch native capabilities. Explicit English key check at line11 remains mandatory.')
correct(227,'English base entry unexpectedly absent after fallback lookup',L,'Call error and fail the operation. This Elvis is a mandatory-base invariant failure, not a silent English/native fallback.')
correct(229,'Display error kind is not present in errorKeys map',L,'Return error.request translation key for display only. Does not change thrown exception type or actual operation result.')
correct(230,'A source display phrase has no sourceDisplayKeys entry',L,'Try errorKeys for the same display value, then existing English key or error.operation display key. Actual unknown operations are filtered/propagated earlier; no native call here.')
correct(231,'A display value is neither source phrase nor known error key',L,'Use existing English resource key when available, otherwise error.operation display key. No credential/OS recovery is performed.')
correct(242,'Conversation SELECT returns no row versus existing null/invalid/noncanonical/out-of-range contiguous value','Direct Human two contiguous READ-mapper exception; Frozen6.3/6.4; SP-I-001','No rows returns0n; present bad value throws. This mapper changed from accepted base by explicit Human approval; it is NOT EXCLUDED_UNCHANGED. Complete SELECT SQL and all other Repository bytes are independently equal to accepted base.')
rows=[]
for x in nav:
 n=x['original_ordinal'];b=(R/x['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==x['source_sha256']
 corrected=corrections.get(n)
 ground=corrected or {k:x[k] for k in ('specific_fault','present_authority','actual_recovery_or_failure')}
 # Report own semantic decision separately from supplied local decisions.
 result='RETAINED_AFTER_INDEPENDENT_SOURCE_AND_AUTHORITY_REVIEW'
 if not x['executable']:result='NONEXECUTABLE_TOKEN_CONFIRMED'
 if 'EXCLUDED_UNCHANGED_POLICY' in ground['actual_recovery_or_failure']:result='EXCLUDED_POLICY_BYTES_CHECKED_NOT_POSITIVE_APPROVAL'
 if corrected:result='CURRENT_NAVIGATION_GROUND_REJECTED_P2_PRODUCT_BEHAVIOR_OTHERWISE_VALID'
 if n in [56,84,85,175,199,200,316,317,318]:result='P1_EXPIRY_CLEANUP_OWNER_RETIREMENT_CHAIN_REJECTED'
 rows.append(dict(composite_identity=x['composite_identity'],ordinal=n,id=x['original_id'],path=x['path'],line=x['line'],column=x['column'],source_sha256=x['source_sha256'],executable=x['executable'],actual_source=x['source'],independent_disposition=result,**ground))
(E/'current-retained318.json').write_text(json.dumps(dict(candidate_sha=SHA,reviewer='/root/regular_review_27cdd93',method='Read full current owning source/imports and actual consumer chains; rejudged each supplied navigation entry. No supplied local disposition is independent authority. Specific corrections reject inaccurate supplied grounds; P1 is a failed lifecycle chain despite retained primary roots.',records=rows),ensure_ascii=False,indent=2))
out=[]
for n,g in corrections.items():
 x=nav[n-1];out.append(dict(composite_identity=x['composite_identity'],ordinal=n,id=x['original_id'],path=x['path'],line=x['line'],column=x['column'],actual_source=x['source'],source_sha256=x['source_sha256'],supplied_ground={k:x[k] for k in ('specific_fault','present_authority','actual_recovery_or_failure')},independent_correction=g))
(E/'ground-corrections.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
coverage=[]
for i,x in enumerate(inv):
 p=x['path'];ext=pathlib.Path(p).suffix
 if ext in ['.png','.ico','.jar']:kind='binary_integrity_only';assessment='Unchanged asset/vendor launcher bytes bound; no manual image design or third-party JAR implementation audit claimed.'
 elif i in [68,69,71,112,113,114,159,160,162]:kind='pure_literal_data';assessment='All lines classified:260 unique string-literal entries, package/map wrapper only; accepted base byte equality. No executable fallback. Language builder independently verifies cross-platform key/value/placeholder parity.'
 elif p.endswith(('package-lock.json','Cargo.lock','go.sum')):kind='dependency_lock';assessment='Parsed package/version/dependency inventory and exact lock integrity; no new dependency versus accepted base. No third-party source audit claimed.'
 elif pathlib.Path(p).name=='.gitkeep':kind='empty_placeholder';assessment='Actual empty placeholder content inspected; no business/plugin/SDK implementation.'
 else:
  kind='full_text_logic_config_or_document'
  if '/core/' in p:assessment='Full functions/imports reviewed: Core Auth/session writes, atomic message+Outbox, membership/metadata Sync stay Core; query/decode/commit errors fail, unknown commit conservative, transport-only Outbox retry.'
  elif '/gateway/' in p:assessment='Full functions/imports reviewed: connection/bind/read-only Session validation/proxy/fanout only; real socket write failures retire, uncertainty preserved, no cross-service import or credential exposure.'
  elif '/shared/' in p and p.startswith('backend'):assessment='Full functions/imports reviewed: config/health/cryptographic support only; no full Auth/session-write business or reverse imports.'
  elif p.startswith('backend/java/'):assessment='Full accepted SRC-06 transport skeleton reviewed: only per-request IOException recovery after socket retirement, accept and unchecked failures escape; no S3 business activation.'
  elif '/src-tauri/' in p:assessment='Full native adapter/imports and relevant tests reviewed against ADR5/9/10/12; no client business moves native, strict HTTPS/system trust and sanitized capability boundary retained. SQL adapter excluded unchanged.'
  elif 'Repository' in p or 'repository' in p or 'Schema' in p or 'schema' in p or '/storage/' in p:assessment='Full materialization/read ownership inspected; protected writes/schema/init/transactions unchanged; only two explicitly approved contiguous READ mappers changed, no-row0 and invalid-present failure.'
  elif '/application/' in p or '/send/' in p or '/sync/' in p or p.endswith(('Auth.kt','Preferences.kt','WorkspaceViewModel.kt')):assessment='Full owning functions/imports and producer/consumer failure chains reviewed against current contract; known boundary failures distinguished from unknown/internal errors; timers/queue/account/retirement/cleanup inspected. P1 where linked below.'
  elif '/components/' in p or '/ui/' in p or '/i18n/' in p or p.endswith(('MainActivity.kt','build_language_packs.py')):assessment='Full text/imports inspected: UI emits existing intents and displays observed state; required message identity/content/state fails explicitly; optional selection/profile/preview and locale fallback only; no new runtime/framework.'
  else:assessment='Full runtime/build/config/deployment/migration text inspected: actual entry/exit and dependency authority; explicit failure and existing defaults; no new product responsibility.'
 finding='F-EXPIRY-CLEANUP-OWNER' if p.endswith(('application/ui/auth.ts','application/ui/workspace.ts','ui/Auth.kt','ui/WorkspaceViewModel.kt')) else None
 coverage.append(dict(index=i,path=p,sha256=x['sha256'],inspection_kind=kind,independent_assessment=assessment,finding=finding,overall_candidate_result='FAIL'))
(E/'semantic-coverage185.json').write_text(json.dumps(dict(candidate_sha=SHA,files=coverage,limitations='Full first-party source semantics; resources, locks, binary and empty placeholders explicitly classified. No claim of manually reading every literal translation or third-party binary/source. Historical raw evidence not blanket semantic accepted.'),ensure_ascii=False,indent=2))
print('Independent current318 judgments and',len(out),'specific P2 corrections;185 classified input coverage sealed later')
