import im.platform.client.ui.*
import kotlinx.coroutines.runBlocking
import java.io.*
import java.net.*
import javax.net.ssl.HttpsURLConnection
class Peer(url:URL):HttpsURLConnection(url){override fun connect(){};override fun disconnect(){};override fun usingProxy()=false;override fun getCipherSuite()="controlled";override fun getLocalCertificates():Array<java.security.cert.Certificate>?=null;override fun getServerCertificates():Array<java.security.cert.Certificate> = emptyArray();override fun getOutputStream():OutputStream=ByteArrayOutputStream();override fun getResponseCode()=401;override fun getContentType()="application/json";override fun getErrorStream():InputStream=ByteArrayInputStream("{\"error\":{\"code\":\"AUTH_SESSION_REVOKED\"}}".toByteArray())}
fun main()=runBlocking {
 URL.setURLStreamHandlerFactory{scheme->if(scheme=="https")object:URLStreamHandler(){override fun openConnection(url:URL)=Peer(url)}else null}
 val prefs=Preferences(IOException("Credential cleanup failed"));val owner=Auth("https://fixture.invalid",prefs);owner.savedAccount()
 val result=try{owner.refresh();error("unexpected success")}catch(e:Exception){e};check(result is IOException);check((result.cause as ApiFailure).kind=="session_expired")
 val consumer=Consumer();consumer.receive(result);check(consumer.expired==0);check(consumer.state.authenticated);check(consumer.state.error=="Operation unavailable");check(prefs.removes==1)
 println("REPRODUCED: actual Auth.refresh known IOException + byte-exact Workspace.fail body: expired="+consumer.expired+" authenticated="+consumer.state.authenticated+" error="+consumer.state.error+" removes="+prefs.removes)
}
