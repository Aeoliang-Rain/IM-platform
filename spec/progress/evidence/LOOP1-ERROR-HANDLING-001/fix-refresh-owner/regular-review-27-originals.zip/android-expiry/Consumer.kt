package im.platform.client.ui
import im.platform.client.send.*
class SyncFailure:Exception()
class SendStorageFailure:Exception()
data class Projection(val error:String?=null,val authenticated:Boolean=true)
class Consumer{var state=Projection();var expired=0;private fun publish(f:(Projection)->Projection){state=f(state)};private fun expire(){expired++;state=state.copy(authenticated=false)}
    private fun fail(e:Exception,active:Boolean=true){if(e !is ApiFailure && e !is SyncFailure && e !is WireFailure && e !is SendStorageFailure && e !is java.io.IOException && e !is java.security.GeneralSecurityException)throw e;if(!active)return;publish{it.copy(error=if(e is ApiFailure)e.message else "Operation unavailable")};if(e is ApiFailure&&e.kind=="session_expired")expire()}
fun receive(e:Exception){fail(e)}
}
