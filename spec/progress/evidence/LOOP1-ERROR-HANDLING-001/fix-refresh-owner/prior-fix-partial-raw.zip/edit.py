from pathlib import Path
R=Path('H:/.codex/worktrees/err/IM-platform')
p=R/'clients/desktop/src/application/ui/workspace.ts';s=p.read_text();old='this.activity.clear();this.publish({session:null,offlineAccount:null,profile:null,friends:[],results:[],conversations:[],selected:"",messages:[],connection:"offline",sync:"idle",unavailable:[],previews:{}});await old?.close();}'
new='''this.activity.clear();const failures:unknown[]=[];
    try{this.publish({session:null,offlineAccount:null,profile:null,friends:[],results:[],conversations:[],selected:"",messages:[],connection:"offline",sync:"idle",unavailable:[],previews:{}});}catch(error){failures.push(error);}
    try{await old?.close();}catch(error){if(!failures.includes(error))failures.push(error);}
    if(failures.length===1)throw failures[0];if(failures.length>1)throw new AggregateError(failures,"Workspace retirement failed");}'''
assert s.count(old)==1;s=s.replace(old,new)
old='async refresh(){if(this.state.busy||!this.auth)return;const op=++this.operation;const owner=this.auth,g=this.generation;this.publish({busy:true,error:null});try{const session=await owner.refresh();if(op===this.operation)await this.bind(session,op);}catch(error){this.failure(error,op===this.operation);}finally{if(op===this.operation)this.publish({busy:false});}}'
new='''async refresh(){if(this.state.busy||!this.auth)return;const op=++this.operation;const owner=this.auth,g=this.generation;this.publish({busy:true,error:null});try{const session=await owner.refresh();if(op===this.operation)await this.bind(session,op);}catch(error){
    let failure=error;
    if(op===this.operation&&owner===this.auth&&g===this.generation&&!owner.session){this.auth=null;try{await this.stop();}catch(cleanup){if(cleanup!==error)failure=new AggregateError([error,cleanup],"Refresh and retirement failed");}}
    this.failure(failure,op===this.operation);
  }finally{if(op===this.operation)this.publish({busy:false});}}'''
assert s.count(old)==1;s=s.replace(old,new);p.write_text(s,newline='\n')
p=R/'clients/mobile/app/src/main/kotlin/im/platform/client/ui/WorkspaceViewModel.kt';raw=p.read_bytes();s=raw.decode();ending='\r\n' if '\r\n' in s else '\n';s=s.replace('\r\n','\n')
old='    fun refresh(){if(state.value.busy)return;val op=++operation;scope.launch{publish{it.copy(busy=true,error=null)};try{auth?.let{val session=withContext(Dispatchers.IO){it.refresh()};if(op==operation)bind(session,op)}}catch(e:Exception){fail(e,op==operation)}finally{if(op==operation)publish{it.copy(busy=false)}}}}'
new='''    fun refresh(){if(state.value.busy)return;val owner=auth?:return;val op=++operation;val g=generation;scope.launch{publish{it.copy(busy=true,error=null)};try{val session=withContext(Dispatchers.IO){owner.refresh()};if(op==operation)bind(session,op)}catch(e:Throwable){
        var failure=e
        if(op==operation && owner===auth && g==generation && owner.session==null){auth=null;try{withContext(NonCancellable){stop()}}catch(cleanup:Throwable){if(cleanup!==e)failure=IllegalStateException("Refresh and retirement failed",e).also{it.addSuppressed(cleanup)}}}
        if(failure is Exception)fail(failure,op==operation)else throw failure
    }finally{if(op==operation)publish{it.copy(busy=false)}}}}'''
assert s.count(old)==1;s=s.replace(old,new);p.write_bytes(s.replace('\n',ending).encode())
print('Only existing Desktop/Android Workspace lifecycle edited; no Auth/storage change')
