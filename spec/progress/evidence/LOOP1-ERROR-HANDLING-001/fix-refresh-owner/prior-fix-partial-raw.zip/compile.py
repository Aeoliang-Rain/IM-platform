from pathlib import Path
import json,subprocess
E=Path(__file__).parent
c=json.loads((E.parent/'fix-read-origin/tsconfig.json').read_text());c['compilerOptions']['outDir']=str(E/'desktop-build');(E/'tsconfig.json').write_text(json.dumps(c,indent=2));(E/'package.json').write_text('{"type":"module"}')
subprocess.run(['H:/node.js/node.exe',str(E.parent/'fix-read-origin/node_modules/typescript/bin/tsc'),'-p',str(E/'tsconfig.json')],check=True)
stub=E/'desktop-build/node_modules/@tauri-apps/api';stub.mkdir(parents=True,exist_ok=True);(stub/'package.json').write_text('{"type":"module","exports":{"./core":"./core.js"}}');(stub/'core.js').write_text('export const invoke=(...args)=>globalThis.window.__TAURI_INTERNALS__.invoke(...args);');(E/'desktop-build/package.json').write_text('{"type":"module"}')
print('Independent strict current Desktop compile PASS; only IPC stub')
