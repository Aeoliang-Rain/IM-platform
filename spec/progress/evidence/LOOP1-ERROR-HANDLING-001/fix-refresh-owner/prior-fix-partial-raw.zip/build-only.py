import pathlib,subprocess,sys,time,json,os
R=pathlib.Path('H:/.codex/worktrees/err/IM-platform');E=pathlib.Path(__file__).parent;adb='H:/Android/platform-tools/adb.exe';serial='emulator-5612';runner=sys.argv[1];PY=sys.executable
os.environ.update(ANDROID_USER_HOME=str(E/'android-user'),ANDROID_AVD_HOME=str(E/'avds'))
subprocess.run([PY,'-Xutf8','-B',str(R/'tests/clients/gui/native.py'),'gradle','--max-workers=1','-Dorg.gradle.jvmargs=-Xmx768m -Dfile.encoding=UTF-8','-Pkotlin.compiler.execution.strategy=in-process','-PimSendInstrumentation='+runner,'assembleDebug','assembleDebugAndroidTest'],cwd=R,check=True)

