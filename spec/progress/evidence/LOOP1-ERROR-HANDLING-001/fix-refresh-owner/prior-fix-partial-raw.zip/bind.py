from pathlib import Path
import json,hashlib,zipfile,subprocess,difflib,re
R=Path('H:/.codex/worktrees/err/IM-platform');E=Path(__file__).parent;O=E.parent/'regular-review-27cdd93';D=R/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001';B='27cdd93e30a72527bba9f3b0d611b13ba860e92f'
def sha(b):return hashlib.sha256(b).hexdigest()
def js(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
receipt=json.loads((O/'final-receipt.json').read_text());assert sha((O/'final-receipt.json').read_bytes())=='a8df4b6fe9ba3147bce44f2646d56aafd7199dc3bf92a7cf35918e16b50818fa';assert len(receipt['artifacts'])==211
with zipfile.ZipFile(E/'regular-review-27-originals.zip','w',zipfile.ZIP_DEFLATED) as z:
 for x in receipt['artifacts']:
  b=(O/x['path']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256'];z.writestr(x['path'],b)
 z.writestr('final-receipt.json',(O/'final-receipt.json').read_bytes())
with zipfile.ZipFile(E/'regular-review-27-originals.zip') as z:
 for x in receipt['artifacts']:assert sha(z.read(x['path']))==x['sha256']
js(E/'prior-review-seals.json',dict(receipt_sha256=sha((O/'final-receipt.json').read_bytes()),artifacts=receipt['artifacts'],archive_sha256=sha((E/'regular-review-27-originals.zip').read_bytes()),meaning='All211 original artifacts plus receipt ZIP-byte verified. ZIP entries are reconstructed bytes, not individually claimed Git blobs. Original external sealed bytes unchanged.'))
nav=json.loads((D/'fix-android-wss-cleanup/current-navigation.json').read_text());inv=json.loads((D/'production-inventory.json').read_text());changed=['clients/desktop/src/application/ui/workspace.ts','clients/mobile/app/src/main/kotlin/im/platform/client/ui/WorkspaceViewModel.kt']
for path in changed:
 old=subprocess.check_output(['git','show',B+':'+path],cwd=R).decode();new=(R/path).read_bytes().decode();ops=difflib.SequenceMatcher(None,old,new,autojunk=False).get_opcodes();starts=[];n=0
 for line in old.splitlines(keepends=True):starts.append(n);n+=len(line)
 for x in nav['records']:
  if x['path']!=path:continue
  point=starts[x['line']-1]+x['column']-1;m=[c+point-a for typ,a,b,c,d in ops if typ=='equal' and a<=point<b]
  if len(m)!=1:
   if path.endswith('workspace.ts') and 'async refresh()' in x['source']:
    point2=new.index('catch(error){',new.index('async refresh()'));m=[point2]
   elif path.endswith('WorkspaceViewModel.kt') and 'fun refresh()' in x['source']:
    point2=new.index('catch(e:Throwable)',new.index('fun refresh()'));m=[point2];x['token']='catch'
  assert len(m)==1,(path,x['original_ordinal'],x['source']);pos=m[0];line=new.count('\n',0,pos)+1;column=pos-new.rfind('\n',0,pos);source=new.splitlines()[line-1];assert source[column-1:].startswith(x['token']),(x['original_ordinal'],source,column,x['token'])
  x.update(line=line,column=column,source=source,source_sha256=sha((R/path).read_bytes()))
corrections=json.loads((O/'ground-corrections.json').read_text());assert len(corrections)==22
for c in corrections:
 x=next(x for x in nav['records'] if x['composite_identity']==c['composite_identity']);b=(R/x['path']).read_bytes();assert sha(b)==c['source_sha256'] and b.decode().splitlines()[c['line']-1]==c['actual_source'];x.update(c['independent_correction']);x['decision']='FIX_REJUDGED_ACTUAL_SOURCE_AUTHORITY_PENDING_NEW_INDEPENDENT_REVIEW'
G='Frozen6.1/7.1 Session ownership; ADR0009 secure credential boundary; AUF-I session retirement; current error-handling primary/cleanup identity preservation'
F='Actual refresh invalidates the current Auth.session before secure credential cleanup may fail; Workspace must retire that same active owner even when error roots are mixed or unknown'
REC='Only matching operation+generation+Auth owner with session null detaches Auth, cancels existing refresh/observers, clears authenticated projection and closes old Sync once. No credential retry. Existing known error reports failure; unknown/Error/cancellation propagates. Distinct retirement roots preserve original refresh cause graph. Stale owner cannot retire new account.'
for x in nav['records']:
 if x['path'] in changed and ('async refresh()' in x['source'] or 'fun refresh()' in x['source'] or x['source'].strip()=='failed=true;failure=error;'):
  x.update(specific_fault=F,present_authority=G,actual_recovery_or_failure=REC)
# Add each new catch by actual source position, preserving prior composite ordinals.
new_sites=[]
for path in changed:
 text=(R/path).read_text();bound={(x['line'],x['column']) for x in nav['records'] if x['path']==path and x['token']=='catch'}
 for m in re.finditer(r'\bcatch\s*\(',text):
  line=text.count('\n',0,m.start())+1;column=m.start()-text.rfind('\n',0,m.start())
  if (line,column) in bound:continue
  # Existing navigation includes catch as alternate token variants; validate any actual bound token too.
  if any(x['path']==path and x['line']==line and x['column']==column for x in nav['records']):continue
  source=text.splitlines()[line-1]
  new_sites.append((path,line,column,source))
assert len(new_sites)==5,new_sites
for path,line,column,source in new_sites:
 ordinal=len(nav['records'])+1;sid='RH'+str(ordinal)
 fault=F;recovery=REC
 if 'Workspace retirement failed' in source or 'this.publish({session:null' in source or 'await old?.close()' in source:
  fault='Current Workspace projection listener or actual old Sync.close can throw during retirement'
  recovery='Owner and refresh scheduling are detached first; publish sets unauthenticated state. Attempt old close even after observer failure. Preserve one exact root or distinct aggregate; never report successful retirement on failure.'
 elif 'Refresh and observer failed' in source:
  fault='Actual final busy=false publication listener throws after refresh or retirement has already failed'
  recovery='State busy is cleared before listener callback; preserve prior refresh/retirement roots and distinct observer root, then propagate through existing failure gate. Falsy roots remain roots.'
 nav['records'].append(dict(original_ordinal=ordinal,original_id=sid,id=sid,composite_identity=f'{ordinal}|{path}|{sid}',path=path,line=line,column=column,source=source,source_sha256=sha((R/path).read_bytes()),token='catch',token_class='catch',executable=True,specific_fault=fault,present_authority=G,actual_recovery_or_failure=recovery,disposition='LOCAL_RETAINED_CURRENT_GROUND_PENDING_INDEPENDENT_REVIEW',decision='FIX_LOCAL_CURRENT_BINDING_NOT_INDEPENDENT_ACCEPTANCE'))
for x in nav['records']:
 ordinal=x['original_ordinal'];site=inv['retained_sites'][ordinal-1] if ordinal<=len(inv['retained_sites']) else {'id':x['id'],'path':x['path'],'operation':'current Workspace refresh retirement','disposition':'RETAINED'}
 site.update(line=x['line'],column=x['column'],source=x['source'].strip(),source_sha256=x['source_sha256'],actual_source=x['source'],specific_fault=x['specific_fault'],present_authority=x['present_authority'],actual_recovery_or_failure=x['actual_recovery_or_failure'],authority=x['present_authority'],specific_ground_and_recovery=x['specific_fault']+' → '+x['present_authority']+' → '+x['actual_recovery_or_failure'])
 if ordinal>len(inv['retained_sites']):inv['retained_sites'].append(site)
for x in inv['files']:
 if x['path'] in changed:x.update(sha256=sha((R/x['path']).read_bytes()),bytes=(R/x['path']).stat().st_size,changed=True,inspection='Current active-owner refresh lifecycle fix; focused native/current consumer evidence follows fix-refresh-owner/handoff.md; final independent semantic reviews PENDING.')
 assert sha((R/x['path']).read_bytes())==x['sha256']
counts=dict(records=len(nav['records']),executable=sum(x['executable'] for x in nav['records']),nonexecutable=sum(not x['executable'] for x in nav['records']));assert counts==dict(records=323,executable=288,nonexecutable=35)
nav.update(counts=counts,binding='Current local323 navigation tokens (288 executable35 nonexecutable), not catch count. Prior318 composite identities preserved plus5 current lifecycle catches. Current authority/fault/recovery only; historical candidates remain immutable. NEW finalSHA regular/specialized PENDING.')
inv['counts']['retained_sites']=323;inv['candidate_binding']='Current clean committed task HEAD through fix-refresh-owner/final external receipt; independent regular/specialized finalSHA PENDING';inv['fix_refresh_owner']=dict(base=B,production_delta=changed,counts=counts,current_navigation='spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-refresh-owner/current-navigation.json',grounds22='Current actual source/type/parser/display/READ authority rejudged; prior ground-corrections preserved sealed.')
protected=json.loads((D/'fix-android-wss-cleanup/protected-inputs.json').read_text());assert len(protected['files'])==65
for x in protected['files']:
 b=(R/x['path']).read_bytes();assert sha(b)==x['sha256'];assert b==subprocess.check_output(['git','show',B+':'+x['path']],cwd=R)
for x in nav['records']:
 b=(R/x['path']).read_bytes();assert sha(b)==x['source_sha256'];assert b.decode().splitlines()[x['line']-1][x['column']-1:].startswith(x['token'])
js(E/'current-navigation.json',nav);js(E/'production-inventory.json',inv);js(E/'protected-inputs.json',protected);js(E/'input-checks.json',dict(production185=True,navigation=counts,protected65_exact27=True,prior211seal_verified=True,grounds22_rejudged=True,sole_production_delta=changed,independent_acceptance=False))
print('185/323(288exec35nonexec)/65 exact27, sealed211 and22 grounds verified; external preview prepared')
