from pathlib import Path
import subprocess,sys,shutil,json,hashlib
E=Path(__file__).parent;R=Path('H:/.codex/worktrees/err/IM-platform')
for name,runner in [('owner','im.platform.client.ui.RefreshOwnerInstrumentation'),('errors','im.platform.client.ui.ErrorHandlingInstrumentation')]:
 cmd=[sys.executable,'-Xutf8','-B',str(R/'tests/clients/gui/native.py'),'gradle','--max-workers=1','-Dorg.gradle.jvmargs=-Xmx768m -XX:ActiveProcessorCount=2 -Dfile.encoding=UTF-8','-Pkotlin.compiler.execution.strategy=in-process','-PimSendInstrumentation='+runner,'assembleDebug','assembleDebugAndroidTest'];subprocess.run(cmd,check=True)
 dest=E/'apks'/name;dest.mkdir(parents=True,exist_ok=True);seals={}
 for p in [R/'clients/mobile/app/build/outputs/apk/debug/app-debug.apk',R/'clients/mobile/app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk']:
  b=p.read_bytes();(dest/p.name).write_bytes(b);seals[p.name]=hashlib.sha256(b).hexdigest()
 (dest/'seals.json').write_text(json.dumps(dict(runner=runner,apks=seals),indent=2));print('Preserved newly built '+name+' APKs',flush=True)
