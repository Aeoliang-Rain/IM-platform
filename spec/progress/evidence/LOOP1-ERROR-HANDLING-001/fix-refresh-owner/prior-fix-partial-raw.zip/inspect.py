from pathlib import Path
import hashlib,subprocess,json
R=Path.cwd();E=Path(__file__).parent;O=E.parent/'regular-review-27cdd93'
print('root',subprocess.check_output(['git','rev-parse','--show-toplevel'],text=True).strip());assert Path(subprocess.check_output(['git','rev-parse','--show-toplevel'],text=True).strip()).resolve()==R.resolve()
for p,h in [('spec/architecture/frozen-architecture.md','efbe04c7eb308904d1759b8e145a32363620ed8c14daef58f09c644bdc897bdc'),('scalable-distributed-im-architecture.pdf','546915f639f30cd294f11390da3ade2ce6a85b620bf55727c2a90ca6017d7510')]:assert hashlib.sha256((R/p).read_bytes()).hexdigest()==h
assert hashlib.sha256((O/'final-receipt.json').read_bytes()).hexdigest()=='a8df4b6fe9ba3147bce44f2646d56aafd7199dc3bf92a7cf35918e16b50818fa'
files=['spec/architecture/frozen-architecture.md','spec/governance/minimality.md','spec/governance/error-handling.md','spec/governance/execution-boundaries.md','spec/governance/independent-review.md','spec/governance/technology-selection.md','spec/acceptance/client-gui.md','spec/acceptance/client-supplement.md']
files += [str(p.relative_to(R)) for d in ['spec/domain','spec/invariants','spec/architecture/decisions','contracts/errors','contracts/http','contracts/websocket','contracts/database'] for p in (R/d).rglob('*') if p.is_file() and p.suffix in ['.md','.json','.yaml','.yml','.sql']]
with (E/'authority-read.txt').open('w',encoding='utf8') as f:
 for p in files:f.write('\nFILE '+p+'\n'+(R/p).read_text(encoding='utf8'))
print('authority inputs read',len(files));print((O/'report.md').read_text(encoding='utf8'));print((O/'final-receipt.json').read_text());print((O/'ground-corrections.json').read_text(encoding='utf8'))
for args in [['git','status','--short'],['git','diff','--stat'],['git','log','-5','--oneline']]:print(subprocess.check_output(args,text=True))
