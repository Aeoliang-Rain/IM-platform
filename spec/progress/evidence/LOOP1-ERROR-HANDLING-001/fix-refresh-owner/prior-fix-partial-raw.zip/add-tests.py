from pathlib import Path
R=Path('H:/.codex/worktrees/err/IM-platform');E=Path(__file__).parent
p=R/'clients/mobile/app/src/androidTest/kotlin/im/platform/client/ui/RefreshOwnerInstrumentation.kt';assert not p.exists();p.write_bytes((E/p.name).read_bytes())
p=R/'tests/clients/errors/desktop_owner_retirement.mjs';assert not p.exists();p.write_bytes((E/p.name).read_bytes())
print('Added actual consumer regression controls within allowed test paths')
