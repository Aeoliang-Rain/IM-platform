from pathlib import Path
import subprocess,json,os,time,shutil,hashlib,ctypes
E=Path(__file__).parent;R=Path('H:/.codex/worktrees/err/IM-platform');x=json.loads((E/'emulator-receipt.json').read_text());assert x['serial']=='emulator-5612' and x['owned_name']=='RefreshOwner20261015'
adb='H:/Android/platform-tools/adb.exe';os.environ.update(ANDROID_USER_HOME=str(E/'android-user'),ANDROID_AVD_HOME=str(E/'avds'))
subprocess.run([adb,'-s',x['serial'],'emu','kill'],check=True)
for _ in range(30):
 s=subprocess.check_output([adb,'devices','-l'],text=True)
 if x['serial'] not in s:break
 time.sleep(1)
else:raise RuntimeError('own emulator still running')
(E/'own-emulator-build-pause.json').write_text(json.dumps(dict(serial=x['serial'],stopped=True,devices=s,reason='Host JVM native memory allocation failed twice; release own emulator before sequential build'),indent=2))
for name in ['hs_err_pid26308.log','hs_err_pid39416.log','replay_pid39416.log']:
 p=R/'clients/mobile'/name;
 if not p.exists():continue
 b=p.read_bytes();dest=E/name;dest.write_bytes(b);assert dest.read_bytes()==b;p.unlink();print(name,len(b),hashlib.sha256(b).hexdigest())
print('Only proven own emulator paused and exact generated crash logs preserved externally')


