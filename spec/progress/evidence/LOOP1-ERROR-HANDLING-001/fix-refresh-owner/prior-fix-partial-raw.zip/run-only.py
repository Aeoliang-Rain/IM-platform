import pathlib,subprocess,sys,time,json,os
R=pathlib.Path('H:/.codex/worktrees/err/IM-platform');E=pathlib.Path(__file__).parent;adb='H:/Android/platform-tools/adb.exe';serial='emulator-5612';runner=sys.argv[1];PY=sys.executable
os.environ.update(ANDROID_USER_HOME=str(E/'android-user'),ANDROID_AVD_HOME=str(E/'avds'))
os.environ['ANDROID_SDK_HOME']=str(E/'android-sdk-home')
subprocess.run([adb,'-s',serial,'wait-for-device'],check=True,timeout=120)
for _ in range(100):
 boot=subprocess.check_output([adb,'-s',serial,'shell','getprop','sys.boot_completed'],text=True).strip()
 if boot=='1':break
 time.sleep(1)
else:raise RuntimeError('owned emulator boot timeout')
for path in ['debug/app-debug.apk','androidTest/debug/app-debug-androidTest.apk']:subprocess.run([adb,'-s',serial,'install','-r',str(R/'clients/mobile/app/build/outputs/apk'/path)],check=True)
p=subprocess.run([adb,'-s',serial,'shell','am','instrument','-w','im.platform.client.test/'+runner],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=180);print(p.stdout,flush=True)
(E/(runner.rsplit('.',1)[-1]+'.output.txt')).write_text(p.stdout,encoding='utf8');assert p.returncode==0 and 'result=PASS' in p.stdout and 'sdkInt=34' in p.stdout and 'INSTRUMENTATION_CODE: -1' in p.stdout,p.stdout



