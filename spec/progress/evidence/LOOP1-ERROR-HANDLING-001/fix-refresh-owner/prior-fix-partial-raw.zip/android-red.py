from pathlib import Path
import subprocess,json,hashlib
E=Path(__file__).parent;R=Path('H:/.codex/worktrees/err/IM-platform');F=E/'android-expiry';F.mkdir(exist_ok=True)
old=E.parent/'recover-wss-desktop-finish/android-refresh'
for name in ['Session.kt','Json.kt','Preferences.kt']:(F/name).write_bytes((old/name).read_bytes())
for path,name in [('send/Wire.kt','Wire.kt'),('ui/Auth.kt','Auth.kt')]:
 src=R/'clients/mobile/app/src/main/kotlin/im/platform/client'/path;(F/name).write_bytes(src.read_bytes())
s=(R/'clients/mobile/app/src/main/kotlin/im/platform/client/ui/WorkspaceViewModel.kt').read_text();line=next(x for x in s.splitlines() if x.strip().startswith('private fun fail('))
(F/'Consumer.kt').write_text('''package im.platform.client.ui
import im.platform.client.send.*
class SyncFailure:Exception()
class SendStorageFailure:Exception()
data class Projection(val error:String?=null,val authenticated:Boolean=true)
class Consumer{var state=Projection();var expired=0;private fun publish(f:(Projection)->Projection){state=f(state)};private fun expire(){expired++;state=state.copy(authenticated=false)}
'''+line+'''
fun receive(e:Exception){fail(e)}
}
''')
(F/'Main.kt').write_text('''import im.platform.client.ui.*
import kotlinx.coroutines.runBlocking
import java.io.*
import java.net.*
import javax.net.ssl.HttpsURLConnection
class Peer(url:URL):HttpsURLConnection(url){override fun connect(){};override fun disconnect(){};override fun usingProxy()=false;override fun getCipherSuite()="controlled";override fun getLocalCertificates():Array<java.security.cert.Certificate>?=null;override fun getServerCertificates():Array<java.security.cert.Certificate> = emptyArray();override fun getOutputStream():OutputStream=ByteArrayOutputStream();override fun getResponseCode()=401;override fun getContentType()="application/json";override fun getErrorStream():InputStream=ByteArrayInputStream("{\\"error\\":{\\"code\\":\\"AUTH_SESSION_REVOKED\\"}}".toByteArray())}
fun main()=runBlocking {
 URL.setURLStreamHandlerFactory{scheme->if(scheme=="https")object:URLStreamHandler(){override fun openConnection(url:URL)=Peer(url)}else null}
 val prefs=Preferences(IOException("Credential cleanup failed"));val owner=Auth("https://fixture.invalid",prefs);owner.savedAccount()
 val result=try{owner.refresh();error("unexpected success")}catch(e:Exception){e};check(result is IOException);check((result.cause as ApiFailure).kind=="session_expired")
 val consumer=Consumer();consumer.receive(result);check(consumer.expired==0);check(consumer.state.authenticated);check(consumer.state.error=="Operation unavailable");check(prefs.removes==1)
 println("REPRODUCED: actual Auth.refresh known IOException + byte-exact Workspace.fail body: expired="+consumer.expired+" authenticated="+consumer.state.authenticated+" error="+consumer.state.error+" removes="+prefs.removes)
}
''')
cache=Path('H:/gradle/caches/modules-2/files-2.1')
def jar(g,n,v):return next((cache/g/n/v).rglob('*.jar'))
std=jar('org.jetbrains.kotlin','kotlin-stdlib','2.1.10');cor=jar('org.jetbrains.kotlinx','kotlinx-coroutines-core-jvm','1.9.0');ann=jar('org.jetbrains','annotations','23.0.0')
compiler=[jar('org.jetbrains.kotlin','kotlin-compiler-embeddable','2.1.10'),std,cor,ann,jar('org.jetbrains.kotlin','kotlin-script-runtime','2.1.10'),jar('org.jetbrains.kotlin','kotlin-reflect','1.6.10'),jar('org.jetbrains.intellij.deps','trove4j','1.0.20200330')]
java='H:/.jdks/jdk17/bin/java.exe';target=F/'classes';target.mkdir(exist_ok=True)
for cmd in [[java,'-cp',';'.join(map(str,compiler)),'org.jetbrains.kotlin.cli.jvm.K2JVMCompiler','-no-stdlib','-no-reflect','-classpath',';'.join(map(str,[std,cor,ann])),'-d',str(target),*map(str,F.glob('*.kt'))],[java,'-cp',';'.join(map(str,[target,std,cor,ann])),'MainKt']]:subprocess.run(cmd,check=True)
print('Scope: JVM exact production Auth/Wire + exact extracted fail method, stub external storage and minimal publish/expiry counters. Not full Android/emulator acceptance.')
