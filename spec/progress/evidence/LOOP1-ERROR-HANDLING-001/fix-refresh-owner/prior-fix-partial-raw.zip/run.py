from pathlib import Path
import sys,subprocess,os
R=Path('H:/.codex/worktrees/err/IM-platform');E=Path(__file__).parent;env=os.environ.copy();env.update(PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8');env['PATH']=str(Path(sys.executable).parent)+';H:/node.js;'+env.get('PATH','')
sys.exit(subprocess.call([sys.executable,'-Xutf8','-B',str(R/'tools/research/recorder.py'),'run-command','--research-root',str(E/'research'),'--run-id','R-FIX-REFRESH-OWNER','--',*sys.argv[1:]],cwd=R,env=env))

