from pathlib import Path
import os,json,subprocess
E=Path(__file__).parent;x=json.loads((E/'emulator-receipt.json').read_text());assert x['serial']=='emulator-5612' and x['owned_name']=='RefreshOwner20261015'
env=os.environ.copy();env.update(JAVA_HOME='H:/.jdks/jdk17',ANDROID_HOME='H:/Android',ANDROID_SDK_ROOT='H:/Android',ANDROID_USER_HOME=str(E/'android-user'),ANDROID_AVD_HOME=str(E/'avds'))
devices=subprocess.check_output(['H:/Android/platform-tools/adb.exe','devices','-l'],env=env,text=True);assert not [s for s in devices.splitlines() if s.startswith('emulator-')]
log=(E/'emulator-restart.log').open('w');args=['H:/Android/emulator/emulator.exe','-avd',x['owned_name'],'-port','5612','-memory','1024','-cores','2','-no-window','-no-audio','-no-snapshot','-gpu','swiftshader_indirect'];p=subprocess.Popen(args,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW);(E/'emulator-restart-receipt.json').write_text(json.dumps(dict(pid=p.pid,argv=args,owned_avd=x['owned_avd'],serial=x['serial'],devices_before=devices),indent=2));print('Own API34 AVD restart',p.pid)
