from pathlib import Path
R=Path('H:/.codex/worktrees/err/IM-platform');p=R/'clients/desktop/src/application/ui/workspace.ts';s=p.read_text();old='''async refresh(){if(this.state.busy||!this.auth)return;const op=++this.operation;const owner=this.auth,g=this.generation;this.publish({busy:true,error:null});try{const session=await owner.refresh();if(op===this.operation)await this.bind(session,op);}catch(error){
    let failure=error;
    if(op===this.operation&&owner===this.auth&&g===this.generation&&!owner.session){this.auth=null;try{await this.stop();}catch(cleanup){if(cleanup!==error)failure=new AggregateError([error,cleanup],"Refresh and retirement failed");}}
    this.failure(failure,op===this.operation);
  }finally{if(op===this.operation)this.publish({busy:false});}}'''
new='''async refresh(){if(this.state.busy||!this.auth)return;const op=++this.operation;const owner=this.auth,g=this.generation;let failed=false,failure:unknown;this.publish({busy:true,error:null});try{const session=await owner.refresh();if(op===this.operation)await this.bind(session,op);}catch(error){
    failed=true;failure=error;
    if(op===this.operation&&owner===this.auth&&g===this.generation&&!owner.session){this.auth=null;try{await this.stop();}catch(cleanup){if(cleanup!==error)failure=new AggregateError([error,cleanup],"Refresh and retirement failed");}}
  }finally{if(op===this.operation)try{this.publish({busy:false});}catch(cleanup){failure=failed&&cleanup!==failure?new AggregateError([failure,cleanup],"Refresh and observer failed"):cleanup;failed=true;}}
    if(failed)this.failure(failure,op===this.operation);
  }'''
assert s.count(old)==1;p.write_text(s.replace(old,new),newline='\n')
p=R/'tests/clients/errors/desktop_parallel.mjs';s=p.read_text();old='const w=new Workspace();w.auth=auth;w.state.session=session;let error,failed=false;';new='const w=new Workspace();w.auth=auth;w.state.session=session;let closed=0;w.sync={close:async()=>{closed++;}};let error,failed=false;';assert s.count(old)==1;s=s.replace(old,new)
old="await (consumer?w.refresh():auth.refresh()).catch(root=>{failed=true;error=root;});await tick();assert(primary instanceof ApiFailure);"
new="await (consumer?w.refresh():auth.refresh()).catch(root=>{failed=true;error=root;});await tick();if(consumer){assert.equal(w.state.session,null);assert.equal(w.auth,null);assert.equal(w.sync,null);assert.equal(closed,1);const before=removes;await w.refresh();assert.equal(removes,before);}assert(primary instanceof ApiFailure);";assert s.count(old)==1;s=s.replace(old,new);p.write_text(s,newline='\n')
print('Desktop final observer root retention and existing37 lifecycle assertions updated')
