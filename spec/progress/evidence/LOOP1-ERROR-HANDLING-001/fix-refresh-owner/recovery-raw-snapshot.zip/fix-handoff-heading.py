from pathlib import Path
import shutil
E=Path(__file__).parent;R=Path('H:/.codex/worktrees/err/IM-platform')
for ext in ['json','txt']:shutil.copyfile(E/('development.'+ext),E/('development-first.'+ext))
p=R/'spec/tasks/review/LOOP1-ERROR-HANDLING-001.md';s=p.read_text(encoding='utf8');needle='# Handoff\n\n# Current refresh owner recovery';assert needle in s;s=s.replace(needle,'# Handoff\n\nCurrent recovery owner /root/recover_refresh_owner_finish; current local185/323/65 candidate evidence in spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-refresh-owner/handoff.md. Task review/S2 OPEN; finalSHA regular/specialized/hosted/integration/main/sync PENDING.\n\n# Current refresh owner recovery',1);p.write_text(s,encoding='utf8',newline='\n')
p=R/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-refresh-owner/handoff.md';s=p.read_text();s+='\nFinal Development first failed because the inserted current recovery subheading followed # Handoff before any body, so the unchanged verifier parsed an empty section. Only the Task Handoff body now states actual owner/evidence/pending status. Original exit1/output retained; only the failed Development check reruns.\n';p.write_text(s,encoding='utf8',newline='\n')
print('Corrected only empty parsed Task Handoff body; original Development failure retained')
