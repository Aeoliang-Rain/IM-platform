from pathlib import Path
import json,subprocess,os,shutil,stat
E=Path(__file__).parent;O=E.parent/'fix-refresh-owner';R=Path('H:/.codex/worktrees/err/IM-platform');adb='H:/Android/platform-tools/adb.exe';pwsh='C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe'
x=json.loads((E/'emulator-receipt.json').read_text());avd=Path(x['owned_avd']).resolve();expected=(R/'clients/mobile/.gradle/owner-runtime/RefreshOwner20261015.avd').resolve();assert avd==expected and avd.is_relative_to((R/'clients/mobile').resolve())
cmd="@(Get-CimInstance Win32_Process | Where-Object { $_.Name -match 'qemu|emulator' -and $_.CommandLine -match 'RefreshOwner20261015|5612' } | Select-Object ProcessId,ParentProcessId,Name,CommandLine) | ConvertTo-Json -Depth 3"
probe=subprocess.run([pwsh,'-NoProfile','-Command',cmd],stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(E/'cleanup-process-check.txt').write_bytes(probe.stdout);assert probe.returncode==0 and not probe.stdout.strip(),probe.stdout.decode('utf8','replace')
env=os.environ.copy();env.update(ANDROID_USER_HOME=str(O/'android-user'),ANDROID_AVD_HOME=str(O/'avds'))
devices=subprocess.check_output([adb,'devices','-l'],env=env,text=True);assert not [line for line in devices.splitlines()[1:] if line.strip()],devices
attributes=[]
def retry_readonly(function,path,error):
 p=Path(path).resolve();assert p.is_relative_to(expected)
 attrs=getattr(p.stat(),'st_file_attributes',0);attributes.append(dict(path=str(p),attributes=attrs))
 if not isinstance(error,PermissionError) or not attrs & stat.FILE_ATTRIBUTE_READONLY:raise error
 # Windows os.chmod changes only the read-only file attribute; no trust/ACL modification.
 os.chmod(p,stat.S_IWRITE);function(p)
if avd.exists():shutil.rmtree(avd,onexc=retry_readonly)
ini=O/'avds/RefreshOwner20261015.ini';assert 'RefreshOwner20261015' in ini.name
if ini.exists():ini.unlink()
moved=[]
for rel in ['clients/mobile/app/build','clients/mobile/build','clients/mobile/.gradle']:
 p=(R/rel).resolve();assert p.is_relative_to((R/'clients/mobile').resolve());assert not subprocess.check_output(['git','ls-files','--',rel],cwd=R).strip()
 if not p.exists():continue
 dest=E/'generated'/rel.replace('/','_');dest.parent.mkdir(parents=True,exist_ok=True);assert not dest.exists();shutil.move(str(p),str(dest));moved.append(dict(source=rel,preserved=str(dest)))
subprocess.run([adb,'kill-server'],env=env,check=True)
receipt=dict(serial=x['serial'],owned_avd=str(avd),avd_resolved_inside_assigned_root=True,closed=True,own_qemu_process_absent=True,removed_only_receipt_proven_avd=True,devices_after=devices,reverse_before='',generated_outputs_preserved=moved,read_only_attributes_cleared=attributes,new_daemon_started_by_recovery_query=True,new_daemon_stopped=True,private_device_or_global_trust_or_acl_touched=False,prior_cleanup_failure='First deletion failed on own pstore.bin; preserved raw. Retried only after own qemu absence; only Windows read-only file attribute may be cleared, never ACL.')
(E/'runtime-cleanup.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
