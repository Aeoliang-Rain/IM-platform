from pathlib import Path
import json
E=Path(__file__).parent;O=E.parent/'fix-refresh-owner'
nav=json.loads((O/'current-navigation.json').read_text());inv=json.loads((O/'production-inventory.json').read_text())
print('navkeys',list(nav));print('inventorykeys',list(inv))
for ordinal in [28,242,319,320,321,322,323]:
 n=next(x for x in nav['records'] if x['original_ordinal']==ordinal);print(json.dumps(n,ensure_ascii=False));print('inventory',json.dumps(inv['retained_sites'][ordinal-1],ensure_ascii=False))
events=[json.loads(s) for s in (O/'research/runs/R-FIX-REFRESH-OWNER/events.jsonl').read_text().splitlines()]
starts={x['data']['command_id']:x for x in events if x['event_type']=='command_started'}
for x in events:
 if x['event_type']=='command_finished':
  d=x['data'];s=starts[d['command_id']];print('oldcommand',s['seq'],s['data'].get('argv'),d['exit_code'],d['stdout_blob'])
print('lastoldseq',events[-1]['seq'],events[-1]['event_type'])
