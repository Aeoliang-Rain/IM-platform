from pathlib import Path
import os,json,subprocess,socket,time,hashlib
E=Path(__file__).parent;O=E.parent/'fix-refresh-owner';R=Path('H:/.codex/worktrees/err/IM-platform');adb='H:/Android/platform-tools/adb.exe'
def sha(b):return hashlib.sha256(b).hexdigest()
def js(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf8')
x=json.loads((O/'emulator-receipt.json').read_text());assert x['serial']=='emulator-5612' and x['owned_name']=='RefreshOwner20261015'
avd=Path(x['owned_avd']);assert avd.resolve()==(R/'clients/mobile/.gradle/owner-runtime/RefreshOwner20261015.avd').resolve();assert avd.is_dir()
env=os.environ.copy();env.update(JAVA_HOME='H:/.jdks/jdk17',ANDROID_HOME='H:/Android',ANDROID_SDK_ROOT='H:/Android',ANDROID_USER_HOME=str(O/'android-user'),ANDROID_AVD_HOME=str(O/'avds'))
devices=subprocess.check_output([adb,'devices','-l'],env=env,text=True);assert 'emulator-' not in devices,devices
for port in [5612,5613]:
 with socket.socket() as sock:sock.bind(('127.0.0.1',port))
args=['H:/Android/emulator/emulator.exe','-avd',x['owned_name'],'-port','5612','-memory','1024','-cores','2','-no-window','-no-audio','-no-snapshot','-gpu','swiftshader_indirect']
log=(E/'emulator.log').open('w');p=subprocess.Popen(args,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
js(E/'emulator-receipt.json',dict(pid=p.pid,argv=args,owned_avd=str(avd),serial=x['serial'],devices_before=devices,adopted_ownership_receipt_sha256=sha((O/'emulator-receipt.json').read_bytes()),private_devices_touched=False,global_trust_changed=False))
print('Started only proven owned API34/5612 pid='+str(p.pid),flush=True)
serial=x['serial'];subprocess.run([adb,'-s',serial,'wait-for-device'],env=env,check=True,timeout=120)
for _ in range(120):
 boot=subprocess.check_output([adb,'-s',serial,'shell','getprop','sys.boot_completed'],env=env,text=True).strip()
 if boot=='1':break
 time.sleep(1)
else:raise RuntimeError('Owned emulator boot timeout')
results=[]
for name in ['owner','errors']:
 dest=E/'apks'/name;seal=json.loads((dest/'seals.json').read_text());runner=seal['runner']
 for filename in ['app-debug.apk','app-debug-androidTest.apk']:
  apk=dest/filename;b=apk.read_bytes();assert len(b)==seal['apks'][filename]['bytes'] and sha(b)==seal['apks'][filename]['sha256']
  subprocess.run([adb,'-s',serial,'install','-r',str(apk)],env=env,check=True,timeout=120)
 cmd=[adb,'-s',serial,'shell','am','instrument','-w','im.platform.client.test/'+runner];start=time.monotonic();q=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=240)
 (E/f'native-{name}.txt').write_bytes(q.stdout);output=q.stdout.decode('utf8','replace');print(output,flush=True)
 item=dict(argv=cmd,exit_code=q.returncode,elapsed_seconds=time.monotonic()-start,serial=serial,sdkInt=34,output_sha256=sha(q.stdout),apk_seal_sha256=sha((dest/'seals.json').read_bytes()),output=f'native-{name}.txt');results.append(item);js(E/'native-results.json',results)
 assert q.returncode==0 and 'result=PASS' in output and 'sdkInt=34' in output and 'INSTRUMENTATION_CODE: -1' in output,output
 if name=='owner':assert 'checks=10' in output and 'REFRESH-OWNER normal Auth refresh rotation PASS' in output,output
 else:assert 'httpCleanupChecks=32' in output and 'wssCleanupChecks=21' in output,output
 print('Actual API34 '+name+' required controls PASS',flush=True)
print('Fresh exact APK owner10 and originalErrors+HTTP32+WSS21 actual Android runtime PASS',flush=True)
