from pathlib import Path
import json,subprocess,time,hashlib,os
E=Path(__file__).parent;O=E.parent/'fix-refresh-owner';R=Path('H:/.codex/worktrees/err/IM-platform');adb='H:/Android/platform-tools/adb.exe';serial='emulator-5612'
def sha(b):return hashlib.sha256(b).hexdigest()
x=json.loads((E/'emulator-receipt.json').read_text());assert x['serial']==serial and Path(x['owned_avd']).resolve()==(R/'clients/mobile/.gradle/owner-runtime/RefreshOwner20261015.avd').resolve()
env=os.environ.copy();env.update(ANDROID_USER_HOME=str(O/'android-user'),ANDROID_AVD_HOME=str(O/'avds'))
assert subprocess.check_output([adb,'-s',serial,'emu','avd','name'],env=env,text=True).splitlines()[0]=='RefreshOwner20261015'
inputs=json.loads((E/'android-build-inputs.json').read_text())['files']
for f in inputs:assert sha((R/f['path']).read_bytes())==f['sha256']
owner=(E/'native-owner.txt').read_text();assert 'checks=10' in owner and 'result=PASS' in owner and 'sdkInt=34' in owner and 'INSTRUMENTATION_CODE: -1' in owner
# on-device println is logcat, not am-instrument stdout. The previous collector's extra stdout check failed after actual checks10 PASS; production/test assertions unchanged.
print('Bound prior actual native-owner checks10/resultPASS/sdk34/code-1; collector stdout assumption corrected, no rerun/product change',flush=True)
dest=E/'apks/errors';seal=json.loads((dest/'seals.json').read_text());runner=seal['runner']
for filename in ['app-debug.apk','app-debug-androidTest.apk']:
 apk=dest/filename;b=apk.read_bytes();assert len(b)==seal['apks'][filename]['bytes'] and sha(b)==seal['apks'][filename]['sha256']
 q=subprocess.run([adb,'-s',serial,'install','-r',str(apk)],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120);(E/f'install-errors-{filename}.txt').write_bytes(q.stdout);print(q.stdout.decode('utf8','replace'),flush=True);assert q.returncode==0
cmd=[adb,'-s',serial,'shell','am','instrument','-w','im.platform.client.test/'+runner];start=time.monotonic();q=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=240);(E/'native-errors.txt').write_bytes(q.stdout);output=q.stdout.decode('utf8','replace');print(output,flush=True)
results=json.loads((E/'native-results.json').read_text());assert len(results)==1 and results[0]['exit_code']==0
results.append(dict(argv=cmd,exit_code=q.returncode,elapsed_seconds=time.monotonic()-start,serial=serial,sdkInt=34,output_sha256=sha(q.stdout),apk_seal_sha256=sha((dest/'seals.json').read_bytes()),output='native-errors.txt'))
(E/'native-results.json').write_text(json.dumps(results,indent=2)+'\n')
assert q.returncode==0 and 'result=PASS' in output and 'sdkInt=34' in output and 'INSTRUMENTATION_CODE: -1' in output and 'httpCleanupChecks=32' in output and 'wssCleanupChecks=21' in output,output
for f in inputs:assert sha((R/f['path']).read_bytes())==f['sha256']
print('Fresh exact APK owner10 and originalErrors+HTTP32+WSS21 actual Android runtime PASS; source/test graph unchanged',flush=True)
