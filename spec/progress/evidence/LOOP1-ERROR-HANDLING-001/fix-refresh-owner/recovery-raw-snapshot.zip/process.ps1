$ErrorActionPreference='Stop'
$rows=@(Get-CimInstance Win32_Process | Where-Object { $_.Name -match 'java|python|qemu|emulator|gradle' -and $_.CommandLine -match 'fix-refresh-owner|worktrees[\\/]err|R-FIX-REFRESH|5612|GradleDaemon' } | Select-Object ProcessId,ParentProcessId,Name,CreationDate,CommandLine)
$json=ConvertTo-Json -InputObject $rows -Depth 3
[IO.File]::WriteAllText('C:/Users/21441/.codex/visualizations/2026/10/13/01a1341c-f5bd-7a20-8d63-e5a574250f3c/recover-refresh-owner-finish/process-inventory.json',$json)
$json
& 'H:/Android/platform-tools/adb.exe' devices -l
if($LASTEXITCODE -ne 0){exit $LASTEXITCODE}
