from pathlib import Path
import subprocess,json,hashlib
R=Path('H:/.codex/worktrees/err/IM-platform');E=Path(__file__).parent
assert Path(subprocess.check_output(['git','rev-parse','--show-toplevel'],cwd=R,text=True).strip()).resolve()==R.resolve()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='27cdd93e30a72527bba9f3b0d611b13ba860e92f'
assert subprocess.check_output(['git','branch','--show-current'],cwd=R,text=True).strip()=='task/LOOP1-ERROR-HANDLING-001'
O=E.parent/'regular-review-27cdd93'
assert hashlib.sha256((O/'final-receipt.json').read_bytes()).hexdigest()=='a8df4b6fe9ba3147bce44f2646d56aafd7199dc3bf92a7cf35918e16b50818fa'
D=R/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-refresh-owner'
D.mkdir(exist_ok=True)
handoff='''# Refresh owner Fix recovery (2026-10-15)

Current actor /root/recover_refresh_owner_finish is the sole source writer, recovering disappeared /root/fix_refresh_owner_retirement. Assigned and Git-resolved root H:/.codex/worktrees/err/IM-platform; branch task/LOOP1-ERROR-HANDLING-001; base27cdd93e30a72527bba9f3b0d611b13ba860e92f. Task review, S2 OPEN. Last accepted main35bd6f5f1091503f95a0282f730ed04233b0b6ea. No push/PR/CI/main write/synchronization or acceptance is claimed.

Fresh regular27cdd93 FAIL F-EXPIRED-REFRESH-OWNER[P1] and22 current-retained ground mismatches[P2] remain immutable. Original receipt SHA a8df4b6fe9ba3147bce44f2646d56aafd7199dc3bf92a7cf35918e16b50818fa;211 original artifacts were byte/hash verified by Coordinator and prior Fix. Exact archive/rebinding will be delivered with final local candidate. Old318 navigation remains historical, current local preview323=288 executable+35 nonexecutable,185 production inputs/65 protected bytes; current full semantic independent reviews pending.

Adopted known-owned source changes only Desktop application/ui/workspace.ts and Android ui/WorkspaceViewModel.kt; actual invalidated active refresh owner is retired using operation+owner+generation+Auth.session null. Auth/Preferences/Repository/SQL/native database/transactions/writes/Composer/drafts unchanged from27. Known-owned tests: strengthened desktop_parallel.mjs, new desktop_owner_retirement.mjs and RefreshOwnerInstrumentation.kt. Prior actual Desktop strict compile/37+12 controls and actual API34 owner9 are qualified historical local evidence only. Added normal native token-rotation control requires a new owner10 APK and execution. No old9APK claim as10.

New run R-RECOVER-REFRESH-OWNER-FINISH prospective_resume parentR-ERROR-INTEGRATION-COORD-20261013 relatedR-FIX-REFRESH-OWNER. Old raw run remains partial, last seq60 command_started build-two.py; actual old command exit is unavailable. No old event is edited or finished. Startup read/inspection and truncated-read gaps disclosed. Current privileged process query found no old build/emulator child; adb query started a new daemon and no devices. Current frozen minimum baseline PASS.

Next exact action: emulator remains closed while sequential owner10 and originalErrors build, preserve each APK/hash, then boot only proven ownAPI34/5612 at1024MB/2cores and run both. Preserve generated crash logs and own runtime cleanup. Complete current grounds22/input bindings/immutable old archives; final local checks/exact-owned commit/clean Acceptance/Recorder/receipt. Both NEW fresh regular then DIFFERENT NEW specialized on SAME finalSHA PENDING; any Fix repeats both before hostedCI/protectedintegration/actual-main/safe H:/IM-platform synchronization. No Taskdone or StagePASS.
'''
(D/'handoff.md').write_text(handoff,encoding='utf8',newline='\n')
p=R/'spec/tasks/review/LOOP1-ERROR-HANDLING-001.md';s=p.read_text(encoding='utf-8-sig');s=s.replace('owner: fresh recovery Fix Agent /root/recover_wss_desktop_fix_finish','owner: fresh recovery Fix Agent /root/recover_refresh_owner_finish',1)
marker='# Current refresh owner recovery (2026-10-15)\n\n'
assert marker not in s
s=s.replace('# Handoff\n','# Handoff\n\n'+marker+handoff.split('\n',2)[2]+'\n# Historical pre-27 recovery handoff\n',1)
p.write_text(s,encoding='utf8',newline='\n')
(R/'spec/progress/current.md').write_text('''# Current Execution State

Current Loop: Loop 1
Current Stage: S2
Current Gate: S2
Gate Status: OPEN
Current Batch: LOOP1-ERROR-HANDLING-001
Batch Status: REVIEW_PENDING
Current Task: LOOP1-ERROR-HANDLING-001
Current Task State: review
Execution Status: RECOVERING_27CDD93_REVIEW_FAIL_REFRESH_OWNER_FIX

## Immediately Relevant Completed Work

Regular27cdd93 FAIL: expired refresh credential cleanup leaves active Workspace owner;22 retained grounds mismatch actual source. Old211 artifacts/receipt immutable. Sole fresh recovery Fix adopts known-owned two Workspace changes and focused tests. Current185/323 preview/65 protected input verification and final native10+originalErrors run still pending. Evidence: spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-refresh-owner/handoff.md.

## Current Blockers

Final native10+originalErrors verification, exact bindings and clean committed candidate pending. Then NEW full regular review and DIFFERENT NEW specialized SAMEfinalSHA pending; both PASS before any push/CI-triggeringPR. Exact-head hostedCI/protectedintegration/actual-main/safe H:/IM-platform synchronization pending. Task review/S2 OPEN.

## Verification

- Command: `python -Xutf8 -B tools/verify_frozen_architecture.py`
  - Result: current fresh minimum baseline PASS; canonical/PDF hashes match. Final checks and clean Acceptance pending.
  - Evidence: `spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-refresh-owner/handoff.md`

## Changed Files or Migrations

Relative27 only Desktop ui/workspace.ts and Android ui/WorkspaceViewModel.kt; existing Auth/Preferences/Send/Sync/Repository/storage/SQL/nativeDB/Composer/draft bytes unchanged. Known-owned focused tests only. No dependencies/contracts/Frozen/ADR/security/ACK/compatibility change.65 protected inputs remain bound to27; final exact proof pending.

## Known Failures, Risks, and Assumptions

Old R-FIX-REFRESH-OWNER remains partial; last seq60 build-two.py command outcome unavailable. Prior owner9 actual API34 PASS cannot prove added normal control10. Host build OOM/crash outputs retained; build while own emulator closed, then one low-memory boot. New recovery startup/direct/truncated-read gaps disclosed, no complete trace claim. Local checks/Recorder are not acceptance. Main782unknown/two tracked edits untouched.

## Next Exact Action

Sequentially build/preserve current owner10 and originalErrors APKs with emulator closed; boot only ownAPI34/5612 then run both; preserve/clean own runtime; finalize185/323/65 and22grounds, metadata and exact-owned commit/clean Acceptance/sealedreceipt/release. NEW regular then different NEW specialist SAMEfinalSHA, hostedCI/protectedintegration/actual-main/main sync all pending.

## Last Known Good Commit

`35bd6f5f1091503f95a0282f730ed04233b0b6ea` accepted I18N/main. Current task base27cdd93e30a72527bba9f3b0d611b13ba860e92f is unaccepted local candidate; finalSHA pending.

## Latest Checkpoint

`spec/progress/checkpoints/2026-10-14-error-handling-wss-cleanup-review-candidate.md` historical local candidate; current stable recovery checkpoint will follow final local binding.

## Uncommitted Changes / Ownership

Sole source writer /root/recover_refresh_owner_finish adopts exact known-owned prior Fix delta at H:/.codex/worktrees/err/IM-platform, branch task/LOOP1-ERROR-HANDLING-001. Main H:/IM-platform782unknown/two tracked edits untouched. Current replay_pid26308.log is generated prior-Fix crash output; preserve externally then remove exact bytes. No unknown work adopted. Old emulator5612 is stopped; only this recovery adb daemon query started, cleanup pending.

## Architecture Conflicts / ACP / ADR

None observed. Existing authorized Kotlin/TypeScript and lifecycle cleanup only. Taskdone/S2PASS/mainSHA synchronization pending.
''',encoding='utf8',newline='\n')
print('Updated exact Task/current recovery owner, immutable27 FAIL and pending native10/current binding; historical handoff retained')
