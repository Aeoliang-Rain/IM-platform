from pathlib import Path
import json,hashlib,zipfile,subprocess
E=Path(__file__).parent;O=E.parent/'fix-refresh-owner';R=Path('H:/.codex/worktrees/err/IM-platform');D=R/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-refresh-owner'
def sha(b):return hashlib.sha256(b).hexdigest()
def js(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
allcommands=[]
for root,run in [(O,'R-FIX-REFRESH-OWNER'),(E,'R-RECOVER-REFRESH-OWNER-FINISH')]:
 p=root/'research/runs'/run;events=[json.loads(s) for s in (p/'events.jsonl').read_text().splitlines()];finished={x['data']['command_id']:x for x in events if x['event_type']=='command_finished'}
 for x in events:
  if x['event_type']!='command_started':continue
  v=finished.get(x['data']['command_id']);item=dict(run_id=run,start=x,finish=v if v else 'unavailable',classification='Historical immutable partial' if root==O else 'Current recovery snapshot before final finish')
  if v:
   d=v['data'];item['output_blobs']=[]
   for channel in ['stdout','stderr']:
    blob=p/d[channel+'_blob'];b=blob.read_bytes();item['output_blobs'].append(dict(channel=channel,path=d[channel+'_blob'],stored_bytes=len(b),stored_sha256=sha(b),raw_output_sha256=d[channel+'_sha256'],redaction_applied=d.get('secret_redaction_applied',False)))
  allcommands.append(item)
snapshot=(E/'research/runs/R-RECOVER-REFRESH-OWNER-FINISH/events.jsonl').read_bytes()
js(D/'command-history.json',dict(commands=allcommands,current_snapshot_last_sequence=json.loads(snapshot.splitlines()[-1])['seq'],capture_mode='prospective_resume',complete_final_run='External final receipt after clean commit; repo snapshot intentionally cannot include its own finish',direct_command_gap='One launcher path codx-primary-runtime typo returned PowerShell exit1 before child Recorder launch; no source/product mutation. Startup/direct-read/helper/truncation gaps disclosed; unavailable facts remain unavailable.',old_last_command_exit='unavailable',raw_vs_stored_output_hashes_distinct=True))
items=[]
for p in E.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(E)
 if rel.parts[0] in ['generated','apks'] or p.name.startswith('final-receipt') or p.name=='recovery-raw-snapshot.zip':continue
 items.append((rel.as_posix(),p))
seals=[]
with zipfile.ZipFile(D/'recovery-raw-snapshot.zip','w',zipfile.ZIP_DEFLATED) as z:
 for rel,p in sorted(items):
  b=p.read_bytes();z.writestr(rel,b);seals.append(dict(path=rel,sha256=sha(b),bytes=len(b)))
with zipfile.ZipFile(D/'recovery-raw-snapshot.zip') as z:
 for x in seals:assert sha(z.read(x['path']))==x['sha256']
js(D/'recovery-raw-snapshot-seals.json',dict(archive_sha256=sha((D/'recovery-raw-snapshot.zip').read_bytes()),entries=seals,partial_snapshot=True,complete_run_after_commit='External recover-refresh-owner-finish/research; final receipt seals completed structural validation'))
print('Current command history/raw snapshot preserved with separate raw/stored hashes; old last build remains unavailable')
