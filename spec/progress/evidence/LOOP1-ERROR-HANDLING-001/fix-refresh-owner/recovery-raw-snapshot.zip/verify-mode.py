from pathlib import Path
import subprocess,sys,time,json,hashlib
E=Path(__file__).parent;R=Path('H:/.codex/worktrees/err/IM-platform');mode=sys.argv[1];assert mode in ['Development','Acceptance']
cmd=['C:/Users/21441/.cache/codex-runtimes/codex-primary-runtime/dependencies/native/powershell/pwsh.exe','-NoProfile','-File','tools/verify-loop1-ctrl-002.ps1','-Mode',mode]
t=time.monotonic();p=subprocess.run([sys.executable,'-Xutf8','-B',str(E/'run.py'),*cmd],cwd=R,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(E/(mode.lower()+'.txt')).write_bytes(p.stdout)
receipt=dict(argv=cmd,exit_code=p.returncode,elapsed_seconds=time.monotonic()-t,stored_output_sha256=hashlib.sha256(p.stdout).hexdigest());(E/(mode.lower()+'.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(p.stdout.decode('utf8','replace'),flush=True);print(json.dumps(receipt),flush=True);sys.exit(p.returncode)
