from pathlib import Path
import os,json,subprocess,time,hashlib
E=Path(__file__).parent;O=E.parent/'fix-refresh-owner';R=Path('H:/.codex/worktrees/err/IM-platform');adb='H:/Android/platform-tools/adb.exe'
def sha(b):return hashlib.sha256(b).hexdigest()
def js(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf8')
x=json.loads((E/'emulator-receipt.json').read_text());assert x['serial']=='emulator-5612'
assert Path(x['owned_avd']).resolve()==(R/'clients/mobile/.gradle/owner-runtime/RefreshOwner20261015.avd').resolve()
env=os.environ.copy();env.update(ANDROID_USER_HOME=str(O/'android-user'),ANDROID_AVD_HOME=str(O/'avds'))
serial=x['serial'];devices=subprocess.check_output([adb,'devices','-l'],env=env,text=True);assert serial in devices
assert subprocess.check_output([adb,'-s',serial,'emu','avd','name'],env=env,text=True).splitlines()[0]=='RefreshOwner20261015'
# Only disposable task fixture packages on this proven own emulator; preserve first failure in Recorder.
for package in ['im.platform.client.test','im.platform.client']:
 q=subprocess.run([adb,'-s',serial,'uninstall',package],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 (E/('uninstall-'+package+'.txt')).write_bytes(q.stdout);print(q.stdout.decode('utf8','replace'),flush=True);assert q.returncode==0
results=[]
for name in ['owner','errors']:
 dest=E/'apks'/name;seal=json.loads((dest/'seals.json').read_text());runner=seal['runner']
 for filename in ['app-debug.apk','app-debug-androidTest.apk']:
  apk=dest/filename;b=apk.read_bytes();assert len(b)==seal['apks'][filename]['bytes'] and sha(b)==seal['apks'][filename]['sha256']
  q=subprocess.run([adb,'-s',serial,'install','-r',str(apk)],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=120)
  (E/f'install-{name}-{filename}.txt').write_bytes(q.stdout);print(q.stdout.decode('utf8','replace'),flush=True);assert q.returncode==0
 cmd=[adb,'-s',serial,'shell','am','instrument','-w','im.platform.client.test/'+runner];start=time.monotonic();q=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=240)
 (E/f'native-{name}.txt').write_bytes(q.stdout);output=q.stdout.decode('utf8','replace');print(output,flush=True)
 item=dict(argv=cmd,exit_code=q.returncode,elapsed_seconds=time.monotonic()-start,serial=serial,sdkInt=34,output_sha256=sha(q.stdout),apk_seal_sha256=sha((dest/'seals.json').read_bytes()),output=f'native-{name}.txt');results.append(item);js(E/'native-results.json',results)
 assert q.returncode==0 and 'result=PASS' in output and 'sdkInt=34' in output and 'INSTRUMENTATION_CODE: -1' in output,output
 if name=='owner':assert 'checks=10' in output and 'REFRESH-OWNER normal Auth refresh rotation PASS' in output,output
 else:assert 'httpCleanupChecks=32' in output and 'wssCleanupChecks=21' in output,output
 print('Actual API34 '+name+' required controls PASS',flush=True)
for f in json.loads((E/'android-build-inputs.json').read_text())['files']:assert sha((R/f['path']).read_bytes())==f['sha256']
print('Fresh exact APK owner10 and originalErrors+HTTP32+WSS21 actual Android runtime PASS; full current source/test graph unchanged',flush=True)
