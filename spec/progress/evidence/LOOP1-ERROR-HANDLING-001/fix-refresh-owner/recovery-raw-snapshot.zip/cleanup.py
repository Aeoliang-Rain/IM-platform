from pathlib import Path
import json,subprocess,os,time,shutil,hashlib
E=Path(__file__).parent;O=E.parent/'fix-refresh-owner';R=Path('H:/.codex/worktrees/err/IM-platform');adb='H:/Android/platform-tools/adb.exe';serial='emulator-5612'
def sha(b):return hashlib.sha256(b).hexdigest()
assert Path(subprocess.check_output(['git','rev-parse','--show-toplevel'],cwd=R,text=True).strip()).resolve()==R.resolve()
x=json.loads((E/'emulator-receipt.json').read_text());old=json.loads((O/'emulator-receipt.json').read_text());avd=Path(x['owned_avd']).resolve();expected=(R/'clients/mobile/.gradle/owner-runtime/RefreshOwner20261015.avd').resolve();assert avd==expected==Path(old['owned_avd']).resolve()
assert expected.is_relative_to((R/'clients/mobile').resolve()) and x['serial']==serial and old['owned_name']=='RefreshOwner20261015'
env=os.environ.copy();env.update(ANDROID_USER_HOME=str(O/'android-user'),ANDROID_AVD_HOME=str(O/'avds'))
assert subprocess.check_output([adb,'-s',serial,'emu','avd','name'],env=env,text=True).splitlines()[0]=='RefreshOwner20261015'
reverse=subprocess.check_output([adb,'-s',serial,'reverse','--list'],env=env,text=True);assert not reverse.strip(),reverse
subprocess.run([adb,'-s',serial,'emu','kill'],env=env,check=True)
for _ in range(40):
 devices=subprocess.check_output([adb,'devices','-l'],env=env,text=True)
 if serial not in devices:break
 time.sleep(1)
else:raise RuntimeError('Owned emulator did not stop')
assert not [line for line in devices.splitlines()[1:] if line.strip()],devices
config=avd/'config.ini';(E/'owned-avd-config.ini').write_bytes(config.read_bytes())
ini=O/'avds/RefreshOwner20261015.ini';ini_bytes=ini.read_bytes();assert str(expected).replace('\\','/') in ini_bytes.decode().replace('\\','/');(E/'owned-avd-registration.ini').write_bytes(ini_bytes)
assert avd==expected and avd.is_relative_to((R/'clients/mobile').resolve())
shutil.rmtree(avd);ini.unlink()
moved=[]
for rel in ['clients/mobile/app/build','clients/mobile/build','clients/mobile/.gradle']:
 p=(R/rel).resolve();assert p.is_relative_to((R/'clients/mobile').resolve());assert not subprocess.check_output(['git','ls-files','--',rel],cwd=R).strip()
 if not p.exists():continue
 dest=E/'generated'/rel.replace('/','_');dest.parent.mkdir(parents=True,exist_ok=True);assert not dest.exists()
 shutil.move(str(p),str(dest));moved.append(dict(source=rel,preserved=str(dest)))
# Initial process query explicitly started this previously absent daemon; no other devices/sessions were used.
subprocess.run([adb,'kill-server'],env=env,check=True)
receipt=dict(serial=serial,owned_avd=str(avd),avd_resolved_inside_assigned_root=True,closed=True,removed_only_receipt_proven_avd=True,devices_after=devices,reverse_before=reverse,generated_outputs_preserved=moved,new_daemon_started_by_recovery_query=True,new_daemon_stopped=True,private_device_or_global_trust_touched=False)
(E/'runtime-cleanup.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2),flush=True)
