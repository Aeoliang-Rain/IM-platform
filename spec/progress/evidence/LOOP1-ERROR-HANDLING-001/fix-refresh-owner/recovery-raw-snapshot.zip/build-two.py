from pathlib import Path
import subprocess,sys,json,hashlib,time
E=Path(__file__).parent;R=Path('H:/.codex/worktrees/err/IM-platform');O=E.parent/'fix-refresh-owner'
def sha(b):return hashlib.sha256(b).hexdigest()
def js(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf8')
assert Path(subprocess.check_output(['git','rev-parse','--show-toplevel'],cwd=R,text=True).strip()).resolve()==R.resolve()
devices=subprocess.check_output(['H:/Android/platform-tools/adb.exe','devices','-l'],text=True)
assert 'emulator-' not in devices,devices
# Preserve only the explicitly adopted generated prior Fix output, byte-for-byte.
p=R/'clients/mobile/replay_pid26308.log'
if p.exists():
 b=p.read_bytes();assert b'26308' in (O/'hs_err_pid26308.log').read_bytes()
 dst=E/'prior-crash'/p.name;dst.parent.mkdir(exist_ok=True);dst.write_bytes(b);assert dst.read_bytes()==b
 js(E/'prior-crash/seal.json',dict(path=str(p),bytes=len(b),sha256=sha(b),ownership='Prior Fix generated JVM replay log PID26308; matching old hs_err immutable outside repo'))
 p.unlink()
files=[]
for root in ['clients/mobile/app/src/main','clients/mobile/app/src/androidTest']:
 for p in sorted((R/root).rglob('*')):
  if p.is_file():files.append(dict(path=p.relative_to(R).as_posix(),sha256=sha(p.read_bytes()),bytes=p.stat().st_size))
for name in ['clients/mobile/build.gradle.kts','clients/mobile/app/build.gradle.kts','clients/mobile/settings.gradle.kts','tests/clients/gui/native.py']:
 p=R/name
 if p.exists():files.append(dict(path=name,sha256=sha(p.read_bytes()),bytes=p.stat().st_size))
js(E/'android-build-inputs.json',dict(files=files,devices_before=devices,source_change=False,normal_control_count=10))
results=[]
for name,runner in [('owner','im.platform.client.ui.RefreshOwnerInstrumentation'),('errors','im.platform.client.ui.ErrorHandlingInstrumentation')]:
 cmd=[sys.executable,'-Xutf8','-B',str(R/'tests/clients/gui/native.py'),'gradle','--max-workers=1','-Dorg.gradle.jvmargs=-Xmx768m -XX:ActiveProcessorCount=2 -Dfile.encoding=UTF-8','-Pkotlin.compiler.execution.strategy=in-process','-PimSendInstrumentation='+runner,'assembleDebug','assembleDebugAndroidTest']
 start=time.monotonic();p=subprocess.run(cmd,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(E/f'build-{name}.txt').write_bytes(p.stdout)
 x=dict(argv=cmd,exit_code=p.returncode,elapsed_seconds=time.monotonic()-start,output_sha256=sha(p.stdout),output=f'build-{name}.txt');results.append(x);js(E/'build-results.json',results)
 print(json.dumps(x),flush=True);print(p.stdout.decode('utf8','replace')[-3000:],flush=True)
 if p.returncode:sys.exit(p.returncode)
 dest=E/'apks'/name;dest.mkdir(parents=True,exist_ok=True);seals={}
 for apk in [R/'clients/mobile/app/build/outputs/apk/debug/app-debug.apk',R/'clients/mobile/app/build/outputs/apk/androidTest/debug/app-debug-androidTest.apk']:
  b=apk.read_bytes();(dest/apk.name).write_bytes(b);assert (dest/apk.name).read_bytes()==b;seals[apk.name]=dict(sha256=sha(b),bytes=len(b))
 js(dest/'seals.json',dict(runner=runner,apks=seals,build_inputs_sha256=sha((E/'android-build-inputs.json').read_bytes()),expected_owner_checks=10 if name=='owner' else 'original+HTTP32+WSS21'))
 print('Sealed fresh '+name+' APKs',flush=True)
for x in files:assert sha((R/x['path']).read_bytes())==x['sha256']
print('Both exact current APK pairs built with emulator closed; source/test graph unchanged during build',flush=True)
