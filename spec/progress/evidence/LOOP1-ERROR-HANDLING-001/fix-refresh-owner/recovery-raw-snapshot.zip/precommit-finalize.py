from pathlib import Path
import shutil,json
E=Path(__file__).parent;R=Path('H:/.codex/worktrees/err/IM-platform');D=R/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-refresh-owner'
assert json.loads((E/'development.json').read_text())['exit_code']==0
for name in ['development.json','development.txt','development-first.json','development-first.txt']:shutil.copyfile(E/name,D/name)
p=R/'spec/progress/current.md';s=p.read_text();s=s.replace('actual final Development/clean committed Acceptance results follow command-history.json and final external receipt; no independent acceptance claim.','fresh final Development PASS; clean committed Acceptance/postclean follows final external receipt. Local evidence is not independent acceptance.');p.write_text(s,encoding='utf8',newline='\n')
p=D/'handoff.md';s=p.read_text();s+='\nCorrected final Development actual PASS (17.469s,exit0), exact first-failure and final outputs retained as development-first.txt/development.txt. Clean committed Acceptance/postclean/complete Recorder result follows external final receipt. No product/source/test change after current input binding.\n';p.write_text(s,encoding='utf8',newline='\n')
print('Actual final Development PASS persisted; source/test/input graph unchanged')
