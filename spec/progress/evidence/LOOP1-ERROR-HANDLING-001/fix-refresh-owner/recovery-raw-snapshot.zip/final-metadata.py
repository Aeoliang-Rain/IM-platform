from pathlib import Path
import json,hashlib,shutil,subprocess
E=Path(__file__).parent;R=Path('H:/.codex/worktrees/err/IM-platform');D=R/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-refresh-owner'
assert Path(subprocess.check_output(['git','rev-parse','--show-toplevel'],cwd=R,text=True).strip()).resolve()==R.resolve()
checks=json.loads((E/'final-static.json').read_text());assert len(checks)==4 and all(x['exit_code']==0 for x in checks)
for n in ['final-static.json',*[f'final-static-{i}.txt' for i in range(4)]]:shutil.copyfile(E/n,D/n)
handoff='''# Refresh owner local Fix candidate (2026-10-15)

Sole source Fix actor /root/recover_refresh_owner_finish recovers disappeared /root/fix_refresh_owner_retirement. Assigned and Git-resolved root H:/.codex/worktrees/err/IM-platform; branch task/LOOP1-ERROR-HANDLING-001; base27cdd93e30a72527bba9f3b0d611b13ba860e92f. Task review/S2 OPEN. Last accepted main35bd6f5f1091503f95a0282f730ed04233b0b6ea. Final newSHA/clean Acceptance/actual Gitblob binding/Recorder structural validation/sourcelease release follow the external recover-refresh-owner-finish/final-receipt.json. These are local candidate evidence, not independent Task/Gate acceptance or main synchronization.

## Actual repairs and minimality

Fresh regular27 FAIL F-EXPIRED-REFRESH-OWNER[P1] proves actual401/session_expired+credential cleanup failure sets Auth.session null while Workspace still owns authenticated state/Sync. Only Desktop ui/workspace.ts and Android ui/WorkspaceViewModel.kt differ from27;183 other production inputs unchanged. Current refresh checks matching operation+Auth owner+generation plus the actual owner.session null fact before retiring that invalidated owner. Detach Auth, existing timer/observers and authenticated projection; close old Sync once, with no second secure credential removal. Stale completion cannot retire the newer operation/generation/account.

Desktop stop now attempts old Sync.close even when actual projection listener throws, retaining one exact root or distinct AggregateError roots; refresh retains both operation/retirement failures and a final busy=false observer failure, including falsy primitives. This small literal capture is necessary because publish may fail before the existing close. Android catches Throwable at the same literal refresh consumer so Error cannot skip actual invalidated-owner retirement; NonCancellable is confined to mandatory stop after the above active/null gate. Cancellation and unknown/Error propagate after cleanup. Distinct retirement failures use standard cause/suppressed; no original failure graph is mutated. Existing known-only failure remains honest unavailable UI, no forged success or category, dependency/framework/retry/logging mechanism added.

Auth/Preferences/Repository/storage/SQL/native DB/schema/init/transactions/all writes/Composer/drafts are unchanged from27.65 protected inputs exact27:63 whole accepted baseline plus two earlier Human contiguous READ-mapper exceptions, with SELECT SQL and all other Repository bytes unchanged. Current Fix makes no additional READ/storage exception. Frozen/approved ADR/contracts/security/ACK/compatibility/invariants unchanged.

## Actual verification and limits

Prior Fix Desktop strict compile, strengthened37 original parallel controls, new12 actual compiled Auth/Workspace controls and original Auth controls are qualified historical reuse, not new runs. Current185 hashes equal the prior post-edit input preview; old command starts24/26/28/46 and exact raw outputs/compiled graph are preserved in prior-fix-partial-raw.zip and rebound by runtime-source-bindings.json. Tests prove exact primary/cleanup roots, falsy/unknown/observer+finally roots, close once/timer stopped/no double-remove, three active gates and normal existing bind. No additional Desktop source change since those observations.

New actual Android build commands use bundled Python tests/clients/gui/native.py gradle --max-workers=1 '-Dorg.gradle.jvmargs=-Xmx768m -XX:ActiveProcessorCount=2 -Dfile.encoding=UTF-8' -Pkotlin.compiler.execution.strategy=in-process -PimSendInstrumentation=<runner> assembleDebug assembleDebugAndroidTest, once for im.platform.client.ui.RefreshOwnerInstrumentation then im.platform.client.ui.ErrorHandlingInstrumentation. Both build while the proven own emulator is closed;14.844s/8.875s exits0, runner-specific APK bytes/SHA and current full main/androidTest/build config input graph preserved externally and in *-apk-seals.json/android-build-inputs.json.

Actual exclusively owned API34 emulator5612 runs `adb -s emulator-5612 shell am instrument -w im.platform.client.test/im.platform.client.ui.RefreshOwnerInstrumentation`: checks=10/result=PASS/sdkInt=34/INSTRUMENTATION_CODE:-1. Nine original owner controls retain all assertions; added tenth verifies actual Auth.refresh normal token rotation with actual secure Preferences, no removal. Current Workspace/Auth/actual Preferences and existing Sync/Send exercise authenticated projection/owner/socket closed once, timer/observers cancelled, known/unknown/Error/close, three stale gates and real cancellation. Controlled HTTP and secure commit producers prove real Android boundary semantics, not default-provider incidence or real server/TLS credential failure.

Same current input graph and separately sealed errors APK runs original ErrorHandlingInstrumentation: result=PASS/httpCleanupChecks=32/wssCleanupChecks=21/sdkInt=34/code:-1. All original assertions retained. Earlier actual Send66+Read21/Sync69+Read33+contiguous18 remain qualified historical unchanged responsibility graphs; not newly observed here or full Go durable-ACK/installed GUI acceptance. No visual/layout change.

Fresh final tools/verify_frozen_architecture.py, ci/check_architecture.py --scope all --json, ci/check_s2_planning.py and82 tests/architecture PASS (one pre-existing Windows skip), exact argv/exit/time/output in final-static.json. Development and clean committed Acceptance/postclean results are bound by command-history.json and final external receipt. Local/Recorder results do not establish independent acceptance.

## Preserved failures and cleanup

Old R-FIX-REFRESH-OWNER remains raw immutable partial: lastseq60 command_started build-two.py, actual old exit unavailable. Old OOM/mmap/malloc/argument split/SyntaxError and controlled native9 outputs preserved; no old9APK promoted to10. Old raw/captured stdout redaction hashes are distinguished from stored blob hashes. New first install failed debug signature mismatch; only two disposable fixture packages on proven own5612 uninstalled then sealed APKs installed. Owner actual bundle10 PASS was followed by external collector FAIL because it expected println in am stdout; println belongs to device logcat. Corrected only collector to bind existing actual count/result/sdk/code, then ran remaining errors. No production/test assertion weakened or unnecessary owner rerun. One direct launcher path typo failed before Recorder started child; disclosed as a direct trace gap.

Own5612 closed, qemu absence verified, reverse/devices empty; only receipt-proven AVD removed after exact resolved-path checks. First deletion WinError5 on own pstore.bin retained; only its Windows readonly attribute33 cleared, never ACL/trust. Generated build/.gradle preserved externally. Only the adb daemon proved newly started by recovery query stopped. No private device/data/global trust/ACL/main write. Main782unknown/two tracked edits untouched.

## Current bindings and independent next action

185 current production input hashes;323 distinct composite ordinal/path/ID navigation records=288 executable+35 nonexecutable, never323 catches. Prior318 identities preserved plus five current necessary lifecycle catches; duplicate RH294 identities remain distinct. All actual source tokens/line/column/hash and inventory fault→present authority→actual recovery agree.22 actual factual grounds corrected in both current navigation and inventory: native header/menu/enum and translation display cases are distinct; Android Sync wire coercion/parser/overflow is protocol rejection; approved shared contiguous READ absent-row mapper is RETAINED_ABSENT_ROW_ONLY, not excluded unchanged. No inherited semantic-review PASS. Full new independent semantic reviews remain mandatory.

Original regular27 receipt SHAa8df4b6fe9ba3147bce44f2646d56aafd7199dc3bf92a7cf35918e16b50818fa and all211 artifacts remain byte-exact in original external directory and regular-review-27-originals.zip; per-entry SHA/bytes and archive GitOID separately bind reconstruction. Old318 metadata Gitblob OIDs/bytes are in prior-318-candidate-metadata.zip. Prior Fix raw/helpers/compiled graph sealed in prior-fix-partial-raw.zip without editing/finishing that run. Old50MB full diff is archived original once, no recursive new full diff regeneration.

New R-RECOVER-REFRESH-OWNER-FINISH prospective_resume parentR-ERROR-INTEGRATION-COORD-20261013 relatedR-FIX-REFRESH-OWNER; direct startup/inspection/external helper preparation and truncated-authority-read gaps disclosed, no complete prospective trace or hidden-fact reconstruction. Repo command-history/snapshot is bounded before own final finish; final complete run remains external and sealed after commit. Recorder validation only verifies structure.

Coordinator next: NEW fresh complete regular185/323/65 on clean finalSHA, then DIFFERENT NEW uninvolved specialized error review SAMEfinalSHA. Any Fix repeats both. Both PASS before push/CI-triggeringPR; then applicable actual exact-head required hostedCI/protectedintegration/actual-main verification/safe H:/IM-platform sync. Taskdone/S2PASS/mainSHA/synchronization all PENDING. Sourcelease RELEASED only after final clean sealed receipt. No acceptance performed by this Fix.
'''
(D/'handoff.md').write_text(handoff,encoding='utf8',newline='\n')
p=R/'spec/tasks/review/LOOP1-ERROR-HANDLING-001.md';s=p.read_text(encoding='utf-8-sig');a=s.index('# Current refresh owner recovery (2026-10-15)');b=s.index('# Historical pre-27 recovery handoff',a);s=s[:a]+'# Current refresh owner recovery (2026-10-15)\n\n'+handoff.split('\n',2)[2]+'\n'+s[b:];p.write_text(s,encoding='utf8',newline='\n')
checkpoint='''# Local refresh owner recovery candidate — 2026-10-15

Task LOOP1-ERROR-HANDLING-001 remains review/S2 OPEN. Last accepted main35bd6f5f1091503f95a0282f730ed04233b0b6ea. Branch task/LOOP1-ERROR-HANDLING-001, base27cdd93e30a72527bba9f3b0d611b13ba860e92f; clean newSHA from final external recover-refresh-owner-finish/final-receipt.json. This is a stable local recovery checkpoint, not Task/Gate acceptance or main sync.

Current two Workspace refresh-owner retirement repairs;185 inputs/323 navigation(288 executable35 nonexecutable)/65 exact protected/22 corrected retained grounds. Old211 review and old318 metadata/partial Fix raw immutable; actual owner10 and originalErrors/HTTP32/WSS21 API34/5612 PASS, Desktop37/12 qualified historical current graph. New source/test/native exact seals and failures/cleanup in spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-refresh-owner/handoff.md. Frozen canonical efbe04c7 and historicalPDF546915 unchanged; no contract/migration/schema/ACK/security change.

Only new regular finalSHA then different new specialized SAMEfinalSHA may precede exacthead hostedCI/protectedintegration/actual-main/safe main synchronization. All independent acceptance/main synchronization pending; no done/S2PASS. Main782unknown/two tracked edits preserved. Sourcelease released only by final clean external receipt.
'''
(R/'spec/progress/checkpoints/2026-10-15-error-handling-refresh-owner-review-candidate.md').write_text(checkpoint,encoding='utf8',newline='\n')
(R/'spec/progress/current.md').write_text('''# Current Execution State

Current Loop: Loop 1
Current Stage: S2
Current Gate: S2
Gate Status: OPEN
Current Batch: LOOP1-ERROR-HANDLING-001
Batch Status: REVIEW_PENDING
Current Task: LOOP1-ERROR-HANDLING-001
Current Task State: review
Execution Status: AWAITING_NEW_FINAL_SHA_REGULAR_REVIEW_AND_SPECIALIZED_AUDIT

## Immediately Relevant Completed Work

Recovered interrupted refresh-owner Fix after regular27cdd93 FAIL. Two Workspace production changes retire the actual invalidated active owner, preserve refresh/retirement/observer roots and avoid credential retry. Current185/323(288 executable35 nonexecutable)/65 exact protected and22 retained-ground corrections verified. Full history/limits: spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-refresh-owner/handoff.md.

## Current Blockers

NEW full regular finalSHA then DIFFERENT NEW specialized SAMEfinalSHA PENDING. Exact-head hostedCI/protectedintegration/actual-main/safe H:/IM-platform synchronization PENDING. No push/CI-triggeringPR before both reviews PASS. Taskdone/S2PASS forbidden; local proof is not acceptance.

## Verification

- Command: `python -Xutf8 -B tools/verify_frozen_architecture.py`
  - Result: fresh final frozen/PDF/architectureall/planning/82architecturetests PASS, one existing Windows skip. Exact results in final-static.json; local only.
  - Evidence: `spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-refresh-owner/final-static.json`
- Command: `pwsh -NoProfile -File tools/verify-loop1-ctrl-002.ps1 -Mode Development`
  - Result: actual final Development/clean committed Acceptance results follow command-history.json and final external receipt; no independent acceptance claim.
  - Evidence: `spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-refresh-owner/handoff.md`
- New actual API34/5612 owner10 plus originalErrors/HTTP32/WSS21 PASS, exact sealedAPK/current input graph. Desktop strictcompile/strengthened37/owner12/originalAuth are qualified prior current-graph observations; Send66+Read21/Sync69+Read33+contiguous18 qualified unchanged runtime reuse, never new execution.

## Changed Files or Migrations

Relative27cdd93 only Desktop ui/workspace.ts and Android ui/WorkspaceViewModel.kt production;183 others unchanged. Focused tests/evidence/recovery metadata only.65 protected exact27:63 whole accepted base plus two earlier Human contiguous READ-mapper exceptions; SQL/all other Repository bytes unchanged. No Auth/Preferences/storage/nativeDB/SQL/write/Composer/draft/Frozen/ADR/contracts/security/ACK/dependency change in this Fix.

## Known Failures, Risks, and Assumptions

Old R-FIX-REFRESH-OWNER immutable partial,lastseq60 build-two.py outcome unavailable. New install signature mismatch resolved only on disposable own fixture packages; owner actual10PASS collector stdout assumption failed then corrected without test/product change. Cleanup readonly own pstore leaf retry changed only Windows readonly attribute, no ACL/trust. All old OOM/argument/SyntaxError and new raw failures retained. Startup/direct/truncated-read/helper gaps disclosed. No full scope independent semantic acceptance or default-provider incidence claimed.

## Next Exact Action

Coordinator receives clean finalSHA/sealedreceipt/sourcelease RELEASED. NEW full fresh regular185/323/65 -> DIFFERENT NEW specialized SAMEfinalSHA; any Fix repeats both. BothPASS then exacthead required hostedCI/protectedintegration/actual-main/safe main sync. All Taskdone/S2PASS/main synchronization PENDING.

## Last Known Good Commit

`35bd6f5f1091503f95a0282f730ed04233b0b6ea` accepted I18N/main. Final task SHA is exact committed Git HEAD in final external receipt; candidate commit is not main acceptance or sync.

## Latest Checkpoint

`spec/progress/checkpoints/2026-10-15-error-handling-refresh-owner-review-candidate.md` local stable recovery only.

## Uncommitted Changes / Ownership

Sole /root/recover_refresh_owner_finish owns exact known-owned assigned task delta until clean commit/releasedreceipt. Root H:/.codex/worktrees/err/IM-platform, branch task/LOOP1-ERROR-HANDLING-001. Main H:/IM-platform782unknown/two tracked edits untouched. Own5612/qemu/reverse/AVD/newqueryadb closed; generated build/.gradle/crash outputs preserved externally. No private device/globaltrust/ACL/main write.

## Architecture Conflicts / ACP / ADR

None. Existing authorized TypeScript/Kotlin and current lifecycle cleanup only. Both final reviews/CI/integration/main/sync PENDING; S2 OPEN.
''',encoding='utf8',newline='\n')
print('Final local handoff/current/Task/checkpoint updated truthfully; both new reviews and all hosted/integration/main/sync pending')
