from pathlib import Path
import subprocess,sys,time,json,hashlib
E=Path(__file__).parent;R=Path('H:/.codex/worktrees/err/IM-platform')
commands=[[sys.executable,'-Xutf8','-B','tools/verify_frozen_architecture.py'],[sys.executable,'-Xutf8','-B','ci/check_architecture.py','--scope','all','--json'],[sys.executable,'-Xutf8','-B','ci/check_s2_planning.py'],[sys.executable,'-Xutf8','-B','-m','unittest','discover','-s','tests/architecture','-v']]
results=[]
for i,c in enumerate(commands):
 t=time.monotonic();p=subprocess.run([sys.executable,'-Xutf8','-B',str(E/'run.py'),*c],cwd=R,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(E/f'final-static-{i}.txt').write_bytes(p.stdout);v=dict(argv=c,exit_code=p.returncode,elapsed_seconds=time.monotonic()-t,output=f'final-static-{i}.txt',stored_output_sha256=hashlib.sha256(p.stdout).hexdigest());results.append(v);(E/'final-static.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(v),flush=True);print(p.stdout.decode('utf8','replace')[-1200:],flush=True)
 if p.returncode:sys.exit(p.returncode)
