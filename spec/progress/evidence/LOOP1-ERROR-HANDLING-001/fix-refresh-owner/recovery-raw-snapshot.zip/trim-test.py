from pathlib import Path
import hashlib,json
E=Path(__file__).parent;R=Path('H:/.codex/worktrees/err/IM-platform');O=E.parent/'fix-refresh-owner';D=R/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-refresh-owner'
p=R/'tests/clients/errors/desktop_owner_retirement.mjs';b=p.read_bytes();old=(O/'desktop_owner_retirement.mjs').read_bytes();assert b==old
new=b.rstrip()+b'\n';assert b.split()==new.split();p.write_bytes(new)
proof=dict(original_sha256=hashlib.sha256(b).hexdigest(),current_sha256=hashlib.sha256(new).hexdigest(),original_bytes=len(b),current_bytes=len(new),only_trailing_whitespace_changed=True,token_sequence_equal=True,original_source='prior-fix-partial-raw.zip::desktop_owner_retirement.mjs',cause='Scoped staged whitespace failed on original last-line CR; product and test assertions unchanged.')
(D/'test-format-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
p=D/'runtime-source-bindings.json';x=json.loads(p.read_text());x['desktop_qualified_historical_reuse']['test_format_only']=proof;p.write_text(json.dumps(x,indent=2)+'\n')
p=D/'handoff.md';s=p.read_text();s+='\nPrecommit actual staged Gitblob equality PASS, then scoped whitespace failed on the new Desktop owner test final-line CR. Trimmed only trailing whitespace; token sequence equals sealed original, all assertions/product unchanged. Original raw failure and original source bytes retained; focused owner12 rerun follows command history.\n';p.write_text(s,encoding='utf8',newline='\n')
print('Trimmed only test EOF whitespace; exact original source archived, token sequence unchanged')
