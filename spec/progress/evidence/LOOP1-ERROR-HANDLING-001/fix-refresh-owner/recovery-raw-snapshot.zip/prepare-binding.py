from pathlib import Path
import json,hashlib,subprocess,zipfile,shutil
E=Path(__file__).parent;O=E.parent/'fix-refresh-owner';V=E.parent/'regular-review-27cdd93';R=Path('H:/.codex/worktrees/err/IM-platform');D=R/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-refresh-owner';B='27cdd93e30a72527bba9f3b0d611b13ba860e92f'
def sha(b):return hashlib.sha256(b).hexdigest()
def js(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
assert Path(subprocess.check_output(['git','rev-parse','--show-toplevel'],cwd=R,text=True).strip()).resolve()==R.resolve()
receipt_bytes=(V/'final-receipt.json').read_bytes();assert sha(receipt_bytes)=='a8df4b6fe9ba3147bce44f2646d56aafd7199dc3bf92a7cf35918e16b50818fa';receipt=json.loads(receipt_bytes);assert len(receipt['artifacts'])==211
for x in receipt['artifacts']:
 b=(V/x['path']).read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256']
archive=O/'regular-review-27-originals.zip';entries=[]
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==212
 for x in receipt['artifacts']:
  b=z.read(x['path']);assert len(b)==x['bytes'] and sha(b)==x['sha256'];entries.append(dict(path=x['path'],bytes=len(b),sha256=sha(b)))
 assert z.read('final-receipt.json')==receipt_bytes
 entries.append(dict(path='final-receipt.json',bytes=len(receipt_bytes),sha256=sha(receipt_bytes)))
D.mkdir(exist_ok=True);shutil.copyfile(archive,D/archive.name);assert (D/archive.name).read_bytes()==archive.read_bytes();js(D/'prior-review-seals.json',dict(receipt_sha256=sha(receipt_bytes),candidate=B,artifacts211_verified=True,archive_sha256=sha(archive.read_bytes()),archive_bytes=archive.stat().st_size,entries=entries,meaning='Original211 artifacts plus receipt ZIP-byte exact; each entry is reconstructable original bytes. ZIP GitOID is separate; entries are not individually claimed Git blobs. No inherited review PASS.'))
# Preserve prior318 candidate metadata exactly from Git, including inventory; no recursive full diff.
meta=[]
with zipfile.ZipFile(D/'prior-318-candidate-metadata.zip','w',zipfile.ZIP_DEFLATED) as z:
 for rel in ['spec/progress/evidence/LOOP1-ERROR-HANDLING-001/production-inventory.json','spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-android-wss-cleanup/current-navigation.json']:
  b=subprocess.check_output(['git','show',B+':'+rel],cwd=R);oid=subprocess.check_output(['git','rev-parse',B+':'+rel],cwd=R,text=True).strip();z.writestr(rel,b);meta.append(dict(path=rel,sha256=sha(b),bytes=len(b),original_git_blob_oid=oid))
js(D/'prior-318-metadata-seals.json',dict(candidate=B,entries=meta,archive_sha256=sha((D/'prior-318-candidate-metadata.zip').read_bytes())))
# Old interrupted raw is immutable; archive exact raw, helpers, controlled outputs and compiled Desktop graph.
oldfiles=[]
for p in O.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(O)
 if rel.parts[0] in ['android-user','avds','android-expiry'] or p.name=='regular-review-27-originals.zip':continue
 if rel.parts[0]=='desktop-build' or rel.parts[0]=='research' or len(rel.parts)==1:oldfiles.append((rel.as_posix(),p))
oldseals=[]
with zipfile.ZipFile(D/'prior-fix-partial-raw.zip','w',zipfile.ZIP_DEFLATED) as z:
 for rel,p in sorted(oldfiles):
  b=p.read_bytes();z.writestr(rel,b);oldseals.append(dict(path=rel,bytes=len(b),sha256=sha(b)))
with zipfile.ZipFile(D/'prior-fix-partial-raw.zip') as z:
 for x in oldseals:assert sha(z.read(x['path']))==x['sha256']
events=[json.loads(s) for s in (O/'research/runs/R-FIX-REFRESH-OWNER/events.jsonl').read_text().splitlines()];assert events[-1]['seq']==60 and events[-1]['event_type']=='command_started'
js(D/'prior-fix-partial-seals.json',dict(run_id='R-FIX-REFRESH-OWNER',status='IMMUTABLE_PARTIAL',last_sequence=60,last_event_type='command_started',last_command_exit='unavailable',archive_sha256=sha((D/'prior-fix-partial-raw.zip').read_bytes()),entries=oldseals))
nav=json.loads((O/'current-navigation.json').read_text());inv=json.loads((O/'production-inventory.json').read_text());protected=json.loads((O/'protected-inputs.json').read_text());corrections=json.loads((V/'ground-corrections.json').read_text());assert len(corrections)==22
for c in corrections:
 n=next(x for x in nav['records'] if x['composite_identity']==c['composite_identity']);assert n['source_sha256']==c['source_sha256']
 for k,v in c['independent_correction'].items():assert n[k]==v,(n['id'],k)
 # Bind/rejudge current semantics against actual source, preserving supplied old wrong grounds in original ZIP.
 b=(R/n['path']).read_bytes();assert sha(b)==n['source_sha256'] and b.decode().splitlines()[n['line']-1]==n['source']
g='Frozen Architecture §6.1 account isolation and §7.1 Session lifecycle; approved ADR-0009 credential lifecycle ownership; spec/governance/error-handling.md mandatory cleanup and original unknown-root propagation'
for n in nav['records']:
 if n['path'] in ['clients/desktop/src/application/ui/workspace.ts','clients/mobile/app/src/main/kotlin/im/platform/client/ui/WorkspaceViewModel.kt'] and ('Actual refresh invalidates' in n['specific_fault'] or n['original_ordinal']>=319):n['present_authority']=g
 if n['original_ordinal']==319:n['specific_fault']='Actual Workspace session=null publication listener throws during retirement after the owner/timer are detached'
 if n['original_ordinal']==320:n['specific_fault']='Actual old Sync.close rejects while retirement already has zero or one distinct projection-listener failure'
 if n['original_ordinal']==322:n['specific_fault']='Actual final busy=false publication listener throws, either alone or after an existing refresh/retirement failure'
 if 'historical_navigation_reference' in n:n['historical_navigation_reference']='spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-android-wss-cleanup/'+n['historical_navigation_reference']
 n['current_candidate_binding']='Final clean committed task HEAD through external recover-refresh-owner-finish/final-receipt.json; fresh regular and different fresh specialized finalSHA reviews PENDING'
 s=inv['retained_sites'][n['original_ordinal']-1]
 for k in ['specific_fault','present_authority','actual_recovery_or_failure']:s[k]=n[k]
 s['authority']=n['present_authority'];s['specific_ground_and_recovery']=' → '.join(n[k] for k in ['specific_fault','present_authority','actual_recovery_or_failure'])
 for k in ['path','line','column','source_sha256']:assert s[k]==n[k]
 assert s['actual_source']==n['source']
 b=(R/n['path']).read_bytes();assert sha(b)==n['source_sha256'];line=b.decode().splitlines()[n['line']-1];assert line==n['source'] and line[n['column']-1:].startswith(n['token'])
assert len(nav['records'])==323 and len({n['composite_identity'] for n in nav['records']})==323
assert sum(n['executable'] for n in nav['records'])==288 and len(inv['files'])==185 and len(protected['files'])==65
changed=[]
for f in inv['files']:
 b=(R/f['path']).read_bytes();assert sha(b)==f['sha256']
 if b!=subprocess.check_output(['git','show',B+':'+f['path']],cwd=R):changed.append(f['path'])
assert sorted(changed)==sorted(['clients/desktop/src/application/ui/workspace.ts','clients/mobile/app/src/main/kotlin/im/platform/client/ui/WorkspaceViewModel.kt'])
for f in protected['files']:
 b=(R/f['path']).read_bytes();assert sha(b)==f['sha256'] and b==subprocess.check_output(['git','show',B+':'+f['path']],cwd=R)
inv['candidate_binding']='Current clean committed task HEAD through external recover-refresh-owner-finish final receipt; final independent regular/specialized PENDING'
inv['fix_refresh_owner']['current_navigation']='spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-refresh-owner/current-navigation.json';inv['fix_refresh_owner']['local_not_acceptance']=True
js(D/'current-navigation.json',nav);js(D.parent/'production-inventory.json',inv);js(D/'protected-inputs.json',protected);js(D/'ground-corrections22.json',corrections)
js(D/'input-checks.json',dict(production185=True,navigation=dict(records=323,executable=288,nonexecutable=35),protected65_exact27=True,only2_production_delta_from27=changed,grounds22_corrected_in_both_current_navigation_and_inventory=True,prior211_original_seals_verified=True,old318_git_bytes_preserved=True,independent_whole_scope_semantic_acceptance=False))
# Historical Send/Sync graph reuse remains narrowly qualified; current Workspace/Auth consumer runs are fresh above.
prior=json.loads((D.parent/'fix-android-wss-cleanup/runtime-source-bindings.json').read_text());reuse=[]
for f in prior['unchanged_send_sync_inputs']:
 assert sha((R/f['path']).read_bytes())==f['sha256'];reuse.append(f)
# Bind actual old green Desktop commands and unchanged inputs; compile/37/12 are historical observations, never fresh runtime.
starts={v['data']['command_id']:v for v in events if v['event_type']=='command_started'};observed=[]
for v in events:
 if v['event_type']!='command_finished':continue
 s=starts[v['data']['command_id']]
 if s['seq'] in [24,26,28,46]:
  assert v['data']['exit_code']==0;observed.append(dict(start=s,finish=v))
assert len(observed)==4
assert (R/'tests/clients/errors/desktop_owner_retirement.mjs').read_bytes()==(O/'desktop_owner_retirement.mjs').read_bytes()
js(D/'runtime-source-bindings.json',dict(desktop_qualified_historical_reuse=dict(observed_commands=observed,current185_preview_sha256=sha((O/'production-inventory.json').read_bytes()),compiled_graph_archive='prior-fix-partial-raw.zip::desktop-build/',qualification='Prior Fix compiled after the actual two Workspace changes, then ran strengthened37/owner12/originalAuth controls; current production185 bytes match prior post-edit preview and no new source change. These are historical local observations, not new execution or independent acceptance.'),unchanged_send_sync_inputs=reuse,send_sync_qualification='Prior actual Send66+Read21/Sync69+Read33+contiguous18 remain unchanged responsibility graphs; no new native run claimed. Current Workspace owner10 and original errors/HTTP32/WSS21 are newly observed on own API34/5612 with exact APK/input graph.',fresh_android_build_inputs_sha256=sha((E/'android-build-inputs.json').read_bytes())))
for name in ['android-build-inputs.json','build-results.json','build-owner.txt','build-errors.txt','native-results.json','native-owner.txt','native-errors.txt','emulator-receipt.json','runtime-cleanup.json','owned-avd-config.ini','owned-avd-registration.ini','cleanup-process-check.txt']:
 shutil.copyfile(E/name,D/name)
for name in ['owner','errors']:
 shutil.copyfile(E/'apks'/name/'seals.json',D/(name+'-apk-seals.json'))
print('Bound current185/323(288exec35nonexec)/65 exact27,22 factual grounds/current inventory, immutable211+old318+partialraw and qualified runtime graphs')
