from pathlib import Path
import json,hashlib,subprocess,sys
R=Path('H:/.codex/worktrees/err/IM-platform');E=Path(__file__).parent;D=R/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-refresh-owner'
B='27cdd93e30a72527bba9f3b0d611b13ba860e92f'
def git(*args):return subprocess.check_output(['git','-c','core.excludesFile=.git/info/exclude',*args],cwd=R)
def sha(b):return hashlib.sha256(b).hexdigest()
assert Path(git('rev-parse','--show-toplevel').decode().strip()).resolve()==R.resolve()
assert git('branch','--show-current').decode().strip()=='task/LOOP1-ERROR-HANDLING-001' and git('rev-parse','HEAD').decode().strip()==B
staged_before=set(filter(None,git('diff','--cached','--name-only','-z').decode().split('\0')))
owned=[
'clients/desktop/src/application/ui/workspace.ts',
'clients/mobile/app/src/main/kotlin/im/platform/client/ui/WorkspaceViewModel.kt',
'clients/mobile/app/src/androidTest/kotlin/im/platform/client/ui/RefreshOwnerInstrumentation.kt',
'tests/clients/errors/desktop_parallel.mjs',
'tests/clients/errors/desktop_owner_retirement.mjs',
'spec/progress/current.md',
'spec/tasks/review/LOOP1-ERROR-HANDLING-001.md',
'spec/progress/checkpoints/2026-10-15-error-handling-refresh-owner-review-candidate.md',
'spec/progress/evidence/LOOP1-ERROR-HANDLING-001/production-inventory.json',
]
owned+=sorted(p.relative_to(R).as_posix() for p in D.rglob('*') if p.is_file())
assert staged_before.issubset(set(owned)),staged_before-set(owned)
status=git('status','--porcelain=v1','-z','--untracked-files=all');actual=[]
for entry in status.split(b'\0'):
 if not entry:continue
 assert entry[:2] in [b' M',b'??',b'M ',b'A ',b'MM',b'AM'],entry
 actual.append(entry[3:].decode())
assert set(actual)==set(owned),(set(actual)-set(owned),set(owned)-set(actual))
nav=json.loads((D/'current-navigation.json').read_text());inv=json.loads((D.parent/'production-inventory.json').read_text());assert len(nav['records'])==323 and len(inv['files'])==185
for f in inv['files']:assert sha((R/f['path']).read_bytes())==f['sha256']
for n in nav['records']:
 b=(R/n['path']).read_bytes();assert sha(b)==n['source_sha256'];assert b.decode().splitlines()[n['line']-1]==n['source'];assert n['source'][n['column']-1:].startswith(n['token'])
for f in json.loads((D/'protected-inputs.json').read_text())['files']:assert sha((R/f['path']).read_bytes())==f['sha256'] and (R/f['path']).read_bytes()==git('show',B+':'+f['path'])
subprocess.run(['git','-c','core.autocrlf=false','-c','core.excludesFile=.git/info/exclude','add','--',*owned],cwd=R,check=True)
staged=git('diff','--cached','--name-only','-z').decode().split('\0');assert set(filter(None,staged))==set(owned)
blobs=[]
for rel in owned:
 b=(R/rel).read_bytes();oid=git('rev-parse',':'+rel).decode().strip();actual_blob=git('cat-file','blob',oid);assert actual_blob==b,rel
 blobs.append(dict(path=rel,sha256=sha(b),bytes=len(b),git_blob_oid=oid))
audit=dict(assigned_root=str(R),branch='task/LOOP1-ERROR-HANDLING-001',base=B,owned_path_count=len(owned),all_staged_git_blobs_equal_exact_working_bytes=True,files=blobs)
(E/'staged-blob-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
# Scoped text whitespace excludes immutable raw outputs. Raw source/evidence bytes stay exact.
textpaths=[p for p in owned if p.endswith(('.ts','.kt','.mjs','.md'))]
subprocess.run(['git','diff','--cached','--check','--',*textpaths],cwd=R,check=True)
subprocess.run(['git','-c','core.excludesFile=.git/info/exclude','commit','-m','Retire invalidated refresh owners and correct retained grounds'],cwd=R,check=True)
head=git('rev-parse','HEAD').decode().strip();assert head!=B
assert not git('status','--porcelain=v1','--untracked-files=all').strip()
for f in blobs:assert git('rev-parse',head+':'+f['path']).decode().strip()==f['git_blob_oid'] and git('cat-file','blob',f['git_blob_oid'])==(R/f['path']).read_bytes()
audit['committed_sha']=head;audit['committed_clean']=True;(E/'committed-blob-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
print('CLEAN_LOCAL_CANDIDATE_SHA='+head,flush=True);print('Exact owned '+str(len(owned))+' staged/committed Gitblob byte equality PASS; independent reviews/CI/main sync still pending',flush=True)
