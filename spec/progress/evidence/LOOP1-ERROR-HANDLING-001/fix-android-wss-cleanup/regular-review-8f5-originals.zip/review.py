from pathlib import Path
import sys,hashlib,json,subprocess,re
root=Path('H:/.codex/worktrees/err/IM-platform')
mode=sys.argv[1]
if mode=='read':
 for name in sys.argv[2:]:
  p=root/name
  print('\nFILE '+name+' SHA256 '+hashlib.sha256(p.read_bytes()).hexdigest())
  print(p.read_text(encoding='utf-8'))
elif mode=='frozen':
 for n in ['spec/architecture/frozen-architecture.md','scalable-distributed-im-architecture.pdf']:
  print(n,hashlib.sha256((root/n).read_bytes()).hexdigest())
 text=(root/'spec/architecture/frozen-architecture.md').read_text(encoding='utf8')
 for a,b in [('2','4'),('5','8'),('10','15'),('18','19'),('21','appendix-a')]:
  start=text.index('<a id="section-'+a+'">')
  end=text.index('<a id="'+('section-' if b!='appendix-a' else '')+b+'">',start)
  print(text[start:end])
elif mode=='list':
 for glob in sys.argv[2:]:
  for p in sorted(root.glob(glob)):
   if p.is_file(): print(p.relative_to(root).as_posix())
elif mode=='section':
 t=(root/'spec/architecture/frozen-architecture.md').read_text(encoding='utf8')
 for a,b in zip(sys.argv[2::2],sys.argv[3::2]):
  print(t[t.index('<a id="section-'+a+'">'):t.index('<a id="section-'+b+'">')])
