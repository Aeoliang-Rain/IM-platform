from pathlib import Path
import subprocess,hashlib,json,re
R=Path('H:/.codex/worktrees/err/IM-platform');E=Path(__file__).parent
head='8f5f2b4275652d8e3fdff343d6a286ac805ad14a';base='35bd6f5f1091503f95a0282f730ed04233b0b6ea';prev='a337780de5f2ab5d2c8cd43d93c66dac06d53a53'
def git(*a):return subprocess.check_output(['git','-c','core.excludesFile=.git/info/exclude',*a],cwd=R)
def blob(ref,path):
 row=git('ls-tree',ref,'--',path).decode().strip();oid=row.split()[2];return git('cat-file','blob',oid)
def sha(b):return hashlib.sha256(b).hexdigest()
inv=json.loads((R/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001/production-inventory.json').read_text());checks=[]
for f in inv['files']:
 b=blob(head,f['path']);assert sha(b)==f['sha256'],f['path'];assert (R/f['path']).read_bytes()==b,f['path'];checks.append({'path':f['path'],'sha256':sha(b),'semantic_review_complete':False})
protect=json.loads((R/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-android-suppressed/protected-inputs.json').read_text());ps=[]
exceptions={'clients/shared/protocol-sdk/src/storage/repository.ts':('  async contiguous(','  async conversationIds('),'clients/mobile/app/src/main/kotlin/im/platform/client/storage/Repository.kt':('    fun contiguous(','    fun conversationIds(')}
for f in protect['files']:
 p=f['path'];b=blob(head,p);assert sha(b)==f['sha256'];assert b==blob(prev,p)
 bb=blob(base,p)
 if p not in exceptions:assert b==bb,p
 else:
  start,end=map(str.encode,exceptions[p]);before,rest=b.split(start,1);method,after=rest.split(end,1);oldbefore,oldrest=bb.split(start,1);oldmethod,oldafter=oldrest.split(end,1);assert before==oldbefore and after==oldafter,p
  sql=lambda x:re.findall(rb'"SELECT[^"\n]*"',x)
  assert sql(method)==sql(oldmethod),p
 ps.append({'path':p,'sha256':sha(b),'whole_equal_pre_fix':True,'whole_equal_baseline':p not in exceptions,'only_contiguous_read_and_identical_SQL':p in exceptions})
nav=json.loads((R/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-android-suppressed/current-navigation.json').read_text());keys=[x.get('composite_identity',x.get('composite_key')) for x in nav['records']];assert len(keys)==311 and len(set(keys))==311
result={'candidate':head,'root':str(R),'production185_hash_and_Gitblob_checkout_binding':len(checks),'navigation_composite_identities':len(keys),'navigation_semantics_complete':False,'protected65':ps,'whole_scope_semantics_complete':False,'inventory':checks}
(E/'input-binding.json').write_text(json.dumps(result,indent=2),encoding='utf8');(E/'full-diff.patch').write_bytes(git('diff','--no-ext-diff','--no-renames',base,head));(E/'post-status.txt').write_bytes(git('status','--porcelain=v1'));assert not git('status','--porcelain=v1')
print('Independent 185 production Gitblobs/worktree/inventory equal; 65 preFix equal; 63 wholebaseline + 2 exactly READ method-only/sameSQL; 311 unique composite identities. These are bindings, not full semantic review. Exact candidate clean.')
