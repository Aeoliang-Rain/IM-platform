import subprocess,sys,json,time,os
from pathlib import Path
r=Path('H:/.codex/worktrees/err/IM-platform'); e=Path(__file__).parent
py=sys.executable
commands=[[py,'-Xutf8','-B','tools/verify_frozen_architecture.py'],[py,'-Xutf8','-B','ci/check_architecture.py','--scope','all','--json'],[py,'-Xutf8','-B','ci/check_s2_planning.py'],[py,'-Xutf8','-B','-m','unittest','discover','-s','tests/architecture','-v']]
results=[]
for i,c in enumerate(commands):
 t=time.monotonic(); p=subprocess.run([py,'-Xutf8','-B','tools/research/recorder.py','run-command','--research-root',str(e/'research'),'--run-id','R-REGULAR-8F5F2B4','--',*c],cwd=r,capture_output=True)
 (e/f'baseline-{i}.txt').write_bytes(p.stdout+p.stderr)
 results.append({'argv':c,'exit':p.returncode,'seconds':time.monotonic()-t})
 print(json.dumps(results[-1]),flush=True)
(e/'baseline.json').write_text(json.dumps(results,indent=2),encoding='utf8')
sys.exit(any(x['exit'] for x in results))
