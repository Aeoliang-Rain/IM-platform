from pathlib import Path
import json,subprocess,hashlib
R=Path('H:/.codex/worktrees/err/IM-platform');E=Path(__file__).parent
for f in ['spec/progress/evidence/LOOP1-ERROR-HANDLING-001/production-inventory.json','spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-android-suppressed/input-checks.json','spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-android-suppressed/protected-inputs.json']:
 p=R/f
 if p.exists():
  d=json.loads(p.read_text());print(f, list(d) if isinstance(d,dict) else 'list '+str(len(d)));print(json.dumps(d,ensure_ascii=False)[:2000])
n=json.loads((R/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-android-suppressed/current-navigation.json').read_text())
for e in n['records']:
 if e['path'].endswith('/Wss.kt'):print(json.dumps(e,ensure_ascii=False))
for i,line in enumerate((R/'clients/mobile/app/src/main/kotlin/im/platform/client/send/Wss.kt').read_text().splitlines(),1):
 if i>=65:print(i,line)
