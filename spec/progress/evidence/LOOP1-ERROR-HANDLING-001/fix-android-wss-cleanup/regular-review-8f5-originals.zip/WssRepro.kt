import im.platform.client.send.Wss
import java.net.*
import java.io.*
import javax.net.ssl.*
import java.util.concurrent.*
import java.util.concurrent.atomic.*
class Peer(val primary:Throwable,val cleanup:Throwable):SSLSocket(){
 var closes=0
 override fun startHandshake(){throw primary}
 override fun close(){closes++;throw cleanup}
 override fun getInputStream():InputStream=ByteArrayInputStream(byteArrayOf())
 override fun getOutputStream():OutputStream=ByteArrayOutputStream()
 override fun getSupportedCipherSuites()=arrayOf("TLS_AES_128_GCM_SHA256")
 override fun getEnabledCipherSuites()=supportedCipherSuites
 override fun setEnabledCipherSuites(s:Array<String>){}
 override fun getSupportedProtocols()=arrayOf("TLSv1.2")
 override fun getEnabledProtocols()=supportedProtocols
 override fun setEnabledProtocols(s:Array<String>){}
 override fun getSession():SSLSession=throw IllegalStateException("unused session")
 override fun addHandshakeCompletedListener(l:HandshakeCompletedListener){}
 override fun removeHandshakeCompletedListener(l:HandshakeCompletedListener){}
 override fun setUseClientMode(v:Boolean){}
 override fun getUseClientMode()=true
 override fun setNeedClientAuth(v:Boolean){}
 override fun getNeedClientAuth()=false
 override fun setWantClientAuth(v:Boolean){}
 override fun getWantClientAuth()=false
 override fun setEnableSessionCreation(v:Boolean){}
 override fun getEnableSessionCreation()=true
}
class Factory(val peer:Peer):SSLSocketFactory(){
 override fun getDefaultCipherSuites()=peer.supportedCipherSuites
 override fun getSupportedCipherSuites()=peer.supportedCipherSuites
 override fun createSocket(s:Socket,h:String,p:Int,c:Boolean)=peer
 override fun createSocket(h:String,p:Int)=peer
 override fun createSocket(h:String,p:Int,l:InetAddress,q:Int)=peer
 override fun createSocket(h:InetAddress,p:Int)=peer
 override fun createSocket(h:InetAddress,p:Int,l:InetAddress,q:Int)=peer
}
fun graph(root:Throwable):Set<Throwable>{val seen=java.util.Collections.newSetFromMap(java.util.IdentityHashMap<Throwable,Boolean>());fun walk(e:Throwable){if(!seen.add(e))return;e.cause?.let(::walk);e.suppressed.forEach(::walk)};walk(root);return seen}
fun main(){
 val old=Thread.getDefaultUncaughtExceptionHandler()
 try {
  for(kind in listOf("unknown-exception","unknown-error","known-io")){
   val primary:Throwable=when(kind){"unknown-exception"->IllegalStateException("controlled handshake bug");"unknown-error"->AssertionError("controlled handshake assertion");else->IOException("controlled handshake IO")}
   val cleanup=IllegalStateException("controlled close bug")
   val peer=Peer(primary,cleanup);val observed=AtomicReference<Throwable?>();val ended=AtomicBoolean(false);val done=CountDownLatch(1)
   Thread.setDefaultUncaughtExceptionHandler{thread,error->if(thread.name=="im-wss"){observed.set(error);done.countDown()}else old?.uncaughtException(thread,error)}
   Wss("wss://localhost/v1/ws",{}, {}, {ended.set(true)},Factory(peer))
   check(done.await(10,TimeUnit.SECONDS)){"Wss thread did not report failure"}
   val error=observed.get()!!
   check(error===cleanup);check(primary !in graph(error));check(peer.closes==1);check(!ended.get())
   println("REPRO $kind: top-level cleanup identity=true; primary reachable=false; closeCalls=${peer.closes}; ended=${ended.get()}")
  }
 }finally{Thread.setDefaultUncaughtExceptionHandler(old)}
}
