import os,sys,subprocess
from pathlib import Path
env=dict(os.environ);env['PATH']=str(Path(sys.executable).parent)+';'+env['PATH'];env['PYTHONDONTWRITEBYTECODE']='1'
print('Fresh Acceptance uses bundled Python first PATH; earlier G:/Python27 failure preserved',flush=True)
sys.exit(subprocess.call(['pwsh','-NoProfile','-File','tools/verify-loop1-ctrl-002.ps1','-Mode','Acceptance'],env=env))
