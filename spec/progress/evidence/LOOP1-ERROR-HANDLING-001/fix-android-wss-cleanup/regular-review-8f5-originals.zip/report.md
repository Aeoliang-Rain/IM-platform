# Independent regular Review — FAIL

Candidate: 8f5f2b4275652d8e3fdff343d6a286ac805ad14a
Branch: task/LOOP1-ERROR-HANDLING-001
Assigned/resolved Git root: H:/.codex/worktrees/err/IM-platform
Diff base: 35bd6f5f1091503f95a0282f730ed04233b0b6ea
Actor: /root/regular_review_8f5f2b4 — fresh context, no participation in implementation, Fix, older regular Review or specialized audit. No source changes, push, PR, CI, integration or main write. Source lease RELEASED.

## F-WSS-CLEANUP-ROOT-REPLACEMENT [P1]

Location: clients/mobile/app/src/main/kotlin/im/platform/client/send/Wss.kt:70 (with close implementation at line 82).
The thread's finally executes `close(); ended()` without retaining its primary Throwable. When the actual TLS operation raises an unknown IllegalStateException or AssertionError and socket.close also raises an unknown IllegalStateException, the finally failure replaces the primary. The surfaced cleanup has neither cause nor suppressed primary. A known IOException primary is discarded by line 69 before the same cleanup failure. The original diagnostic failure is irretrievable.

Fresh actual current production Wss.kt was compiled unmodified with Kotlin 2.1.10 and executed on JDK17 using its existing injected SSLSocketFactory boundary and a controlled standard SSLSocket subclass. Three cases reproduced: unknown Exception primary, JVM Error primary and IOException primary, each followed by unknown close failure. All surfaced exact cleanup identity, zero primary reachability in cause/suppressed graph, close exactly once, ended not invoked. The controlled producer substitutes only socket external operations; no stub replaces Wss, its thread, catch or finally. This proves current production handling, not observed incidence in Android's default TLS provider, real network TLS acceptance or emulator execution. Compile exit 0 ~5.078s; execution exit 0 ~0.156s (exit zero means the expected defect was reproduced, not Task PASS). Exact source SHA256: 8f34a4c563e47b2f166661319f06d2e9df02f0961fb73d6d07f70d4a1dc7ee44.

Authority: current Task Acceptance/Minimality and spec/governance/error-handling.md forbid swallowed original exceptions and cleanup replacement of unknown root causes; Frozen §6.2/§7.2 authorize existing socket retirement/FAILED, not replacing an internal bug. This is a currently implemented resource boundary and existing test injection seam, not a speculative future mechanism.

Smallest correction: preserve actual primary Throwable and attach distinct cleanup failure without losing identity/cycling, using a local standard-language cleanup boundary; retain existing known transport retirement and fail-fast unknown behavior. Exercise JVM Error as well as Exception and known primary plus unknown cleanup. Do not add a framework or change SQLite/storage/ACK/security/dependencies. Whether/how ended is attempted must preserve roots; its skipped invocation is an observed consequence, not a separate architectural mandate to continue after fatal failure.

## F-WSS-RETAINED-GROUND-MISMATCH [P2]

Current navigation records 136|.../send/Wss.kt|RH138, 137|.../send/Wss.kt|RH139 and 138|.../send/Wss.kt|RH140 describe optional UI identity/profile/selection defaults, Frozen6.5/ADR0006/0012 and UI placeholder restoration. Their actual expressions are the WSS IOException transport catch, explicit unavailable-socket invariant throw and IOException socket.close catch. These are transport/cleanup/fail-fast boundaries, not optional UI defaults. The task requires per-site concrete fault -> current authority -> actual recovery, so these entries do not satisfy it. Correct actual meanings and any necessary source change together; preserve the composite identities. The fourth regex record RH137 is correctly nonexecutable. These records were actually read; no claim is made that all remaining grounds were inspected.

## Coverage and limits

This FAIL stops the review cycle. Whole-scope semantic completion=false. Seven complete production source texts were inspected (Https.kt, Auth.kt, WorkspaceViewModel.kt, SyncViewModel.kt, Wss.kt, SendViewModel.kt, RepositoryRead.kt), plus focused Go Outbox/session diffs. This is not a complete per-file PASS for those files or a 185-file/311-record semantic review. Remaining whole-source imports, producer-consumer logic, normal invariants and per-record grounds are unfinished. Full baseline-to-candidate diff is stored but not fully semantically reviewed. No older regular or specialist verdict was adopted.

Independent binding checks do establish all 185 candidate production Gitblobs equal their current inventory hashes and checkout bytes; all 65 protected inputs equal pre-fix a337, 63 equal whole accepted baseline and two match only allowed contiguous READ-method exceptions with identical SQL/all other Repository bytes. These are byte/scope checks, not semantic acceptance. All311 composite identities are distinct (never311 catches).

Startup read handoff/current/exact unique review Task first; Frozen resolver and actual canonical/PDF hashes matched manifest. Relevant canonical §2.3/3/5/6/7/10/11/12-14/18/21, approved ADRs and domain/invariants/governance were read. One oversized architecture/ADR read was truncated, relevant omitted sections retried; old Windows PowerShell encoding/read hash failure preserved. Broader referenced machine-contract details were partially read and remain unfinished; this is not a claim of complete global authority startup or full review. Shell crash before a command began and a cmd quoting failure were direct preparation gaps, not recorder events; initial direct reads/Git inspection/preparation and later direct tooling reads are disclosed. The registered delegated prompt is explicitly a summary, not verbatim full delegate/Human prompt.

Fresh actual minimum: frozen verifier exit0; architecture --scope all --json exit0; S2planning exit0; tests/architecture exit0 (82 tests, one existing Windows symlink skip). Recovery Acceptance result appears in current Recorder command stream. No fresh Android/Go live/native Desktop run is claimed. Historical Fix32/Send66/Sync69 tests were read as historical facts, not reused as regular acceptance. No private data, credentials, trust, global ACL, listener or emulator was touched. Generated JVM outputs only under this external review directory; owned fixture Wss threads terminated by their uncaught failure and default handler restored.

Next: root dispatches a NEW Fix Agent; after a new final committed candidate, NEW full regular review then DIFFERENT NEW specialized audit. No push/CI-triggering PR. Task remains review, S2 OPEN, hostedCI/integration/main synchronization PENDING; last accepted35bd6f5.

Fresh recovery Acceptance first failed because nested `python` resolved G:/Python27; original failure preserved. Bundled Python PATH rerun result is recorded in command stream. Recorder finished FAIL and own raw event stream validates structurally; incomplete trace and whole semantic scope remain explicit, not acceptance. Exact candidate remains clean.
