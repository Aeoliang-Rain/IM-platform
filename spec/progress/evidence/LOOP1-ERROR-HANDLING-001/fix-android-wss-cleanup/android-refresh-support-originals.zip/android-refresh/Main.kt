import im.platform.client.ui.*
import kotlinx.coroutines.runBlocking
import java.io.*
import java.net.*
import javax.net.ssl.HttpsURLConnection
class Peer(url:URL):HttpsURLConnection(url){override fun connect(){};override fun disconnect(){};override fun usingProxy()=false;override fun getCipherSuite()="controlled";override fun getLocalCertificates():Array<java.security.cert.Certificate>?=null;override fun getServerCertificates():Array<java.security.cert.Certificate> = emptyArray();override fun getOutputStream():OutputStream=ByteArrayOutputStream();override fun getResponseCode()=401;override fun getContentType()="application/json";override fun getErrorStream():InputStream=ByteArrayInputStream("{\"error\":{\"code\":\"AUTH_SESSION_REVOKED\"}}".toByteArray())}
fun roots(error:Throwable,seen:MutableSet<Throwable> = java.util.Collections.newSetFromMap(java.util.IdentityHashMap())):List<Throwable>{if(!seen.add(error))return emptyList();return listOf(error)+(error.cause?.let{roots(it,seen)}?:emptyList())+error.suppressed.flatMap{roots(it,seen)}}
fun main()=runBlocking {
 URL.setURLStreamHandlerFactory{scheme->if(scheme=="https")object:URLStreamHandler(){override fun openConnection(url:URL)=Peer(url)}else null}
 val unknown=IllegalStateException("controlled unknown credential cleanup")
 val p=Preferences(unknown);val owner=Auth("https://fixture.invalid",p);check(owner.savedAccount()=="11111111-1111-4111-8111-111111111111")
 try{owner.refresh();error("unexpected success")}catch(error:Exception){check(error===unknown);check(roots(error).none{it is ApiFailure});check(p.removes==1);println("F-ANDROID-REFRESH-CLEANUP-ROOT: actual Auth.request+Wire.parse HTTP401 creates session_expired; actual Auth.refresh->clear->Preferences.remove unknown replaces primary; no ApiFailure in cause/suppressed graph")}
 val io=IOException("Credential cleanup failed");val badCommit=Preferences(io);val commitOwner=Auth("https://fixture.invalid",badCommit);commitOwner.savedAccount();try{commitOwner.refresh();error("unexpected success")}catch(error:Exception){check(error===io);check(roots(error).none{it is ApiFailure});println("CONTROL current Preferences.remove commit=false IOException also replaces session_expired primary")}
 val good=Preferences();val control=Auth("https://fixture.invalid",good);control.savedAccount();try{control.refresh();error("unexpected success")}catch(error:ApiFailure){check(error.kind=="session_expired");check(good.removes==2);println("CONTROL actual successful cleanup rethrows session_expired primary and removes slot/current pointer")}
}
