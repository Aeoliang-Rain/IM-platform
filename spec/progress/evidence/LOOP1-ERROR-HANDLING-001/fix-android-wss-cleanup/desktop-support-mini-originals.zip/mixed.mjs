import assert from 'node:assert/strict';
import {Auth,ApiFailure} from './fixture/clients/desktop/src/application/ui/auth.js';
import {Workspace} from './fixture/clients/desktop/src/application/ui/workspace.js';
import {SendStorageFailure} from './fixture/clients/desktop/src/application/send.js';
import {accountRepository} from './fixture/clients/desktop/src/application/accountSend.js';
const tick=()=>new Promise(resolve=>setImmediate(resolve));
const unknown=new Error('controlled unknown IPC cleanup root');
const session={userId:'11111111-1111-4111-8111-111111111111',sessionId:'22222222-2222-4222-8222-222222222222',sessionEpoch:1n,accessToken:'public-owned-fixture'};
let release,removeStarted=false,remoteFail=true;
globalThis.literalInvoke=async(command)=>{
 if(command==='native_https')return remoteFail?[503,{'content-type':'application/json'},[...new TextEncoder().encode('{"error":{"code":"REQUEST_FAILED"}}')]]:[204,{},[]];
 if(command==='credential_remove'){removeStarted=true;await new Promise((resolve,reject)=>{release=()=>reject(unknown);});}
 else throw new Error('Unexpected controlled IPC command '+command);
};
function owner(){const a=new Auth('https://fixture.invalid');a.session=session;a.slot='https://fixture.invalid/'+session.userId+'/'+session.sessionId;return a;}
const unhandled=[];process.on('unhandledRejection',e=>unhandled.push(e));
const a=owner();let first;await a.logout().catch(e=>first=e);assert(first instanceof ApiFailure);assert.equal(first.kind,'REQUEST_FAILED');assert(removeStarted);release();await tick();await tick();assert(!unhandled.includes(unknown));console.log('F-DESKTOP-LOGOUT-MIXED: known remote ApiFailure settles logout before unknown credential cleanup; later unknown lost; no unhandled rejection');
removeStarted=false;const workspace=new Workspace();workspace.auth=owner();workspace.state.session=session;let workspaceRoot;await workspace.logout().catch(e=>workspaceRoot=e);assert.equal(workspaceRoot,undefined);assert.equal(workspace.state.error,'REQUEST_FAILED');assert.equal(workspace.state.busy,false);release();await tick();await tick();assert(!unhandled.includes(unknown));console.log('actual Workspace.logout consumer: resolved undefined; error REQUEST_FAILED; busy false; cleanup unknown absent');
remoteFail=false;removeStarted=false;const c=owner();const control=c.logout();await tick();release();await assert.rejects(control,e=>e===unknown);console.log('CONTROL remote success + unknown cleanup: actual Auth.logout rejects original identity');
const readUnknown=new Error('controlled unknown read producer root');let rejectRead;const known=new SendStorageFailure('Storage query rejected');const reads={conversationIds:async()=>['A','B'],messages:async id=>{if(id==='A')throw known;await new Promise((resolve,reject)=>{rejectRead=()=>reject(readUnknown);});return [];}};
const list=new Workspace();let listRoot;await list.updateList(reads,0).catch(e=>listRoot=e);assert.equal(listRoot,undefined);assert.equal(list.state.error,'Conversation history unavailable');rejectRead();await tick();await tick();assert(!unhandled.includes(readUnknown));console.log('F-DESKTOP-LIST-MIXED: actual updateList Promise.all consumes later unknown read; operation resolves known history error');
const controlList=new Workspace();await assert.rejects(controlList.updateList({conversationIds:async()=>['B'],messages:async()=>{throw readUnknown;}},0),e=>e===readUnknown);console.log('CONTROL lone unknown read: updateList rejects original identity');
const cA='33333333-3333-4333-8333-333333333333',cB='44444444-4444-4444-8444-444444444444';
globalThis.literalInvoke=async(command,args)=>{assert.equal(command,'database_query');if(args.sql.startsWith('SELECT conversation_id'))return [[cA],[cB]];if(args.binds[0]===cA)throw 'Storage query rejected';if(args.binds[0]===cB){await new Promise((resolve,reject)=>{rejectRead=()=>reject(readUnknown);});return [];}throw Error('Unexpected read');};
const literalRepo=accountRepository(session.userId),literalList=new Workspace();await literalList.updateList(literalRepo,0);assert.equal(literalList.state.error,'Conversation history unavailable');rejectRead();await tick();await tick();assert(!unhandled.includes(readUnknown));console.log('CONFIRMED literal invoke -> accountDatabase.query -> accountRepository origin tag -> Repository.messages -> Workspace.updateList: known-first native read rejection masks unknown-later IPC root');
assert.equal(unhandled.length,0);console.log('4 affected production/consumer observations + 2 unknown identity controls; no SQLite transaction/write or private storage');
