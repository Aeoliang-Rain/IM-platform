const fs=require('fs'),path=require('path');
const ts=require('../fix-read-origin/node_modules/typescript');
const root=path.join(__dirname,'fixture');
const paths=JSON.parse(fs.readFileSync(path.join(__dirname,'proof-source-bindings.json'),'utf8'));
for(const f of paths){const file=path.join(root,f.path);const result=ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ES2022},fileName:file,reportDiagnostics:true});if(result.diagnostics?.some(x=>x.category===ts.DiagnosticCategory.Error))throw Error('Transpile diagnostic');fs.writeFileSync(file.replace(/\.ts$/,'.js'),result.outputText);}
const stub=path.join(root,'node_modules/@tauri-apps/api');fs.mkdirSync(stub,{recursive:true});fs.writeFileSync(path.join(stub,'package.json'),JSON.stringify({type:'module',exports:{'./core':'./core.js'}}));fs.writeFileSync(path.join(stub,'core.js'),'export const invoke=(...args)=>globalThis.literalInvoke(...args);');
console.log('Transpiled exact 14-file import closure; no full typecheck claim; IPC linking stub only');
