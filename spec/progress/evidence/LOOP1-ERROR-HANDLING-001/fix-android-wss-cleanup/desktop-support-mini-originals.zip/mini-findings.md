# Read-only support findings at 8f5f2b4275652d8e3fdff343d6a286ac805ad14a

Actor /root/remaining_error_audit_8f5 did not implement or accept this candidate. This is support evidence, neither independent regular Review nor specialized audit PASS. Active worktree is concurrently dirty under the sole WSS writer; all production fixture inputs are immutable Git blobs at 8f5. No CI or source mutation occurred.

## F-DESKTOP-LOGOUT-MIXED (P1)

At `clients/desktop/src/application/ui/auth.ts:43`, logout starts remote revocation and secure credential cleanup and returns `Promise.all([this.clear(),remote])`. The actual `nativeFetch` → literal native_https invoke producer returns a controlled HTTP503 error; actual Auth.request projects it to ApiFailure. Meanwhile actual clear → secure.remove → literal credential_remove invoke has a pending unknown Error rejection. Promise.all exposes only the first ApiFailure. Actual Workspace.logout at workspace.ts:83 catches this known class, resolves undefined, sets busy=false and displays REQUEST_FAILED. Releasing the cleanup rejection afterwards produces no unhandled rejection and the unknown original identity disappears. A remote-success/lone-unknown control rejects the original unknown identity.

The current branch may also hide a second distinct known cleanup root. More seriously, the unknown is lost while credential removal remains failed. This violates governance/error-handling.md:7,9,11 and Frozen6.1/7.1 credential cleanup/no plaintext fallback obligations. It does not require changing security semantics. Minimal repair: wait for both already-required operations and preserve distinct roots; mixed unknown must escape the consumer's accepted ApiFailure boundary, while both-known failures retain truthful known failure. Do not add retries/framework/credential fallback.

Allowed path: `clients/desktop/src/application/ui/*.ts`. No SQLite writes or draft scope is involved.

## F-DESKTOP-LIST-MIXED (P1)

At workspace.ts:66, updateList concurrently maps conversations through `Promise.all(ids.map(...repo.messages...))`. Using actual immutable accountRepository → accountDatabase.query → literal database_query invoke → actual shared Repository.messages, conversation A's known native string `Storage query rejected` becomes actual SendStorageFailure first. Conversation B later rejects with an unknown Error from the controlled IPC producer. The Promise.all first rejection is handled by actual Workspace.failure/updateList catch at :69, resolving updateList with `Conversation history unavailable`; the later unknown is consumed and lost. A lone unknown read control rejects exact identity.

This violates error-handling.md:7,11; account-local materialized view/read errors remain real failures under Frozen6.1/6.5. Minimal repair: settle the current parallel reads before judging roots and preserve unknown/different failures, without changing SQL, Repository, transaction/write policy, ordering, or account ownership. Known-only read failures may continue the existing honest history error state.

Allowed path: `clients/desktop/src/application/ui/*.ts`. All fixture database commands are read-only database_query; no initialize, transaction, write or live SQLite call was executed.

## Actual proof and limits

`compile.cjs` transpiles the 17-file exact Git-blob TypeScript import closure, with one link stub forwarding literal @tauri-apps/api/core invoke to the controlled public fixture. This is transpilation/actual application consumer execution, not a full tsc typecheck, installed Tauri runtime, real database corruption or real OS credential failure incidence. `mixed.mjs` runs both actual producer paths and Workspace consumers with known-first/unknown-later timing, plus lone-unknown identity controls. The current Windows IPC producer's unknown outcome is injected at the authorized literal boundary; no private credential, ACL, trust or device access occurred. All input SHA256 values are in proof-source-bindings.json. Recorder events contain argv, actual exits, elapsed, raw output hashes and durable stdout. Initial missing locale module failed and was preserved; adding the three immutable production locale modules corrected the fixture link without weakening assertions.
