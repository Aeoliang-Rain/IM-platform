from pathlib import Path
import json,subprocess,sys
R=Path('H:/.codex/worktrees/err/IM-platform');E=Path(__file__).parent
c=json.loads((E.parent/'fix-read-origin/tsconfig.json').read_text());c['compilerOptions']['outDir']=str(E/'desktop-build');(E/'tsconfig.json').write_text(json.dumps(c,indent=2));(E/'package.json').write_text('{"type":"module"}')
subprocess.run(['H:/node.js/node.exe',str(E.parent/'fix-read-origin/node_modules/typescript/bin/tsc'),'-p',str(E/'tsconfig.json')],cwd=R,check=True)
stub=E/'desktop-build/node_modules/@tauri-apps/api';stub.mkdir(parents=True,exist_ok=True);(stub/'package.json').write_text('{"type":"module","exports":{"./core":"./core.js"}}');(stub/'core.js').write_text('export const invoke=(...args)=>globalThis.window.__TAURI_INTERNALS__.invoke(...args);');(E/'desktop-build/package.json').write_text('{"type":"module"}')
for source,name in [('tests/clients/gui/auth.mjs','auth.mjs'),('tests/clients/send/desktop.mjs','send.mjs'),('tests/clients/sync/desktop.mjs','sync.mjs')]:
 t=(R/source).read_text().replace('../../../clients/desktop/dist/','./desktop-build/').replace('../../../clients/shared/protocol-sdk/dist/storage/','./desktop-build/shared/protocol-sdk/src/storage/');(E/name).write_text(t)
print('Strict full Desktop TypeScript actual production compile PASS; stub only literal IPC link')
