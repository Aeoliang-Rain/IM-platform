from pathlib import Path
import hashlib,json
R=Path('H:/.codex/worktrees/err/IM-platform');E=Path(__file__).parent;S=E.parent/'recover-remaining-error-support';b=(S/'android-refresh-receipt.json').read_bytes();assert hashlib.sha256(b).hexdigest()=='74592bced5643814021a193dbdfa340f30f9d9d538c3372fa6859b248accee1e'
note='''
# Confirmed Android refresh cleanup scope (2026-10-15, before source writes)

Root authorized F-ANDROID-REFRESH-CLEANUP-ROOT P2 after fresh read-only support immutable8f5 proof; android-refresh-receipt SHA25674592bced5643814021a193dbdfa340f30f9d9d538c3372fa6859b248accee1e. Only existing allowed mobile/ui/Auth.kt refresh catch/mandatory clear boundary changes. Actual request401 session_expired primary is replaced by Preferences.remove commit=false IOException or unknown Throwable. Preserve both distinct roots through standard cause/suppressed without mutating originals. Successful clear keeps exact primary and two pointer removals. Actual IOException-only cleanup remains honest known IOException failure for current Workspace consumer without triggering additional expiry cleanup; unknown/Error/mixed cleanup becomes ordinary IllegalStateException with both roots and propagates. No new public category/framework/retry/security policy, no Preferences implementation/Repository/SQL/schema/init/transactions/SQLite writes/drafts/nativeDB changes. Required current JVM compile/lifecycle controls plus exclusively owned actual API34 refresh instrumentation and original Http32/WSS21/error controls. Prior unchanged WSS/Send/Sync results may be reused only with exact current source/test hash binding and stated historic runtime limits. Both NEW full finalSHA reviews/hosted/integration/main/safe sync remain PENDING; task review/S2 OPEN.
'''
for rel in ['spec/progress/current.md','spec/tasks/review/LOOP1-ERROR-HANDLING-001.md','spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-android-wss-cleanup/handoff.md']:
 p=R/rel;p.write_text(p.read_text(encoding='utf8')+note,encoding='utf8',newline='\n')
print('Prewrite current scope recorded; four-source final binding required')
