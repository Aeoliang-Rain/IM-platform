from pathlib import Path
import json,hashlib,zipfile,subprocess
R=Path('H:/.codex/worktrees/err/IM-platform');E=Path(__file__).parent;S=E.parent/'recover-remaining-error-support';D=R/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001';F=D/'fix-android-wss-cleanup'
def sha(b):return hashlib.sha256(b).hexdigest()
def js(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
assert sha((S/'support-receipt.json').read_bytes())=='6b4ddca7bfcb434847bbb36e57f3f45eb665c7424624634702faac0867d7a18b';assert sha((S/'android-ground-addendum.json').read_bytes())=='f6d182d306062db77f1c48c3f1fb38ca309adaaddc26950e58647d49280d1e7b'
cs=json.loads((S/'android-ground-addendum.json').read_text());assert len(cs)==68;nav=json.loads((F/'current-navigation.json').read_text());inv=json.loads((D/'production-inventory.json').read_text());applied=[]
for c in cs:
 rec=next(x for x in nav['records'] if x['composite_identity']==c['composite_identity']);b=(R/c['path']).read_bytes();assert sha(b)==rec['source_sha256'];assert b.decode().splitlines()[rec.get('current_line',rec['line'])-1][rec.get('current_column',rec['column'])-1:].startswith(rec['token'])
 old=subprocess.check_output(['git','show','8f5f2b4275652d8e3fdff343d6a286ac805ad14a:'+c['path']],cwd=R);assert sha(old)==c['source_sha256'];assert old.decode().splitlines()[c['line_at_8f5']-1].strip()==c['source'].strip()
 site=inv['retained_sites'][rec['original_ordinal']-1]
 if rec['original_id']=='RH177':applied.append(dict(identity=c['composite_identity'],result='Current repaired refresh catch grounds supersede historical defect paragraph'));continue
 fault=c['specific_fault'];authority=c['present_authority'];recovery=c['actual_recovery_or_failure']
 if rec['original_id']=='RH176':fault='Secure refresh credential genuinely absent before request';authority='Frozen6.1/7.1; ADR0009 current refresh credential lifecycle';recovery='Existing null read throws explicit session_expired before request; no empty credential/request or failed read is converted to success. Preferences.read exceptions propagate; this token is not the later cleanup catch.'
 site.update(authority=authority,specific_ground_and_recovery=fault+' → '+authority+' → '+recovery);rec.update(specific_fault=fault,present_authority=authority,actual_recovery_or_failure=recovery,decision='FIX_CURRENT_GROUND_REJUDGED_PENDING_INDEPENDENT_REVIEW');applied.append(dict(identity=c['composite_identity'],result='Current source/token and old immutable hash verified; grounds rejudged'))
rr=json.loads((S/'support-receipt.json').read_text());archive=F/'remaining-support-originals.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p,h in rr['files'].items():b=(S/p).read_bytes();assert sha(b)==h;z.writestr(p,b)
 z.writestr('support-receipt.json',(S/'support-receipt.json').read_bytes())
js(F/'remaining-support-seals.json',dict(receipt_sha256=sha((S/'support-receipt.json').read_bytes()),files=rr['files'],archive_sha256=sha(archive.read_bytes()),current_ground_adjudications=applied,whole_scope_semantic_complete=False,limit='Support verified185 old hashes/311 coordinates and observed133 historical FILE markers; final full185semantic regular/specialized cannot inherit support conclusions. No extra confirmed defect; Android logout stop concern unproved and excluded DB policy preserved.'))
js(F/'current-navigation.json',nav);js(D/'production-inventory.json',inv)
print('68 Android support inputs rejudged including exact absent-credential RH176 vs repairedcatch RH177; all sealed originals archived; support is not full semantic acceptance')
