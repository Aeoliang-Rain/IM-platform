from pathlib import Path
import json,collections
R=Path('H:/.codex/worktrees/err/IM-platform');D=R/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001';i=json.loads((D/'production-inventory.json').read_text());n=json.loads((D/'fix-android-wss-cleanup/current-navigation.json').read_text());print('SITEKEYS',collections.Counter(k for x in i['retained_sites'] for k in x));print('NAVKEYS',collections.Counter(k for x in n['records'] for k in x))
for sid,path in [('RH024','backend/java/InfraPlaceholder.java'),('RH060','clients/desktop/src/application/ui/native.ts'),('RH071','clients/desktop/src/application/ui/workspace.ts'),('RH176','clients/mobile/app/src/main/kotlin/im/platform/client/ui/Auth.kt'),('RH177','clients/mobile/app/src/main/kotlin/im/platform/client/ui/Auth.kt')]:
 print('SITE',next(x for x in i['retained_sites'] if x['id']==sid and x['path']==path));print('NAV',next(x for x in n['records'] if x['original_id']==sid and x['path']==path))
