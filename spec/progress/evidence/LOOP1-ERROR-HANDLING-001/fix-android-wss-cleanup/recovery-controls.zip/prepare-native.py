from pathlib import Path
import shutil
E=Path(__file__).parent;R=Path('H:/.codex/worktrees/err/IM-platform');S=E.parent/'recover-remaining-error-support';F=E/'android-refresh';F.mkdir(exist_ok=True)
for p in (S/'android-refresh').glob('*.kt'):shutil.copyfile(p,F/p.name)
(F/'Auth.kt').write_bytes((R/'clients/mobile/app/src/main/kotlin/im/platform/client/ui/Auth.kt').read_bytes())
s=(F/'Main.kt').read_text();a=s.index(' val unknown=');s=s[:a]+''' for(kind in listOf("normal","known","unknown","Error","mixed")){
 val unknown=IllegalStateException("cleanup unknown");val cleanup:Throwable?=when(kind){"known"->IOException("Credential cleanup failed");"unknown"->unknown;"Error"->AssertionError("cleanup Error");"mixed"->IOException("cleanup IO").also{it.addSuppressed(unknown)};else->null}
 val p=Preferences(cleanup);val owner=Auth("https://fixture.invalid",p);owner.savedAccount();val error=try{owner.refresh();error("unexpected success")}catch(e:Throwable){e};val graph=roots(error);val primary=graph.filterIsInstance<ApiFailure>().single();check(primary.kind=="session_expired");check(owner.session==null)
 if(kind=="normal"){check(error===primary);check(p.removes==2)}else{check(error.cause===primary);check(error.suppressed.single()===cleanup);check(cleanup in graph);check(p.removes==1);if(kind=="known")check(error is IOException)else check(error is IllegalStateException);if(kind=="mixed")check(unknown in graph)}
 println("REFRESH-JVM "+kind+" PASS")
 }
}
''';(F/'Main.kt').write_text(s)
s=(S/'android-refresh-run.py').read_text();(E/'android-refresh-run.py').write_text(s)
# Preserve own new runtime environment and exact H-only AVD without touching private AVDs.
s=(E.parent/'fix-android-wss-cleanup/start.py').read_text();s=s.replace("name='WssCleanup20261014';port=5600","name='RefreshCleanup20261015';port=5610").replace("avd=E/'avd'/'WssCleanup20261014.avd';avd.parent.mkdir(exist_ok=True)","avd=R/'clients/mobile/.gradle/refresh-runtime/RefreshCleanup20261015.avd';avd.parent.mkdir(parents=True,exist_ok=True)").replace("'emulator-5600'","'emulator-5610'")
(E/'start-emulator.py').write_text(s)
s=(E.parent/'fix-android-wss-cleanup/runtime.py').read_text();s=s.replace("serial='emulator-5600'","serial='emulator-5610'");(E/'runtime.py').write_text(s)
print('Own JVM/control scripts prepared')
