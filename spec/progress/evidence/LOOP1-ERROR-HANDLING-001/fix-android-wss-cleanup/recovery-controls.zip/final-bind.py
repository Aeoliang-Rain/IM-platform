from pathlib import Path
import hashlib,json,subprocess,difflib,zipfile
R=Path('H:/.codex/worktrees/err/IM-platform');E=Path(__file__).parent;D=R/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001';F=D/'fix-android-wss-cleanup';B='8f5f2b4275652d8e3fdff343d6a286ac805ad14a'
def sha(b):return hashlib.sha256(b).hexdigest()
def js(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
def base(p):return subprocess.check_output(['git','show',B+':'+p],cwd=R)
inv=json.loads((D/'production-inventory.json').read_text());nav=json.loads((F/'current-navigation.json').read_text());path='clients/mobile/app/src/main/kotlin/im/platform/client/ui/Auth.kt';new=(R/path).read_text();old=base(path).decode();assert len(nav['records'])==317
assert next(x['sha256'] for x in inv['files'] if x['path']==path)==sha(base(path))
ops=difflib.SequenceMatcher(None,old,new,autojunk=False).get_opcodes();starts=[];n=0
for line in old.splitlines(keepends=True):starts.append(n);n+=len(line)
for ordinal,site in enumerate(inv['retained_sites'],1):
 if site['path']!=path:continue
 rec=next(x for x in nav['records'] if x['original_ordinal']==ordinal);point=starts[site['line']-1]+site['column']-1;m=[c+point-a for typ,a,b,c,d in ops if typ=='equal' and a<=point<b];assert len(m)==1,(site['id'],point)
 pos=m[0];ln=new.count('\n',0,pos)+1;col=pos-new.rfind('\n',0,pos);src=new.splitlines()[ln-1];assert src[col-1:].startswith(rec['token']);site.update(line=ln,column=col,source=src.strip());rec.update(line=ln,column=col,source=src,source_sha256=sha((R/path).read_bytes()))
 for k in ['current_line','current_column','current_source']:rec.pop(k,None)
G='Frozen6.1/7.1; ADR0009 current secure credential cleanup; error-handling actual root preservation and unknown propagation'
fault='Current refresh request returns session_expired ApiFailure; mandatory Preferences.remove can fail with actual commit=false IOException or unknown Throwable'
recovery='Successful current clear removes slot/current then rethrows exact primary. Distinct cleanup retains exact primary cause and cleanup suppressed without root mutation. IO-only cleanup uses standard IOException for existing honest Workspace unavailable failure without re-expire; unknown/Error/mixed cleanup uses standard IllegalStateException and escapes. Sameidentity rethrows original. No extra cleanup retry, plaintext or storage change.'
for x in nav['records']:
 if x['path']==path and 'catch(e:ApiFailure)' in x['source']:
  x.update(specific_fault=fault,present_authority=G,actual_recovery_or_failure=recovery);inv['retained_sites'][x['original_ordinal']-1].update(authority=G,specific_ground_and_recovery=fault+' → '+G+' → '+recovery)
token='catch(cleanup:Throwable)';pos=new.index(token,new.index('suspend fun refresh'));ln=new.count('\n',0,pos)+1;col=pos-new.rfind('\n',0,pos);src=new.splitlines()[ln-1];ordinal=len(nav['records'])+1;sid='RH'+str(ordinal)
nav['records'].append(dict(original_ordinal=ordinal,original_id=sid,id=sid,composite_identity=f'{ordinal}|{path}|{sid}',path=path,line=ln,column=col,source=src,token='catch',token_class='catch',executable=True,source_sha256=sha((R/path).read_bytes()),specific_fault=fault,present_authority=G,actual_recovery_or_failure=recovery,decision='FIX_LOCAL_NAVIGATION_ONLY_PENDING_INDEPENDENT_REVIEW'))
inv['retained_sites'].append(dict(id=sid,path=path,line=ln,column=col,source=src.strip(),operation='refresh mandatory secure cleanup',disposition='RETAINED',authority=G,specific_ground_and_recovery=fault+' → '+G+' → '+recovery))
for x in inv['files']:
 if x['path']==path:x.update(sha256=sha((R/path).read_bytes()),bytes=(R/path).stat().st_size,changed=True,inspection='Current refresh literal cleanup root fix with fresh JVM5 and actual API34 Preferences5 plus original errors/Http32/WSS21; final independent semantic Review/audit still PENDING.');x['finding'].append('F-ANDROID-REFRESH-CLEANUP-ROOT')
counts=dict(records=len(nav['records']),executable=sum(bool(x['executable']) for x in nav['records']),nonexecutable=sum(not x['executable'] for x in nav['records']));assert counts==dict(records=318,executable=283,nonexecutable=35);nav.update(counts=counts,binding='311 prior composite identities+2WSS catches+3Desktop parallel/projection+Desktop refresh cleanup+Android refresh cleanup=318 navigation (283 executable,35 nonexecutable), not catches. Historical sourcebound review preserved; final regular/specialized PENDING.')
inv['counts']['retained_sites']=318;inv['fix_android_wss_cleanup'].update(counts=counts,production_delta=['clients/mobile/app/src/main/kotlin/im/platform/client/send/Wss.kt','clients/desktop/src/application/ui/auth.ts','clients/desktop/src/application/ui/workspace.ts',path],recovery_actor='/root/recover_wss_desktop_fix_finish',partial_previous_run='R-FIX-ANDROID-WSS remains raw partial, not finished in new identity',current_run='R-RECOVER-WSS-DESKTOP-FINISH')
for x in inv['files']:assert sha((R/x['path']).read_bytes())==x['sha256'],x['path']
keys=set()
for x in nav['records']:
 key=(x['original_ordinal'],x['path'],x['original_id']);assert key not in keys;keys.add(key);b=(R/x['path']).read_bytes();assert sha(b)==x['source_sha256'];assert b.decode().splitlines()[x.get('current_line',x['line'])-1][x.get('current_column',x['column'])-1:].startswith(x['token']),key
for x in json.loads((F/'protected-inputs.json').read_text())['files']:assert (R/x['path']).read_bytes()==base(x['path']);assert sha((R/x['path']).read_bytes())==x['sha256']
changed=[x['path'] for x in inv['files'] if (R/x['path']).read_bytes()!=base(x['path'])];assert set(changed)==set(inv['fix_android_wss_cleanup']['production_delta'])
S=E.parent/'recover-remaining-error-support';rr=json.loads((S/'android-refresh-receipt.json').read_text());assert sha((S/'android-refresh-receipt.json').read_bytes())=='74592bced5643814021a193dbdfa340f30f9d9d538c3372fa6859b248accee1e'
with zipfile.ZipFile(F/'android-refresh-support-originals.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p,h in rr['files'].items():b=(S/p).read_bytes();assert sha(b)==h;z.writestr(p,b)
 z.writestr('android-refresh-receipt.json',(S/'android-refresh-receipt.json').read_bytes())
seals=json.loads((F/'prior-review-seals.json').read_text());O=E.parent/'regular-review-8f5f2b4'
with zipfile.ZipFile(F/'regular-review-8f5-originals.zip') as z:
 for x in seals['artifacts']:assert sha(z.read(x['path']))==x['sha256'];assert sha((O/x['path']).read_bytes())==x['sha256']
 assert sha(z.read('final-receipt.json'))==seals['receipt_sha256']
# Archive raw interrupted research exactly, with reproducible entry hashes, never rewriting or finishing old run.
old=E.parent/'fix-android-wss-cleanup/research';manifest={}
with zipfile.ZipFile(F/'partial-original-research.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(old.rglob('*')):
  if p.is_file():b=p.read_bytes();name=p.relative_to(old).as_posix();manifest[name]=sha(b);z.writestr(name,b)
js(F/'partial-original-research-seals.json',dict(status='PARTIAL_INTERRUPTED_UNFINISHED',run_id='R-FIX-ANDROID-WSS',entries=manifest,archive_sha256=sha((F/'partial-original-research.zip').read_bytes()),last_recorded_command='refresh-bind.py exit1 seq117; both exact reconstruction match typos repaired only in new actor scripts; no final prior binding PASS',unavailable_facts='missing child outcomes/timing not reconstructed; original WinError2 command_started lacks finished'))
js(D/'production-inventory.json',inv);js(F/'current-navigation.json',nav);js(F/'input-checks.json',dict(production185=True,navigation=counts,protected65_exact_pre_fix=True,sole_production_delta=changed,old80_verified=True,desktop_support_mini_addendum=True,android_refresh_support=True,meaning='local binding integrity only; independent final Review/audit PENDING'))
print('Current185/318(283exec35nonexec)/65 PASS; fourproduction only; sealed old80/support/rawpartial exact')
