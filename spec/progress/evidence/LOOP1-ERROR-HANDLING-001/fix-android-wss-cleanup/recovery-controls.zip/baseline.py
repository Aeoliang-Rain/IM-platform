from pathlib import Path
import subprocess,sys,json,time
R=Path('H:/.codex/worktrees/err/IM-platform');E=Path(__file__).parent
commands=[[sys.executable,'-Xutf8','-B','tools/verify_frozen_architecture.py'],[sys.executable,'-Xutf8','-B','ci/check_architecture.py','--scope','all','--json'],[sys.executable,'-Xutf8','-B','ci/check_s2_planning.py'],[sys.executable,'-Xutf8','-B','-m','unittest','discover','-s','tests/architecture','-v']]
results=[]
for i,c in enumerate(commands):
 t=time.monotonic();p=subprocess.run([sys.executable,'-Xutf8','-B',str(E/'run.py'),*c],cwd=R,capture_output=True);(E/f'baseline-{i}.txt').write_bytes(p.stdout+p.stderr);v={'argv':c,'exit':p.returncode,'elapsed_seconds':time.monotonic()-t};results.append(v);print(json.dumps(v),flush=True)
(E/'baseline.json').write_text(json.dumps(results,indent=2));sys.exit(any(x['exit'] for x in results))
