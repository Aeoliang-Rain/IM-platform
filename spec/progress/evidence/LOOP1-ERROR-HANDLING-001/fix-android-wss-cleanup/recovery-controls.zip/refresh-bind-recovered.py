from pathlib import Path
import hashlib,json,subprocess,difflib,zipfile
R=Path('H:/.codex/worktrees/err/IM-platform');E=Path(__file__).parent.parent/'fix-android-wss-cleanup';D=R/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001';F=D/'fix-android-wss-cleanup';O=E.parent/'remaining-error-audit-8f5';BASE='8f5f2b4275652d8e3fdff343d6a286ac805ad14a'
def sha(b):return hashlib.sha256(b).hexdigest()
def raw(p):return subprocess.check_output(['git','show',BASE+':'+p],cwd=R)
def js(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
inv=json.loads((D/'production-inventory.json').read_text());nav=json.loads((F/'current-navigation.json').read_text());assert len(nav['records'])==316
paths=['clients/desktop/src/application/ui/auth.ts','clients/desktop/src/application/ui/workspace.ts']
for path in paths:
 new=(R/path).read_text();old=new
 if path.endswith('/auth.ts'):
  old=old.replace('''if(g===this.generation&&error instanceof ApiFailure&&error.kind==="session_expired"){
      try{await this.clear();}catch(cleanup){if(cleanup===error)throw error;throw new AggregateError([error,cleanup],"Refresh cleanup failed");}
    }throw error;''','if(g===this.generation&&error instanceof ApiFailure&&error.kind==="session_expired")await this.clear();throw error;')
 else:old=old.replace('const authentication=error instanceof ApiFailure?error:undefined;','const authentication=failures.find(root=>root instanceof ApiFailure);').replace('if(authentication?.kind==="session_expired")void this.expire();','if(failures.some(root=>root instanceof ApiFailure&&root.kind==="session_expired"))void this.expire();')
 prev=next(x['sha256'] for x in inv['files'] if x['path']==path);assert sha(old.encode())==prev,(path,sha(old.encode()),prev)
 ops=difflib.SequenceMatcher(None,old,new,autojunk=False).get_opcodes();starts=[];n=0
 for line in old.splitlines(keepends=True):starts.append(n);n+=len(line)
 for ordinal,site in enumerate(inv['retained_sites'],1):
  if site['path']!=path:continue
  rec=next(x for x in nav['records'] if x['original_ordinal']==ordinal);point=starts[site['line']-1]+site['column']-1;m=[c+point-a for typ,a,b,c,d in ops if typ=='equal' and a<=point<b];assert len(m)==1,(site['id'],point)
  pos=m[0];ln=new.count('\n',0,pos)+1;col=pos-new.rfind('\n',0,pos);src=new.splitlines()[ln-1];assert src[col-1:].startswith(rec['token']),(site['id'],src,col);site.update(line=ln,column=col,source=src.strip());rec.update(line=ln,column=col,source=src,source_sha256=sha((R/path).read_bytes()));rec.pop('current_line',None);rec.pop('current_column',None)
 for x in inv['files']:
  if x['path']==path:x.update(sha256=sha((R/path).read_bytes()),bytes=(R/path).stat().st_size,inspection='Fresh local literal fault correction and strict exactsource Desktop37/current Auth/readcontrols PASS; whole final independent regular/specialist PENDING. Only current operation-owned standard cleanup/parallel handling changed.');x['finding']+=['F-DESKTOP-REFRESH-CLEANUP-ROOT'] if path.endswith('/auth.ts') else []
G='Frozen6.1/7.1; ADR0009 secure refresh/session cleanup; current error-handling exact roots/no retry'
for sid,fault,recovery in [('RH058','Current generation refresh returns canonical session_expired primary, mandatory clear can also fail','Successful clear rethrows original ApiFailure. Distinct cleanup root retained with exact primary in standard AggregateError; sameidentity rethrows original. Mixedunknown/Error/primitive0nullundefined rejects completegraph; no additional credential retry or policy.'),('RH087','Current refresh/bind operation can fail with single or cleanup aggregate roots','Unknown/mixed aggregate throws unchanged even retired; only nonempty allknown existing root types publish current Operation unavailable. Only originaltopApiFailure session_expired retains existing expiry action; aggregatecleanupfailure does not add retry.')]:
 rec=next(x for x in nav['records'] if x['original_id']==sid and x['path'] in paths);site=inv['retained_sites'][rec['original_ordinal']-1];site.update(authority=G,specific_ground_and_recovery=fault+' → '+G+' → '+recovery);rec.update(specific_fault=fault,present_authority=G,actual_recovery_or_failure=recovery)
path=paths[0];new=(R/path).read_text();token='catch(cleanup)';pos=new.index(token);ln=new.count('\n',0,pos)+1;col=pos-new.rfind('\n',0,pos);src=new.splitlines()[ln-1];ordinal=len(nav['records'])+1;sid='RH'+str(ordinal);fault='Existing secure clear fails after actual canonical sessionexpired primary';recovery='Preserve exact distinct primary+cleanup AggregateError without mutation/cycle; same identity propagates original. Unknown cleanup stays failure, known-only aggregate remains honest failure; no retry/plaintext downgrade.'
inv['retained_sites'].append(dict(id=sid,path=path,line=ln,column=col,source=src.strip(),operation='refresh mandatory cleanup',disposition='RETAINED',authority=G,specific_ground_and_recovery=fault+' → '+G+' → '+recovery));nav['records'].append(dict(original_ordinal=ordinal,original_id=sid,id=sid,composite_identity=f'{ordinal}|{path}|{sid}',path=path,line=ln,column=col,source=src,token='catch',token_class='catch',executable=True,source_sha256=sha((R/path).read_bytes()),specific_fault=fault,present_authority=G,actual_recovery_or_failure=recovery,decision='FIX_LOCAL_NAVIGATION_ONLY_PENDING_INDEPENDENT_REVIEW'))
corrections=json.loads((O/'ground-corrections.json').read_text());assert len(corrections)==35;assert sha((O/'ground-corrections.json').read_bytes())=='27d9e2a19849d055b2d2bdba8522994d5d506f4c134e4b2cdfee4fb9ed8e3b45'
for c in corrections:
 rec=next(x for x in nav['records'] if f"{x['original_ordinal']}|{x['path']}|{x['original_id']}"==c['composite_identity']);site=inv['retained_sites'][rec['original_ordinal']-1]
 # Actual token checked against current source; support old hash remains separately archived.
 b=(R/c['path']).read_bytes();assert sha(b)==rec['source_sha256'];ln=rec.get('current_line',rec['line']);col=rec.get('current_column',rec['column']);assert b.decode().splitlines()[ln-1][col-1:].startswith(rec['token'])
 if rec['original_id'] in ['RH083','RH087','RH089']:continue # Final local repaired semantics above/in prior bind supersede old source defect paragraphs.
 site.update(authority=c['present_authority'],specific_ground_and_recovery=c['specific_fault']+' → '+c['present_authority']+' → '+c['actual_recovery_or_failure']);rec.update(specific_fault=c['specific_fault'],present_authority=c['present_authority'],actual_recovery_or_failure=c['actual_recovery_or_failure'],decision='FIX_CURRENT_GROUND_REJUDGED_PENDING_INDEPENDENT_REVIEW')
# Actual local aggregate classification handles current root types only; known aggregates do not replay nested expiry action.
rec=next(x for x in nav['records'] if x['original_id']=='RH316');rec['actual_recovery_or_failure']='Nonempty allknown current Api/Wire/Sync/SendStorage/NativeCapability types permit existing safe Operation unavailable. Unknown/empty aggregate throws original including retired result. Only originaltop ApiFailure runs existing expiry action; no aggregate-driven credential retry.';inv['retained_sites'][rec['original_ordinal']-1]['specific_ground_and_recovery']=rec['specific_fault']+' → '+rec['present_authority']+' → '+rec['actual_recovery_or_failure']
counts=dict(records=len(nav['records']),executable=sum(bool(x['executable']) for x in nav['records']),nonexecutable=sum(not x['executable'] for x in nav['records']));assert counts==dict(records=317,executable=282,nonexecutable=35);nav['counts']=counts;nav['binding']='311 prior composite identities+2WSS cleanup/ended catches+3current parallel/classification projections+1current refreshcleanup catch=317navigation, not catches. Currentgrounds rejudged; old independent facts sourcebound historical; bothfinalSHAreviews PENDING.';inv['counts']['retained_sites']=317;inv['fix_android_wss_cleanup']['counts']=counts
for x in inv['files']:assert sha((R/x['path']).read_bytes())==x['sha256']
keys=set()
for x in nav['records']:
 key=(x['original_ordinal'],x['path'],x['original_id']);assert key not in keys;keys.add(key);b=(R/x['path']).read_bytes();assert sha(b)==x['source_sha256'];ln=x.get('current_line',x['line']);col=x.get('current_column',x['column']);assert b.decode().splitlines()[ln-1][col-1:].startswith(x['token']),key
for x in json.loads((F/'protected-inputs.json').read_text())['files']:assert (R/x['path']).read_bytes()==raw(x['path']);assert sha((R/x['path']).read_bytes())==x['sha256']
changed=[x['path'] for x in inv['files'] if (R/x['path']).read_bytes()!=raw(x['path'])];assert set(changed)==set(paths+['clients/mobile/app/src/main/kotlin/im/platform/client/send/Wss.kt'])
receipt=O/'mini-addendum-receipt.json';assert sha(receipt.read_bytes())=='04450ea67f3bddcab04ca1c99b6887fac73498864e40f566c9c9d54707c2a411';rr=json.loads(receipt.read_text());archive=F/'desktop-support-addendum-originals.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
 for p,digest in rr['seals'].items():b=(O/p).read_bytes();assert sha(b)==digest;z.writestr(p,b)
 z.writestr('mini-addendum-receipt.json',receipt.read_bytes());z.writestr('ground-corrections.json',(O/'ground-corrections.json').read_bytes())
js(F/'desktop-support-addendum-seals.json',dict(receipt_sha256=sha(receipt.read_bytes()),seals=rr['seals'],ground_corrections_sha256=sha((O/'ground-corrections.json').read_bytes()),ground_corrections_count=35,archive_sha256=sha(archive.read_bytes()),meaning='Immutable source supportinput, not authority or final acceptance. Currentactualscope/grounds checked; three repairedWorkspace specifics supersede source8f5 defect descriptions; original35JSON archived unchanged.'))
js(D/'production-inventory.json',inv);js(F/'current-navigation.json',nav);js(F/'input-checks.json',dict(production185=True,navigation=counts,protected65_exact_pre_fix=True,sole_production_delta=changed,old80_verified=True,desktop_support_mini_and_addendum_verified=True,current_support_ground_corrections=35))
print('Final current185/317(282exec35nonexec)/65; threeproduction only; supportgrounds actualread/token verified')

