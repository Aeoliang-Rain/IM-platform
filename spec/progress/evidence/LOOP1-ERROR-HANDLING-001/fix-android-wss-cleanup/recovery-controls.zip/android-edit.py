from pathlib import Path
R=Path('H:/.codex/worktrees/err/IM-platform');p=R/'clients/mobile/app/src/main/kotlin/im/platform/client/ui/Auth.kt';s=p.read_text(encoding='utf8');old='catch(e:ApiFailure){if(g==generation && e.kind=="session_expired")clear();throw e}'
new='''catch(e:ApiFailure){
        if(g==generation && e.kind=="session_expired")try{clear()}catch(cleanup:Throwable){
            if(cleanup===e)throw e
            val failure=if(transportCleanup(cleanup))java.io.IOException("Refresh cleanup failed",e) else IllegalStateException("Refresh cleanup failed",e)
            failure.addSuppressed(cleanup);throw failure
        }
        throw e
    }'''
assert s.count(old)==1;s=s.replace(old,new);p.write_text(s,encoding='utf8',newline='\n');print('Only literal Auth.refresh catch preserves exact roots; known IO remains existing known failure')
