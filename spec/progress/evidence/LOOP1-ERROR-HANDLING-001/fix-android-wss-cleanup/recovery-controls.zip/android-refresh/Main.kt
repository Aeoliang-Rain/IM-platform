import im.platform.client.ui.*
import kotlinx.coroutines.runBlocking
import java.io.*
import java.net.*
import javax.net.ssl.HttpsURLConnection
class Peer(url:URL):HttpsURLConnection(url){override fun connect(){};override fun disconnect(){};override fun usingProxy()=false;override fun getCipherSuite()="controlled";override fun getLocalCertificates():Array<java.security.cert.Certificate>?=null;override fun getServerCertificates():Array<java.security.cert.Certificate> = emptyArray();override fun getOutputStream():OutputStream=ByteArrayOutputStream();override fun getResponseCode()=401;override fun getContentType()="application/json";override fun getErrorStream():InputStream=ByteArrayInputStream("{\"error\":{\"code\":\"AUTH_SESSION_REVOKED\"}}".toByteArray())}
fun roots(error:Throwable,seen:MutableSet<Throwable> = java.util.Collections.newSetFromMap(java.util.IdentityHashMap())):List<Throwable>{if(!seen.add(error))return emptyList();return listOf(error)+(error.cause?.let{roots(it,seen)}?:emptyList())+error.suppressed.flatMap{roots(it,seen)}}
fun main()=runBlocking {
 URL.setURLStreamHandlerFactory{scheme->if(scheme=="https")object:URLStreamHandler(){override fun openConnection(url:URL)=Peer(url)}else null}
 for(kind in listOf("normal","known","unknown","Error","mixed")){
 val unknown=IllegalStateException("cleanup unknown");val cleanup:Throwable?=when(kind){"known"->IOException("Credential cleanup failed");"unknown"->unknown;"Error"->AssertionError("cleanup Error");"mixed"->IOException("cleanup IO").also{it.addSuppressed(unknown)};else->null}
 val p=Preferences(cleanup);val owner=Auth("https://fixture.invalid",p);owner.savedAccount();val error=try{owner.refresh();error("unexpected success")}catch(e:Throwable){e};val graph=roots(error);val primary=graph.filterIsInstance<ApiFailure>().single();check(primary.kind=="session_expired");check(owner.session==null)
 if(kind=="normal"){check(error===primary);check(p.removes==2)}else{check(error.cause===primary);check(error.suppressed.single()===cleanup);check(cleanup in graph);check(p.removes==1);if(kind=="known")check(error is IOException)else check(error is IllegalStateException);if(kind=="mixed")check(unknown in graph)}
 println("REFRESH-JVM "+kind+" PASS")
 }
}
