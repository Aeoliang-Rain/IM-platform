package im.platform.client.ui
class Preferences(var cleanup:Throwable?=null){var removes=0;fun write(a:String,b:String){};fun read(a:String):String?=if(a.endsWith("/current"))"https://fixture.invalid/11111111-1111-4111-8111-111111111111/22222222-2222-4222-8222-222222222222"else "public-owned-refresh-fixture";fun remove(a:String){removes++;cleanup?.let{throw it}}}

