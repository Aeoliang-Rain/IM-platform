from pathlib import Path
import os,json,subprocess,shutil,time
R=Path('H:/.codex/worktrees/err/IM-platform');E=Path(__file__).parent;D=R/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-android-wss-cleanup';x=json.loads((E/'emulator-receipt.json').read_text());assert x['serial']=='emulator-5610';own=Path(x['owned_avd']).resolve();expected=(R/'clients/mobile/.gradle/refresh-runtime/RefreshCleanup20261015.avd').resolve();assert own==expected and own.is_relative_to((R/'clients/mobile/.gradle').resolve())
os.environ.update(ANDROID_USER_HOME=str(E/'android-user'),ANDROID_SDK_HOME=str(E/'android-sdk-home'));adb='H:/Android/platform-tools/adb.exe';reverse=subprocess.check_output([adb,'-s',x['serial'],'reverse','--list'],text=True);assert not reverse.strip(),reverse
subprocess.run([adb,'-s',x['serial'],'emu','kill'],check=True)
for _ in range(60):
 state=subprocess.check_output([adb,'devices','-l'],text=True)
 if x['serial'] not in state:break
 time.sleep(1)
else:raise RuntimeError('owned emulator did not close')
print('Verified exact owned AVD deletion target',own,flush=True);shutil.rmtree(own);(E/'avds/RefreshCleanup20261015.ini').unlink()
outputs=[]
for rel in ['clients/mobile/app/build','clients/mobile/.gradle']:
 src=(R/rel).resolve();assert src.is_relative_to(R.resolve());dest=E/'owned-build-artifacts'/rel.replace('/','_');assert not dest.exists();dest.parent.mkdir(exist_ok=True)
 if src.exists():shutil.move(str(src),str(dest));outputs.append(dict(source=str(src),preserved=str(dest)))
assert not any(z.strip() and not z.startswith('List of devices') for z in state.splitlines()),state
run=E/'research/runs/R-RECOVER-WSS-DESKTOP-FINISH';ev=[json.loads(z) for z in (run/'events.jsonl').read_text().splitlines()];starts={z['data']['command_id']:z for z in ev if z['event_type']=='command_started'};rows=[z for z in ev if z['event_type']=='command_finished' and any(a.endswith('/start-emulator.py') for a in starts[z['data']['command_id']]['data']['argv'])];assert len(rows)==1
raw=''.join((run/rows[0]['data'][k]).read_text() for k in ['stdout_blob','stderr_blob']);assert 'daemon not running' in raw and 'daemon started successfully' in raw;subprocess.run([adb,'kill-server'],check=True)
result=dict(owned_emulator=x,reverse_empty=True,remaining_devices=state,deleted_exact_owned_avd=str(own),preserved_outputs=outputs,own_new_adb_daemon_stopped=True,private_data_global_trust_main_touched=False)
(D/'recovery-runtime-cleanup.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');(E/'runtime-cleanup.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf8');print('Owned5610 closed/AVD removed/build outputs external/new adb stopped; all leases released')

