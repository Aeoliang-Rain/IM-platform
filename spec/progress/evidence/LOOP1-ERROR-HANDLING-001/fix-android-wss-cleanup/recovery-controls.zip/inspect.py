from pathlib import Path
import hashlib,subprocess,json
R=Path('H:/.codex/worktrees/err/IM-platform');E=Path(__file__).parent;old=E.parent/'fix-android-wss-cleanup'
assert hashlib.sha256((R/'spec/architecture/frozen-architecture.md').read_bytes()).hexdigest()=='efbe04c7eb308904d1759b8e145a32363620ed8c14daef58f09c644bdc897bdc'
s=(R/'spec/architecture/frozen-architecture.md').read_text(encoding='utf8');lines=s.splitlines();show=False
for line in lines:
 if line.startswith('## '):
  import re
  m=re.match(r'## (\d+)',line);show=bool(m and int(m[1]) in [2,3,5,6,7,10,11,12,13,14,18,21])
 if show:print(line)
for args in [['rev-parse','--show-toplevel'],['status','--short'],['diff','--stat'],['log','-5','--oneline']]:print(subprocess.check_output(['git',*args],cwd=R).decode())
assert Path(subprocess.check_output(['git','rev-parse','--show-toplevel'],cwd=R).decode().strip()).resolve()==R.resolve()
meta=json.loads((old/'research/runs/R-FIX-ANDROID-WSS/metadata.json').read_text());print('OLD RUN',meta)
events=[json.loads(l) for l in (old/'research/runs/R-FIX-ANDROID-WSS/events.jsonl').read_text().splitlines()];print('LASTEVENTS',json.dumps(events[-2:],ensure_ascii=False))
for f in ['spec/progress/evidence/LOOP1-ERROR-HANDLING-001/production-inventory.json','spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-android-wss-cleanup/current-navigation.json']:
 data=json.loads((R/f).read_text());print(f,data.keys(),data.get('counts'))
