from pathlib import Path
import json,hashlib,subprocess
E=Path(__file__).parent;R=Path('H:/.codex/worktrees/err/IM-platform');F=R/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-android-wss-cleanup';old=E.parent/'fix-android-wss-cleanup'
owned=subprocess.check_output(['git','ls-files','-m','-o','--exclude-standard','-z'],cwd=R).decode().split('\0');owned=[x for x in owned if x];snap={p:hashlib.sha256((R/p).read_bytes()).hexdigest() for p in owned};(E/'initial-owned-bytes.json').write_text(json.dumps(snap,indent=2));print('Owned count',len(snap))
for x in json.loads((F/'current-navigation.json').read_text())['records']:
 if x['path'].endswith('/auth.ts') and x['path'].startswith('clients/desktop'):print(json.dumps(x,ensure_ascii=False))
print('Owned evidence names', [p.name for p in F.iterdir()])
s=(old/'refresh-bind.py').read_text();s=s.replace('E=Path(__file__).parent;D=',"E=Path(__file__).parent.parent/'fix-android-wss-cleanup';D=")
s=s.replace('error.kind=="session_expired"','error.kind==="session_expired"')
s=s.replace("rec.update(line=ln,column=col,source=src,source_sha256=sha((R/path).read_bytes()))","rec.update(line=ln,column=col,source=src,source_sha256=sha((R/path).read_bytes()));rec.pop('current_line',None);rec.pop('current_column',None)")
(E/'refresh-bind-recovered.py').write_text(s,encoding='utf8')
