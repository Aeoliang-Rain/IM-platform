from pathlib import Path
p=Path('H:/.codex/worktrees/err/IM-platform/spec/tasks/review/LOOP1-ERROR-HANDLING-001.md');s=p.read_text();a=s.index('# Handoff\n');b=s.index('# Next Action\n',a);s=s[:a]+'''# Handoff

Current recovery actor /root/recover_wss_desktop_fix_finish; exact assigned root H:/.codex/worktrees/err/IM-platform; branch task/LOOP1-ERROR-HANDLING-001. Final four-source repairs and185/318(283 executable35 nonexecutable)/65 exact current inputs are in spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-android-wss-cleanup/handoff.md. Last accepted main35bd6f5; final task SHA/clean Acceptance/Recorder/lease release comes from external final receipt. Main782unknown/two tracked edits untouched. Taskreview/S2OPEN; both NEW finalSHA reviews/hosted/integration/main/sync PENDING. Local proof is not acceptance.

Historical candidate-specific implementation/fix records below retain their original scope/counts and do not override this current recovery handoff or current.md. Earlier local/native outputs only qualify where exact unchanged input graphs are explicitly rebound. Current support did not complete whole185 semantic acceptance; final independent regular and specialist each cover entire current scope.

'''+s[b:];p.write_text(s,encoding='utf8',newline='\n')
