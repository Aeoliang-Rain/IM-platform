from pathlib import Path
import json,hashlib,subprocess,zipfile
R=Path('H:/.codex/worktrees/err/IM-platform');E=Path(__file__).parent;F=R/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-android-wss-cleanup'
def sha(b):return hashlib.sha256(b).hexdigest()
def js(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
rows=[]
for directory,runid,old in [(E.parent/'fix-android-wss-cleanup','R-FIX-ANDROID-WSS',True),(E,'R-RECOVER-WSS-DESKTOP-FINISH',False)]:
 run=directory/'research/runs'/runid;ev=[json.loads(x) for x in (run/'events.jsonl').read_text().splitlines()];starts={x['data']['command_id']:x for x in ev if x['event_type']=='command_started'};done=set()
 for x in ev:
  if x['event_type']!='command_finished':continue
  d=x['data'];cid=d['command_id'];done.add(cid);item=dict(run_id=runid,command_id=cid,started=starts[cid],finished=x)
  for key in ['stdout_blob','stderr_blob']:
   b=(run/d[key]).read_bytes();item[key+'_stored_redacted_sha256']=sha(b);item[key+'_raw_output_sha256']=d[key.replace('_blob','_sha256')]
   if old:item[key+'_durable']='partial-original-research.zip::runs/'+runid+'/'+d[key]
   else:
    out=F/'recovery-recorded-output'/Path(d[key]).name;out.parent.mkdir(exist_ok=True);out.write_bytes(b);item[key+'_durable']=out.relative_to(R).as_posix()
  rows.append(item)
 rows.append(dict(run_id=runid,snapshot_sequence=ev[-1]['seq'],unfinished_command_ids=sorted(set(starts)-done),status='PARTIAL_INTERRUPTED_NEVER_FINISHED' if old else 'SNAPSHOT_BEFORE_CURRENT_COLLECTOR_FINISH_FINAL_EXTERNAL_RECEIPT_WILL_BIND_COMPLETE_RUN',facts='No outcome inferred for genuinely missing old children. Current collector command is still running at snapshot; final external raw stream contains its real finish.'))
js(F/'recovery-command-history.json',dict(trace_limits='prospective_resume incomplete direct startup/main then assigned-root reread, direct tool-only read and external script preparation gaps. Principal mutations/tests/verifiers recorded. Stored redacted blob SHA differs from original raw hash where redaction applied. Recorder structural validity is not complete trace or product acceptance.',runs=rows))
# Bind runtime proof scope precisely: old Send/Sync do not consume Auth.refresh; current original errors and focused refresh freshly execute.
initial=json.loads((E/'initial-owned-bytes.json').read_text());paths=[]
for pattern in ['clients/mobile/app/src/main/kotlin/im/platform/client/send/*.kt','clients/mobile/app/src/main/kotlin/im/platform/client/sync/*.kt','clients/mobile/app/src/androidTest/kotlin/im/platform/client/send/*.kt','clients/mobile/app/src/androidTest/kotlin/im/platform/client/sync/*.kt']:
 for p in R.glob(pattern):
  rel=p.relative_to(R).as_posix();b=p.read_bytes()
  if rel in initial:assert sha(b)==initial[rel]
  else:assert b==subprocess.check_output(['git','show','8f5f2b4275652d8e3fdff343d6a286ac805ad14a:'+rel],cwd=R)
  paths.append(dict(path=rel,sha256=sha(b),relation='Same bytes as prior recorded runtime input; protected source graphs remain unchanged'))
old=E.parent/'fix-android-wss-cleanup';controls={}
for name in ['send-mobile.actual-output.txt','mobile.actual-output.txt','original-errors.actual-output.txt','runtime-cleanup.json']:
 b=(old/name).read_bytes();controls[name]=dict(sha256=sha(b),path=str(old/name));assert b
assert (R/'clients/mobile/app/src/androidTest/kotlin/im/platform/client/send/WssCleanupInstrumentation.kt').read_text().startswith((old/'Checks.kt').read_text())
js(F/'runtime-source-bindings.json',dict(current_production_hashes={p:sha((R/p).read_bytes()) for p in ['clients/desktop/src/application/ui/auth.ts','clients/desktop/src/application/ui/workspace.ts','clients/mobile/app/src/main/kotlin/im/platform/client/send/Wss.kt','clients/mobile/app/src/main/kotlin/im/platform/client/ui/Auth.kt']},unchanged_send_sync_inputs=paths,prior_API34_runtime_outputs=controls,reuse_qualification='Prior emulator5600 Send66+Read21/Sync69+Read33+contiguous18 are historical actual runtime observations on unchanged responsibility graphs; no new Go durable ACK proof. Auth refresh changed now: JVM5 and actual API34 emulator5610 Preferences5 and originalErrors+Http32+WSS21 run fresh. WSS current JVM21 fresh too. Current recovery outputs and exact argv/exits are in recovery-command-history and final external stream.'))
print('Accurate old partial+new command histories exported; unchanged native graph reuse qualified by exact bytes')
