from pathlib import Path
import json
S=Path(__file__).parent.parent/'recover-remaining-error-support'
for x in json.loads((S/'android-ground-addendum.json').read_text()):print(json.dumps(x,ensure_ascii=False))
print((S/'support-status.md').read_text())
print((S/'support-receipt.json').read_text())
