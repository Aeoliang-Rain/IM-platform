from pathlib import Path
import json,zipfile,hashlib
R=Path('H:/.codex/worktrees/err/IM-platform');E=Path(__file__).parent;F=R/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-android-wss-cleanup'
h='''# Recovered WSS/Desktop/Android lifecycle Fix candidate — local evidence

Sole Fix actor /root/recover_wss_desktop_fix_finish, fresh recovery of interrupted /root/fix_android_wss_cleanup. Exact assigned and Git-resolved root H:/.codex/worktrees/err/IM-platform; branch task/LOOP1-ERROR-HANDLING-001; pre-fix8f5f2b4275652d8e3fdff343d6a286ac805ad14a. Current Task review/S2 OPEN. Last accepted main35bd6f5f1091503f95a0282f730ed04233b0b6ea. Final committed SHA/clean Acceptance/Recorder structural result/sourcelease RELEASED are bound by final external receipt, not by self-acceptance. No push/PR/CI/integration/main write or sync here.

## Current scope and behavior

Exactly four production files differ from8f5: mobile/send/Wss.kt, desktop/application/ui/auth.ts and workspace.ts, mobile/ui/Auth.kt. Other181 of185 current production inputs are byte-identical. No new dependency/framework/error category, logging/retry platform, contract/schema/ACK/security/compatibility/Frozen/ADR change. Preferences implementation, Repository/SQL/init/transactions/native database/SQLite writes/Composer/drafts remain untouched. Protected65 are byte-identical8f5:63 whole accepted baseline plus two prior Human contiguous READ mapper exceptions; exact SQL/all other Repository bytes unchanged.

Fresh independent regular8f5 FAIL F-WSS-CLEANUP-ROOT-REPLACEMENT[P1]/F-WSS-RETAINED-GROUND-MISMATCH[P2] is preserved. Current WSS used finally close then ended, replacing operation primary with unknown close and skipping ended. Actual Throwable retention now preserves distinct operation/retirement/ended roots with standard fresh IllegalStateException(cause=primary,suppressed=cleanup); original graphs are not mutated. Single unknown/same root keeps identity. Synchronized private retireSocket detaches ownership before one close; public close retains only actual known IOException retirement. Finally always attempts ended. IO-only external transport still retires normally; opened/message observer IO is outside transport recovery and fails. Local retain and socket detachment address three actual current lifecycle sites and caller-close cancellation; no speculative factory/runtime.

Read-only support immutable8f5 confirmed Desktop logout Promise.all early known rejection masks later unknown secure removal, and parallel Workspace actual Repository reads mask later unknown siblings. Both current operations use standard allSettled, wait existing work, deduplicate identical roots, preserve single identity or AggregateError. Workspace failure accepts only nonempty all-known existing boundary types; mixed/unknown/empty aggregate rejects even when retired. Known-only still shows honest unavailable failure. No blanket Promise conversion or generic classifier.

Desktop refresh canonical session_expired followed by credential_remove failure lost primary. Current literal clear catch retains distinct primary/cleanup AggregateError and same-root identity. Workspace only original top-level ApiFailure triggers existing expiry action; known aggregate shows unavailable and adds no cleanup retry. Falsy primitive0/null/undefined remain roots.

Fresh support F-ANDROID-REFRESH-CLEANUP-ROOT[P2] independently reproduced actual request401/Wire session_expired then Preferences.remove commit=false IOException or unknown cleanup replacing primary. Root authorized current allowed Auth.refresh boundary before source edits. Successful clear retains exact ApiFailure and both pointer removals. Distinct roots use standard cause/suppressed without mutating originals. IO-only credential cleanup remains standard IOException, preserving existing Workspace known unavailable handling without re-expiry; unknown/Error/mixed cleanup uses ordinary IllegalStateException and propagates. No network-category borrowing, new category, Prefs change or retry. Same-root guard rethrows original.

## Verification and runtime limits

Fresh exact-source strict Desktop compilation PASS, focused literal IPC/current Workspace37 controls PASS, original Auth/workspace/appearance/native/UTF8/account retirement controls PASS. Node uses actual production compilation; link stub only forwards literal Tauri IPC, no live private credential or SQLite operations. Historical SQLx/TLS/Desktop/Go results belong to earlier unchanged responsibility graphs and are not newly observed here.

Fresh current WSS JVM21 PASS. Fresh Android Auth/Wire JVM5 PASS: normal cleanup/known IO/unknown/Error/IO-with-suppressed-unknown. One initial host fixture compile failed because its Preferences linking stub accepted Exception instead of Throwable; only the host link signature was corrected. Not product runtime incidence.

Actual exclusively owned Android API34 emulator5610: final native compile and RefreshCleanupInstrumentation5 PASS. It executes current Auth.request HTTP401/refresh/clear and actual Preferences encrypted write/read/remove. Actual SharedPreferences.commit=false exercises production IOException; controlled Editor runtime exception/Error exercise unknown roots. Normal removes two pointers and retains primary; non-expiry fails without cleanup. No real network/TLS/commit-failure incidence claim. Process URL handler belongs only to disposable instrumentation. Focused JVM additionally covers direct mixed IOException roots without Java proxy checked-exception wrapping. Original ErrorHandlingInstrumentation fresh PASS, HttpCleanupChecks32 and WssCleanupChecks21 PASS on same current source. All old assertions retained.

Old actual API34 emulator5600 Send66+Read21, Sync69+Read33+contiguous18 PASS are reused only after unchanged Send/Sync source/test graph byte checks. These graphs do not consume Auth.refresh; current changed Auth controls run fresh. runtime-source-bindings.json records exact hashes/qualification. Original native controls use owned verified TLS fixtures and unchanged default-trust negative controls, not Go durable ACK or full three-end GUI acceptance. No visual/layout change or new screenshot claim.

Own emulator5610/reverse rules/AVD and generated build outputs cleaned or preserved externally; only adb daemon proved created by this run stopped. Exact verified H-only AVD deletion recorded in recovery-runtime-cleanup.json. Prior5600 cleanup remains runtime-cleanup.json unchanged. No private device/app data/global trust/ACL or main work touched. Read-only process inventory found only our query/Recorder command lines, no surviving old worker; no process killed outside own emulator.

## Binding and preserved evidence

185 current production hashes,318 distinct ordinal/path/ID navigation=283 executable35 nonexecutable, never318 catches. Original duplicate RH294 identities remain distinct. 311 prior identities+2 WSS catches+3 Desktop parallel/projection entries+Desktop refresh catch+Android refresh catch. All exact tokens/source hashes/coordinates verified. Android RH176 is absent refresh credential before request; RH177 is repaired lifecycle catch, not copied old defect text. Other35 Desktop/Java and68 Android support ground suggestions rejudged against actual source with corrected fault→authority→outcome. Local input binding is not complete independent semantic acceptance.

All80 original regular8f5 sealed artifacts+receipt remain exact in regular-review-8f5-originals.zip and external original directory. Original full diff50,594,724 bytes preserved, not regenerated/nested again. Archive GitOID plus each ZIP entry SHA proves reconstructability; entries are not individually claimed Git blobs. Desktop support mini/addendum and Android refresh/remaining support sealed originals are archived byte-exact. remaining-support-seals.json records whole_scope_semantic_complete=false: support185 hash/311 old coordinates and133 historical public FILE markers do not prove full185 semantic coverage. No other confirmed defect; unproved Android logout stop concern is not promoted or used to expand excluded DB scope. Final reviewers must inspect full scope independently.

Interrupted R-FIX-ANDROID-WSS raw research remains running/partial unchanged, archived byte-exact with per-entry seals. Last actual seq117 refresh-bind exit1 is retained; two exact-match typos (=== vs ==) in reconstruction script were corrected only in recovery scripts, first recovery retry also failed on Workspace matcher before successful binding. Old Node WinError2 missing child finish and other unavailable facts remain unavailable. Original AVD disk failures, Gradle environment failure, fixture/account/probe errors remain raw. Old output redaction/raw hash distinctions are preserved.

recovery-command-history.json records actual old/new argv, exits, elapsed time and durable output references. Live collector snapshot cannot include its own finish; complete final stream/clean Acceptance follows external receipt. New run R-RECOVER-WSS-DESKTOP-FINISH prospective_resume parentR-ERROR-INTEGRATION-COORD-20261013 relatedR-FIX-ANDROID-WSS. First direct read accidentally used main recovery files, read-only, then startup restarted on assigned root. Startup truncation/direct read and external script preparation trace gaps disclosed; no complete trace/hidden facts claimed. Recorder structural validity is not Task/Gate PASS.

## Next exact action

Final frozen/PDF/architectureall/planning/82 architecture tests(one existing Windows skip)/Development results and clean committed Acceptance/postclean are bound in final history/external receipt. Coordinator must dispatch NEW fresh full regular185/318/65 on final clean SHA, then DIFFERENT NEW specialized audit SAME SHA. Any Fix repeats both. Both PASS permits exact-head actual required hosted CI, protected integration, actual-main verification and safe H:/IM-platform synchronization preserving782 unknown files/two tracked edits. Taskdone/S2PASS/main synchronization remain PENDING. Source lease released only after clean committed final receipt; no stale context is independent reviewer.
'''
(F/'handoff.md').write_text(h,encoding='utf8',newline='\n')
p=R/'spec/tasks/review/LOOP1-ERROR-HANDLING-001.md';s=p.read_text();s=s.replace('owner: fresh Fix Agent /root/fix_android_wss_cleanup','owner: fresh recovery Fix Agent /root/recover_wss_desktop_fix_finish');marker='# Fresh regular8f5 FAIL and WSS lifecycle Fix (2026-10-14)';assert marker in s;s=s[:s.index(marker)]+h.replace('# Recovered WSS/Desktop/Android lifecycle Fix candidate — local evidence','# Recovered final local Fix candidate (2026-10-15)',1);p.write_text(s,encoding='utf8',newline='\n')
current='''# Current Execution State

Current Loop: Loop 1
Current Stage: S2
Current Gate: S2
Gate Status: OPEN
Current Batch: LOOP1-ERROR-HANDLING-001
Batch Status: REVIEW_PENDING
Current Task: LOOP1-ERROR-HANDLING-001
Current Task State: review
Execution Status: AWAITING_NEW_FINAL_SHA_REGULAR_REVIEW_AND_SPECIALIZED_AUDIT

## Immediately Relevant Completed Work

Recovered interrupted WSS Fix; completed confirmed Desktop parallel/refresh and Android refresh cleanup root repairs. Four production files only. 185 current hashes/318 navigation(283 executable,35 nonexecutable)/65 protected byte checks. Local evidence is not acceptance. Full history/limits: spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-android-wss-cleanup/handoff.md.

## Current Blockers

NEW full regular finalSHA then DIFFERENT NEW specialized SAMEfinalSHA PENDING. Exact-head hosted CI/protected integration/actual-main/safe sync PENDING. No push/CI-triggering PR before both final reviews PASS. Support sealed, no extra confirmed defect; support whole185 semantic review incomplete and cannot replace either final review.

## Verification

- Command: `python -Xutf8 -B tools/verify_frozen_architecture.py`; `python -Xutf8 -B ci/check_architecture.py --scope all --json`; `python -Xutf8 -B ci/check_s2_planning.py`; `python -Xutf8 -B -m unittest discover -s tests/architecture -v`.
  - Result: fresh minimum baseline PASS,82 tests/one existing Windows skip; final checks and clean committed Acceptance/postclean bound by external final receipt.
  - Evidence: `spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-android-wss-cleanup/recovery-command-history.json`.
- Command: `pwsh -NoProfile -File tools/verify-loop1-ctrl-002.ps1 -Mode Development`; committed clean `-Mode Acceptance`.
  - Result: actual final results follow same history/external receipt; local verification never independent acceptance.
  - Evidence: `spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-android-wss-cleanup/handoff.md`.
- Fresh strict Desktop compile, focused37 and originalAuth/workspace controls PASS; current WSS JVM21 PASS; Android refresh JVM5 and actual API34 emulator5610 actualPreferences5 PASS; originalErrors+Http32+WSS21 fresh PASS. Prior unchanged Send66+Read21/Sync69+Read33+contiguous18 are qualified historical runtime reuse with exact source graph hashes, not new runs.

## Changed Files or Migrations

Four production files relative8f5: Desktop auth.ts/workspace.ts; Mobile send/Wss.kt and ui/Auth.kt. Necessary focused tests/evidence/recovery metadata only. Other181 production inputs unchanged. 65 protected exact8f5 (63 whole baseline+two earlier Human contiguous READ mapper exceptions with identical SQL/all other Repository bytes). No Preferences/storage/SQL/writes/drafts/Composer/schema/contracts/Frozen/ADR/dependency/security/ACK change.

## Known Failures, Risks, and Assumptions

Old R-FIX-ANDROID-WSS partial raw unchanged; last seq117 refresh-bind exit1, never final PASS. Recovery exact reconstruction retry failed then corrected; host fixture Throwable signature failed then corrected. All failures/raw redaction distinctions retained. Prospective-resume direct startup/read/preparation gaps disclosed. Controlled cleanup producers prove current boundary semantics, not default-provider incidence. Support185 hash/311 old coordinates/133 historical read markers is not full semantic acceptance. Human-deferred social case unexecuted/notcanonicalPASS. Prior runtime failures retained, no weakened assertion.

## Next Exact Action

Coordinator receives clean committed branch SHA/sealedreceipt/sourcelease RELEASED. NEW full fresh regular185/318/65 -> DIFFERENT NEW specialized SAMEfinalSHA. Any Fix repeats both. Both PASS then exact-head required hostedCI/protectedintegration/actual-main/safe main synchronization. Taskdone/S2PASS/sync/main acceptance PENDING.

## Last Known Good Commit

`35bd6f5f1091503f95a0282f730ed04233b0b6ea` accepted I18N/main. Task candidate is exact committed Git HEAD in final external receipt; candidate commit is not main acceptance or sync.

## Latest Checkpoint

`spec/progress/checkpoints/2026-10-14-error-handling-wss-cleanup-review-candidate.md` updated recovery2026-10-15; local recoverable candidate only.

## Uncommitted Changes / Ownership

Sole /root/recover_wss_desktop_fix_finish owns exact enumerated assigned task delta until clean commit/released receipt. Root H:/.codex/worktrees/err/IM-platform, branch task/LOOP1-ERROR-HANDLING-001. Main H:/IM-platform782 unknown/two tracked edits untouched. Own5610/reverse/AVD/build leases released; prior5600 cleanup preserved. No private device/globaltrust/ACL/main write.

## Architecture Conflicts / ACP / ADR

None. Current standard lifecycle/root retention uses existing authorized Kotlin/TypeScript and accepted canonical/ADR9 authority. Both final reviews/CI/integration/main/sync PENDING; S2 OPEN.
'''
(R/'spec/progress/current.md').write_text(current,encoding='utf8',newline='\n')
(R/'spec/progress/checkpoints/2026-10-14-error-handling-wss-cleanup-review-candidate.md').write_text('''# Error handling recoverable local candidate (updated 2026-10-15)

Task LOOP1-ERROR-HANDLING-001 review; S1 accepted/S2 OPEN. Assigned H:/.codex/worktrees/err/IM-platform task/LOOP1-ERROR-HANDLING-001; pre-fix8f5f2b4275652d8e3fdff343d6a286ac805ad14a; last accepted main35bd6f5f1091503f95a0282f730ed04233b0b6ea. Exact final task SHA/clean state in external final receipt, not independent acceptance/main sync.

Four production repairs: WSS operation/retirement/ended roots and observer boundary; Desktop parallel logout/history and refresh cleanup roots; Android refresh secure cleanup roots.185 hashes/318 navigation(283 executable,35 nonexecutable)/65protected exact. No migrations/contracts/Frozen/ADR/dependencies/security/ACK/storage-writes/drafts change. Existing schema/fixture versions retained.

Fresh strictDesktop37+originalAuth, WSSJVM21, AndroidrefreshJVM5/API34actualPreferences5 and originalErrors/Http32/WSS21 local PASS. Historical unchanged Send/Sync runtime only qualified by exact graph hashes. Run history/old partial/sealed FAIL/native cleanup in fix-android-wss-cleanup/handoff.md and recovery-command-history.json. Support is incomplete full semantic review, not acceptance.

NEW full regular then DIFFERENT NEW specialized SAMEfinalSHA pending; both PASS before hostedCI/protectedintegration/actual-main/safeH:/IM-platformsync. Main782unknown/two tracked edits untouched. Own emulator5610/AVD/reverse/newadb/build leases released. Sourcelease released only by clean final receipt. No Taskdone or S2 Gate PASS.
''',encoding='utf8',newline='\n')
print('Current task/current/checkpoint rewritten accurately for four files,185/318/65 and incomplete support; no self acceptance')
