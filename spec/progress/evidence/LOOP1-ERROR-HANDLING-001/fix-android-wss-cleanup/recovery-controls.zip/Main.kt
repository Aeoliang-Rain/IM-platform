fun main(){println("WSS-RESULT="+im.platform.client.send.WssCleanupChecks.run())}
