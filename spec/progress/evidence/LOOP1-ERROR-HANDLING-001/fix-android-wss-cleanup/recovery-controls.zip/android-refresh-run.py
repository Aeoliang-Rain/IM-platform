from pathlib import Path
import subprocess,json,time
root=Path(__file__).parent;fixture=root/'android-refresh';cache=Path('H:/gradle/caches/modules-2/files-2.1')
def jar(g,n,v):return next((cache/g/n/v).rglob('*.jar'))
std=jar('org.jetbrains.kotlin','kotlin-stdlib','2.1.10');cor=jar('org.jetbrains.kotlinx','kotlinx-coroutines-core-jvm','1.9.0');ann=jar('org.jetbrains','annotations','23.0.0')
compiler=[jar('org.jetbrains.kotlin','kotlin-compiler-embeddable','2.1.10'),std,cor,ann,jar('org.jetbrains.kotlin','kotlin-script-runtime','2.1.10'),jar('org.jetbrains.kotlin','kotlin-reflect','1.6.10'),jar('org.jetbrains.intellij.deps','trove4j','1.0.20200330')]
java='H:/.jdks/jdk17/bin/java.exe';target=fixture/'classes';target.mkdir(exist_ok=True)
commands=[[java,'-cp',';'.join(map(str,compiler)),'org.jetbrains.kotlin.cli.jvm.K2JVMCompiler','-no-stdlib','-no-reflect','-classpath',';'.join(map(str,[std,cor,ann])),'-d',str(target),*map(str,fixture.glob('*.kt'))],[java,'-cp',';'.join(map(str,[target,std,cor,ann])),'MainKt']]
history=[]
for i,cmd in enumerate(commands):
 start=time.monotonic();p=subprocess.run(cmd,capture_output=True);(fixture/f'command-{i}.stdout.txt').write_bytes(p.stdout);(fixture/f'command-{i}.stderr.txt').write_bytes(p.stderr);history.append({'argv':cmd,'exit_code':p.returncode,'elapsed_seconds':time.monotonic()-start});print(p.stdout.decode('utf-8','replace'));print(p.stderr.decode('utf-8','replace'))
 (fixture/'commands.json').write_text(json.dumps(history,indent=2),encoding='utf-8')
 if p.returncode:raise SystemExit(p.returncode)
