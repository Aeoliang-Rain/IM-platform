from pathlib import Path
import subprocess,sys,hashlib,json,time
E=Path(__file__).parent;R=Path('H:/.codex/worktrees/err/IM-platform');cache=Path('H:/gradle/caches/modules-2/files-2.1')
def jar(g,n,v):return next((cache/g/n/v).rglob('*.jar'))
std=jar('org.jetbrains.kotlin','kotlin-stdlib','2.1.10');cor=jar('org.jetbrains.kotlinx','kotlinx-coroutines-core-jvm','1.9.0');ann=jar('org.jetbrains','annotations','23.0.0')
compiler=[jar('org.jetbrains.kotlin','kotlin-compiler-embeddable','2.1.10'),std,cor,ann,jar('org.jetbrains.kotlin','kotlin-script-runtime','2.1.10'),jar('org.jetbrains.kotlin','kotlin-reflect','1.6.10'),jar('org.jetbrains.intellij.deps','trove4j','1.0.20200330')]
java='H:/.jdks/jdk17/bin/java.exe';target=E/'wss-classes';target.mkdir(exist_ok=True)
source=R/'clients/mobile/app/src/main/kotlin/im/platform/client/send/Wss.kt'
print('EXACT PRODUCTION Wss.kt SHA256',hashlib.sha256(source.read_bytes()).hexdigest(),flush=True)
commands=[[java,'-cp',';'.join(map(str,compiler)),'org.jetbrains.kotlin.cli.jvm.K2JVMCompiler','-no-stdlib','-no-reflect','-classpath',';'.join(map(str,[std,cor,ann])),'-d',str(target),str(source),str(E/'Checks.kt'),str(E/'Main.kt')],[java,'-cp',';'.join(map(str,[target,std,cor,ann])),'MainKt']]
for c in commands:
 t=time.monotonic();p=subprocess.run(c);print('EXIT',p.returncode,'SECONDS',time.monotonic()-t,flush=True)
 if p.returncode:sys.exit(p.returncode)
