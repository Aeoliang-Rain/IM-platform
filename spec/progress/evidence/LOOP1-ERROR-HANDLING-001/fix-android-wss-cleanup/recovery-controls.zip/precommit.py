from pathlib import Path
import json,hashlib,subprocess,zipfile,shutil
R=Path('H:/.codex/worktrees/err/IM-platform');E=Path(__file__).parent;D=R/'spec/progress/evidence/LOOP1-ERROR-HANDLING-001';F=D/'fix-android-wss-cleanup';B='8f5f2b4275652d8e3fdff343d6a286ac805ad14a'
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):return subprocess.check_output(['git','-c','core.autocrlf=false','-c','core.excludesFile=.git/info/exclude',*args],cwd=R)
def js(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8',newline='\n')
assert Path(git('rev-parse','--show-toplevel').decode().strip()).resolve()==R.resolve();assert git('rev-parse','HEAD').decode().strip()==B
checks=json.loads((E/'final-effective-checks.json').read_text());assert len(checks)==5 and all(x['exit']==0 for x in checks)
inv=json.loads((D/'production-inventory.json').read_text());nav=json.loads((F/'current-navigation.json').read_text());assert len(inv['files'])==185 and len(nav['records'])==318 and nav['counts']==dict(records=318,executable=283,nonexecutable=35)
for x in inv['files']:assert sha((R/x['path']).read_bytes())==x['sha256'],x['path']
for x in nav['records']:
 b=(R/x['path']).read_bytes();assert sha(b)==x['source_sha256'];assert b.decode().splitlines()[x.get('current_line',x['line'])-1][x.get('current_column',x['column'])-1:].startswith(x['token']),x['composite_identity']
protected=json.loads((F/'protected-inputs.json').read_text())['files'];assert len(protected)==65
for x in protected:assert sha((R/x['path']).read_bytes())==x['sha256'];assert (R/x['path']).read_bytes()==git('show',B+':'+x['path'])
expected=set(inv['fix_android_wss_cleanup']['production_delta']);actual={x['path'] for x in inv['files'] if (R/x['path']).read_bytes()!=git('show',B+':'+x['path'])};assert len(expected)==4 and actual==expected
for entry in [json.loads((F/'prior-review-seals.json').read_text())]:
 with zipfile.ZipFile(F/'regular-review-8f5-originals.zip') as z:
  for x in entry['artifacts']:assert sha(z.read(x['path']))==x['sha256']
  assert sha(z.read('final-receipt.json'))==entry['receipt_sha256']
for archive,manifest,field in [('remaining-support-originals.zip','remaining-support-seals.json','files')]:
 with zipfile.ZipFile(F/archive) as z:
  for p,h in json.loads((F/manifest).read_text())[field].items():assert sha(z.read(p))==h
old=json.loads((F/'partial-original-research-seals.json').read_text())
with zipfile.ZipFile(F/'partial-original-research.zip') as z:
 for p,h in old['entries'].items():assert sha(z.read(p))==h
assert json.loads((F/'recovery-runtime-cleanup.json').read_text())['own_new_adb_daemon_stopped']
for name in ['RefreshCleanupInstrumentation.output.txt','ErrorHandlingInstrumentation.output.txt']:
 text=(E/name).read_text();assert 'result=PASS' in text and 'sdkInt=34' in text
 out=F/'recovery-native-output'/name;out.parent.mkdir(exist_ok=True);out.write_bytes((E/name).read_bytes())
controls={}
with zipfile.ZipFile(F/'recovery-controls.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(list(E.glob('*.py'))+list((E/'android-refresh').glob('*.kt'))+[E/'Checks.kt',E/'Main.kt',E/'tsconfig.json']):
  b=p.read_bytes();name=p.relative_to(E).as_posix();z.writestr(name,b);controls[name]=sha(b)
js(F/'recovery-controls-seals.json',dict(entries=controls,archive_sha256=sha((F/'recovery-controls.zip').read_bytes()),method='Public reproduction/setup/verification scripts and exact JVM linking inputs. No build output/private data; Recorder raw remains separate.'))
js(F/'recovery-local-checks.json',dict(candidate_binding='Final task HEAD via external final receipt after clean commit',baseline=B,final_checks=checks,production_inputs=185,navigation=nav['counts'],protected_inputs=65,production_delta=sorted(actual),frozen_unchanged=True,old80_reconstruction_verified=True,current_native_refresh=5,current_native_HttpCleanup=32,current_native_WssCleanup=21,current_JVM_Wss=21,current_JVM_refresh=5,current_Desktop_focused=37,independent_regular='PENDING',independent_specialized='PENDING',CI_main_sync='PENDING'))
# Only exact approved owned paths may stage; no wildcard staging or unknown source adoption.
paths=set(git('ls-files','-m','-o','--exclude-standard','-z').decode().split('\0'))-{''}
exact=expected|{'clients/mobile/app/src/androidTest/kotlin/im/platform/client/ui/ErrorHandlingInstrumentation.kt','clients/mobile/app/src/androidTest/kotlin/im/platform/client/ui/RefreshCleanupInstrumentation.kt','clients/mobile/app/src/androidTest/kotlin/im/platform/client/send/WssCleanupInstrumentation.kt','tests/clients/errors/desktop_parallel.mjs','spec/progress/current.md','spec/progress/evidence/LOOP1-ERROR-HANDLING-001/production-inventory.json','spec/tasks/review/LOOP1-ERROR-HANDLING-001.md','spec/progress/checkpoints/2026-10-14-error-handling-wss-cleanup-review-candidate.md'}
for p in paths:assert p in exact or p.startswith('spec/progress/evidence/LOOP1-ERROR-HANDLING-001/fix-android-wss-cleanup/'),p
subprocess.run(['git','-c','core.autocrlf=false','diff','--check'],cwd=R,check=True)
(E/'owned-pathspec.nul').write_bytes(b'\0'.join((':(literal)'+p).encode() for p in sorted(paths))+b'\0');js(E/'precommit-owned.json',dict(paths={p:sha((R/p).read_bytes()) for p in sorted(paths)},production_delta=sorted(actual),checks=checks))
print('Final local checks PASS; exact owned stage list',len(paths),'paths;185/318/65; main untouched')


