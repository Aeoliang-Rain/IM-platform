from pathlib import Path
import json
R=Path('H:/.codex/worktrees/err/IM-platform');S=Path(__file__).parent.parent/'recover-remaining-error-support';cs=json.loads((S/'android-ground-addendum.json').read_text());print('COUNT',len(cs))
for c in cs:print(c['composite_identity'],c['specific_fault'],'->',c['actual_recovery_or_failure'])
for rel in ['clients/mobile/app/src/main/kotlin/im/platform/client/ui/WorkspaceViewModel.kt','clients/mobile/app/src/main/kotlin/im/platform/client/ui/components/Messages.kt','clients/mobile/app/src/main/kotlin/im/platform/client/ui/components/Friends.kt']:print(rel,(R/rel).read_text())
